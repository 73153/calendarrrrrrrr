//
//  ConfirmPasswordViewController.h
//  Plan It Sync It
//
//  Created by apple on 15/04/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ConfirmPasswordViewController.h"
#import "CustomKeyboard.h"
@interface ConfirmPasswordViewController : UIViewController<UITextFieldDelegate,CustomKeyboardDelegate>
{
    CustomKeyboard *customKeyboard;
}
@property (nonatomic, strong) IBOutlet UITextField *txtPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtConfirmPassword;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSubmit;

@property (nonatomic, retain) UITabBarController *tabcontroller;
- (IBAction)btnBackClicked:(id)sender;

- (IBAction)submitButtonClicked:(id)sender;
- (void) passwordMatchSuccess:(NSNotification *)notification;
- (void) passwordMatchFailed:(NSNotification *)notification;
- (void) showProgressHud;
- (void) hideProgressHud;
-(void)responseSuccessMessage;
@end

