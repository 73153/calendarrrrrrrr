//
//  MobileVerificationViewController.m
//  Plan It Sync It
//
//  Created by apple on 15/04/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import "AppConstant.h"
#import "WebService.h"
#import "MobileVerificationViewController.h"
#import "REFrostedViewController.h"
#import "TabBarController.h"
#import "ConfirmPassWordViewController.h"
#import "MBProgressHUD.h"
#import "UIView+Toast.h"

@interface MobileVerificationViewController()

@end

@implementation MobileVerificationViewController

@synthesize txtMobileVerificationNumber;
@synthesize roundedBtnSubmit;
- (void)viewDidLoad{
    [super viewDidLoad];
    [self hideProgressHud];
    [self setTitle:@"Mobile Verification"];
    
//    int height = self.navigationController.navigationBar.frame.size.height;
//    int width = self.navigationController.navigationBar.frame.size.width;
//    
//    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
//    [navLabel setText:@"Mobile Verification"];
//    navLabel.textColor = [UIColor whiteColor];
//    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
//    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
//    navLabel.textAlignment = NSTextAlignmentCenter;
//    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
//    roundedBtnSubmit.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnSubmit.layer.borderWidth = 2.0f;
    roundedBtnSubmit.clipsToBounds=YES;
    roundedBtnSubmit.layer.cornerRadius = 5;
    
}
-(void)viewDidAppear:(BOOL)animated
{
    txtMobileVerificationNumber.delegate = self;
    txtMobileVerificationNumber.text=@"";
    [txtMobileVerificationNumber setReturnKeyType:UIReturnKeyDone];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(contactVeifyKeySuccess:) name:kContactVerifyKeySuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(contactVeifyKeyFailed:) name:kContactVerifyKeyFailed object:nil];
}
-(void)viewWillAppear:(BOOL)animated
{
    NSInteger isGotoLogin = [[NSUserDefaults standardUserDefaults] integerForKey:@"IsRegistration"];
    if(isGotoLogin==2)
    {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}
-(void)viewDidUnload
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (IBAction)submitButtonClicked:(id)sender
{
    //    http://dev.planitsyncit.com/app/android/webservices.php?action=verify&verify_key=123mobile=98675675
    [txtMobileVerificationNumber resignFirstResponder];
    if([txtMobileVerificationNumber.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter verification code" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter verification code."];
        
    }
    else{
        [self showProgressHud];
        NSString *mobileNumber = [[NSUserDefaults standardUserDefaults] objectForKey:kUserMobileNumber];
        if(mobileNumber==nil)
        {
            //            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Your mobile number does not exist in Database." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            //            [alert show];
            [self.view makeToast:@"Your mobile number does not exist in Database."];
            
        }
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:txtMobileVerificationNumber.text,@"verify_key",mobileNumber,@"mobile", nil];
        [self showProgressHud];
        [[WebService sharedWebService] callVerifyMobileNumberWebService:dictionary];
        
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if([alertView tag] == 101 && buttonIndex == 0){
        NSInteger forgetPasssValue = [[[NSUserDefaults standardUserDefaults] objectForKey:kForgotPassSuccessVerifyKey] integerValue];
        NSLog(@"forgetPasssValue %ld",(long)forgetPasssValue);
        
        if (forgetPasssValue==1) {
            
   
            ConfirmPasswordViewController *demoController = (ConfirmPasswordViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"confirmPasswordViewControllerID"];
            [self.navigationController pushViewController:demoController animated:YES];
        }
        else{
            [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"IsRegistration"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            TabBarController *demoController = (TabBarController*)[self.storyboard instantiateViewControllerWithIdentifier:@"splitContollerID"];
            [self presentViewController:demoController animated:YES completion:nil];
        }
    }
}

-(void)responseSuccessMessage
{
    NSInteger forgetPasssValue = [[[NSUserDefaults standardUserDefaults] objectForKey:kForgotPassSuccessVerifyKey] integerValue];
    NSLog(@"forgetPasssValue %ld",(long)forgetPasssValue);
    
    if (forgetPasssValue==1) {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"IsForgotPassword"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ConfirmPasswordViewController *demoController = (ConfirmPasswordViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"confirmPasswordViewControllerID"];
        [self.navigationController pushViewController:demoController animated:YES];
        
    }
    else{
        
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"IsRegistration"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        TabBarController *demoController = (TabBarController*)[self.storyboard instantiateViewControllerWithIdentifier:@"splitContollerID"];
        [self presentViewController:demoController animated:YES completion:nil];
    }
    
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void) contactVeifyKeySuccess:(NSNotification *)notification{
    [self hideProgressHud];
    
//    [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"IsLoginAndLogout"];
//    [[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"Data=%@",notification.object);
    
    [[NSUserDefaults standardUserDefaults] setObject:@"RegiteredAndVerifiedEmailId" forKey:@"IsRegiteredAndVerifiedEmailId"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *userProfile = [dictionary objectForKey:@"data"];

    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert setTag:101];
    //    [alert show];
    [self performSelector:@selector(responseSuccessMessage) withObject:self afterDelay:2];
    
}
- (void) contactVeifyKeyFailed:(NSNotification *)notification{
    [self hideProgressHud];
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert show];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtMobileVerificationNumber){
        [txtMobileVerificationNumber resignFirstResponder];
    }
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//hide keyboard
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}


@end
