//
//  LoginViewController.m
//  Plan It Sync It
//
//  Created by apple on 15/04/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import "AppConstant.h"
#import "LoginViewController.h"
#import "ForgotPassWordViewController.h"
//#import "MobileVerificationViewController.h"
#import "RegistrationViewController.h"
#import "WebService.h"
#import "TabBarController.h"
#import "MBProgressHUD.h"
#import "UIView+Toast.h"
#import "MobileVerificationViewController.h"
#import "TextValidator.h"
#import "DateHandler.h"
@interface LoginViewController ()

@end

@implementation LoginViewController

@synthesize txtFieldEmail;
@synthesize txtFieldPassword;
@synthesize btnLogin;
@synthesize btnRegistration;
@synthesize btnForgotPassword;
@synthesize roundedBtnLogin;

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [self setTitle:@""];
    
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Login"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    [self hideProgressHud];
    txtFieldEmail.delegate = self;
    txtFieldPassword.delegate = self;
    
    txtFieldEmail.tag = 1;
    txtFieldPassword.tag = 2;
    
    //Bar color from here changing for.
    NSArray *ver = [[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."];
    if ([[ver objectAtIndex:0] intValue] >= 7) {
        // iOS 7.0 or later
        self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:(34/255.0f) green:(139/255.0f) blue:(34/255.0f) alpha:1];
        self.navigationController.navigationBar.translucent = NO;
    }else {
        // iOS 6.1 or earlier
        self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:(34/255.0f) green:(139/255.0f) blue:(34/255.0f) alpha:1];
    }
    
    //    roundedBtnLogin.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnLogin.layer.borderWidth = 2.0f;
    roundedBtnLogin.clipsToBounds=YES;
    roundedBtnLogin.layer.cornerRadius = 5;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    [txtFieldEmail setReturnKeyType:UIReturnKeyNext];
    [txtFieldPassword setReturnKeyType:UIReturnKeyDone];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSuccess:) name:kLoginSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginFailed:) name:kLoginFailed object:nil];
}

-(void)viewDidUnload
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)viewDidAppear:(BOOL)animated
{
    [self hideProgressHud];
    
    [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"IsRegistration"];
    [[NSUserDefaults  standardUserDefaults]synchronize];
    
    txtFieldPassword.text =@"";
    //    txtFieldEmail.text=@"agc@gmail.com";
    //    txtFieldPassword.text =@"abc123";
    
    //    txtFieldEmail.text=@"keyur@agc1.com";
    //    txtFieldPassword.text =@"keyur@007";
    
//        txtFieldEmail.text=@"bhupat@acquaintsoft.com";
//        txtFieldPassword.text =@"abc123";
    
    txtFieldEmail.text=@"ranapreyas64@gmail.com";
    txtFieldPassword.text =@"agc1234";
    
//   txtFieldEmail.text=@"ajay@acquaintsoft.com";
//   txtFieldPassword.text =@"ajaysudani007";
    
//    txtFieldEmail.text=@"guddi@gmail.com";
//    txtFieldPassword.text =@"abc123";
   
//      txtFieldEmail.text=@"parent1@mailcatch.com";
//       txtFieldPassword.text =@"agc123";
    
    NSString *checkingForVerifiedKey = [[NSUserDefaults standardUserDefaults] valueForKey:@"IsRegiteredAndVerifiedEmailId"];
    if([checkingForVerifiedKey isEqualToString:@"RegiteredAndVerifiedEmailId"])
    {
        
    }
    else if (checkingForVerifiedKey != nil || checkingForVerifiedKey != NULL)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"SMS Verification" message:[NSString stringWithFormat:@"Your registration process for %@ is not yet completed, Do you want to finish registration process for the same?.",checkingForVerifiedKey] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:@"Not Now", nil];
        [alert setTag:102];
        [alert show];
        
    }
}


- (IBAction)loginButtonClicked:(id)sender{
    if ([txtFieldEmail isFirstResponder]) {
        [txtFieldEmail resignFirstResponder];
    }
    else if ([txtFieldPassword isFirstResponder]) {
        [txtFieldPassword resignFirstResponder];
    }
    
    NSString *checkingForVerifiedKey = [[NSUserDefaults standardUserDefaults] valueForKey:@"IsRegiteredAndVerifiedEmailId"];
    
    if ([checkingForVerifiedKey isEqualToString:txtFieldEmail.text] )
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"SMS Verification" message:[NSString stringWithFormat:@"Your registration process for %@ is not yet completed, Do you want to finish registration process for the same?.",checkingForVerifiedKey] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:@"Not Now", nil];
        [alert setTag:102];
        [alert show];
        return;
    }
    
    if([txtFieldEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter email Addess" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter email address."];
        return;
        
    }
    else if ([TextValidator isValidEmail:txtFieldEmail.text]==false)
    {
        [self.view makeToast:@"Please enter valid email address."];
        return;
    }
    else if([txtFieldPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter password."];
        return;
    }
    
    else{
        [self showProgressHud];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:txtFieldEmail.text,kUserName,txtFieldPassword.text,kPassword, nil];
        [[WebService sharedWebService] callLoginWebService:dictionary];
    }
}
- (IBAction)registrationButtonClicked:(id)sender{
    RegistrationViewController* controller = (RegistrationViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"registrationViewControllerID"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)forgotPasswordButtonClicked:(id)sender{
    ForgotPassWordViewController* controller = (ForgotPassWordViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"forgotPassWordViewControllerID"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtFieldEmail){
        [txtFieldEmail resignFirstResponder];
        [txtFieldPassword becomeFirstResponder];
    }
    else if(textField == txtFieldPassword){
        [txtFieldPassword resignFirstResponder];
    }
    return YES;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if([alertView tag] == 101 && buttonIndex == 0){
        TabBarController *demoController = (TabBarController*)[self.storyboard instantiateViewControllerWithIdentifier:@"splitContollerID"];
        [self presentViewController:demoController animated:YES completion:nil];
    }
    if([alertView tag] == 102){
        if (buttonIndex == 0) {
            MobileVerificationViewController* controller = (MobileVerificationViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"mobileVerificationViewControllerID"];
            [self.navigationController pushViewController:controller animated:YES];
        }
    }
}
-(void)responseSuccessMessage
{
    //    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"IsLoginAndLogout"];
    //    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    TabBarController *demoController = (TabBarController*)[self.storyboard instantiateViewControllerWithIdentifier:@"splitContollerID"];
    [self presentViewController:demoController animated:YES completion:nil];
    
}

- (IBAction)btnAboutPressed:(id)sender {
    NSURL *settings = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
    if ([[UIApplication sharedApplication] canOpenURL:settings])
    {
        [[UIApplication sharedApplication] openURL:settings];
    }
}

- (void) loginSuccess:(NSNotification *)notification{
    NSLog(@"Data=%@",notification.object);
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *userProfile = [dictionary objectForKey:@"data"];
    NSDictionary *preferenceDict = [userProfile objectForKey:@"preference"];
    [[NSUserDefaults standardUserDefaults] setObject:[preferenceDict objectForKey:@"name"] forKey:kUserNameInMasterTable];
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%@",[preferenceDict objectForKey:@"default_rsvp_date"]] forKey:kEventRSVPPriorTime];
    
    [[NSUserDefaults standardUserDefaults] setObject:[preferenceDict objectForKey:@"default_time_format"] forKey:KTimeFormat];
    //    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"logged_in"];
    
    
    [[NSUserDefaults standardUserDefaults] setValue:[preferenceDict objectForKey:@"image_path"] forKey:kUserImage];
    
    [[NSUserDefaults standardUserDefaults] setValue:[preferenceDict objectForKey:@"default_color_event"] forKey:kTimeLineColor];

    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSString *strTextFieldCalenederView = [preferenceDict objectForKey:@"default_calendar"];
    if([strTextFieldCalenederView  isEqualToString:@"month"]){
        strTextFieldCalenederView =@"Month";
    }
    else if([strTextFieldCalenederView isEqualToString:@"timeline"]){
        strTextFieldCalenederView = @"Timeline";
    }
    else if([strTextFieldCalenederView isEqualToString:@"week"]){
        strTextFieldCalenederView = @"Week";
    }
    else if([strTextFieldCalenederView isEqualToString:@"day"]){
        strTextFieldCalenederView = @"Day";
    }
    
    [[NSUserDefaults standardUserDefaults] setValue:strTextFieldCalenederView forKey:KRootController];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    NSString *strDateFormat = [preferenceDict objectForKey:@"default_date_format"];
    
    NSString *date1FormatToSend = @"d/m/Y";
    NSString *date2FormatToSend = @"m/d/Y";
    NSString *date3FormatToSend = @"Y/m/d";
    NSString *date4FormatToSend = @"j M Y";
    NSString *date5FormatToSend = @"M j, Y";
    if([date1FormatToSend isEqualToString:strDateFormat])
        [[NSUserDefaults standardUserDefaults] setValue:@"dd/MM/yyyy" forKey:KDateFormat];
    else if([date2FormatToSend isEqualToString:strDateFormat])
        [[NSUserDefaults standardUserDefaults] setValue:@"MM/dd/yyyy" forKey:KDateFormat];
    else if([date3FormatToSend isEqualToString:strDateFormat])
        [[NSUserDefaults standardUserDefaults] setValue:@"yyyy/MM/dd" forKey:KDateFormat];
    else if([date4FormatToSend isEqualToString:strDateFormat])
        [[NSUserDefaults standardUserDefaults] setValue:@"dd MMMM yyyy" forKey:KDateFormat];
    else if([date5FormatToSend isEqualToString:strDateFormat])
        [[NSUserDefaults standardUserDefaults] setValue:@"MMMM dd yyyy" forKey:KDateFormat];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self performSelector:@selector(responseSuccessMessage) withObject:self afterDelay:1.0 ];
}

- (void) loginFailed:(NSNotification *)notification{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSDictionary *responseData = [dictionary objectForKey:@"data"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if([strMessageResponse isEqualToString:@"account_disable"]){
        [[NSUserDefaults standardUserDefaults] setObject:txtFieldEmail.text forKey:@"IsRegiteredAndVerifiedEmailId"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[NSUserDefaults standardUserDefaults] setObject:responseData forKey:kUserMobileNumber];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"SMS Verification" message:[NSString stringWithFormat:@"Your registration process for %@ is not yet completed, Do you want to finish registration process for the same?.",txtFieldEmail.text] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:@"Not Now", nil];
        [alert setTag:102];
        [alert show];
    }else{
        
        if(strMessageResponse.length >=15)
        {
            [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
        }
        else{
            [self.view makeToast:[response objectForKey:@"message"]];
        }
    }
    
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert show];
}


- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 2;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}

- (void)nextClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [txtFieldEmail resignFirstResponder];
            [txtFieldPassword becomeFirstResponder];
        }
            break;
            
        case 2: {
            [txtFieldPassword resignFirstResponder];
        }
            break;
            
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    switch (sender){
            
        case 1: {
            [txtFieldEmail resignFirstResponder];
        }
            break;
            
        case 2: {
            [txtFieldEmail becomeFirstResponder];
            [txtFieldPassword resignFirstResponder];
        }
            break;
            
            
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
    
    switch (sender){
        case 1: {
            if ([txtFieldEmail isFirstResponder]) {
                [txtFieldEmail resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([txtFieldPassword isFirstResponder]) {
                [txtFieldPassword resignFirstResponder];
            }
        }
            break;
            
            
        default: {
        }
            break;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
@end
