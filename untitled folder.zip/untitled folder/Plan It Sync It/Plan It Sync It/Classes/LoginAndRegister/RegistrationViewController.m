//
//  RegistrationViewController.m
//  Plan It Sync It
//
//  Created by apple on 15/04/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import "RegistrationViewController.h"
#import "TextValidator.h"
#import "WebService.h"
#import "MobileVerificationViewController.h"
#import "REFrostedViewController.h"
#import <CoreTelephony/CTCarrier.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import "UIView+Toast.h"
#import "MBProgressHUD.h"
#define MAXLENGTH 11
@interface RegistrationViewController ()
{
    BOOL isAgreeClicked;
    NSString *maleOrFemale;
}
@property (nonatomic, strong) NSArray *codes;
@property (nonatomic, strong) NSDictionary *codeDict;

@end

@implementation RegistrationViewController

@synthesize txtFieldFullName;
@synthesize txtFieldEmailId;
@synthesize txtFieldContactNumber;
@synthesize txtFieldCountryCode;
@synthesize txtPassword;
@synthesize txtConfirmPassword;
@synthesize btnMale;
@synthesize btnFemale;
@synthesize btnSubmit;
@synthesize scrollView;
@synthesize btnAgreeTerms;
@synthesize pickerBackground;
@synthesize datePicker;
@synthesize roundedBtnCreateAccount;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    [self hideProgressHud];
    [self setTitle:@"Registration"];
    
    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"IsRegistration"];
    [[NSUserDefaults standardUserDefaults] synchronize];
//    int height = self.navigationController.navigationBar.frame.size.height;
//    int width = self.navigationController.navigationBar.frame.size.width;
//    
//    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
//    [navLabel setText:@"Registration"];
//    navLabel.textColor = [UIColor whiteColor];
//    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
//    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
//    navLabel.textAlignment = NSTextAlignmentCenter;
//    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
//    roundedBtnCreateAccount.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnCreateAccount.layer.borderWidth = 2.0f;
    roundedBtnCreateAccount.clipsToBounds=YES;
    roundedBtnCreateAccount.layer.cornerRadius = 5;
    
    CTTelephonyNetworkInfo *infoRede = [[CTTelephonyNetworkInfo alloc] init];
    
    CTCarrier *operadora = infoRede.subscriberCellularProvider;
    
    NSString *nomeOperadora = operadora.carrierName;
    NSString *codISOPais = operadora.isoCountryCode;
    NSString *mobileCountryCode = [self getCarrierMobileCountryCode];
    
    // Setup the Network Info and create a CTCarrier object
    CTTelephonyNetworkInfo *netInfo = [[CTTelephonyNetworkInfo alloc] init];
    CTCarrier *carrier = [netInfo subscriberCellularProvider];
    NSString *isocode;
    if (carrier) {
        isocode = [[carrier isoCountryCode] lowercaseString];
    } else {
        NSLocale *locale = [NSLocale currentLocale];
        isocode = [locale objectForKey:NSLocaleCountryCode];
    }
    // Get carrier name
    NSString *carrierName = [carrier carrierName];
    if (carrierName != nil)
        NSLog(@"Carrier: %@", carrierName);
    
    // Get mobile country code
    NSString *mcc = [carrier mobileCountryCode];
    if (mcc != nil)
        NSLog(@"Mobile Country Code (MCC): %@", mcc);
    
    // Get mobile network code
    NSString *mnc = [carrier mobileNetworkCode];
    if (mnc != nil)
        NSLog(@"Mobile Network Code (MNC): %@", mnc);
    
//    [txtFieldFullName setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
//    
//     [txtFieldEmailId setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
//     [txtFieldCountryCode setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
//     [txtPassword setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
//     [txtConfirmPassword setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
//     [txtFieldContactNumber setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];

    [txtFieldFullName setReturnKeyType:UIReturnKeyNext];
    [txtFieldEmailId setReturnKeyType:UIReturnKeyNext];
    [txtFieldCountryCode setReturnKeyType:UIReturnKeyNext];
    [txtPassword setReturnKeyType:UIReturnKeyNext];
    [txtConfirmPassword setReturnKeyType:UIReturnKeyDone];
    [txtFieldContactNumber setReturnKeyType:UIReturnKeyNext];
    isAgreeClicked = false;
    maleOrFemale = @"M";
    txtFieldFullName.tag = 1;
    txtFieldEmailId.tag = 2;
    txtFieldCountryCode.tag = 3;
    txtFieldContactNumber.tag=4;
    txtPassword.tag = 5;
    txtConfirmPassword.tag=6;
    
    txtFieldFullName.delegate = self;
    txtFieldEmailId.delegate = self;
    txtFieldCountryCode.delegate = self;
    txtFieldContactNumber.delegate = self;
    txtPassword.delegate = self;
    txtConfirmPassword.delegate = self;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    // Instantiate the source plist file for country code dictionary
    NSString * plistPath = [[NSBundle mainBundle] pathForResource:@"CountryCode" ofType:@"plist"];
    self.codeDict = [NSDictionary dictionaryWithContentsOfFile:plistPath];
    
    // Moving all keys into an array and filter it with NSPredicate
    self.codes = [self.codeDict allKeys];
    NSLog(@"self.codes %@",self.codes);
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF matches[cd] %@", isocode];
    self.codes = [self.codes filteredArrayUsingPredicate:predicate];
    
    isocode = [isocode lowercaseString];
    
    NSString *str = [self.codeDict valueForKey:isocode];
    
    NSLog(@"self.codes %@",self.codes);
    if (mcc != nil)
        self.txtFieldCountryCode.text = [NSString stringWithFormat:@"+%@", str];
    else
        self.txtFieldCountryCode.text=@"+91";
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1000)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1300)];
    }
    txtFieldFullName.autocapitalizationType = UITextAutocapitalizationTypeWords;
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(registrationSuccess:) name:kRegisrationSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(registrationFailed:) name:kRegisrationFailed object:nil];
}

-(NSString*)getCarrierMobileCountryCode {
    CTTelephonyNetworkInfo *netinfo = [[CTTelephonyNetworkInfo alloc] init];
    
    if (netinfo == nil){
        return @"";
    }
    
    CTCarrier *carrier = [netinfo subscriberCellularProvider];
    if (carrier == nil){
        return @"";
    }
    
    NSString *result = [carrier mobileCountryCode];
    if (result == nil){
        return @"";
    }
    
    return result;
}


-(void)viewDidUnload
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (IBAction)onLoginPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}
- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)toggleRadioButton:(id)sender{
    if([sender tag] == 101){
        maleOrFemale = @"M";
        [btnMale setBackgroundImage:nil forState:UIControlStateNormal];
        [btnFemale setBackgroundImage:nil forState:UIControlStateNormal];
        
        [btnMale setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
        [btnFemale setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    }
    else{
        maleOrFemale = @"F";
        [btnFemale setBackgroundImage:nil forState:UIControlStateNormal];
        [btnMale setBackgroundImage:nil forState:UIControlStateNormal];
        
        
        [btnFemale setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
        [btnMale setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    }
    
}
- (IBAction)submitButtonClicked:(id)sender{
    if ([txtFieldFullName isFirstResponder]) {
        [txtFieldFullName resignFirstResponder];
    }
    else if ([txtFieldEmailId isFirstResponder]) {
        [txtFieldEmailId resignFirstResponder];
    }
    else if ([txtFieldCountryCode isFirstResponder]) {
        [txtFieldCountryCode resignFirstResponder];
    }
    else if ([txtFieldContactNumber isFirstResponder]) {
        [txtFieldContactNumber resignFirstResponder];
    }
    else if ([txtPassword isFirstResponder]) {
        
        [txtPassword resignFirstResponder];
    }
    else if ([txtConfirmPassword isFirstResponder]) {
        [txtConfirmPassword resignFirstResponder];
    }
    
    
    CTTelephonyNetworkInfo *info = [CTTelephonyNetworkInfo new];
    CTCarrier *carrier = info.subscriberCellularProvider;
    
    if([TextValidator isValidName:txtFieldFullName.text]==false){
        
        //        [self.view makeToast:@"New item added successfully" duration:2.0f position:[NSValue valueWithCGPoint:toastPos]];
        //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter correct full name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //                [alert show];
        
        [self.view makeToast:@"Please enter full name"];
        return;
        
    }
    
    else if([TextValidator isValidEmail:txtFieldEmailId.text]==false){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter correct email addess" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter correct e-mail address"];
        return;
        
    }
    else if([txtFieldCountryCode.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter confirm password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter country code"];
        return;
        
    }
    else if(txtFieldContactNumber.text.length ==0){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter correct contact number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter mobile number"];
        return;
    }
    
    else if(txtFieldContactNumber.text.length > 11 || txtFieldContactNumber.text.length < 10){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter correct contact number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Mobile number should be at least of 10 digits"];
        return;
        
    }
    
    
    else if([txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter password"];
        return;
        
    }
    else if([txtConfirmPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter confirm password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter confirm password"];
        return;
        
    }
    
    else if(![txtPassword.text isEqualToString:txtConfirmPassword.text]){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Password should match with confirm password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Password should match with confirm password"];
        return;
        
    }
    
    else if (txtPassword.text.length <= 6){
        // allow only alphanumeric chars
        
        NSCharacterSet *upperlowerCaseChars = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLKMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"];
        //lowerCaseChars = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyz"];
        
        NSCharacterSet *numbers = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        if ([txtConfirmPassword.text rangeOfCharacterFromSet:upperlowerCaseChars].location != NSNotFound &&  [txtConfirmPassword.text rangeOfCharacterFromSet:numbers].location != NSNotFound && txtPassword.text.length >=6 ){
            if(isAgreeClicked==false)
            {
                //            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please agree term of use" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                //            [alert show];
                [self.view makeToast:@"You must agree to the Terms of Service and Privacy Policy in order to continue"];
                return;
            }
            else
            {
                txtFieldFullName.text = [NSString stringWithFormat:@"%@%@",[[txtFieldFullName.text substringToIndex:1] uppercaseString],[txtFieldFullName.text substringFromIndex:1] ];

                [self showProgressHud];
                [[NSUserDefaults standardUserDefaults] setObject:txtFieldContactNumber.text forKey:kUserMobileNumber];
                
                [[NSUserDefaults standardUserDefaults] setObject:txtFieldFullName.text forKey:kUserNameInMasterTable];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
                NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:txtFieldEmailId.text,@"email",txtFieldFullName.text,@"name",maleOrFemale,@"gender",@"91",@"country_code",@"GB",@"country",txtFieldContactNumber.text,@"mobile",txtConfirmPassword.text,@"password", nil];
                [[WebService sharedWebService] callRegisterNewUser:dictionary];
            }
            
        }
        
        else{
            [self.view makeToast:@"Password must be 6 character long and it must have a combination of letters and numbers for your security" duration:3 position:CSToastPositionBottom];
        }
    }
    else{
        if(isAgreeClicked==false)
        {
            //            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please agree term of use" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            //            [alert show];
            [self.view makeToast:@"You must agree to the Terms of Service and Privacy Policy in order to continue"];
            
        }
        else
        {
            txtFieldFullName.text = [NSString stringWithFormat:@"%@%@",[[txtFieldFullName.text substringToIndex:1] uppercaseString],[txtFieldFullName.text substringFromIndex:1] ];

            [[NSUserDefaults standardUserDefaults] setObject:txtFieldContactNumber.text forKey:kUserMobileNumber];
            [[NSUserDefaults standardUserDefaults] synchronize];
            NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:txtFieldEmailId.text,@"email",txtFieldFullName.text,@"name",maleOrFemale,@"gender",@"91",@"country_code",@"GB",@"country",txtFieldContactNumber.text,@"mobile",txtConfirmPassword.text,@"password", nil];
            [[WebService sharedWebService] callRegisterNewUser:dictionary];
        }
    }
    
    //    else{
    //        //         NSString *url = [NSString stringWithFormat:@" http://www.planitsyncit.com/app/android/webservices.php?action=register&email=%@&name=%@&gender=%@&country_code=%@&country=%@&mobile=%@",[dictionary objectForKey:@"email"],[dictionary objectForKey:@"name"],[dictionary objectForKey:@"gender"],[dictionary objectForKey:@"country_code"],[dictionary objectForKey:@"country"],[dictionary objectForKey:@"mobile"]];
    //
    //        //        [self.navigationController popViewControllerAnimated:YES];
    //    }
}



- (BOOL)textField:(UITextField *) textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if(textField ==txtFieldContactNumber)
    {
        NSUInteger oldLength = [textField.text length];
        NSUInteger replacementLength = [string length];
        NSUInteger rangeLength = range.length;
        
        NSUInteger newLength = oldLength - rangeLength + replacementLength;
        
        BOOL returnKey = [string rangeOfString: @"\n"].location != NSNotFound;
        
        return newLength <= MAXLENGTH || returnKey;
    }
    return true;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 6;
    
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}

- (void)nextClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [txtFieldFullName resignFirstResponder];
            [txtFieldEmailId becomeFirstResponder];
        }
            break;
            
        case 2: {
            [txtFieldEmailId resignFirstResponder];
            [txtFieldCountryCode becomeFirstResponder];
        }
            break;
            
        case 3: {
            [txtFieldCountryCode resignFirstResponder];
            [txtFieldContactNumber becomeFirstResponder];
        }
            break;
        case 4: {
            [txtFieldContactNumber resignFirstResponder];
            [txtPassword becomeFirstResponder];
            
        }
            break;
            
        case 5: {
            [txtPassword resignFirstResponder];
            [txtConfirmPassword becomeFirstResponder];
            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtPassword.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
        case 6: {
            [txtConfirmPassword resignFirstResponder];
            //            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
            
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    switch (sender){
            
        case 1: {
            [txtFieldFullName resignFirstResponder];
            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
            
        case 2: {
            [txtFieldFullName becomeFirstResponder];
            [txtFieldEmailId resignFirstResponder];
        }
            break;
            
        case 3: {
            [txtFieldEmailId becomeFirstResponder];
            [txtFieldCountryCode resignFirstResponder];
        }
            break;
        case 4: {
            [txtFieldCountryCode becomeFirstResponder];
            [txtFieldContactNumber resignFirstResponder];
        }
            break;
            
        case 5: {
            [txtFieldContactNumber becomeFirstResponder];
            [txtPassword resignFirstResponder];
            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtPassword.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
        case 6: {
            [txtPassword becomeFirstResponder];
            [txtConfirmPassword resignFirstResponder];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
     [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([txtFieldFullName isFirstResponder]) {
                [txtFieldFullName resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([txtFieldEmailId isFirstResponder]) {
                [txtFieldEmailId resignFirstResponder];
            }
        }
            break;
            
        case 3: {
            if ([txtFieldCountryCode isFirstResponder]) {
                [txtFieldCountryCode resignFirstResponder];
            }
        }
            break;
        case 4: {
            if ([txtFieldContactNumber isFirstResponder]) {
                [txtFieldContactNumber resignFirstResponder];
            }
        }
            break;
            
        case 5: {
            if ([txtPassword isFirstResponder]) {
                [txtPassword resignFirstResponder];
            }
        }
            break;
        case 6: {
            if ([txtConfirmPassword isFirstResponder]) {
                [txtConfirmPassword resignFirstResponder];
                //                [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
            }
        }
            break;
            
            
        default: {
        }
            break;
    }
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField == txtPassword){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtPassword.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == txtConfirmPassword){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtConfirmPassword.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(txtFieldFullName == textField){
        [txtFieldFullName resignFirstResponder];
        [txtFieldEmailId becomeFirstResponder];
    }
    
    else if(txtFieldEmailId == textField){
        [txtFieldEmailId resignFirstResponder];
        [txtFieldCountryCode becomeFirstResponder];
    }
    else if(txtFieldCountryCode == textField){
        [txtFieldCountryCode resignFirstResponder];
        [txtFieldContactNumber becomeFirstResponder];
    }
    
    else if(txtFieldContactNumber == textField){
        [txtFieldContactNumber resignFirstResponder];
        [txtPassword becomeFirstResponder];
    }
    else if(txtPassword == textField){
        [txtPassword resignFirstResponder];
        [txtConfirmPassword becomeFirstResponder];
    }
    else if(txtConfirmPassword == textField){
        [txtConfirmPassword resignFirstResponder];
        //        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    return YES;
}


- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,800, pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    }
    else{
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200, pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    }
    [UIView commitAnimations];
}
- (IBAction)doneButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,800, pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    }
    else{
        [pickerBackground setFrame:CGRectMake(pickerBackground.frame.origin.x,1200, pickerBackground.frame.size.width,pickerBackground.frame.size.height)];
    }
    [UIView commitAnimations];
}

- (IBAction)agreeTermsAndConditionPressed:(id)sender {
    if(isAgreeClicked==false){
        isAgreeClicked=true;
        [btnAgreeTerms setImage:nil forState:UIControlStateNormal];
        [btnAgreeTerms setImage:[UIImage imageNamed:@"check_on"] forState:UIControlStateNormal];
    }
    else{
        isAgreeClicked=false;
        [btnAgreeTerms setImage:nil forState:UIControlStateNormal];
        [btnAgreeTerms setImage:[UIImage imageNamed:@"check_off"] forState:UIControlStateNormal];
    }
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if([alertView tag] == 101 && buttonIndex == 0){
        MobileVerificationViewController* controller = (MobileVerificationViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"mobileVerificationViewControllerID"];
        [self.navigationController pushViewController:controller animated:YES];
    }
}
-(void)responseSuccessMessage
{
    MobileVerificationViewController* controller = (MobileVerificationViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"mobileVerificationViewControllerID"];
    [self.navigationController pushViewController:controller animated:YES];
}
- (void) registrationSuccess:(NSNotification *)notification{
    [self hideProgressHud];
    
    [[NSUserDefaults standardUserDefaults] setObject:txtFieldEmailId.text forKey:@"IsRegiteredAndVerifiedEmailId"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"Data=%@",notification.object);
    NSDictionary *dictionary = notification.object;
    NSDictionary *userProfile = [dictionary objectForKey:@"data"];
    
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert setTag:101];
    //    [alert show];
    [self performSelector:@selector(responseSuccessMessage) withObject:self afterDelay:1.0 ];
    
}
- (void) registrationFailed:(NSNotification *)notification{
    [self hideProgressHud];
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert show];
}
//hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

@end

