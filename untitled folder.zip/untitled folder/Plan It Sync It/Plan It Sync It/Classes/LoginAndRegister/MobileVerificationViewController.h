//
//  MobileVerificationViewController.h
//  Plan It Sync It
//
//  Created by apple on 15/04/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MobileVerificationViewController.h"

@interface MobileVerificationViewController : UIViewController<UITextFieldDelegate>

@property (nonatomic, retain) IBOutlet UITextField *txtMobileVerificationNumber;

@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSubmit;
- (void) contactVeifyKeySuccess:(NSNotification *)notification;
- (void) contactVeifyKeyFailed:(NSNotification *)notification;
- (IBAction)submitButtonClicked:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;
-(void)responseSuccessMessage;
- (IBAction)btnBackClicked:(id)sender;

@end

