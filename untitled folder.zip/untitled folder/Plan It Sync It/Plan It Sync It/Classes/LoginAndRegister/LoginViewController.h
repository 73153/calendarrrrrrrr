//
//  LoginViewController.h
//  Plan It Sync It
//
//  Created by apple on 15/04/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginViewController.h"
#import "CustomKeyboard.h"
@interface LoginViewController : UIViewController<UITextFieldDelegate,CustomKeyboardDelegate>
{
    CustomKeyboard *customKeyboard;
}

@property (nonatomic, strong) IBOutlet UITextField *txtFieldEmail;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldPassword;
@property (nonatomic, strong) IBOutlet UIButton *btnLogin;
@property (nonatomic, strong) IBOutlet UIButton *btnRegistration;
@property (nonatomic, strong) IBOutlet UIButton *btnForgotPassword;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnLogin;


- (void) showProgressHud;
- (void) hideProgressHud;
- (IBAction)loginButtonClicked:(id)sender;
- (IBAction)registrationButtonClicked:(id)sender;
- (IBAction)forgotPasswordButtonClicked:(id)sender;
-(void)responseSuccessMessage;
- (IBAction)btnAboutPressed:(id)sender;


@end

