//
//  ForgotPassWordViewController.m
//  Plan It Sync It
//
//  Created by apple on 15/04/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import "AppConstant.h"
#import "ForgotPassWordViewController.h"
#import "TextValidator.h"
#import "WebService.h"
#import "MobileVerificationViewController.h"
#import "REFrostedViewController.h"
#import "UIView+Toast.h"
#import "MBProgressHUD.h"
@interface ForgotPassWordViewController ()

@end

@implementation ForgotPassWordViewController

@synthesize txtMobileNumber;
@synthesize roundedBtnSubmit;
- (void)viewDidLoad{
    [super viewDidLoad];
    [self setTitle:@"Forgot Password"];
//    int height = self.navigationController.navigationBar.frame.size.height;
//    int width = self.navigationController.navigationBar.frame.size.width;
//    
//    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
//    [navLabel setText:@"Forgot Password"];
//    navLabel.textColor = [UIColor whiteColor];
//    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
//    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
//    navLabel.textAlignment = NSTextAlignmentCenter;
//    self.navigationItem.titleView = navLabel;
    
    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"IsForgotPassword"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
//    roundedBtnSubmit.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnSubmit.layer.borderWidth = 2.0f;
    roundedBtnSubmit.clipsToBounds=YES;
    roundedBtnSubmit.layer.cornerRadius = 5;
    [self hideProgressHud];
    txtMobileNumber.delegate = self;
    [txtMobileNumber setReturnKeyType:UIReturnKeyDone];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(forgotPasswordSuccess:) name:kForgotPassSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(forgotPasswordFailed:) name:kForgotPassFailed object:nil];
}

-(void)viewWillAppear:(BOOL)animated
{

}

-(void)viewDidDisappear:(BOOL)animated
{
    txtMobileNumber.text=@"";
}
-(void)viewDidUnload
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (IBAction)submitButtonClicked:(id)sender
{
    [txtMobileNumber resignFirstResponder];
    if([txtMobileNumber.text isEqualToString:@""])
    {
        [self.view makeToast:@"Please enter contact number"];
        return;
    }
    if(txtMobileNumber.text.length > 11  || txtMobileNumber.text.length < 10){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter correct contact number" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter contact number minimum 10 digits."];
        return;
    }
    else
    {
        NSDictionary *dictionary;
        NSString *storedMobile =[[NSUserDefaults standardUserDefaults] objectForKey:kUserMobileNumber];
        
        if([txtMobileNumber.text isEqualToString:storedMobile]==true){
            dictionary = [NSDictionary dictionaryWithObjectsAndKeys:storedMobile,@"mobile", nil];
            [[WebService sharedWebService] callForgotPasswordWebService:dictionary];
        }
        else{
            [self showProgressHud];
            dictionary = [NSDictionary dictionaryWithObjectsAndKeys:txtMobileNumber.text,@"mobile", nil];
            [[NSUserDefaults standardUserDefaults] setValue:txtMobileNumber.text forKey:kUserMobileNumber];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [[WebService sharedWebService] callForgotPasswordWebService:dictionary];
        }
    }
}

- (BOOL)textField:(UITextField *) textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if(textField ==txtMobileNumber)
    {
        NSUInteger oldLength = [textField.text length];
        NSUInteger replacementLength = [string length];
        NSUInteger rangeLength = range.length;
        
        NSUInteger newLength = oldLength - rangeLength + replacementLength;
        
        BOOL returnKey = [string rangeOfString: @"\n"].location != NSNotFound;
        
        return newLength <= 11 || returnKey;
    }
    return true;
}

- (IBAction)btnBackClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtMobileNumber){
        [txtMobileNumber resignFirstResponder];
    }
    return YES;
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if([alertView tag] == 101 && buttonIndex == 0){
        MobileVerificationViewController* controller = (MobileVerificationViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"mobileVerificationViewControllerID"];
        [self.navigationController pushViewController:controller animated:YES];
    }
}

-(void)responseSuccessMessage
{
    MobileVerificationViewController* controller = (MobileVerificationViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"mobileVerificationViewControllerID"];
    [self.navigationController pushViewController:controller animated:YES];
    
}
- (void) forgotPasswordSuccess:(NSNotification *)notification{
    [self hideProgressHud];
    NSLog(@"Data=%@",notification.object);
    
//    [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"IsLoginAndLogout"];
//    [[NSUserDefaults standardUserDefaults] synchronize];
    NSDictionary *dictionary = notification.object;
    NSDictionary *userProfile = [dictionary objectForKey:@"data"];
    
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert setTag:101];
    //    [alert show];
    [self performSelector:@selector(responseSuccessMessage) withObject:self afterDelay:2];
    
}
- (void) forgotPasswordFailed:(NSNotification *)notification{
    [self hideProgressHud];
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//hide keyboard
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

@end
