//
//  RegistrationViewController.h
//  Plan It Sync It
//
//  Created by apple on 15/04/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RegistrationViewController.h"
#import "AppConstant.h"
#import "CustomKeyboard.h"

@interface RegistrationViewController : UIViewController<UITextFieldDelegate, CustomKeyboardDelegate>
{
    CustomKeyboard *customKeyboard;

}

@property (nonatomic, strong) IBOutlet UITextField *txtFieldFullName;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldEmailId;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldContactNumber;
@property (nonatomic, strong) IBOutlet UITextField *txtFieldCountryCode;
@property (nonatomic, strong) IBOutlet UITextField *txtPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtConfirmPassword;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnCreateAccount;

@property (nonatomic, strong) IBOutlet UIButton *btnMale;
@property (nonatomic, strong) IBOutlet UIButton *btnFemale;
@property (nonatomic, strong) IBOutlet UIButton *btnSubmit;
@property (weak, nonatomic) IBOutlet UIButton *btnAgreeTerms;


@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;

@property (nonatomic, strong) IBOutlet UIView *pickerBackground;
@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;
- (IBAction)btnBackClicked:(id)sender;

- (IBAction)toggleRadioButton:(id)sender;
- (IBAction)submitButtonClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)agreeTermsAndConditionPressed:(id)sender;

- (IBAction)onLoginPressed:(id)sender;
- (void) registrationSuccess:(NSNotification *)notification;
- (void) registrationFailed:(NSNotification *)notification;
-(NSString*)getCarrierMobileCountryCode;
- (void) showProgressHud;
- (void) hideProgressHud;
-(void)responseSuccessMessage;


@end
