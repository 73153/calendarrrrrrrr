//
//  ConfirmPasswordViewController.m
//  Plan It Sync It
//
//  Created by apple on 15/04/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import "AppConstant.h"
#import "ConfirmPasswordViewController.h"
#import "WebService.h"
#import "TabBarController.h"
#import "LoginViewController.h"
#import "MobileVerificationViewController.h"
#import "ConfirmPassWordViewController.h"
#import "REFrostedViewController.h"
#import "UIView+Toast.h"
#import "MBProgressHUD.h"
@interface ConfirmPasswordViewController ()
{
    REFrostedViewController *frostedSplitController;
    
}
@end

@implementation ConfirmPasswordViewController

@synthesize txtPassword;
@synthesize txtConfirmPassword;
@synthesize tabcontroller;
@synthesize roundedBtnSubmit;
- (void)viewDidLoad{
    [super viewDidLoad];
    [self hideProgressHud];
    [self setTitle:@"Confirm Password"];
    int height = self.navigationController.navigationBar.frame.size.height;
    int width = self.navigationController.navigationBar.frame.size.width;
    
//    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
//    [navLabel setText:@"Confirm Password"];
//    navLabel.textColor = [UIColor whiteColor];
//    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
//    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
//    navLabel.textAlignment = NSTextAlignmentCenter;
//    self.navigationItem.titleView = navLabel;
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationItem.titleView = titleView;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    txtPassword.delegate = self;
    txtConfirmPassword.delegate = self;
    
    txtPassword.tag = 1;
    txtConfirmPassword.tag = 2;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
//    roundedBtnSubmit.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnSubmit.layer.borderWidth = 2.0f;
    roundedBtnSubmit.clipsToBounds=YES;
    roundedBtnSubmit.layer.cornerRadius = 5;
    
    [txtPassword setReturnKeyType:UIReturnKeyNext];
    [txtConfirmPassword setReturnKeyType:UIReturnKeyDone];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(passwordMatchSuccess:) name:kPasswordMatchSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(passwordMatchFailed:) name:kPasswordMatchFailed object:nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    txtPassword.text=@"";
    txtConfirmPassword.text=@"";

    NSInteger isGotoLogin = [[NSUserDefaults standardUserDefaults] integerForKey:@"IsForgotPassword"];
    if(isGotoLogin==3)
    {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    
}
-(void)viewDidUnload
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)submitButtonClicked:(id)sender
{
    if ([txtPassword isFirstResponder]) {
        [txtPassword resignFirstResponder];
    }
    else if ([txtConfirmPassword isFirstResponder]) {
        [txtConfirmPassword resignFirstResponder];
    }
    if([txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 && txtPassword.text.length<1){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter password."];
        return;
        
    }
    else if([txtConfirmPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 && txtConfirmPassword.text.length<1){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Please enter confirm password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Please enter confirm password."];
         return;
    }
    else if(![txtPassword.text isEqualToString:txtConfirmPassword.text]){
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Password should match with confirm password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        //        [alert show];
        [self.view makeToast:@"Password should match with confirm password."];
         return;
    }
    else if(txtConfirmPassword.text.length >= 6)
    {
        NSCharacterSet *upperlowerCaseChars = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLKMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"];
        //lowerCaseChars = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyz"];
        
        NSCharacterSet *numbers = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        if ([txtConfirmPassword.text rangeOfCharacterFromSet:upperlowerCaseChars].location != NSNotFound &&  [txtConfirmPassword.text rangeOfCharacterFromSet:numbers].location != NSNotFound && txtPassword.text.length >=6 )
        {
            [self showProgressHud];
            NSString *mobileNumber = [[NSUserDefaults standardUserDefaults] objectForKey:kUserMobileNumber];
            if(mobileNumber==nil)
                if(mobileNumber==nil)
                {
                    //                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:@"Your mobile number does not exist in Database." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                    //                    [alert show];
                    [self.view makeToast:@"Your mobile number does not exist in Database."];
                    
                }
            
            NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:mobileNumber,@"mobile",txtConfirmPassword.text,@"password", nil];
            [[WebService sharedWebService] callSavePasswordWebService:dictionary];
        }
        else
        {
            [self.view makeToast:@"Password must be 6 character long and it must have a combination of letters and numbers for your security" duration:3 position:CSToastPositionBottom];
        }
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(txtPassword == textField){
        [txtPassword resignFirstResponder];
        [txtConfirmPassword becomeFirstResponder];
    }
    else if(txtConfirmPassword == textField){
        [txtConfirmPassword resignFirstResponder];
    }
    
    return YES;
}


- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 2;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}
- (void)nextClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [txtPassword resignFirstResponder];
            [txtConfirmPassword becomeFirstResponder];
        }
            break;
            
        case 2: {
            [txtConfirmPassword resignFirstResponder];
        }
            break;
            
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [txtPassword resignFirstResponder];
        }
            break;
        case 2: {
            [txtPassword becomeFirstResponder];
            [txtConfirmPassword resignFirstResponder];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
     [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([txtPassword isFirstResponder]) {
                [txtPassword resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([txtConfirmPassword isFirstResponder]) {
                [txtConfirmPassword resignFirstResponder];
            }
        }
            break;
            
        default: {
        }
            break;
    }
}



- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if([alertView tag] == 101 && buttonIndex == 0){
        TabBarController *demoController = (TabBarController*)[self.storyboard instantiateViewControllerWithIdentifier:@"splitContollerID"];
        [self presentViewController:demoController animated:YES completion:nil];
    }
    
    
    
    //        TabBarController *demoController = (TabBarController*)[self.storyboard instantiateViewControllerWithIdentifier:@"splitContollerID"];
    
    //
    //        self.tabcontroller  =[[UITabBarController alloc]init];
    //        CGRect window = [[UIScreen mainScreen]bounds];
    //
    //
    //        UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    //
    //        UIViewController *vc[6];
    //        vc[0]= [board instantiateViewControllerWithIdentifier:@"mobileVerificationViewControllerID"];
    //        vc[1] = [board instantiateViewControllerWithIdentifier:@"confirmPasswordViewControllerID"];
    //        vc[2]= [board instantiateViewControllerWithIdentifier:@"loginViewControllerID"];
    //        vc[3]= [board instantiateViewControllerWithIdentifier:@"splitContollerID"];
    //
    //        NSArray *controllers = [NSArray arrayWithObjects:vc[0], vc[1], vc[2], vc[3], nil];
    //        [self.tabcontroller setViewControllers:controllers animated:YES];
    //
    //        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    //        {
    //            CGRect viewFrame=self.tabcontroller.view.frame;
    //            viewFrame.origin.y -=20;
    //            self.tabcontroller.view.frame = viewFrame;
    //        }
    //        if(window.size.height == 480)
    //        {
    //            CGRect viewFrame= self.tabcontroller.view.frame;
    //            viewFrame.size.height += 88;
    //            self.tabcontroller.view.frame = viewFrame;
    //        }
    ////        [self addChildViewController:self.tabcontroller];
    ////        [self.tabcontroller didMoveToParentViewController:self];
    //
    ////        [self.view addSubview:self.tabcontroller.view];
    //
    //        [self presentViewController:self.tabBarController animated:YES completion:nil];
    //
    
}
-(void)responseSuccessMessage
{
    [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"IsForgotPassword"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popToRootViewControllerAnimated:YES];
//    TabBarController *demoController = (TabBarController*)[self.storyboard instantiateViewControllerWithIdentifier:@"splitContollerID"];
//    [self presentViewController:demoController animated:YES completion:nil];
}
- (void) passwordMatchSuccess:(NSNotification *)notification{
    [self hideProgressHud];
    NSLog(@"Data=%@",notification.object);
    NSDictionary *dictionary = notification.object;
    
    NSDictionary *userProfile = [dictionary objectForKey:@"data"];
    
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert setTag:101];
    //    [alert show];
    [self performSelector:@selector(responseSuccessMessage) withObject:self afterDelay:3.0 ];
    
    
    
}
- (void) passwordMatchFailed:(NSNotification *)notification{
    [self hideProgressHud];
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}


@end
