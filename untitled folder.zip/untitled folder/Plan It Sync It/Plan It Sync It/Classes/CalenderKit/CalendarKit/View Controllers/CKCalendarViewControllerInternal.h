//
// Copyright 2014 Inostudio Solutions
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"

@interface CKCalendarViewControllerInternal : UIViewController {
    __weak IBOutlet UITableView *yearTableView;
    __weak IBOutlet UITableView *searchTableView;

    __weak IBOutlet UIView *bottomView;
    NSInteger tagSelected;
    NSIndexPath *nowIndexPath;
    __weak IBOutlet UISearchBar *memoSearchBar;
    AppDelegate *appDelegate;
    NSIndexPath *selectedIndexPath;
    NSString *filePathString;
    NSString *shareText;
    NSString *shareURL;
    
    NSInteger numberOfSharedItems;
    UIBarButtonItem *barButtonItem;
    UIButton * btnInbox;
}
@property (weak, nonatomic) IBOutlet UIView *tabBarView;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnToday;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (nonatomic, strong) NSDate *selectedDate;

- (void)getUserProfileForMasterTableSuccess:(NSNotification *)notification;
- (void)getUserProfileForMasterTableFailed:(NSNotification *)notification;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnTodayPressed:(id)sender;
@end
