//
// Copyright 2014 Inostudio Solutions
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#import "CKCalendarViewControllerInternal.h"
#import "KxMenu.h"
#import "InboxMessageViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "YearDisplayViewController.h"
#import "EventViewController.h"
#import "WeekViewExampleController.h"
#import "DayViewExampleController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "MBProgressHUD.h"
#import "ContactsViewController.h"
#import "TimelineViewController.h"
#import "INOYearTableCell.h"
#import "INOYearModel.h"
#import "UIView+Borders.h"
#import "MonthViewController.h"
#import "SearchTableViewCell.h"
#import "NSDate+FSExtension.h"
#import "DetailViewController.h"
#import "WhenSearch.h"

static NSUInteger const kCellsCount = 20;
static NSUInteger const kHalfCellsCount = kCellsCount >> 1;

@interface CKCalendarViewControllerInternal () <UITableViewDataSource, UITableViewDelegate,
MonthViewDelegate, NSFetchedResultsControllerDelegate, UISearchBarDelegate,
UIActionSheetDelegate>

@property (nonatomic, strong) INOYearModel *model;

@property (nonatomic, assign) NSInteger offset;
@property (nonatomic, assign) NSUInteger integerCellHeight; // is used for fast division
@property (nonatomic, strong) NSFetchedResultsController *fetchedResultsController;

@end

@implementation CKCalendarViewControllerInternal
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize tabBarView;
@synthesize roundedBtnToday;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    memoSearchBar.hidden = YES;
    searchTableView.hidden = YES;
    
    _model = [[INOYearModel alloc] init];
    
    _integerCellHeight = ceilf([INOYearTableCell cellHeight]);
    
    yearTableView.delegate=self;
    yearTableView.dataSource=self;
    
//    roundedBtnToday.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnToday.layer.borderWidth = 2.0f;
    roundedBtnToday.clipsToBounds=YES;
    roundedBtnToday.layer.cornerRadius = 5;
    
    [yearTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [yearTableView setShowsVerticalScrollIndicator:NO];
    [yearTableView reloadData];
    [yearTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:kHalfCellsCount inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    
    [bottomView addTopBorderWithHeight:1.f andColor:[UIColor lightGrayColor]];
    tagSelected = 0;
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    [[NSUserDefaults standardUserDefaults] setObject:@"RegiteredAndVerifiedEmailId" forKey:@"IsRegiteredAndVerifiedEmailId"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[UIWindow new] makeKeyAndVisible];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getUserProfileForMasterTableSuccess:) name:kGetUserProfileForMasterTableSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getUserProfileForMasterTableFailed:) name:kGetUserProfileForMasterTableFailed object:nil];
    
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:kUserId];
    
    [self showProgressHud];
    [[WebService sharedWebService] callUserProfileForMasterTable:dataDictionary];
    
}
- (void)tapMonthView:(NSInteger)tag {
    DLog(@"%ld", (long)tag);
    tagSelected = tag;
    MonthViewController* controller = (MonthViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
    if ([controller respondsToSelector:@selector(setDateTag:)]) {
        [controller setValue:[NSNumber numberWithInteger:tagSelected] forKey:@"dateTag"];
    }
    self.title = [NSString stringWithFormat:@"%ld", (long)tagSelected / 1000];
    
    [self.navigationController pushViewController:controller animated:YES];
    //    [self performSegueWithIdentifier:@"pushToMonth" sender:@"pushToMonth"];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    self.title = NSLocalizedString(@"Calendar", nil);
    
    btnInbox = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnInbox.frame = CGRectMake(0, 0, 56,22);
    
//    btnInbox.layer.borderColor = [UIColor blackColor].CGColor;
//    btnInbox.layer.borderWidth = 2.0f;
    btnInbox.clipsToBounds=YES;
    btnInbox.layer.cornerRadius = 5;
    
    
    
    //    _btn3.imageEdgeInsets = UIEdgeInsetsMake(10, 100, 10, 100);
    
    NSInteger checkForMonthOrOther =  [[NSUserDefaults standardUserDefaults] integerForKey:@"MonthWeekDayTimeline"];
    if(checkForMonthOrOther==3) {
        [btnInbox setTitle:@"Month" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeMonth animated:NO];
    }
    else if (checkForMonthOrOther==2){
        [btnInbox setTitle:@"Week" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeWeek animated:NO];
    }
    else if(checkForMonthOrOther==1){
        [btnInbox setTitle:@"Day" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    else
    {
        [btnInbox setTitle:@"Timeline" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    [btnInbox setTitle:@"Month" forState:UIControlStateNormal];
    [btnInbox addTarget:self action:@selector(showMenuItem:) forControlEvents:UIControlEventTouchUpInside];
    [btnInbox setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    btnInbox.backgroundColor=[UIColor colorWithRed:(0/255.0f) green:(204/255.0f) blue:(102/255.0f) alpha:1];
    
    barButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btnInbox];
    self.navigationItem.rightBarButtonItem = barButtonItem;
    
    
    NSString *dateDetail = [[NSUserDefaults standardUserDefaults] valueForKey:@"MonthTappedDetail"];
    
    if([dateDetail isEqualToString:@""])
    {
    }
    else
    {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        // this is imporant - we set our input date format to match our input string
        // if format doesn't match you'll get nil from your string, so be careful
        [dateFormatter setDateFormat:@"dd-MM-yyyy"];
        NSDate *dateFromString = [[NSDate alloc] init];
        // voila!
        dateFromString = [dateFormatter dateFromString:dateDetail];
    }
    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"EventFeedBlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [yearTableView reloadData];
    
}


- (void)showMenuItem:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      [KxMenuItem menuItem:@"Day"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Week"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Month"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Year"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Timeline"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      ];
    
    [KxMenu showMenuInView:self.view
                  fromRect:CGRectMake(sender.frame.origin.x, sender.frame.origin.y-33, sender.frame.size.width,sender.frame.size.height)
                 menuItems:menuItems];
    
}
- (void) pushMenuItem:(id)sender
{
    NSLog(@"%@", sender);
    
    if([[sender title] isEqual:@"Month"]){
        [btnInbox setTitle:@"Month" forState:UIControlStateNormal];
        
    }
    else if([[sender title]isEqual:@"Week"])
    {
        WeekViewExampleController* controller = (WeekViewExampleController*)[self.storyboard instantiateViewControllerWithIdentifier:@"weekViewExampleController"];
        [self.navigationController pushViewController:controller animated:YES];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeWeek animated:NO];
    }
    else if([[sender title]isEqual:@"Day"])
    {
        DayViewExampleController* controller = (DayViewExampleController*)[self.storyboard instantiateViewControllerWithIdentifier:@"dayViewExampleController"];
        [self.navigationController pushViewController:controller animated:YES];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
        //        [btnInbox setTitle:@"Day" forState:UIControlStateNormal];
    }
    else if([[sender title]isEqual:@"Year"])
    {
        WhenSearch* controller = (WhenSearch*)[self.storyboard instantiateViewControllerWithIdentifier:@"whenSearch"];
        [self.navigationController pushViewController:controller animated:YES];
//        YearDisplayViewController* controller = (YearDisplayViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"yearDisplayViewController"];
//        [self.navigationController pushViewController:controller animated:YES];
    }
    else if ([[sender title] isEqualToString:@"Timeline"])
    {
        TimelineViewController* controller = (TimelineViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"timelineViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
}


- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [memoSearchBar resignFirstResponder];
    memoSearchBar.hidden = YES;
    searchTableView.hidden = YES;
}

#pragma mark - UITableViewDatasource Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    NSInteger count = 1;
    if (tableView == searchTableView) {
        count = [[self.fetchedResultsController sections] count];
    }
    return count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == searchTableView) {
        NSInteger numberOfRows = 0;
        if ([[self.fetchedResultsController sections] count] > 0) {
            id <NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] objectAtIndex:section];
            numberOfRows = [sectionInfo numberOfObjects];
        }
        return numberOfRows;
    } else {
        return kCellsCount;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (tableView == searchTableView) {
        id <NSFetchedResultsSectionInfo> theSection = [[self.fetchedResultsController sections] objectAtIndex:section];
        NSString *sectionName = [theSection name];
        NSInteger sectionInteger = [sectionName integerValue];
        if (sectionInteger > 0) {
            NSInteger year = sectionInteger / 1000;
            NSInteger month = sectionInteger - year * 1000;
            NSDate *date = [NSDate fs_dateWithYear:year month:month day:1];
            NSString *dateString = [date fs_stringWithFormat:@"MMMM yyyy"];
            return dateString;
        } else {
            return @" ";
        }
    } else {
        return nil;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == searchTableView) {
        static NSString *tableCellId = @"SearchTableViewCell";
        SearchTableViewCell *cell = (SearchTableViewCell *)[tableView dequeueReusableCellWithIdentifier:tableCellId];
        Record *record = (Record *)[self.fetchedResultsController objectAtIndexPath:indexPath];
        [cell configureWithRecord:record];
        return cell;
    } else {
        static NSString *yearTableCellId = @"yearTableCellId";
        INOYearTableCell *cell = [tableView dequeueReusableCellWithIdentifier:yearTableCellId];
        if (!cell) {
            cell = [[INOYearTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:yearTableCellId];
            cell.delegate = self;
        }
        [cell setTag:indexPath.row];
        
        NSDate *yearDate = [_model yearWithOffsetFromCurrentDate:indexPath.row + kHalfCellsCount * (_offset -  1)];
        [cell setupWithYearDate:yearDate];
        [_model makeMonthsImagesWithDate:yearDate
                                  ofSize:[INOYearTableCell monthViewSize] cancelTag:[cell tag]
                              completion: ^(BOOL success, NSArray *monthsImages) {
                                  if (success && [monthsImages count] > 0) {
                                      [cell setupWithMonthsImages:monthsImages];
                                  }
                              }];
        return cell;
    }
}

#pragma mark - UITableViewDelegate Methods

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == searchTableView) {
        return 44;
    } else {
        return [INOYearTableCell cellHeight];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    selectedIndexPath = [NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section];
    Record *record = (Record *)[self.fetchedResultsController objectAtIndexPath:indexPath];
    [appDelegate setMemoInfo:record];
    DetailViewController* controller = (DetailViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"detailViewController"];
    
    if (record) {
        [self loadAudioFile:record.path];
        if ([controller respondsToSelector:@selector(setRecord:)]) {
            [controller setValue:record forKey:@"record"];
        }
    }
    
    if ([controller respondsToSelector:@selector(setDelegate:)]) {
        [controller setValue:self forKey:@"delegate"];
    }
    [self.navigationController pushViewController:controller animated:YES];
    //    [self performSegueWithIdentifier:@"pushToDetail" sender:@"pushToDetail"];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == yearTableView) {
        CGPoint contentOffset  = scrollView.contentOffset;
        
        if (contentOffset.y <= _integerCellHeight) {
            contentOffset.y = scrollView.contentSize.height / 2 + _integerCellHeight;
            _offset--;
        } else if (contentOffset.y >= scrollView.contentSize.height - (_integerCellHeight << 1)) {
            contentOffset.y = scrollView.contentSize.height / 2 - (_integerCellHeight << 1);
            _offset++;
        }
        [scrollView setContentOffset:contentOffset];
    }
}

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView
                     withVelocity:(CGPoint)velocity
              targetContentOffset:(inout CGPoint *)targetContentOffset {
    if (scrollView == yearTableView) {
        [_model proceedLoadingOperations];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    if (scrollView == yearTableView) {
        [_model suspendLoadingOperations];
    }
}

#pragma mark - common functionsqwdxsdxxasdwwsxwsqswqzasqzasaxaz          q1`        `?                       \

- (void)loadAudioFile:(NSString *)pathString {
    if (![filePathString isEqualToString:pathString]) {
        
        NSString *filePath = [NSString stringWithFormat:@"%@/Documents/%@.m4a", NSHomeDirectory(), pathString];
        NSURL *pathURL = [NSURL fileURLWithPath:filePath];
        NSError *error = nil;
        filePathString = pathString;
        [appDelegate setFileProtectionNone:filePath];
    }
}


- (void)touchedDetailButton:(NSString *)title {
//    [self performSegueWithIdentifier:@"pushToDetail" sender:@"pushToDetail"];
    DetailViewController* controller = (DetailViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"detailViewController"];
    
    Record *record = (Record *)[self.fetchedResultsController objectAtIndexPath:selectedIndexPath];
    if (record) {
        [self loadAudioFile:record.path];
        if ([controller respondsToSelector:@selector(setRecord:)]) {
            [controller setValue:record forKey:@"record"];
        }
    }
    
    if ([controller respondsToSelector:@selector(setDelegate:)]) {
        [controller setValue:self forKey:@"delegate"];
    }
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)repalceRecord:(NSInteger)type string:(NSString *)string {
    Record *record = (Record *)[self.fetchedResultsController objectAtIndexPath:selectedIndexPath];
    NSEntityDescription *ent = [NSEntityDescription entityForName:@"Record" inManagedObjectContext:appDelegate.managedObjectContext];
    // create an earthquake managed object, but don't insert it in our moc yet
    Record *newRecord = [[Record alloc] initWithEntity:ent insertIntoManagedObjectContext:nil];
    newRecord.memo = record.memo;
    newRecord.note = record.note;
    newRecord.date = record.date;
    newRecord.latitude = record.latitude;
    newRecord.length = record.length;
    newRecord.location = record.location;
    newRecord.longitude = record.longitude;
    newRecord.path = record.path;
    newRecord.unit = record.unit;
    newRecord.category = record.category;
    newRecord.section = record.section;
    if (type == 1) {
        newRecord.memo = string;
    } else if (type == 2) {
        newRecord.note = string;
    }
    
    if (newRecord) {
        [appDelegate.managedObjectContext insertObject:newRecord];
    }
    if (record) {
        [appDelegate.managedObjectContext deleteObject:record];
    }
    
    NSError *error = nil;
    if ([appDelegate.managedObjectContext hasChanges]) {
        if (![appDelegate.managedObjectContext save:&error]) {
            abort();
        }
    }
}

- (void)changeTitleAction:(NSString *)title {
    [self repalceRecord:1 string:title];
}

- (void)changeNoteAction:(NSString *)note {
    [self repalceRecord:2 string:note];
}

- (void)touchedDeleteButton:(NSString *)title isInView:(BOOL)flag {
    if (flag) {
        NSString *titleString = nil;
        if (title && title.length > 0) {
            titleString = [NSString stringWithFormat:@"Delete “%@”", title];
        } else {
            titleString = [NSString stringWithFormat:@"Delete"];
        }
        UIActionSheet *myActionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self
                                                         cancelButtonTitle:@"Cancel"
                                                    destructiveButtonTitle:titleString otherButtonTitles:nil, nil];
        [myActionSheet showInView:self.view];
    } else {
        [self deleteAnRecord];
    }
}

- (void)touchedShareButton:(NSString *)title {
    NSArray *activityItems;
    Record *record = (Record *)[self.fetchedResultsController objectAtIndexPath:selectedIndexPath];
    if (record) {
        NSString *filePath = [NSString stringWithFormat:@"%@/Documents/%@.m4a", NSHomeDirectory(), record.path];
        NSFileManager *fm = [NSFileManager defaultManager];
        NSError *error = nil;
        NSString *newFilePath = [NSString stringWithFormat:@"%@/Documents/voice.m4a", NSHomeDirectory()];
        NSData *audioData = [NSData dataWithContentsOfFile:newFilePath options:0 error:&error];
        if (audioData) {
            [fm removeItemAtPath:newFilePath error:&error];
        }
        [fm copyItemAtPath:filePath toPath:newFilePath error:&error];
        NSURL *fileURL = [NSURL fileURLWithPath:newFilePath];
        if (fileURL) {
            activityItems = @[title, fileURL];
        } else {
            activityItems = @[title];
        }
    } else {
        activityItems = @[title];
    }
    UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:nil];
    [activityViewController setValue:title forKey:@"subject"];
    activityViewController.excludedActivityTypes = @[
                                                     UIActivityTypePostToFacebook,
                                                     UIActivityTypePostToTwitter,
                                                     UIActivityTypePostToWeibo,
                                                     UIActivityTypePrint,
                                                     UIActivityTypeCopyToPasteboard,
                                                     UIActivityTypeSaveToCameraRoll,
                                                     UIActivityTypePostToTencentWeibo,
                                                     UIActivityTypeAssignToContact];
    [activityViewController setCompletionHandler:^(NSString *act, BOOL done) {
        NSFileManager *fm = [NSFileManager defaultManager];
        NSError *error = nil;
        NSString *filePath = [NSString stringWithFormat:@"%@/Documents/voice.m4a", NSHomeDirectory()];
        if ([fm fileExistsAtPath:filePath]) {
            [fm removeItemAtPath:filePath error:&error];
        }
    }];
    [self presentViewController:activityViewController animated:YES completion:nil];
}

- (id)activityViewControllerPlaceholderItem:(UIActivityViewController *)activityViewController {
    static UIActivityViewController *shareController;
    static int itemNo;
    if (shareController == activityViewController && itemNo < numberOfSharedItems - 1) {
        itemNo++;
    } else {
        itemNo = 0;
        shareController = activityViewController;
    }
    
    switch (itemNo) {
        case 0: return @""; // intro in email
        case 1: return @""; // email text
        case 2: return [NSURL new]; // link
        case 3: return [UIImage new]; // picture
        case 4: return @""; // extra text (via in twitter, signature in email)
        default: return nil;
    }
}

- (id)activityViewController:(UIActivityViewController *)activityViewController itemForActivityType:(NSString *)activityType {
    static UIActivityViewController *shareController;
    static int itemNo;
    if (shareController == activityViewController && itemNo < numberOfSharedItems - 1) {
        itemNo++;
    } else {
        itemNo = 0;
        shareController = activityViewController;
    }
    
    NSString *filePath = [NSString stringWithFormat:@"%@/Documents/audio.m4a", NSHomeDirectory()];
    NSURL *fileURL = [NSURL fileURLWithPath:filePath];
    
    if ([activityType isEqualToString:UIActivityTypeMail]) {
        switch (itemNo) {
            case 0: return @"Hi!\r\n\r\nI used a iPhone App SpeakOut\r\n";
            case 1: return shareText;
            case 2: return fileURL;
            case 3: return nil;
            case 4: return [@"\r\nCheck it out.\r\n\r\nCheers\r\n" stringByAppendingString:@"test"];
            default: return nil;
        }
    } else if ([activityType isEqualToString:UIActivityTypeMessage]) {
        switch (itemNo) {
            case 0: return nil;
            case 1: return shareText;
            case 2: return fileURL;
            case 3: return nil;
            case 4: return nil;
            default: return nil;
        }
    } else {
        switch (itemNo) {
            case 0: return nil;
            case 1: return shareText;
            case 2: return shareURL;
            case 3: return nil;
            case 4: return nil;
            default: return nil;
        }
    }
}

- (void)deleteAnRecord {
    Record *record = (Record *)[self.fetchedResultsController objectAtIndexPath:selectedIndexPath];
    if (record) {
        NSFileManager *fm = [NSFileManager defaultManager];
        NSError *error = nil;
        NSString *filePath = [NSString stringWithFormat:@"%@/Documents/%@.m4a", NSHomeDirectory(), record.path];
        [fm removeItemAtPath:filePath error:&error];
        [appDelegate.managedObjectContext deleteObject:record];
        if ([appDelegate.managedObjectContext hasChanges]) {
            if (![appDelegate.managedObjectContext save:&error]) {
                abort();
            }
        }
    }
}

- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex {
    if (buttonIndex == [actionSheet destructiveButtonIndex]) {
        
        [self deleteAnRecord];
    }
}

// called after fetched results controller received a content change notification
- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    //    selectedIndexPath = [NSIndexPath indexPathForRow:-1 inSection:-1];
    //    NSInteger numberOfRows = 0;
    //    NSInteger flag = 0;
    //    if ([[self.fetchedResultsController sections] count] > 0) {
    //        id <NSFetchedResultsSectionInfo> sectionInfo = [[self.fetchedResultsController sections] objectAtIndex:0];
    //        numberOfRows = [sectionInfo numberOfObjects];
    //        if (numberOfRows > originalRows) {
    //            flag = 1;
    //        }
    //    }
    [searchTableView reloadData];
    //    if (flag == 1) {
    //        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    //        [mainTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    //    }
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    UIViewController *viewController = segue.destinationViewController;
    if ([sender isEqualToString:@"pushToMonth"]) {
        
    }
    if ([sender isEqualToString:@"pushToDetail"]) {
        Record *record = (Record *)[self.fetchedResultsController objectAtIndexPath:selectedIndexPath];
        if (record) {
            [self loadAudioFile:record.path];
            if ([viewController respondsToSelector:@selector(setRecord:)]) {
                [viewController setValue:record forKey:@"record"];
            }
        }
        
        if ([viewController respondsToSelector:@selector(setDelegate:)]) {
            [viewController setValue:self forKey:@"delegate"];
        }
    }
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            CKCalendarViewControllerInternal *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"homeController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}



#pragma mark -
#pragma mark - WebService
#pragma mark -
- (void) getUserProfileForMasterTableSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    
    NSDictionary *maiDict = [dictionary objectForKey:@"data"];
    
    NSDictionary *profileDataDict = [maiDict objectForKey:@"user_profile"];
    
    [[NSUserDefaults standardUserDefaults] setObject:profileDataDict forKey:kProfileData];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}

- (void) getUserProfileForMasterTableFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"message"]];
}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
- (IBAction)btnTodayPressed:(id)sender {
    //    searchTableView.hidden = YES;
    memoSearchBar.hidden = YES;
    _offset = 0;
    _model = [[INOYearModel alloc] init];
    _integerCellHeight = ceilf([INOYearTableCell cellHeight]);
    [yearTableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    [yearTableView setShowsVerticalScrollIndicator:NO];
    
    [yearTableView reloadData];
    [yearTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:kHalfCellsCount inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    //    [[self calendarView] setDate:[NSDate date] animated:NO];
}
@end
