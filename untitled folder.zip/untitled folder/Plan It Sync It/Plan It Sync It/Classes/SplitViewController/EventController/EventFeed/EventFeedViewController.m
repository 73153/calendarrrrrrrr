//
//  EventFeedViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "EventFeedViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "EditProfileViewController.h"
#import "MBProgressHUD.h"
#import "InboxMessageViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "AddCommentViewController.h"
#import "AskWhatToBringViewController.h"
#import "CreatePollViewController.h"
#import "UploadPictureViewController.h"
#import "EventFeedAskWhatToBringViewController.h"
#import "EventFeedUploadPictureViewController.h"
#import "EventFeedCreatePollViewController.h"
#import "EventFeedViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "DateHandler.h"

@interface EventFeedViewController (){
    NSString *maleOrFemale;
}

@end

@implementation EventFeedViewController


@synthesize scrollView;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize btnCommentMessage;
@synthesize btnUploadPhoto;
@synthesize btnCreatePoll;
@synthesize btnAskWhatToBring;
@synthesize roundedBtnAddComment;

-(void)viewDidLoad
{
    // Create a tab bar and set it as root view for the application
    [self hideProgressHud];
    maleOrFemale = @"M";
 
    [self setTitle:@"Event Feed"];
    
    int height = self.navigationController.navigationBar.frame.size.height;
    int width = self.navigationController.navigationBar.frame.size.width;
    
    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    [navLabel setText:@"Event Feed"];
    navLabel.textColor = [UIColor whiteColor];
    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    navLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = navLabel;
//    roundedBtnAddComment.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnAddComment.layer.borderWidth = 2.0f;
    roundedBtnAddComment.clipsToBounds=YES;
    roundedBtnAddComment.layer.cornerRadius = 5;
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,800)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1600)];
    }
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    NSInteger eventFeedBlueTabNumberInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"EventFeedBlueTabNumber"];
    switch (eventFeedBlueTabNumberInt) {
        case 1:
            [btnCommentMessage setImage:[UIImage imageNamed:@"comment_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnUploadPhoto setImage:[UIImage imageNamed:@"camera_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnCreatePoll setImage:[UIImage imageNamed:@"menuicon_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnAskWhatToBring setImage:[UIImage imageNamed:@"bag_icon_active.png"] forState:UIControlStateNormal];
            break;
            
        default:
            break;
    }
    
}

-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}



- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnSaveClicked:(id)sender{
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];


    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnChatClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"EventFeedBlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    EventFeedViewController* controller = (EventFeedViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventFeedViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}
- (IBAction)btnUploadPhotoClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"EventFeedBlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    EventFeedUploadPictureViewController* controller = (EventFeedUploadPictureViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventFeedUploadPictureViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)btnCreatePollClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"EventFeedBlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    EventFeedCreatePollViewController* controller = (EventFeedCreatePollViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventFeedCreatePollViewController"];
    [self.navigationController pushViewController:controller animated:YES];
    
}

- (IBAction)btnAskWhatToBringClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"EventFeedBlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    EventFeedAskWhatToBringViewController* controller = (EventFeedAskWhatToBringViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventFeedAskWhatToBringViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}


- (IBAction)btnAddCommentClicked:(id)sender {
    AddCommentViewController* controller = (AddCommentViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"addCommentViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)btnSendMessageClicked:(id)sender {
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnComposeMessageClicked:(id)sender {
}

- (IBAction)btnRsvpStyleClicked:(id)sender {
}

- (IBAction)btnInviteGuestClicked:(id)sender {
}

////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
@end
