//
//  EventFeedViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
#import "EventFeedViewController.h"
@interface EventFeedViewController : UIViewController<UITabBarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (nonatomic) UIImagePickerController *imagePickerController;
@property (weak, nonatomic) IBOutlet UIButton *btnCommentMessage;
@property (weak, nonatomic) IBOutlet UIButton *btnUploadPhoto;
@property (weak, nonatomic) IBOutlet UIButton *btnCreatePoll;
@property (weak, nonatomic) IBOutlet UIButton *btnAskWhatToBring;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnAddComment;


@property (weak, nonatomic) IBOutlet UIButton *editButton;
@property (nonatomic, strong) IBOutlet UIButton *deleteButton;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
- (IBAction)btnUploadPhotoClicked:(id)sender;
- (IBAction)btnCreatePollClicked:(id)sender;
- (IBAction)btnChatClicked:(id)sender;

- (IBAction)btnAddCommentClicked:(id)sender;
- (IBAction)btnAskWhatToBringClicked:(id)sender;

- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnManageGuestClicked;


- (void) showProgressHud;
- (void) hideProgressHud;


@end
