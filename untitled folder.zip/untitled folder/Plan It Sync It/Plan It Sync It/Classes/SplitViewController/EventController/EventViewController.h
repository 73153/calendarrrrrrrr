//
//  EventViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
@interface EventViewController : UIViewController<UITabBarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CustomKeyboardDelegate,UITextViewDelegate>
{
    CustomKeyboard *customKeyboard;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnEdit;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnDelete;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnRoundedOption;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnRsvpStyle;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnInviteGuest;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnManageGuest;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSendMessage;
@property (strong, nonatomic)  NSMutableDictionary*oldDictionary;
@property (nonatomic, readwrite)  BOOL isDataFromWebservice;



@property (nonatomic) UIImagePickerController *imagePickerController;
@property (nonatomic, strong) IBOutlet UILabel *txtEventMainTitle;
@property (nonatomic, strong) IBOutlet UIButton *txtPlaceBelowMainEvent;
- (IBAction)btnLocationMapViewClicked:(id)sender;

@property (nonatomic, strong) IBOutlet UILabel *txtTypeOfEvent;
@property (nonatomic, strong) IBOutlet UITextView *txtNotes;
@property (nonatomic, strong) IBOutlet UILabel *txtStartDate;
@property (nonatomic, strong) IBOutlet UILabel *txtStartTime;
@property (nonatomic, strong) IBOutlet UILabel *txtDuration;
@property (nonatomic, strong) IBOutlet UILabel *txtRepeating;
@property (nonatomic, strong) IBOutlet UILabel *txtBirthDate;

@property (weak, nonatomic) IBOutlet UIButton *editButton;
@property (nonatomic, strong) IBOutlet UIButton *deleteButton;
@property (weak, nonatomic) IBOutlet UILabel *deleteHearderLbl;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
- (IBAction)btnEditEventClicked:(id)sender;

- (IBAction)btnEventOptionsClicked:(id)sender;
- (IBAction)btnDeleteEventClicked:(id)sender;
- (IBAction)btnManageGuestClicked:(id)sender;

- (IBAction)btnSendMessageClicked:(id)sender;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnRsvpStyleClicked:(id)sender;
- (IBAction)btnInviteGuestClicked:(id)sender;

@property (nonatomic, strong) NSMutableArray *allRecordArray;

@property (weak, nonatomic) IBOutlet UILabel *deleteHeaderLbl;
@property (weak, nonatomic) IBOutlet UIButton *btnDeleteOnlyThisInstanceRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnDeleteAllFollowingRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnDeleteAllInstancesRoundedCorner;
- (IBAction)btnDeleteOnlyThisIntanceClicked:(id)sender;
- (IBAction)btnDeleteAlFollowingIntanceClicked:(id)sender;
- (IBAction)btnDeleteAll_IntanceClicked:(id)sender;


@property (weak, nonatomic) IBOutlet UILabel *deleteAllInstanceLbl;

@property (weak, nonatomic) IBOutlet UILabel *deleteAllotherLbl;
@property (weak, nonatomic) IBOutlet UILabel *deleteAllFollowingLbl;
@property (weak, nonatomic) IBOutlet UIView *deletePopUpView;
@property (weak, nonatomic) IBOutlet UIButton *deleteCloseBtnRoundedCorner;


- (IBAction)deleteCloseButtonClicked:(id)sender;

- (void) getSingleEventsWebServiceSuccess:(NSNotification *)notification;
- (void) getSingleEventsWebServiceFailed:(NSNotification *)notification;

- (void) deleteEventsViewContorllerSuccess:(NSNotification *)notification;
- (void) deleteEventsViewContorllerFailed:(NSNotification *)notification;

- (void) showProgressHud;
- (void) hideProgressHud;



@end
