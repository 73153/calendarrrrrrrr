//
//  EventsViewController.m
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import "EventsListViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "EditEventsViewController.h"
#import "ToDoViewController.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
#import "CTCheckbox.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "YearViewController.h"
#import "EventViewController.h"
#import "CTCheckbox.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "DateHandler.h"
#import "UIImage+Helpers.h"
#import "ContactsViewController.h"

@interface EventsListViewController ()
{
    NSIndexPath *swipeCellIndexPath;
    
}
@property (nonatomic, strong) CTCheckbox *checkbox1;
@property (nonatomic, strong) CTCheckbox *checkbox2;
@property (nonatomic, strong) CTCheckbox *checkbox3;

@end

@implementation EventsListViewController
@synthesize tableView;
@synthesize  selectedContacts;
@synthesize totalIndaxPath;
@synthesize  emailIdArray;
@synthesize nameArray;
@synthesize deletedContactArray;
@synthesize searchedEmailArray;
@synthesize viewSelectAllAndDelete;
@synthesize selectedData;
@synthesize selectedRows;
@synthesize mSearchBar;
@synthesize toolBar_EditAndDelete;
//@synthesize searchedNameArray;
@synthesize btnSelectAll;
@synthesize btn1;
@synthesize btn2;
@synthesize btn3;
@synthesize labelNoRecordFound;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnNewEvent;
@synthesize allRecordArray;
@synthesize isFiltered;
@synthesize isPastChecked;
@synthesize isReverseChecked;
@synthesize isUpcomingChecked;
@synthesize deleteAllFollowingLbl;
@synthesize deleteAllInstanceLbl;
@synthesize deleteAllotherLbl;
@synthesize deleteHeaderLbl;
@synthesize deletePopUpView;
@synthesize btnDeleteAllFollowingRoundedCorner;
@synthesize btnDeleteAllInstancesRoundedCorner;
@synthesize btnDeleteOnlyThisInstanceRoundedCorner;
@synthesize deleteCloseBtnRoundedCorner;

- (void)viewDidLoad
{
    [super viewDidLoad];
    //init data
    self.selectedRows = [NSMutableArray array];
    tableView.dataSource=self;
    tableView.delegate=self;
    mSearchBar.delegate= self;
    [self setTitle:@"Events"];
    
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Events"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    toolBar_EditAndDelete.hidden = true;
    labelNoRecordFound.hidden=true;
    
    
    deletePopUpView.layer.cornerRadius=8;
    deletePopUpView.clipsToBounds=YES;
    
    deletePopUpView.layer.borderColor = [UIColor blackColor].CGColor;
    deletePopUpView.layer.borderWidth = 5.0f;
    deletePopUpView.hidden=true;
    
    //    roundedBtnNewEvent.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnNewEvent.layer.borderWidth = 2.0f;
    roundedBtnNewEvent.clipsToBounds=YES;
    roundedBtnNewEvent.layer.cornerRadius = 5;
    
    CGPoint position1 = btn1.frame.origin;
    NSLog(@"position1 x %f and Y %f",position1.x,position1.y);
    CGPoint position2 = btn2.frame.origin;
    NSLog(@"position2 x %f and Y %f",position2.x,position2.y);
    CGPoint position3 = btn3.frame.origin;
    NSLog(@"position2 x %f and Y %f",position3.x,position3.y);
    
    
    deleteAllFollowingLbl.numberOfLines=3;
    deleteAllInstanceLbl.numberOfLines=3;
    deleteAllotherLbl.numberOfLines=3;
    deleteHeaderLbl.numberOfLines=3;
    
    deleteAllFollowingLbl.lineBreakMode=YES;
    deleteAllInstanceLbl.lineBreakMode=YES;
    deleteAllotherLbl.lineBreakMode=YES;
    deleteHeaderLbl.lineBreakMode=YES;
    
    //    deletePopUpView.hidden=true;
    
    [deleteCloseBtnRoundedCorner setBackgroundColor:[UIColor lightGrayColor]];
    
    deleteCloseBtnRoundedCorner.layer.borderColor = [UIColor blackColor].CGColor;
    deleteCloseBtnRoundedCorner.layer.borderWidth = 1.0f;
    deleteCloseBtnRoundedCorner.layer.cornerRadius=8;
    deleteCloseBtnRoundedCorner.clipsToBounds=YES;
    
    
    [btnDeleteAllFollowingRoundedCorner setBackgroundColor:[UIColor lightGrayColor]];
    
    btnDeleteAllFollowingRoundedCorner.layer.borderColor = [UIColor blackColor].CGColor;
    btnDeleteAllFollowingRoundedCorner.layer.borderWidth = 1.0f;
    btnDeleteAllFollowingRoundedCorner.layer.cornerRadius=8;
    btnDeleteAllFollowingRoundedCorner.clipsToBounds=YES;
    
    [btnDeleteAllInstancesRoundedCorner setBackgroundColor:[UIColor lightGrayColor]];
    btnDeleteAllInstancesRoundedCorner.layer.borderColor = [UIColor blackColor].CGColor;
    btnDeleteAllInstancesRoundedCorner.layer.borderWidth = 1.0f;
    btnDeleteAllInstancesRoundedCorner.layer.cornerRadius=8;
    btnDeleteAllInstancesRoundedCorner.clipsToBounds=YES;
    
    [btnDeleteOnlyThisInstanceRoundedCorner setBackgroundColor:[UIColor lightGrayColor]];
    btnDeleteOnlyThisInstanceRoundedCorner.layer.borderColor = [UIColor blackColor].CGColor;
    btnDeleteOnlyThisInstanceRoundedCorner.layer.borderWidth = 1.0f;
    btnDeleteOnlyThisInstanceRoundedCorner.layer.cornerRadius=8;
    btnDeleteOnlyThisInstanceRoundedCorner.clipsToBounds=YES;
    
    
    isPastChecked= false;
    isUpcomingChecked=true;
    isReverseChecked=false;
    
    self.checkbox1 = [[CTCheckbox alloc] initWithFrame:CGRectMake(position1.x, position1.y, 280.0, 30.0)];
    self.checkbox1.textLabel.text = @"Past";
    self.checkbox1.tag=111;
    [self.view addSubview:self.checkbox1];
    [self.checkbox1 addTarget:self action:@selector(checkBoxTapped:) forControlEvents:UIControlEventValueChanged];
    
    
    self.checkbox2 = [[CTCheckbox alloc] initWithFrame:CGRectMake(position2.x, position2.y, 280.0, 30.0)];
    [self.checkbox2 setColor:[UIColor blackColor] forControlState:UIControlStateSelected];
    //    [self.checkbox2 setColor:[UIColor grayColor] forControlState:UIControlStateSelected];
    self.checkbox2.checked=true;
    self.checkbox2.textLabel.text = @"Upcoming";
    [self.view addSubview:self.checkbox2];
    self.checkbox2.tag=112;
    
    [self.checkbox2 addTarget:self action:@selector(checkBoxTapped:) forControlEvents:UIControlEventValueChanged];
    self.checkbox3.tag=113;
    
    self.checkbox3 = [[CTCheckbox alloc] initWithFrame:CGRectMake(position3.x, position3.y, 280.0, 30.0)];
    self.checkbox3.textLabel.text = @"Reverse order";
    [self.view addSubview:self.checkbox3];
    
    [self.checkbox3 addTarget:self action:@selector(checkBoxTapped:) forControlEvents:UIControlEventValueChanged];
    
    
    self.tableView.rowHeight = 80;
    
    // Initialize Refresh Control
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    
    // Configure Refresh Control
    [refreshControl addTarget:self action:@selector(toggleCells:) forControlEvents:UIControlEventValueChanged];
    refreshControl.tintColor = [UIColor blueColor];
    
    // Configure View Controller
    [self.tableView addSubview:refreshControl];
    self.refreshControl = refreshControl;
    self.useCustomCells = NO;
    totalIndaxPath = [NSMutableArray array];
    
    allRecordArray = [[NSMutableArray alloc] init];
    // Do any additional setup after loading the view, typically from a nib.
    selectedContacts = [NSMutableArray array];
    
    emailIdArray = [[NSMutableArray alloc] init];
    nameArray = [[NSMutableArray alloc] init];
    
    isSelectAllPressed=false;
    isSearchAndDelete=false;
    //    searchedEmailArray = emailIdArray;
    //    searchedNameArray=nameArray;
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfEventsSuccess:) name:kGetListOfEventsSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfEventsFailed:) name:kGetListOfEventsFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deleteEventsSuccess:) name:kDeleteEventsSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deleteEventsFailed:) name:kDeleteEventsFailed object:nil];
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)checkBoxTapped:(CTCheckbox *)checkbox
{
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:@"" forKey:@"eventid"];
    [dataDictionary setObject:@"" forKey:@"instance_date"];
    [dataDictionary setObject:@"" forKey:@"search"];
    NSInteger tag = [checkbox tag];
    switch (tag) {
        case 111:{
            if(isPastChecked==false)
                isPastChecked=true;
            else
                isPastChecked=false;
        }
            break;
        case 112:{
            if(isUpcomingChecked==false)
                isUpcomingChecked=true;
            else
                isUpcomingChecked=false;
        }
            break;
        case 113:{
            if(isReverseChecked==false)
                isReverseChecked=true;
            else
                isReverseChecked=false;
        }
            break;
        default:
            break;
    }
    
    [dataDictionary setObject:userid forKey:kUserId];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isUpcomingChecked] forKey:@"upcoming"];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isPastChecked] forKey:@"past"];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isReverseChecked] forKey:@"reverse"];
    [dataDictionary setObject:@"0" forKey:@"limit_start"];
    [dataDictionary setObject:@"30" forKey:@"limit_end"];
    
    [self showProgressHud];
    [[WebService sharedWebService] callGetListOfEventsWebService:dataDictionary];
    
}


-(void)viewWillAppear:(BOOL)animated
{
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:kUserId];
    [dataDictionary setObject:@"" forKey:@"eventid"];
    [dataDictionary setObject:@"" forKey:@"instance_date"];
    [dataDictionary setObject:@"" forKey:@"search"];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isUpcomingChecked] forKey:@"upcoming"];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isPastChecked] forKey:@"past"];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isReverseChecked] forKey:@"reverse"];
    [dataDictionary setObject:@"0" forKey:@"limit_start"];
    [dataDictionary setObject:@"30" forKey:@"limit_end"];
    
    [self showProgressHud];
    
    [[WebService sharedWebService] callGetListOfEventsWebService:dataDictionary];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change
                       context:(void *)context
{
    
}

-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark - dataSource method
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //    return searchedEmailArray.count;
    return allRecordArray.count;
    
}
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"UMCell";
    UMTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    if(allRecordArray.count>0)
        labelNoRecordFound.hidden=true;
    NSString *currentText;
    
    id object = [nameArray objectAtIndex:indexPath.row];
    
    if (object == [NSNull null])
        return cell;
    
    id object1 = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"email"];
    
    if (object1 == [NSNull null])
        return cell;
    
    cell.label.text = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"email"];
    currentText =cell.label1.text = [nameArray objectAtIndex:indexPath.row];
    NSString *wholeDayStr = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"full_time"];
    if([wholeDayStr isEqualToString:@"yes"])
        cell.lblClass.text=@"Whole day";
    else
        cell.lblClass.hidden=true;
    
    
    NSString *locationName = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"location_name"];
    if(locationName.length>0)
        cell.label.text = locationName;
    
    NSString *dateString = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"date"];
    
    NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString =  [dateFormatter dateFromString:dateString];
    
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] ){
        cell.lblCellDate.text=@"";
    }
    cell.lblCellDate.text = [DateHandler getDateFromString:dateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
    
    NSString *timeFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KTimeFormat];
    timeFormatStr = [NSString stringWithFormat:@"%@",timeFormatStr];
    
    NSString *startTime = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"time"];
    cell.lblCellTime.text = [DateHandler convertTimeFormat:startTime timeFormat:timeFormatStr];
    
    NSString *repeatingOrNot = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"cal_type"];
    if(![repeatingOrNot isEqualToString:@"single"])
    {
        cell.repeatingImage.image = [UIImage imageNamed:@"recurring_96.png"];
    }
    
    cell.label.numberOfLines = 3;
    cell.label1.numberOfLines = 3;
    cell.label.lineBreakMode=0;
    cell.label1.lineBreakMode=0;
    
    
    NSString *userImage = [[[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"event_image"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    if(![userImage isEqualToString:@""] && ![userImage isEqualToString:nil]){
        
        [UIImage loadFromURL:[NSURL URLWithString:userImage] callback:^(UIImage *image){
            cell.userImage.image = image;
        }];
    }
    else
    {
        [cell.userImage setImage:[UIImage imageNamed:@"user_image_default.png"]];
    }
    cell.userImage.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    cell.userImage.layer.masksToBounds = YES;
    cell.userImage.layer.cornerRadius = 10.0;
    cell.userImage.layer.borderColor = [UIColor whiteColor].CGColor;
    cell.userImage.layer.borderWidth = 1.0f;
    cell.userImage.clipsToBounds = YES;
    UIImage *image;
    
    if ([selectedContacts containsObject:currentText]) {
        image = [UIImage imageNamed:@"check_on.png"];
    } else  {
        image = [UIImage imageNamed:@"check_off.png"];
    }
    
    [cell.checkBoxButton setImage:image forState:UIControlStateNormal];
    [cell.checkBoxButton addTarget:self action:@selector(checkButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:70.0f];
    
    if (cell==Nil) {
        cell = [[UMTableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    
    //    [cell setBackgroundColor:[UIColor clearColor]];
    //
    //    CAGradientLayer *grad = [CAGradientLayer layer];
    //    grad.frame = CGRectMake(0,0,480,80);
    //    //    139-137-137
    //    UIColor *color1 = [UIColor colorWithRed:139.0f/255.0f green:137.0f/255.0f blue:137.0f/255.0f alpha:0.5];
    //    UIColor *color2 = [UIColor colorWithRed:240.0f/255.0f green:240.0f/255.0f blue:240.0f/255.0f alpha:0.5];
    //
    //    //    grad.colors = [NSArray arrayWithObjects:(id)[[UIColor whiteColor] CGColor], (id)[[UIColor greenColor] CGColor], nil];
    //    [grad setColors:[NSArray arrayWithObjects:(id)color1.CGColor, (id)color2.CGColor, nil]];
    //
    //    grad.cornerRadius = 5.0;
    //
    //    [cell setBackgroundView:[[UIView alloc] init]];
    //    [cell.backgroundView.layer insertSublayer:grad atIndex:0];
    
    cell.delegate = self;
    
    return cell;
    
}

- (void)checkButtonTapped:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:buttonPosition];
    if (indexPath != nil)
    {
        if(isSearchAndDelete==true || isSelectAllPressed==true)
            return;
        NSString *currentText = nameArray[indexPath.row];
        
        //new method
        if ([selectedContacts containsObject:currentText]) {
            [selectedContacts removeObject:currentText];
            [self.selectedRows removeObject:indexPath];
            mSearchBar.hidden=false;
            toolBar_EditAndDelete.hidden=true;
        } else {
            mSearchBar.hidden=true;
            toolBar_EditAndDelete.hidden=false;
            
            [selectedContacts addObject:currentText];
            [self.selectedRows addObject:indexPath];
        }
    }
    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - delegate method
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [[NSUserDefaults standardUserDefaults] setObject:[[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"id"] forKey:kEventId];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    EventViewController* controller = (EventViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventViewController"];
    
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)delRow:(id)sender {
    
    [tableView reloadRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.4];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableArray *idArr = [NSMutableArray array];
    NSString *idFinalStr=@"";
    NSInteger count =  [selectedRows count];
    for (NSInteger i = count; i>0; i--) {
        NSIndexPath *path = [selectedRows objectAtIndex:i-1];
        NSString *str = [[allRecordArray objectAtIndex:path.row] valueForKey:@"id"];
        NSString *commaSeparatedStr;
        if(i==1)
            commaSeparatedStr = [NSString stringWithFormat:@"%@",str];
        else
            commaSeparatedStr = [NSString stringWithFormat:@"%@,",str];
        if([commaSeparatedStr isEqualToString:@""])
            return;
        idFinalStr = [idFinalStr stringByAppendingString:commaSeparatedStr];
        
    }
    [dataDictionary setObject:@"all_events" forKey:@"type"];
    
    [dataDictionary setObject:idFinalStr forKey:@"id"];
    
    //    NSString* leftBracketRemove = [idStr stringByReplacingOccurrencesOfString:@"(" withString:@""];
    //    NSString* rightBracketRemove = [idStr stringByReplacingOccurrencesOfString:@")" withString:@""];
    //
    //    NSString *finalStr = [NSString stringWithFormat:@"%@%@",leftBracketRemove,rightBracketRemove];
    
    [dataDictionary setObject:userid forKey:kUserId];
    
    NSInteger index = count;
    for (int i=0; i<count; i++) {
        NSIndexPath *path = [selectedRows objectAtIndex:index-1];
        if([nameArray count] > 0 && [nameArray count] > path.row && index >= 0){
            [nameArray removeObjectAtIndex:path.row];
            [allRecordArray removeObjectAtIndex:path.row];
            index--;
        }
    }
    //    NSString *repeatingOrNot = [[allRecordArray objectAtIndex:cellIndexPath.row] valueForKey:@"cal_type"];
    //
    //    [dataDictionary setObject:repeatingOrNot forKey:@"type"];
    [self showProgressHud];
    [[WebService sharedWebService] callDeleteEventsWebService:dataDictionary];
    
    
    [tableView deleteRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    [UIView commitAnimations];
    [selectedContacts removeAllObjects];
    [self.selectedRows removeAllObjects];
    mSearchBar.hidden=false;
    toolBar_EditAndDelete.hidden=true;
    if(allRecordArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    
}

- (IBAction)editRows:(id)sender {
    BOOL edit = tableView.editing;
    [tableView setEditing:!edit animated:YES];
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if(isSearchAndDelete==true || isSelectAllPressed==true)
        return;
    if ([self.selectedRows containsObject:indexPath]) {
        [self.selectedRows removeObject:indexPath];
        [selectedContacts removeObject:nameArray[indexPath.row]];
    }
    
}



- (IBAction)selectAll:(id)sender {
    [self showProgressHud];
    if(isSelectAllPressed==false){
        isSelectAllPressed=true;
        btnSelectAll.title = @"Un Select All";
        [selectedContacts removeAllObjects];
        [selectedRows removeAllObjects];
        [nameArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            NSString *currentText = nameArray[idx];
            [selectedContacts addObject:currentText];
            [selectedRows addObject:[NSIndexPath indexPathForRow:idx inSection:0]];
        }];
        [tableView reloadData];
    }
    else
    {
        isSearchAndDelete=false;
        isSelectAllPressed=false;
        btnSelectAll.title = @"Select All";
        toolBar_EditAndDelete.hidden=true;
        mSearchBar.hidden=false;
        
        [selectedContacts removeAllObjects];
        [selectedRows removeAllObjects];
        [tableView reloadData];
    }
    [self hideProgressHud];
    
}

- (IBAction)btnBackClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UIRefreshControl Selector

- (void)toggleCells:(UIRefreshControl*)refreshControl
{
    [refreshControl beginRefreshing];
    self.useCustomCells = !self.useCustomCells;
    
    if (self.useCustomCells)
    {
        self.refreshControl.tintColor = [UIColor redColor];
    }
    else
    {
        self.refreshControl.tintColor = [UIColor blueColor];
        [self showProgressHud];
        
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        [self showProgressHud];
        [dataDictionary setObject:@"" forKey:@"eventid"];
        [dataDictionary setObject:@"" forKey:@"instance_date"];
        [dataDictionary setObject:@"" forKey:@"search"];
        [dataDictionary setObject:userid forKey:kUserId];
        [dataDictionary setObject:[NSString stringWithFormat:@"%d",isUpcomingChecked] forKey:@"upcoming"];
        [dataDictionary setObject:[NSString stringWithFormat:@"%d",isPastChecked] forKey:@"past"];
        [dataDictionary setObject:[NSString stringWithFormat:@"%d",isReverseChecked] forKey:@"reverse"];
        
        [dataDictionary setObject:@"0" forKey:@"limit_start"];
        [dataDictionary setObject:@"30" forKey:@"limit_end"];
        [[WebService sharedWebService] callGetListOfEventsWebService:dataDictionary];
    }
    [refreshControl endRefreshing];
}
////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}


#pragma mark -
#pragma mark - tabBarButtonsPressed
#pragma mark -
- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
- (IBAction)btnNewEventClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    EditEventsViewController* controller = (EditEventsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editEventsViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - Search Functionality

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    isSearchAndDelete=true;
    [mSearchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    [mSearchBar setShowsCancelButton:NO animated:YES];
    
    //    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    //    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    [dataDictionary setObject:@"" forKey:@"eventid"];
    //    [dataDictionary setObject:@"" forKey:@"instance_date"];
    //    [dataDictionary setObject:searchBar.text forKey:@"search"];
    //    [dataDictionary setObject:userid forKey:kUserId];
    //    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isUpcomingChecked] forKey:@"upcoming"];
    //    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isPastChecked] forKey:@"past"];
    //    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isReverseChecked] forKey:@"reverse"];
    //
    //    [dataDictionary setObject:@"0" forKey:@"limit_start"];
    //    [dataDictionary setObject:@"30" forKey:@"limit_end"];
    //
    //    [self showProgressHud];
    //    [[WebService sharedWebService] callGetListOfEventsWebService:dataDictionary];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchText.length>0) {
        //        searchText = [searchText stringByReplacingOccurrencesOfString:@" " withString:@""];
        //        NSLog(@"its pincode");
        //
        //        NSPredicate *predicate = [NSPredicate predicateWithFormat: @"SELF CONTAINS[cd] %@", searchText ];
        //
        //        searchedEmailArray = [emailIdArray filteredArrayUsingPredicate:predicate];
        //
        //
        //        NSPredicate *predicate1 = [NSPredicate predicateWithFormat: @"SELF CONTAINS[cd] %@", searchText ];
        //
        //        searchedNameArray = [nameArray filteredArrayUsingPredicate:predicate1];
        //        [tableView reloadData];
    }
    else
    {
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        [dataDictionary setObject:@"" forKey:@"eventid"];
        [dataDictionary setObject:@"" forKey:@"instance_date"];
        [dataDictionary setObject:@"" forKey:@"search"];
        [dataDictionary setObject:userid forKey:kUserId];
        [dataDictionary setObject:[NSString stringWithFormat:@"%d",isUpcomingChecked] forKey:@"upcoming"];
        [dataDictionary setObject:[NSString stringWithFormat:@"%d",isPastChecked] forKey:@"past"];
        [dataDictionary setObject:[NSString stringWithFormat:@"%d",isReverseChecked] forKey:@"reverse"];
        
        [dataDictionary setObject:@"0" forKey:@"limit_start"];
        [dataDictionary setObject:@"30" forKey:@"limit_end"];
        
        [self showProgressHud];
        [[WebService sharedWebService] callGetListOfEventsWebService:dataDictionary];
    }
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    isSearchAndDelete=false;
    
    [mSearchBar resignFirstResponder];
    NSString *serachedText = mSearchBar.text;
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:@"" forKey:@"eventid"];
    [dataDictionary setObject:@"" forKey:@"instance_date"];
    [dataDictionary setObject:serachedText forKey:@"search"];
    [dataDictionary setObject:userid forKey:kUserId];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isUpcomingChecked] forKey:@"upcoming"];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isPastChecked] forKey:@"past"];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isReverseChecked] forKey:@"reverse"];
    
    [dataDictionary setObject:@"0" forKey:@"limit_start"];
    [dataDictionary setObject:@"30" forKey:@"limit_end"];
    
    [self showProgressHud];
    [[WebService sharedWebService] callGetListOfEventsWebService:dataDictionary];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    isSearchAndDelete=false;
    [mSearchBar resignFirstResponder];
    //    searchedEmailArray=emailIdArray;
    [tableView reloadData];
}

#pragma mark ***************************DELETE EVENT WEBSEVICE*********************

-(void)deleteEventByInstance:(NSString*)eventInstance
{
    [self showProgressHud];
    
    NSString *str = [[allRecordArray objectAtIndex:swipeCellIndexPath.row] valueForKey:@"id"];
    
    if(selectedContacts.count>0&&selectedRows.count>0){
        NSString *emailText = nameArray[swipeCellIndexPath.row];
        
        [selectedContacts removeObject:emailText];
        [self.selectedRows removeObject:swipeCellIndexPath];
    }
    
    NSLog(@"delete");
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    [dataDictionary setObject:userid forKey:kUserId];
    [dataDictionary setObject:str forKey:@"id"];
    
    [dataDictionary setObject:eventInstance forKey:@"type"];
    //    [allRecordArray removeObjectAtIndex:swipeCellIndexPath.row];
    //    [nameArray removeObjectAtIndex:swipeCellIndexPath.row];
    
    [[WebService sharedWebService] callDeleteEventsWebService:dataDictionary];
    
    
}

- (IBAction)btnDeleteOnlyThisIntanceClicked:(id)sender {
    [self deleteEventByInstance:@"this_instance"];
}

- (IBAction)btnDeleteAlFollowingIntanceClicked:(id)sender {
    [self deleteEventByInstance:@"following_events"];
}

- (IBAction)btnDeleteAll_IntanceClicked:(id)sender {
    
    [self deleteEventByInstance:@"all_events"];
}


- (IBAction)deleteCloseButtonClicked:(id)sender {
    deletePopUpView.hidden=true;
}

#pragma mark - WebService
#pragma mark -
- (void) getListOfEventsSuccess:(NSNotification *)notification
{
    deletePopUpView.hidden=true;
    
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"message"]];
    
    NSArray *responseDataArray = [dictionary objectForKey:@"data"];
    
    NSDictionary *dict;
    NSArray *individualRecordArray;
    [nameArray removeAllObjects];
    [allRecordArray removeAllObjects];
    
    individualRecordArray = [responseDataArray valueForKey:@"events"];
    for (int i=0; i<individualRecordArray.count; i++) {
        dict = [individualRecordArray objectAtIndex:i];
        if([[dict valueForKey:@"location_name"] isKindOfClass:[NSArray class]])
        {
            NSLog(@"Nsarray");
            
        }
        else if([[dict valueForKey:@"location_name"] isKindOfClass:[NSDictionary class]])
        {
            NSLog(@"Dictionary");
        }
        else{
            NSString *name = [dict valueForKey:@"title"];
            id object =  [dict valueForKey:@"title"];
            if (object == [NSNull null])
                continue;
            if([name isEqualToString:@""])
                continue;
            name = [name stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            [nameArray addObject:name];
            
        }
    }
    
    allRecordArray = [individualRecordArray mutableCopy];
    [self.tableView reloadData];
    
    if(allRecordArray.count>0){
        labelNoRecordFound.hidden=true;
        
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    }
    else{
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    
    //    searchedEmailArray = emailIdArray;
    //    searchedNameArray =  nameArray;
    
    
}

- (void) getListOfEventsFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *toastMessage =[response objectForKey:@"message"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    if([toastMessage isEqualToString:@"No data found!"])
    {
        [nameArray removeAllObjects];
        [allRecordArray removeAllObjects];
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
        [self.tableView reloadData];
    }
    
}
- (void) deleteEventsSuccess:(NSNotification *)notification
{
    deletePopUpView.hidden=true;
    [self hideProgressHud];
    if(allRecordArray.count>0){
        [allRecordArray removeObjectAtIndex:swipeCellIndexPath.row];
        [nameArray removeObjectAtIndex:swipeCellIndexPath.row];
    }
    else{
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    [self.tableView reloadData];
}

- (void) deleteEventsFailed:(NSNotification *)notification
{
    deletePopUpView.hidden=true;
    
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}


#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
        
        //        navigationController.viewControllers = @[secondViewController];
        
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


#pragma mark - SWTableViewDelegate

- (void)swipeableTableViewCell:(SWTableViewCell *)cell scrollingToState:(SWCellState)state
{
    switch (state) {
        case 0:
            NSLog(@"utility buttons closed");
            break;
        case 1:
            NSLog(@"left utility buttons open");
            break;
        case 2:
            NSLog(@"right utility buttons open");
            break;
        default:
            break;
    }
}

- (void) showDeletePopUpForRepeatingInstance
{
    deletePopUpView.hidden=false;
    deletePopUpView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    
    [UIView animateWithDuration:0.3/1.5 animations:^{
        deletePopUpView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3/2 animations:^{
            deletePopUpView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.3/2 animations:^{
                deletePopUpView.transform = CGAffineTransformIdentity;
            }];
        }];
    }];
}

- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerRightUtilityButtonWithIndex:(NSInteger)index
{
    [cell hideUtilityButtonsAnimated:YES];
    
    switch (index) {
        case 0:
        {
            [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"IsEditEvents"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            [tableView reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [[NSUserDefaults standardUserDefaults] setObject:[[allRecordArray objectAtIndex:cellIndexPath.row] valueForKey:@"id"] forKey:kEventId];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            EditEventsViewController* controller = (EditEventsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editEventsViewController"];
            
            [self.navigationController pushViewController:controller animated:YES];
            
            break;
            
        }
        case 1:
        {
            if(isSearchAndDelete==true || isSelectAllPressed==true)
                return;
            
            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            
            NSString *str = [[allRecordArray objectAtIndex:[cellIndexPath row]] valueForKey:@"id"];
            
            // Delete button was pressed
            [tableView reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            
            NSString *repeatingOrNot = [[allRecordArray objectAtIndex:[cellIndexPath row]] valueForKey:@"cal_type"];
            
            
            if(![repeatingOrNot isEqualToString:@"single"])
            {
                [self showDeletePopUpForRepeatingInstance];
                swipeCellIndexPath = cellIndexPath;
                return;
            }
            
            if(selectedContacts.count>0&&selectedRows.count>0){
                NSString *emailText = nameArray[cellIndexPath.row];
                
                [selectedContacts removeObject:emailText];
                [self.selectedRows removeObject:cellIndexPath];
            }
            
            NSLog(@"delete");
            
            NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
            
            NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
            [dataDictionary setObject:userid forKey:kUserId];
            [dataDictionary setObject:str forKey:@"id"];
            
            [dataDictionary setObject:@"single" forKey:@"type"];
            NSUInteger objIdx = [allRecordArray indexOfObject:cellIndexPath];
            
            [[WebService sharedWebService] callDeleteEventsWebService:dataDictionary];
            
            [tableView setEditing:NO animated:YES];
            
            if(allRecordArray.count<=0){
                [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
                labelNoRecordFound.hidden=false;
            }
            
            break;
        }
            
        default:
            break;
    }
    [self.tableView reloadData];
}

- (BOOL)swipeableTableViewCellShouldHideUtilityButtonsOnSwipe:(SWTableViewCell *)cell
{
    // allow just one cell's utility button to be open at once
    return YES;
}

- (BOOL)swipeableTableViewCell:(SWTableViewCell *)cell canSwipeToState:(SWCellState)state
{
    switch (state) {
        case 1:
            // set to NO to disable all left utility buttons appearings
            return YES;
            break;
        case 2:
            // set to NO to disable all right utility buttons appearing
            return YES;
            break;
        default:
            break;
    }
    
    return YES;
}

- (NSArray *)rightButtons
{
    NSMutableArray *rightUtilityButtons = [NSMutableArray new];
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:0.0f green:1 blue:0.0f alpha:1.0]
                                                title:@"Edit"];
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:1.0f green:0.231f blue:0.188 alpha:1.0f]
                                                title:@"Delete"];
    
    
    return rightUtilityButtons;
}



@end
