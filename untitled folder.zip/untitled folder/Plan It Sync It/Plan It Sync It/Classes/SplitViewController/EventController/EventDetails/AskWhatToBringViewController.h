//
//  AskWhatToBringViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 18/3/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
#import "IQDropDownTextField.h"
@interface AskWhatToBringViewController : UIViewController<UITabBarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CustomKeyboardDelegate,UITextFieldDelegate,IQDropDownTextFieldDelegate>
{
    CustomKeyboard *customKeyboard;
    CGPoint txtItemNamePos;
    CGPoint btnDeletePos;
    CGPoint txtQuantityPos;
    
    CGSize txtItemNameSize;
    CGSize btnDeleteSize;
    CGSize txtQuantitySize;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (nonatomic) UIImagePickerController *imagePickerController;

@property (weak, nonatomic) IBOutlet UITextField *txtItemName;
@property (weak, nonatomic) IBOutlet UITextField *txtQuantity;
@property (weak, nonatomic) IBOutlet UIButton *btnDelete;
@property (weak, nonatomic) IBOutlet UITextField *txtWhatToBringTitle;

@property (weak, nonatomic) IBOutlet UIButton *roundedBtnbtnAddOtherItem;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnbtnPost;

@property (nonatomic) int itemsCount;

@property (weak, nonatomic) IBOutlet UIButton *editButton;
@property (nonatomic, strong) IBOutlet UIButton *deleteButton;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
- (IBAction)btnAddOtherItemClicked:(id)sender;
- (IBAction)btnPostClicked:(id)sender;

- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;
- (IBAction)buttonDeltePressed:(id)sender;

- (void) showProgressHud;
- (void) hideProgressHud;


@end
