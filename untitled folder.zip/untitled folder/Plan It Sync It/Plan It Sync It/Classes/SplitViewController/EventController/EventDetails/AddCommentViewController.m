//
//  AddCommentViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "AddCommentViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "EditProfileViewController.h"
#import "MBProgressHUD.h"
#import "InboxMessageViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "DateHandler.h"
@interface AddCommentViewController ()
{
    NSString *maleOrFemale;
    
}

@end

@implementation AddCommentViewController


@synthesize scrollView;
@synthesize txtFieldAddComment;

@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnPost;


-(void)viewDidLoad
{
    // Create a tab bar and set it as root view for the application
    [self hideProgressHud];
    maleOrFemale = @"M";
    
//    roundedBtnPost.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnPost.layer.borderWidth = 1.0f;
    roundedBtnPost.clipsToBounds=YES;
    roundedBtnPost.layer.cornerRadius = 5;        
    self.title = @"Add Comment";
    [self setTitle:@"Add Comment"];
//    int height = self.navigationController.navigationBar.frame.size.height;
//    int width = self.navigationController.navigationBar.frame.size.width;
//    
//    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
//    [navLabel setText:@"Add Comment"];
//    navLabel.textColor = [UIColor whiteColor];
//    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
//    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
//    navLabel.textAlignment = NSTextAlignmentCenter;
//    self.navigationItem.titleView = navLabel;
    
    // Init views with rects with height and y pos
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationItem.titleView = titleView;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,800)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1600)];
    }
    
    [txtFieldAddComment setReturnKeyType:UIReturnKeyDone];
    
    txtFieldAddComment.delegate = self;
    txtFieldAddComment.tag = 1;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
}


#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
        
        
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}



- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnSaveClicked:(id)sender{
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    [dataDictionary setObject:txtfield1.text forKey:kVP];
    //    [dataDictionary setObject:txtfield2.text forKey:kAP];
    //    [dataDictionary setObject:txtfield3.text forKey:kBF];
    //    [dataDictionary setObject:txtfield4.text forKey:kKTV];
    //    [dataDictionary setObject:txtfield5.text forKey:kSystolic];
    //    [dataDictionary setObject:txtfield7.text forKey:kDryWeight];
    //    [dataDictionary setObject:txtfield8.text forKey:kFluidGain];
    //    [dataDictionary setObject:txtfield9.text forKey:kHB];
    //    [dataDictionary setObject:txtfield10.text forKey:kBun];
    //    [dataDictionary setObject:txtfield11.text forKey:kCR];
    //    [dataDictionary setObject:txtfield12.text forKey:kAlbiumin];
    //    [dataDictionary setObject:txtfield13.text forKey:kPhosph];
    //    [dataDictionary setObject:txtfield14.text forKey:kPTH];
    //    [dataDictionary setObject:txtfield15.text forKey:kKT];
    //    [dataDictionary setObject:txtfield16.text forKey:kINR];
    //    [dataDictionary setObject:selectedDate forKey:kDate];
    
    [self.navigationController popViewControllerAnimated:YES];
}



- (IBAction)btnPostPressed:(id)sender {
}

- (IBAction)btnSendMessageClicked:(id)sender {
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    
    }
    else if (tag == 5)
    {
        
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnComposeMessageClicked:(id)sender {
}

- (IBAction)btnRsvpStyleClicked:(id)sender {
}

- (IBAction)btnInviteGuestClicked:(id)sender {
}
#pragma mark TextFileds Editing ***********************TEXTFIELD************
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtFieldAddComment){
        [txtFieldAddComment resignFirstResponder];
    }
    
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 2;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}

- (void)nextClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [txtFieldAddComment resignFirstResponder];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    switch (sender){
            
        case 1: {
            [txtFieldAddComment resignFirstResponder];
        }
            break;
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
     [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([txtFieldAddComment isFirstResponder]) {
                [txtFieldAddComment resignFirstResponder];
            }
        }
            break;
        default: {
        }
            break;
    }
}

////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
@end
