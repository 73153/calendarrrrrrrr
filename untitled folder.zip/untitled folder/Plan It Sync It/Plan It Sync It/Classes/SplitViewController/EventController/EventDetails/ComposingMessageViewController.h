//
//  ComposingMessageViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 18/3/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
#import "IQDropDownTextField.h"
@interface ComposingMessageViewController : UIViewController<UITabBarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CustomKeyboardDelegate,UITextFieldDelegate,IQDropDownTextFieldDelegate,UITextViewDelegate>
{
    CustomKeyboard *customKeyboard;
    BOOL isSendMeCopy;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSendMessage;

@property (nonatomic) UIImagePickerController *imagePickerController;
@property (weak, nonatomic) IBOutlet UIButton *btnCheckBoxSendMeCopy;
@property (weak, nonatomic) IBOutlet IQDropDownTextField *txtFieldDropDown;

@property (weak, nonatomic) IBOutlet UITextField *txtFieldSubject;
@property (weak, nonatomic) IBOutlet UITextView *txtViewMessage;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
- (IBAction)btnSendMeCopyClicked:(id)sender;

- (IBAction)btnSendMessageClicked:(id)sender ;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;


- (void) showProgressHud;
- (void) hideProgressHud;


@end
