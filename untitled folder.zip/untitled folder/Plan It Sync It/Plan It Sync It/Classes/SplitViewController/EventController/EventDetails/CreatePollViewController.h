//
//  CreatePollViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 18/3/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
@interface CreatePollViewController : UIViewController<UITabBarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CustomKeyboardDelegate,UITextFieldDelegate>
{
    CustomKeyboard *customKeyboard;
    CGPoint txtItemNamePos;
    CGPoint btnDeletePos;
    CGSize txtItemNameSize;
    CGSize btnDeleteSize;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (nonatomic, strong) IBOutlet UITextField *txtPollTitle;
@property (nonatomic) UIImagePickerController *imagePickerController;
@property (weak, nonatomic) IBOutlet UITextField *txtItemName;
@property (weak, nonatomic) IBOutlet UIButton *btnDelete;
@property (weak, nonatomic) IBOutlet UITextField *txtYourQuestion;
- (IBAction)buttonDeltePressed:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *roundedBtnAddOtherItem;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnPost;

@property (nonatomic) int itemsCount;

@property (weak, nonatomic) IBOutlet UIButton *editButton;
@property (nonatomic, strong) IBOutlet UIButton *deleteButton;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
- (IBAction)btnAddOtherItemClicked:(id)sender;
- (IBAction)btnPostClicked:(id)sender;


- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;

- (void) showProgressHud;
- (void) hideProgressHud;


@end
