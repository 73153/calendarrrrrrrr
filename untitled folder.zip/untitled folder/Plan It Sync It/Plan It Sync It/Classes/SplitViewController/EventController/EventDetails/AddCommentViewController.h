//
//  AddCommentViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
@interface AddCommentViewController : UIViewController<UITabBarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CustomKeyboardDelegate,UITextFieldDelegate>
{
    CustomKeyboard *customKeyboard;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnPost;

@property (nonatomic) UIImagePickerController *imagePickerController;

@property (weak, nonatomic) IBOutlet UITextField *txtFieldAddComment;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;

- (IBAction)btnPostPressed:(id)sender;

- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *btnManageGuestClicked;


- (void) showProgressHud;
- (void) hideProgressHud;


@end
