//
//  RSVPViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "RSVPViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "EditProfileViewController.h"
#import "MBProgressHUD.h"
#import "InboxMessageViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "DateHandler.h"

@interface RSVPViewController ()
{
    NSString *maleOrFemale;
    
}

@end

@implementation RSVPViewController
@synthesize txtRSVP;
@synthesize txtMayBe;
@synthesize txtYes;
@synthesize txtWhosComing;
@synthesize scrollView;
@synthesize txtNo;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnSaveIt;
-(void)viewDidLoad
{
    // Create a tab bar and set it as root view for the application
    [self hideProgressHud];
    maleOrFemale = @"M";
    
//    roundedBtnSaveIt.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnSaveIt.layer.borderWidth = 2.0f;
    roundedBtnSaveIt.clipsToBounds=YES;
    roundedBtnSaveIt.layer.cornerRadius = 5;
    [self setTitle:@"RSVP"];
    int height = self.navigationController.navigationBar.frame.size.height;
    int width = self.navigationController.navigationBar.frame.size.width;
    
    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    [navLabel setText:@"RSVP"];
    navLabel.textColor = [UIColor whiteColor];
    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    navLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = navLabel;
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,500)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1600)];
    }
    
    txtRSVP.delegate=self;
    
    [txtWhosComing setReturnKeyType:UIReturnKeyNext];
    [txtYes setReturnKeyType:UIReturnKeyNext];
    [txtMayBe setReturnKeyType:UIReturnKeyNext];
    [txtNo setReturnKeyType:UIReturnKeyDone];
    
    txtRSVP.delegate=self;
    txtWhosComing.delegate=self;
    txtYes.delegate = self;
    txtMayBe.delegate=self;
    txtNo.delegate = self;
    
    txtRSVP.tag=1;
    txtWhosComing.tag=2;
    txtYes.tag = 3;
    txtMayBe.tag=4;
    txtNo.tag=5;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    UIToolbar *toolbar = [[UIToolbar alloc] init];
    [toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [toolbar sizeToFit];
    UIBarButtonItem *buttonflexible = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *buttonDone = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneClicked:)];
    
    //    textFieldTextPicker.inputAccessoryView = toolbar;
    //    [textFieldTextPicker setItemList:[NSArray arrayWithObjects:@"London",@"Johannesburg",@"Moscow",@"Mumbai",@"Tokyo",@"Sydney", nil]];
    
    [toolbar setItems:[NSArray arrayWithObjects:buttonflexible,buttonDone, nil]];
    
    txtRSVP.inputAccessoryView = toolbar;
    
    [txtRSVP setItemList:[NSArray arrayWithObjects:@"Custom Style",@"Default",@"Blackjack",@"Poker",@"Wedding",@"Shakespeare",@"Birthday", nil]];
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
}

-(void)textField:(IQDropDownTextField*)textField didSelectItem:(NSString*)item//Called when textField changes it's selected item.
{
    txtYes.text = @"";
    txtMayBe.text = @"";
    txtWhosComing.text = @"";
    txtNo.text = @"";
    
    if([item isEqualToString:@"Custom Style"]){
        [txtYes setEnabled:true];
        [txtMayBe setEnabled:true];
        [txtNo setEnabled:true];
        [txtWhosComing setEnabled:true];
        
        [txtYes setPlaceholder:@""];
        [txtMayBe setPlaceholder:@""];
        [txtWhosComing setPlaceholder:@""];
        [txtNo setPlaceholder:@""];
    }
    else if([item isEqualToString:@"Default"]){
        [txtYes setEnabled:false];
        [txtMayBe setEnabled:false];
        [txtWhosComing setEnabled:false];
        [txtNo setEnabled:false];
        
        [txtYes setPlaceholder:@"Yes"];
        [txtMayBe setPlaceholder:@"Maybe"];
        [txtWhosComing setPlaceholder:@"Who's Coming?"];
        [txtNo setPlaceholder:@"No"];

    }
    
    else if([item isEqualToString:@"Blackjack"]){
        [txtYes setEnabled:false];
        [txtMayBe setEnabled:false];
        [txtWhosComing setEnabled:false];
        [txtNo setEnabled:false];
        
        [txtYes setPlaceholder:@"Hit"];
        [txtMayBe setPlaceholder:@"Stand"];
        [txtWhosComing setPlaceholder:@"Who's Hitting?"];
        [txtNo setPlaceholder:@"Bust"];
    }
    else if([item isEqualToString:@"Poker"]){
        [txtYes setEnabled:false];
        [txtMayBe setEnabled:false];
        [txtWhosComing setEnabled:false];
        [txtNo setEnabled:false];
        
        [txtYes setPlaceholder:@"All In"];
        [txtMayBe setPlaceholder:@"Time"];
        [txtWhosComing setPlaceholder:@"What's your action?"];
        [txtNo setPlaceholder:@"Fold"];
        
    }
    else if([item isEqualToString:@"Wedding"]){
        [txtYes setEnabled:false];
        [txtMayBe setEnabled:false];
        [txtWhosComing setEnabled:false];
        [txtNo setEnabled:false];
        
        [txtYes setPlaceholder:@"I Do"];
        [txtMayBe setPlaceholder:@"Still Engaged"];
        [txtWhosComing setPlaceholder:@"Who's attending?"];
        [txtNo setPlaceholder:@"Cold Feet"];
        
    }
    else if([item isEqualToString:@"Shakespeare"]){
        [txtYes setEnabled:false];
        [txtMayBe setEnabled:false];
        [txtWhosComing setEnabled:false];
        [txtNo setEnabled:false];
        
        [txtYes setPlaceholder:@"To Be"];
        [txtMayBe setPlaceholder:@"That is the question"];
        [txtWhosComing setPlaceholder:@"Though Commeth?"];
        [txtNo setPlaceholder:@"Not To Be"];
        
    }
    else if([item isEqualToString:@"Birthday"]){
        [txtYes setEnabled:false];
        [txtMayBe setEnabled:false];
        [txtWhosComing setEnabled:false];
        [txtNo setEnabled:false];
        
        [txtYes setPlaceholder:@"I want cake"];
        [txtMayBe setPlaceholder:@"Still wishing"];
        [txtWhosComing setPlaceholder:@"Who's Invited?"];
        [txtNo setPlaceholder:@"No cake for me"];
    }
    else
    {
        [txtYes setEnabled:false];
        [txtMayBe setEnabled:false];
        [txtWhosComing setEnabled:false];
        [txtNo setEnabled:false];
        
        [txtYes setPlaceholder:@"Yes"];
        [txtMayBe setPlaceholder:@"Maybe"];
        [txtWhosComing setPlaceholder:@"Who's Coming?"];
        [txtNo setPlaceholder:@"No"];

    }
}
#pragma mark TextFileds Editing ***********************TEXTFIELD************
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if(textField == txtRSVP){
        [txtRSVP resignFirstResponder];
        [txtWhosComing becomeFirstResponder];
    }
    else if(textField== txtWhosComing)
    {
        [txtWhosComing resignFirstResponder];
        [txtYes becomeFirstResponder];
    }
    else if(textField == txtYes){
        [txtYes resignFirstResponder];
        [txtMayBe becomeFirstResponder];
    }
    else if(textField == txtMayBe){
        [txtMayBe resignFirstResponder];
        [txtNo becomeFirstResponder];
    }
    else if(textField == txtNo){
        [txtNo resignFirstResponder];
    }
    
    
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 5;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}

- (void)nextClicked:(NSUInteger)sender {
    
    switch (sender){
        case 1: {
            [txtRSVP resignFirstResponder];
            [txtWhosComing becomeFirstResponder];
        }
            break;
        case 2: {
            [txtWhosComing resignFirstResponder];
            [txtYes becomeFirstResponder];
        }
            break;
            
        case 3: {
            [txtYes resignFirstResponder];
            [txtMayBe becomeFirstResponder];
        }
            break;
        case 4: {
            [txtMayBe resignFirstResponder];
            [txtNo becomeFirstResponder];
        }
            break;
        case 5: {
            [txtNo resignFirstResponder];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    
    switch (sender){
            
        case 1: {
            [txtRSVP resignFirstResponder];
        }
            break;
        case 2: {
            [txtRSVP becomeFirstResponder];
            [txtWhosComing resignFirstResponder];
        }
            break;
        case 3: {
            [txtWhosComing becomeFirstResponder];
            [txtYes resignFirstResponder];
        }
            break;
        case 4: {
            [txtYes becomeFirstResponder];
            [txtMayBe resignFirstResponder];
        }
            break;
        case 5: {
            [txtMayBe becomeFirstResponder];
            [txtNo resignFirstResponder];
        }
            break;
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
     [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([txtRSVP isFirstResponder]) {
                [txtRSVP resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([txtWhosComing isFirstResponder]) {
                [txtWhosComing resignFirstResponder];
            }
        }
            break;
        case 3: {
            if ([txtYes isFirstResponder]) {
                [txtYes resignFirstResponder];
            }
        }
            break;
        case 4: {
            if ([txtMayBe isFirstResponder]) {
                [txtMayBe resignFirstResponder];
            }
        }
            break;
        case 5: {
            if ([txtNo isFirstResponder]) {
                [txtNo resignFirstResponder];
            }
        }
            break;
        default: {
        }
            break;
    }
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnSaveClicked:(id)sender{
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    [dataDictionary setObject:txtfield1.text forKey:kVP];
    //    [dataDictionary setObject:txtfield2.text forKey:kAP];
    //    [dataDictionary setObject:txtfield3.text forKey:kBF];
    //    [dataDictionary setObject:txtfield4.text forKey:kKTV];
    //    [dataDictionary setObject:txtfield5.text forKey:kSystolic];
    //    [dataDictionary setObject:txtfield7.text forKey:kDryWeight];
    //    [dataDictionary setObject:txtfield8.text forKey:kFluidGain];
    //    [dataDictionary setObject:txtfield9.text forKey:kHB];
    //    [dataDictionary setObject:txtfield10.text forKey:kBun];
    //    [dataDictionary setObject:txtfield11.text forKey:kCR];
    //    [dataDictionary setObject:txtfield12.text forKey:kAlbiumin];
    //    [dataDictionary setObject:txtfield13.text forKey:kPhosph];
    //    [dataDictionary setObject:txtfield14.text forKey:kPTH];
    //    [dataDictionary setObject:txtfield15.text forKey:kKT];
    //    [dataDictionary setObject:txtfield16.text forKey:kINR];
    //    [dataDictionary setObject:selectedDate forKey:kDate];
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnAddCommentClicked:(id)sender {
}

- (IBAction)btnPostPressed:(id)sender {
}

- (IBAction)btnSendMessageClicked:(id)sender {
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnComposeMessageClicked:(id)sender {
}

- (IBAction)btnRsvpStyleClicked:(id)sender {
}

- (IBAction)btnInviteGuestClicked:(id)sender {
}



-(void)doneClicked:(UIBarButtonItem*)button
{
    [self.view endEditing:YES];
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
@end
