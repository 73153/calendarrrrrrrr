//
//  AskWhatToBringViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 18/3/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "AskWhatToBringViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "EditProfileViewController.h"
#import "MBProgressHUD.h"
#import "InboxMessageViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "DateHandler.h"

@interface AskWhatToBringViewController ()
{
    NSString *maleOrFemale;
    
}

@end

@implementation AskWhatToBringViewController

@synthesize scrollView;
@synthesize txtWhatToBringTitle;
@synthesize txtItemName;
@synthesize txtQuantity;
@synthesize itemsCount;
@synthesize btnDelete;
@synthesize roundedBtnbtnAddOtherItem;
@synthesize roundedBtnbtnPost;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;

-(void)viewDidLoad
{
    // Create a tab bar and set it as root view for the application
    [self hideProgressHud];
    maleOrFemale = @"M";
    txtItemNamePos=txtItemName.frame.origin;
    btnDeletePos=btnDelete.frame.origin;
    txtQuantityPos=txtQuantity.frame.origin;
    txtItemNameSize = txtItemName.frame.size;
    btnDeleteSize = btnDelete.frame.size;
    txtQuantitySize = txtQuantity.frame.size;
    
//    roundedBtnbtnAddOtherItem.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnbtnAddOtherItem.layer.borderWidth = 2.0f;
    roundedBtnbtnAddOtherItem.clipsToBounds=YES;
    roundedBtnbtnAddOtherItem.layer.cornerRadius = 5;
    
//    roundedBtnbtnPost.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnbtnPost.layer.borderWidth = 2.0f;
    roundedBtnbtnPost.clipsToBounds=YES;
    roundedBtnbtnPost.layer.cornerRadius = 5;
    
    [self setTitle:@"What To Bring"];
    
    int height = self.navigationController.navigationBar.frame.size.height;
    int width = self.navigationController.navigationBar.frame.size.width;
    
    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    [navLabel setText:@"What To Bring"];
    navLabel.textColor = [UIColor whiteColor];
    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    navLabel.textAlignment = NSTextAlignmentCenter;[txtWhatToBringTitle setReturnKeyType:UIReturnKeyDone];
    
    txtWhatToBringTitle.delegate = self;
    txtWhatToBringTitle.tag = 1;
    itemsCount=1;
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    //    [txtEventMainTitle sizeToFit];
}

- (IBAction)btnAddCommentClicked:(id)sender {
}


- (IBAction)btnAddOtherItemClicked:(id)sender {
    
    int x = txtItemNamePos.x;
    int y = txtItemNamePos.y+(38*itemsCount);
    int x1 = txtQuantityPos.x;
    
    UITextField *txtItemName1 = [[UITextField alloc] initWithFrame:(CGRectMake(txtItemNamePos.x, txtItemNamePos.y+(38*itemsCount),txtItemNameSize.width, txtItemNameSize.height))];
    [txtItemName1 setPlaceholder:@"Item Name"];
    NSLog(@"txtItemName1 pos x = %d and Pos y = %d",x,y);
    [scrollView addSubview:txtItemName1];
    [txtItemName1 setTag:1001+1+itemsCount];
    
    [txtItemName1 setBackgroundColor:[UIColor whiteColor]];
    [txtItemName1.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [txtItemName1.layer setBorderWidth:0.5];
    txtItemName1.layer.cornerRadius = 5;
    
    UITextField *txtQty = [[UITextField alloc] initWithFrame:(CGRectMake(txtQuantityPos.x, txtQuantityPos.y+(38*itemsCount), txtQuantitySize.width, txtQuantitySize.height))];
    NSLog(@"txtQty pos x = %d and Pos y = %d",x1,y);
    [txtQty setPlaceholder:@"Qty"];
    [txtQty setTag:2001+1+itemsCount];
    
    [txtQty setBackgroundColor:[UIColor whiteColor]];
    [txtQty.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [txtQty.layer setBorderWidth:0.5];
    txtQty.layer.cornerRadius = 5;
    
    [scrollView addSubview:txtQty];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setFrame:CGRectMake(btnDeletePos.x, btnDeletePos.y+(38*itemsCount),  btnDeleteSize.width, btnDeleteSize.height)];
    [button setTag:3001+1+itemsCount];
    [button setImage:[UIImage imageNamed:@"delete_Icon.png"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(buttonDeltePressed:) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:button];
    
    
    [roundedBtnbtnPost setFrame:CGRectMake(roundedBtnbtnPost.frame.origin.x, roundedBtnbtnPost.frame.origin.y+36,  roundedBtnbtnPost.frame.size.width, roundedBtnbtnPost.frame.size.height)];
    [roundedBtnbtnAddOtherItem setFrame:CGRectMake(roundedBtnbtnAddOtherItem.frame.origin.x,roundedBtnbtnAddOtherItem.frame.origin.y+36,  roundedBtnbtnAddOtherItem.frame.size.width, roundedBtnbtnAddOtherItem.frame.size.height)];
    
    [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,scrollView.frame.size.height+(38*itemsCount))];
    itemsCount++;
    
}

- (IBAction)buttonDeltePressed:(id)sender {
    
    NSInteger index = [sender tag];
    
    itemsCount--;
    UITextField *txtItemName1 = (UITextField*)[self.view viewWithTag:index-2000];
    UITextField *txtQty = (UITextField*)[self.view viewWithTag:index-1000];
    
    int txtName_Y_Pos = txtItemName1.frame.origin.y;
    int txtQty_Y_Pos = txtQty.frame.origin.y;
    
    //    for (int a=index-3000; a>itemsCount; a++) {
    //        UITextField *txtItemName1 = (UITextField*)[self.view viewWithTag:a+2000];
    //        [txtItemName1 setFrame:CGRectMake(btnDelete.frame.origin.x, btnDelete.frame.origin.y+(38*itemsCount),  btnDelete.frame.size.width, btnDelete.frame.size.height)];
    //        UITextField *txtQty = (UITextField*)[self.view viewWithTag:a+1000];
    //
    //        //        NSString *fieldValue = textField.text;
    //        //        NSLog(@"Field %d has value: %@", a, fieldValue);
    //    }
    
    [txtItemName1 removeFromSuperview];
    [txtQty removeFromSuperview];
    [sender removeFromSuperview];
    
    [roundedBtnbtnPost setFrame:CGRectMake(roundedBtnbtnPost.frame.origin.x, roundedBtnbtnPost.frame.origin.y-36,  roundedBtnbtnPost.frame.size.width, roundedBtnbtnPost.frame.size.height)];
    [roundedBtnbtnAddOtherItem setFrame:CGRectMake(roundedBtnbtnAddOtherItem.frame.origin.x,roundedBtnbtnAddOtherItem.frame.origin.y-36,  roundedBtnbtnAddOtherItem.frame.size.width, roundedBtnbtnAddOtherItem.frame.size.height)];
    [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,scrollView.frame.size.height+(38*itemsCount))];
    
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
        
        //        navigationController.viewControllers = @[secondViewController];
        
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}





- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnSaveClicked:(id)sender{
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    [dataDictionary setObject:txtfield1.text forKey:kVP];
    //    [dataDictionary setObject:txtfield2.text forKey:kAP];
    //    [dataDictionary setObject:txtfield3.text forKey:kBF];
    //    [dataDictionary setObject:txtfield4.text forKey:kKTV];
    //    [dataDictionary setObject:txtfield5.text forKey:kSystolic];
    //    [dataDictionary setObject:txtfield7.text forKey:kDryWeight];
    //    [dataDictionary setObject:txtfield8.text forKey:kFluidGain];
    //    [dataDictionary setObject:txtfield9.text forKey:kHB];
    //    [dataDictionary setObject:txtfield10.text forKey:kBun];
    //    [dataDictionary setObject:txtfield11.text forKey:kCR];
    //    [dataDictionary setObject:txtfield12.text forKey:kAlbiumin];
    //    [dataDictionary setObject:txtfield13.text forKey:kPhosph];
    //    [dataDictionary setObject:txtfield14.text forKey:kPTH];
    //    [dataDictionary setObject:txtfield15.text forKey:kKT];
    //    [dataDictionary setObject:txtfield16.text forKey:kINR];
    //    [dataDictionary setObject:selectedDate forKey:kDate];
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (IBAction)btnPostClicked:(id)sender {
}


- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}



- (IBAction)btnComposeMessageClicked:(id)sender {
}

- (IBAction)btnRsvpStyleClicked:(id)sender {
}

- (IBAction)btnInviteGuestClicked:(id)sender {
}


#pragma mark TextFileds Editing ***********************TEXTFIELD************
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtWhatToBringTitle){
        [txtWhatToBringTitle resignFirstResponder];
    }
    
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 2;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}

- (void)nextClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [txtWhatToBringTitle resignFirstResponder];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    switch (sender){
            
        case 1: {
            [txtWhatToBringTitle resignFirstResponder];
        }
            break;
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
     [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([txtWhatToBringTitle isFirstResponder]) {
                [txtWhatToBringTitle resignFirstResponder];
            }
        }
            break;
        default: {
        }
            break;
    }
}
////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
@end
