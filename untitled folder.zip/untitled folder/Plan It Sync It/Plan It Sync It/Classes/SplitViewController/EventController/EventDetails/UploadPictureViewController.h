//
//  UploadPictureViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
#import "PECropViewController.h"
@interface UploadPictureViewController : UIViewController<UITabBarDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CustomKeyboardDelegate,UITextViewDelegate, PECropViewControllerDelegate, UIActionSheetDelegate>
{
    CustomKeyboard *customKeyboard;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSelectPhoto;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnPost;


@property (nonatomic) UIImagePickerController *imagePickerController;
@property (nonatomic, strong) IBOutlet UITextField *txtAddComment;
@property (weak, nonatomic) IBOutlet UIImageView *userImageView;
@property (nonatomic, strong) UIPopoverController *imagePickerPopoverController;


- (IBAction)btnAddCommentClicked:(id)sender;
- (IBAction)btnPostClicked:(id)sender;
- (IBAction)btnSelectPhotoClicked:(id)sender;

- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;


- (void) showProgressHud;
- (void) hideProgressHud;


@end
