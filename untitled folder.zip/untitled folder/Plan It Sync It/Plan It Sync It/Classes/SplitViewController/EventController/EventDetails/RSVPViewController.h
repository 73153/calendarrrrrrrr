//
//  RSVPViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
#import "IQDropDownTextField.h"
@interface RSVPViewController : UIViewController<UITabBarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CustomKeyboardDelegate,UITextFieldDelegate,IQDropDownTextFieldDelegate>
{
    CustomKeyboard *customKeyboard;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSaveIt;

@property (nonatomic) UIImagePickerController *imagePickerController;

@property (weak, nonatomic) IBOutlet IQDropDownTextField *txtRSVP;
@property (weak, nonatomic) IBOutlet UITextField *txtNo;

@property (weak, nonatomic) IBOutlet UITextField *txtMayBe;
@property (weak, nonatomic) IBOutlet UITextField *txtYes;
@property (weak, nonatomic) IBOutlet UITextField *txtWhosComing;
@property (weak, nonatomic) IBOutlet UIButton *editButton;
@property (nonatomic, strong) IBOutlet UIButton *deleteButton;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
-(void)textField:(IQDropDownTextField*)textField didSelectItem:(NSString*)item; //Called when textField changes it's selected item.

- (IBAction)btnAddCommentClicked:(id)sender;
- (IBAction)btnPostPressed:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnSaveClicked;

- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnManageGuestClicked;


- (void) showProgressHud;
- (void) hideProgressHud;


@end
