//
//  EditEventsViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "IQDropDownTextField.h"
#import "CustomKeyboard.h"
#import "SearchViewController.h"
#import "UMTableViewCell.h"

@interface EditEventsViewController : UIViewController<UITabBarDelegate,UITextFieldDelegate,CustomKeyboardDelegate,IQDropDownTextFieldDelegate,UITextViewDelegate,SearchDelegate,UITableViewDelegate,UITableViewDataSource>
{
    CustomKeyboard *customKeyboard;
    BOOL isDate1Clicked;
    BOOL isDate2Clicked;
    
    BOOL isTime1Clicked;
    BOOL isTime2Clicked;

    BOOL isWholeDayEvent;
    BOOL isDisableRSVP;
    BOOL isRecurringYes;
    BOOL IsRemainderYes;
    BOOL isSetEstimateTravelTime;
    BOOL isRecurringDatePickerOpened;
    BOOL isMondayChecked;
    BOOL isTuesdayChecked;
    BOOL isWednesdayChecked;
    BOOL isThursdayChecked;
    BOOL isFridayChecked;
    BOOL issaturdayChecked;
    BOOL isSundayChecked;
    CGRect btnRecurringDoneRect;
    
}

@property (nonatomic, strong) SearchViewController *searchTableController;


@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (nonatomic, strong) IBOutlet UIButton *btnBack;
@property (nonatomic, strong) IBOutlet UIButton *btnSave;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) NSDate *selectedDate;


@property (nonatomic, strong) NSDictionary *oldDictionary;
@property (weak, nonatomic) IBOutlet UIView *timerPickerBackgroundView;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSaveIt;

@property (nonatomic, strong) IBOutlet UIView *pickerBackGroundView;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarCancel;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarDone;

@property (nonatomic, strong) IBOutlet UIBarButtonItem *timerbtnBarCancel;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *timerbtnBarDone;
@property (nonatomic, strong) IBOutlet UILabel  *lblDate1;
@property (nonatomic, strong) IBOutlet UILabel  *lblDate2;
@property (nonatomic, strong) IBOutlet UILabel  *lblTime1;
@property (nonatomic, strong) IBOutlet UILabel  *lblTime2;
-(void)textField:(IQDropDownTextField*)textField didSelectItem:(NSString*)item; //Called when textField changes it's selected item.
@property (weak, nonatomic) IBOutlet UIImageView *userImage;


@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;
@property (nonatomic, strong) IBOutlet UIDatePicker *timerPicker;

@property (nonatomic, strong) IBOutlet UIButton *btnRecurringYes;
@property (nonatomic, strong) IBOutlet UIButton *btnRecurringNo;

@property (nonatomic, strong) IBOutlet UIButton *btnRemainderYes;
@property (nonatomic, strong) IBOutlet UIButton *btnRemainderNo;

@property (nonatomic, strong) IBOutlet UIButton *btnEstimateTravelTime;

@property (nonatomic, strong) IBOutlet UIButton *btnDisableRSVPDeadLine
;
@property(nonatomic, readwrite) BOOL isDataFromWebservice;
@property (weak, nonatomic) IBOutlet UIButton *btnUserImage;
@property (nonatomic, strong) IBOutlet UIButton *btnWholedayEvent;
@property (nonatomic, strong) IBOutlet UIButton *btnTimedEvent;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectRSVPDate;
@property (weak, nonatomic) IBOutlet UILabel *staticLableStartTime;
@property (weak, nonatomic) IBOutlet UILabel *staticLableEndTime;

@property (nonatomic, strong) NSMutableArray *allRecordArray;

@property (weak, nonatomic) IBOutlet UIButton *btnSelectStartDate;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectEndDate;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectStartTime;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectEndTime;
@property (weak, nonatomic) IBOutlet UILabel *lblSetTravelTime;
@property (weak, nonatomic) IBOutlet UILabel *lblPrivacy;
@property (weak, nonatomic) IBOutlet UILabel *lblSelectRSVPDate;
- (IBAction)changeDateRSVPClicked:(id)sender;

- (IBAction)toogleCheckBoxDisableRSVP:(id)sender;

- (IBAction)toggleRadioButtonRecurringYes:(id)sender;
- (IBAction)toggleRadioButtonRemainderYes:(id)sender;
- (IBAction)toggleRadioButtonRecurringNo:(id)sender;
- (IBAction)toggleRadioButtonRemainderNo:(id)sender;


- (IBAction)toggleRadioButtonEstimateTravelTime:(id)sender;
- (IBAction)toggleRadioButtonTimedEvent:(id)sender;


- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnSaveClicked:(id)sender;

- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;


- (IBAction)timerCancelButtonClicked:(id)sender;
- (IBAction)timerDoneButtonClicked:(id)sender;


- (IBAction)changeTimeButton1Clicked:(id)sender;
- (IBAction)changeTime2ButtonClicked:(id)sender;

- (IBAction)changeDateButton1Clicked:(id)sender;
- (IBAction)changeDate2ButtonClicked:(id)sender;

@property (nonatomic, strong) NSString *selectedKey;
@property (nonatomic, strong) NSString *selectedScale;

-(void)openTimePickerAnimation;
- (void) showProgressHud;
- (void) hideProgressHud;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnDonePressForRecurringView:(id)sender;

@property (weak, nonatomic) IBOutlet UIView *recurringUiViewVisblity;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldTypeOfEvent;
@property (nonatomic, strong) IBOutlet UITextField *textFieldType;
@property (nonatomic, strong) IBOutlet UITextField *textFieldName;
@property (nonatomic, strong) IBOutlet UITextField *textFieldNotes;
@property (nonatomic, strong) IBOutlet UILabel *lblTotalDuration;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldTime;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldLocation;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldPrivacy;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnConflictSaveIt;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnConflictCancel;

/* ********* Scheduling Conflict view ************** */
@property (weak, nonatomic) IBOutlet UIView *schedulingConflictPopUpView;
@property (nonatomic, strong) NSMutableArray *scheduleConflictArray;
@property (weak, nonatomic) IBOutlet UILabel *lblSchedulingConflict;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
- (IBAction)btnScheduleConflictCancelClicked:(id)sender;
- (IBAction)btnScheduleConflictOklClicked:(id)sender;

@property (weak, nonatomic) IBOutlet UIScrollView *recurringScrollView;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldRecurringType;
@property (weak, nonatomic) IBOutlet UITextField *textFieldRecurringNumberOFTimes;
@property (weak, nonatomic) IBOutlet IQDropDownTextField *txtRemainderEmailAndNotification;

@property (weak, nonatomic) IBOutlet UILabel *lblRecurringDate;
- (IBAction)recurringDatePickerClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnRecurringForEver;
@property (weak, nonatomic) IBOutlet UIButton *btnRecurringNumberOfTimes;
@property (weak, nonatomic) IBOutlet UIButton *btnRecurringEndDate;
- (IBAction)toggleRadioButtonEndDate:(id)sender;
- (IBAction)toggleRadioButtonForEver:(id)sender;
- (IBAction)toggleRadioButtonNumberOfTimes:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *recurringWeekView;
- (IBAction)weeklyCheboxClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnMonday;
@property (weak, nonatomic) IBOutlet UIButton *btnTuesday;
@property (weak, nonatomic) IBOutlet UIButton *btnWednesday;
@property (weak, nonatomic) IBOutlet UIButton *btnThursday;
@property (weak, nonatomic) IBOutlet UIButton *btnFriday;
@property (weak, nonatomic) IBOutlet UIButton *btnSaturday;
@property (weak, nonatomic) IBOutlet UIButton *btnsunday;
@property (weak, nonatomic) IBOutlet UIButton *btnRecurringDateForBorder;

@property (nonatomic, strong) NSMutableArray *categoryIdArray;
@property (nonatomic, strong) NSMutableArray *categoryNameArray;
@property (nonatomic, strong) NSString *typeOfEvenetStorageStr;


@property (weak, nonatomic) IBOutlet UIButton *btnDoneForBorderClipping;
- (IBAction)btnRemainderDoneClicked:(id)sender;
@property (weak, nonatomic) IBOutlet IQDropDownTextField *txtRemainderOneDayPrior;
@property (weak, nonatomic) IBOutlet UIButton *btnRemainderDayForBordering;
@property (weak, nonatomic) IBOutlet UIButton *btnRemainderHourForBordering;
@property (weak, nonatomic) IBOutlet UIButton *btnRemainderMinForBordering;
- (IBAction)btnRemainderDayPickerClicked:(id)sender;
- (IBAction)btnRemainderHourPickerClicked:(id)sender;
- (IBAction)btnRemainderMinuteClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *txtHours;
@property (weak, nonatomic) IBOutlet UITextField *txtMinutes;

@property(nonatomic,readwrite)NSString *existingEnentIdString;

@property (weak, nonatomic) IBOutlet IQDropDownTextField *txtRemainderHour1;
@property (weak, nonatomic) IBOutlet IQDropDownTextField *txtRemainderMin1;
@property (weak, nonatomic) IBOutlet IQDropDownTextField *txtRemainderDay1;
@property (weak, nonatomic) IBOutlet UIView *viewRemainderHideSowForOneDayPrior;
@property (weak, nonatomic) IBOutlet UIView *remainderMainViewhideShow;
@property (weak, nonatomic) IBOutlet UIScrollView *remainderScrollView;
@property (weak, nonatomic) IBOutlet UIButton *btnRecurringDoneForBordering;

@property (weak, nonatomic) IBOutlet UITextField *txtSourceLocationPlaceApi;
- (IBAction)btnUserImageClicked:(id)sender;


- (void) addEventSuccess:(NSNotification *)notification;
- (void) addEventFailed:(NSNotification *)notification;
- (void) editEventSuccess:(NSNotification *)notification;
- (void) editEventFailed:(NSNotification *)notification;
- (void) getEditSingleEventSuccess:(NSNotification *)notification;
- (void) getEditSingleEventFailed:(NSNotification *)notification;
- (void) getListOfCategorySuccess:(NSNotification *)notification;
- (void) getListOfCategoryFailed:(NSNotification *)notification;
- (void) getListOfLocationSuccess:(NSNotification *)notification;
- (void) getListOfLocationFailed:(NSNotification *)notification;

-(void)hideKeyBoardOnDateAndTimeClick;


@end
