//
//  EventsListViewController.h
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
#import "CTCheckbox.h"
@class CTCheckbox;

@interface EventsListViewController : UIViewController <UITabBarDelegate, SWTableViewCellDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchDisplayDelegate,CTCheckboxDelegate>
{
    NSMutableArray *deletedContactArray;
    
    UIBarButtonItem *barButtonItem;
    
    BOOL isSearchAndDelete;
    BOOL isSelectAllPressed;
}

@property (weak, nonatomic) IBOutlet UILabel *deleteHeaderLbl;
@property (weak, nonatomic) IBOutlet UIButton *btnDeleteOnlyThisInstanceRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnDeleteAllFollowingRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnDeleteAllInstancesRoundedCorner;
@property (weak, nonatomic) IBOutlet UILabel *deleteAllInstanceLbl;

@property (weak, nonatomic) IBOutlet UILabel *deleteAllotherLbl;
@property (weak, nonatomic) IBOutlet UILabel *deleteAllFollowingLbl;
@property (weak, nonatomic) IBOutlet UIView *deletePopUpView;
@property (weak, nonatomic) IBOutlet UIButton *deleteCloseBtnRoundedCorner;

- (IBAction)deleteCloseButtonClicked:(id)sender;
- (IBAction)btnDeleteOnlyThisIntanceClicked:(id)sender;
- (IBAction)btnDeleteAlFollowingIntanceClicked:(id)sender;
- (IBAction)btnDeleteAll_IntanceClicked:(id)sender;


@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnNewEvent;

@property (weak, nonatomic) IBOutlet UILabel *labelNoRecordFound;
@property(nonatomic, weak) IBOutlet UIBarButtonItem *delButton;
- (IBAction)delRow:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn1;
@property (weak, nonatomic) IBOutlet UIButton *btn2;
@property (weak, nonatomic) IBOutlet UIButton *btn3;

- (void) showDeletePopUpForRepeatingInstance;


@property (assign) BOOL isFiltered;


@property (nonatomic, strong) NSMutableArray *myData;
@property (nonatomic, strong) NSMutableArray *selectedData;
// select row
@property (nonatomic, strong) NSMutableArray *selectedRows;
@property (nonatomic, strong) NSMutableArray *allRecordArray;
@property (nonatomic, readwrite) BOOL isPastChecked;
@property (nonatomic, readwrite) BOOL isUpcomingChecked;
@property (nonatomic, readwrite) BOOL isReverseChecked;


@property (nonatomic, weak) UIRefreshControl *refreshControl;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UISearchBar *mSearchBar;
@property (nonatomic) BOOL useCustomCells;

@property (nonatomic, strong) NSMutableArray *searchedEmailArray;
@property (nonatomic, strong) NSMutableArray *searchedNameArray;

@property (nonatomic, strong) NSMutableArray *selectedContacts;
@property (nonatomic, strong) NSMutableArray *deletedContactArray;
@property (nonatomic, strong) NSMutableArray *emailIdArray;
@property (nonatomic, strong) NSMutableArray *nameArray;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *btnSelectAll;
@property (weak, nonatomic) IBOutlet UIToolbar *toolBar_EditAndDelete;

@property (nonatomic, strong) NSMutableArray *totalIndaxPath;

@property (weak, nonatomic) IBOutlet UIView *viewSelectAllAndDelete;
- (IBAction)selectAll:(id)sender;

- (IBAction)btnBackClicked:(id)sender;

- (IBAction)btnNewEventClicked:(id)sender;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;
- (void) getListOfEventsFailed:(NSNotification *)notification;
- (void) getListOfEventsSuccess:(NSNotification *)notification;

- (void) deleteEventsSuccess:(NSNotification *)notification;
- (void) deleteEventsFailed:(NSNotification *)notification;

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change
                       context:(void *)context;
@end
