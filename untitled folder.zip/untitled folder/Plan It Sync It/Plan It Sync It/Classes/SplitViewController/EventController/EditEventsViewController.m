//
//  EditEventsViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "ProfileViewController.h"
#import "EditEventsViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "MNAutoComplete.h"
#import "PECropViewController.h"
#import "UIImage+fixOrientation.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "DateHandler.h"
#import "Base64.h"
#import "DateHandler.h"
#import "UIImage+Helpers.h"
#import "ActionSheetDatePicker.h"
#import "EventsListViewController.h"
#ifdef __IPHONE_8_0
#define GregorianCalendar NSCalendarIdentifierGregorian
#else
#define GregorianCalendar NSGregorianCalendar
#endif
@interface EditEventsViewController ()<AutocompleteDelgate>
{
    NSString *isAdminAccess;
    MNAutoComplete *_autoComplete;
    NSString *repeatEndsRadioSelectionString;
    BOOL isRSVPDateDibleChecked;
    NSString *imageStringAfterCrop;
    int gapBetweenStartTimeAndEndTime;
    NSDate *firstSelectedDate;
    NSDate *secondSelectedDate;
    NSDate *firstSelectedDateForTime;
    NSDate *secondSelectedDateForTime;
    BOOL isViewAppearForFirstTime;
    NSInteger totalHours;
    NSInteger totalMinutes;
    NSInteger hoursInTimer;
    NSMutableArray *locationIdArray;
    NSMutableArray *locationName;
    
    NSArray *hoursInTwentyFourHourFormatArray;
    NSArray *minutesArray;
    NSString *resultMessage;
    
    NSString *startAndEndDateDifferenceString;
    NSString *startAndEndTimeDifferenceString;
}

@end

@implementation EditEventsViewController
@synthesize existingEnentIdString;
@synthesize btnBack;
@synthesize scrollView;
@synthesize selectedDate;
@synthesize oldDictionary;
@synthesize lblDate1;
@synthesize lblDate2;
@synthesize lblTime1;
@synthesize lblTime2;
@synthesize datePicker;
@synthesize timerPicker;
@synthesize pickerBackGroundView;
@synthesize btnBarCancel;
@synthesize btnBarDone;
@synthesize textFieldTypeOfEvent;
@synthesize textFieldType;
@synthesize textFieldName;
@synthesize textFieldNotes;
@synthesize lblTotalDuration;
@synthesize textFieldLocation;
@synthesize textFieldPrivacy;
@synthesize timerPickerBackgroundView;
@synthesize btnRecurringYes;
@synthesize btnRecurringNo;
@synthesize btnRemainderYes;
@synthesize btnRemainderNo;
@synthesize btnEstimateTravelTime;
@synthesize btnUserImage;
@synthesize btnWholedayEvent;
@synthesize btnTimedEvent;
@synthesize btnSelectStartDate;
@synthesize btnSelectEndDate;
@synthesize btnSelectEndTime;
@synthesize btnSelectStartTime;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnSaveIt;
@synthesize recurringUiViewVisblity;
@synthesize textFieldRecurringType;
@synthesize textFieldRecurringNumberOFTimes;
@synthesize lblRecurringDate;
@synthesize btnRecurringEndDate;
@synthesize btnRecurringForEver;
@synthesize btnRecurringNumberOfTimes;
@synthesize recurringScrollView;
@synthesize recurringWeekView;
@synthesize btnFriday;
@synthesize btnMonday;
@synthesize btnSaturday;
@synthesize btnsunday;
@synthesize btnThursday;
@synthesize btnTuesday;
@synthesize btnWednesday;
@synthesize btnRecurringDateForBorder;
@synthesize txtHours;
@synthesize btnDoneForBorderClipping;
@synthesize txtMinutes;
@synthesize btnRemainderDayForBordering;
@synthesize btnRemainderHourForBordering;
@synthesize btnRemainderMinForBordering;
@synthesize viewRemainderHideSowForOneDayPrior;
@synthesize txtRemainderOneDayPrior;
@synthesize remainderMainViewhideShow;
@synthesize btnRecurringDoneForBordering;
@synthesize schedulingConflictPopUpView;
@synthesize txtSourceLocationPlaceApi;
@synthesize remainderScrollView;
@synthesize lblPrivacy;
@synthesize lblSetTravelTime;
@synthesize txtRemainderHour1;
@synthesize txtRemainderMin1;
@synthesize textFieldTime;
@synthesize timerbtnBarCancel;
@synthesize timerbtnBarDone;
@synthesize btnDisableRSVPDeadLine;
@synthesize lblSelectRSVPDate;
@synthesize btnSelectRSVPDate;
@synthesize staticLableStartTime;
@synthesize staticLableEndTime;
@synthesize allRecordArray;
@synthesize userImage;
@synthesize isDataFromWebservice;
@synthesize scheduleConflictArray;
@synthesize lblSchedulingConflict;
@synthesize txtRemainderEmailAndNotification;
@synthesize categoryIdArray;
@synthesize categoryNameArray;
@synthesize typeOfEvenetStorageStr;
@synthesize txtRemainderDay1;
@synthesize roundedBtnConflictCancel;
@synthesize roundedBtnConflictSaveIt;
-(void)viewDidLoad
{
    isViewAppearForFirstTime=true;
    [self hideProgressHud];
    [self setTitle:@"Edit Event"];
    
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Edit Event"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    
    [self loadAutocompletandSearchTable];
    
    minutesArray = @[@"0",@"1", @"2", @"3", @"4", @"5", @"6", @"7", @"8", @"9", @"10", @"11", @"12", @"13", @"14", @"15", @"16", @"17", @"18", @"19", @"20", @"21", @"22", @"23", @"24"];
    hoursInTwentyFourHourFormatArray = @[@"0",@"5", @"10", @"15", @"20", @"25", @"30", @"35", @"40", @"45", @"50", @"55", @"60"];
    
    repeatEndsRadioSelectionString = [NSString stringWithFormat:@"%d",1];
    
    [recurringWeekView setHidden:true];
    viewRemainderHideSowForOneDayPrior.hidden=true;
    remainderMainViewhideShow.hidden=true;
    remainderMainViewhideShow.hidden=true;
    schedulingConflictPopUpView.hidden=true;
    recurringUiViewVisblity.hidden=true;
    
    schedulingConflictPopUpView.layer.borderColor = [UIColor blackColor].CGColor;
    schedulingConflictPopUpView.layer.borderWidth = 5.0f;
    
    recurringUiViewVisblity.layer.borderColor = [UIColor blackColor].CGColor;
    recurringUiViewVisblity.layer.borderWidth = 5.0f;
    
    recurringWeekView.layer.borderColor = [UIColor blackColor].CGColor;
    recurringWeekView.layer.borderWidth = 5.0f;
    
    remainderMainViewhideShow.layer.borderColor = [UIColor blackColor].CGColor;
    remainderMainViewhideShow.layer.borderWidth = 5.0f;
    
    recurringUiViewVisblity.layer.cornerRadius=8;
    recurringUiViewVisblity.clipsToBounds=YES;
    
    roundedBtnConflictCancel.layer.cornerRadius=8;
    roundedBtnConflictCancel.clipsToBounds=YES;
    
    roundedBtnConflictSaveIt.layer.cornerRadius=8;
    roundedBtnConflictSaveIt.clipsToBounds=YES;
    
    remainderMainViewhideShow.layer.cornerRadius=8;
    remainderMainViewhideShow.clipsToBounds=YES;
    
    schedulingConflictPopUpView.layer.cornerRadius=8;
    schedulingConflictPopUpView.clipsToBounds=YES;
    
    allRecordArray = [[NSMutableArray alloc]init];
    
    lblSchedulingConflict.numberOfLines = 3;
    lblSchedulingConflict.lineBreakMode=YES;
    
    textFieldLocation.adjustsFontSizeToFitWidth=true;
    
    //    CGRect frameRect = textFieldLocation.frame;
    //    frameRect.size.height = 53;
    //    textFieldLocation.frame = frameRect;
    
    self.tableView.dataSource=self;
    self.tableView.delegate=self;
    
    isDataFromWebservice=true;
    isTime1Clicked=false;
    isTime2Clicked=false;
    isWholeDayEvent=false;
    isDisableRSVP=true;
    isRecurringYes=false;
    IsRemainderYes=false;
    isRecurringDatePickerOpened=false;
    isSetEstimateTravelTime=false;
    isMondayChecked=false;
    isTuesdayChecked=false;
    isWednesdayChecked=false;
    isThursdayChecked=false;
    isFridayChecked=false;
    issaturdayChecked=false;
    isSundayChecked=false;
    isRSVPDateDibleChecked=true;
    isDate1Clicked=false;
    isDate2Clicked=false;
    
    textFieldType.delegate = self;
    textFieldNotes.delegate = self;
    textFieldTypeOfEvent.delegate=self;
    textFieldType.delegate=self;
    textFieldName.delegate=self;
    textFieldNotes.delegate=self;
    textFieldLocation.delegate=self;
    textFieldPrivacy.delegate=self;
    textFieldRecurringType.delegate=self;
    textFieldRecurringNumberOFTimes.delegate=self;
    txtRemainderOneDayPrior.delegate=self;
    txtHours.delegate=self;
    txtMinutes.delegate=self;
    txtRemainderDay1.delegate=self;
    txtRemainderHour1.delegate=self;
    txtRemainderMin1.delegate=self;
    txtSourceLocationPlaceApi.delegate=self;
    remainderScrollView.delegate=self;
    txtRemainderEmailAndNotification.delegate=self;
    
    [textFieldRecurringNumberOFTimes setUserInteractionEnabled:false];
    [btnRecurringDateForBorder setUserInteractionEnabled:false];
    
    [lblSelectRSVPDate setAlpha:0.3];
    lblSelectRSVPDate.userInteractionEnabled=false;
    
    categoryIdArray = [[NSMutableArray alloc]init];
    categoryNameArray = [[NSMutableArray alloc] init];
    locationName = [[NSMutableArray alloc] init];
    locationIdArray = [[NSMutableArray alloc]init];
    
    textFieldTypeOfEvent.tag = 1;
    textFieldType.tag = 2;
    textFieldName.tag = 3;
    textFieldNotes.tag = 4;
    lblTotalDuration.tag = 5;
    textFieldLocation.tag = 6;
    textFieldPrivacy.tag = 7;
    textFieldRecurringType.tag=55;
    textFieldRecurringNumberOFTimes.tag=56;
    txtRemainderOneDayPrior.tag=57;
    txtSourceLocationPlaceApi.tag=58;
    txtMinutes.tag=59;
    txtHours.tag=61;
    txtRemainderHour1.tag=62;
    txtRemainderMin1.tag=63;
    txtRemainderEmailAndNotification.tag=64;
    [txtSourceLocationPlaceApi setUserInteractionEnabled:false];
    [txtSourceLocationPlaceApi setAlpha:0.3];
    
    [txtHours setUserInteractionEnabled:false];
    [txtMinutes setUserInteractionEnabled:false];
    [textFieldType setUserInteractionEnabled:false];
    
    
    [textFieldRecurringType setReturnKeyType:UIReturnKeyNext];
    [textFieldType setReturnKeyType:UIReturnKeyNext];
    [textFieldName setReturnKeyType:UIReturnKeyNext];
    [textFieldNotes setReturnKeyType:UIReturnKeyNext];
    [textFieldLocation setReturnKeyType:UIReturnKeyNext];
    [textFieldRecurringNumberOFTimes setReturnKeyType:UIReturnKeyDone];
    [textFieldPrivacy setReturnKeyType:UIReturnKeyDone];
    [txtRemainderOneDayPrior setReturnKeyType:UIReturnKeyDone];
    [txtSourceLocationPlaceApi setReturnKeyType:UIReturnKeyDone];
    
    //    roundedBtnSaveIt.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnSaveIt.layer.borderWidth = 2.0f;
    roundedBtnSaveIt.clipsToBounds=YES;
    roundedBtnSaveIt.layer.cornerRadius = 5;
    
    //    btnRecurringDateForBorder.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnRecurringDateForBorder.layer.borderWidth = 2.0f;
    btnRecurringDateForBorder.clipsToBounds=YES;
    btnRecurringDateForBorder.layer.cornerRadius=5;
    
    //    btnRecurringDoneForBordering.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnRecurringDoneForBordering.layer.borderWidth = 2.0f;
    
    [txtRemainderEmailAndNotification setSelectedItem:txtRemainderEmailAndNotification.text];
    btnRecurringDoneForBordering.clipsToBounds=YES;
    btnRecurringDoneForBordering.layer.cornerRadius=5;
    
    [[btnSelectStartDate layer] setBorderWidth:1.0f];
    [[btnSelectStartDate layer] setOpacity:0.2];
    
    [[btnRecurringDateForBorder layer] setBorderWidth:1.0f];
    [[btnRecurringDateForBorder layer] setOpacity:0.2];
    
    [[btnRemainderMinForBordering layer] setBorderWidth:1.0f];
    [[btnRemainderMinForBordering layer] setOpacity:0.2];
    
    [[btnSelectRSVPDate layer] setBorderWidth:1.0f];
    [[btnSelectRSVPDate layer] setOpacity:0.2];
    
    btnSelectRSVPDate.layer.borderColor = [UIColor blackColor].CGColor;
    btnSelectRSVPDate.layer.borderWidth = 2.0f;
    
    btnSelectRSVPDate.layer.cornerRadius=5;
    btnSelectRSVPDate.clipsToBounds=YES;
    
    [[btnRemainderDayForBordering layer] setBorderWidth:1.0f];
    [[btnRemainderDayForBordering layer] setOpacity:0.2];
    
    //    [[btnRemainderHourForBordering layer] setBorderWidth:1.0f];
    //    [[btnRemainderHourForBordering layer] setOpacity:0.2];
    
    [[btnRecurringDateForBorder layer] setBorderWidth:1.0f];
    [[btnRecurringDateForBorder layer] setOpacity:0.2];
    
    //    btnRemainderMinForBordering.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnRemainderMinForBordering.layer.borderWidth = 2.0f;
    
    btnRemainderMinForBordering.layer.cornerRadius=5;
    btnRemainderMinForBordering.clipsToBounds=YES;
    
    //    btnRemainderHourForBordering.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnRemainderHourForBordering.layer.borderWidth = 2.0f;
    
    btnRemainderHourForBordering.layer.cornerRadius=5;
    btnRemainderHourForBordering.clipsToBounds=YES;
    
    //    btnRemainderDayForBordering.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnRemainderDayForBordering.layer.borderWidth = 2.0f;
    
    btnRemainderDayForBordering.layer.cornerRadius=5;
    btnRemainderDayForBordering.clipsToBounds=YES;
    
    [[btnSelectStartDate layer] setBorderColor:[UIColor grayColor].CGColor];
    btnSelectStartDate.layer.cornerRadius = 5; // this value vary as per your desire
    btnSelectStartDate.clipsToBounds = YES;
    
    //    btnDoneForBorderClipping.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnDoneForBorderClipping.layer.borderWidth = 2.0f;
    
    btnDoneForBorderClipping.layer.cornerRadius=5;
    btnDoneForBorderClipping.clipsToBounds=YES;
    [[btnSelectEndDate layer] setBorderWidth:1.0f];
    
    
    [[btnSelectEndDate layer] setBorderColor:[UIColor grayColor].CGColor];
    btnSelectEndDate.layer.cornerRadius = 5; // this value vary as per your desire
    btnSelectEndDate.clipsToBounds = YES;
    
    [[btnSelectStartTime layer] setBorderWidth:1.0f];
    
    [[btnSelectStartTime layer] setBorderColor:[UIColor grayColor].CGColor];
    btnSelectStartTime.layer.cornerRadius = 5; // this value vary as per your desire
    btnSelectStartTime.clipsToBounds = YES;
    [[btnSelectEndTime layer] setBorderWidth:1.0f];
    
    [[btnSelectEndTime layer] setBorderColor:[UIColor grayColor].CGColor];
    btnSelectEndTime.layer.cornerRadius = 5; // this value vary as per your desire
    btnSelectEndTime.clipsToBounds = YES;
    
    [[btnSelectEndDate layer] setOpacity:0.2];
    [[btnSelectStartTime layer] setOpacity:0.2];
    [[btnSelectEndTime layer] setOpacity:0.2];
    
    selectedDate = [NSDate date];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
        dateFormatStr = @"dd/MM/yyyy";
    
    datePicker.date = selectedDate;
    
    timerPicker.date=selectedDate;
    
    lblDate1.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
    lblDate2.text = lblDate1.text;
    
    NSString *strTimeFormat = [[NSUserDefaults standardUserDefaults]
                               objectForKey:KTimeFormat];
    strTimeFormat = [NSString stringWithFormat:@"%@", strTimeFormat];
    
    lblTime1.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
    firstSelectedDateForTime=selectedDate;
    NSDate *mydate = selectedDate;
    NSTimeInterval secondsInEightHours = 1 * 60 * 60;
    secondSelectedDateForTime = [mydate dateByAddingTimeInterval:secondsInEightHours];
    lblTime2.text= [DateHandler getTimeStringFromDate:secondSelectedDateForTime timeFormat:strTimeFormat];
    startAndEndTimeDifferenceString = [self calculateDifference:firstSelectedDateForTime oldTime:secondSelectedDateForTime];
    
    startAndEndDateDifferenceString = [self calculateDifference:firstSelectedDate oldTime:secondSelectedDate];
    
    if([lblDate1.text isEqualToString:@"Select Date"])
        [[lblDate1 layer]setOpacity:0.2];
    
    if([lblDate2.text isEqualToString:@"Select Date"])
        [[lblDate2 layer]setOpacity:0.2];
    
    if([lblTime1.text isEqualToString:@"Select Time"])
        [[lblTime1 layer]setOpacity:0.2];
    
    if([lblTime2.text isEqualToString:@"Select Time"])
        [[lblTime2 layer]setOpacity:0.2];
    
    if([lblRecurringDate.text isEqualToString:@"End Date"])
        [[lblRecurringDate layer] setOpacity:0.2];
    
    if([txtHours.text isEqualToString:@"Hours"])
        [txtHours setAlpha:0.3];
    
    if([txtMinutes.text isEqualToString:@"Minutes"])
        [txtMinutes setAlpha:0.3];
    
    [textFieldType setAlpha:0.3];
    
    textFieldName.autocapitalizationType = UITextAutocapitalizationTypeWords;
    textFieldNotes.autocapitalizationType = UITextAutocapitalizationTypeWords;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    UIToolbar *toolbar = [[UIToolbar alloc] init];
    [toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [toolbar sizeToFit];
    UIBarButtonItem *buttonflexible = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *buttonDone = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneClicked:)];
    isAdminAccess = @"No";
    
    [toolbar setItems:[NSArray arrayWithObjects:buttonflexible,buttonDone, nil]];
    
    schedulingConflictPopUpView.hidden=true;
    
    textFieldTypeOfEvent.inputAccessoryView = toolbar;
    txtRemainderOneDayPrior.inputAccessoryView = toolbar;
    textFieldPrivacy.inputAccessoryView = toolbar;
    textFieldRecurringType.inputAccessoryView=toolbar;
    //    textFieldTextPicker.isOptionalDropDown = NO;
    [textFieldTypeOfEvent setItemList:[NSArray arrayWithObjects:@"Test",@"Other", nil]];
    [txtRemainderOneDayPrior setItemList:[NSArray arrayWithObjects:@"On Time",@"15 Minutes Prior",@"30 Minutes Prior",@"45 Minutes Prior",@"1 Hour Prior",@"24 Hour",@"Other", nil]];
    [textFieldPrivacy setItemList:[NSArray arrayWithObjects:@"Myself And Anyone I Invite",@"Public",nil]];
    [textFieldRecurringType setItemList:[NSArray arrayWithObjects:@"Daily",@"Weekly",@"Monthly",@"Yearly",nil]];
    [textFieldLocation setItemList:[NSArray arrayWithObjects:@"None",@"Other", nil]];
    
    [txtRemainderDay1 setItemList:[NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26",@"27",@"28",@"29",@"30",@"31", nil]];
    
    [txtRemainderMin1 setItemList:[NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26",@"27",@"28",@"29",@"30",@"31",@"32",@"33",@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41",@"42",@"43",@"44",@"45",@"46",@"47",@"48",@"49",@"50",@"51",@"52",@"53",@"54",@"55",@"56",@"57",@"58",@"59",@"60", nil]];
    
    [txtRemainderHour1 setItemList:[NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24", nil]];
    
    
    [txtRemainderEmailAndNotification setItemList:[NSArray arrayWithObjects:@"Email & Notification",@"Email", @"Notification",nil]];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:GregorianCalendar];
    NSDate *currentDate = [NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setYear:+1000];
    NSDate *minDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    [comps setYear:+1000];
    
    [datePicker setMaximumDate:minDate];
    [datePicker setMinimumDate:currentDate];
    
    [timerPicker setMaximumDate:[NSDate date]];
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1150)];
        [recurringScrollView setContentSize:CGSizeMake(recurringScrollView.frame.size.width,550)];
        [remainderScrollView setContentSize:CGSizeMake(recurringScrollView.frame.size.width,250)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1300)];
    }
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    btnRecurringDoneRect = btnRecurringDoneForBordering.frame;
    
    userImage.layer.masksToBounds = YES;
    userImage.layer.cornerRadius = 10.0;
    userImage.layer.borderColor = [UIColor whiteColor].CGColor;
    userImage.layer.borderWidth = 3.0f;
    userImage.layer.shouldRasterize = YES;
    userImage.clipsToBounds = YES;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getEditSingleEventSuccess:) name:kGetEditSingleEventsWebServiceSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getEditSingleEventFailed:) name:kGetEditSingleEventsWebServiceFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addEventSuccess:) name:kAddEventSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addEventFailed:) name:kAddEventFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(editEventSuccess:) name:kEditEventSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(editEventFailed:) name:kEditEventFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfCategorySuccess:) name:kGetListOfCategorySuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfCategoryFailed:) name:kGetListOfCategoryFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfLocationSuccess:) name:kGetListOfLocationSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfLocationFailed:) name:kGetListOfLocationFailed object:nil];
}
- (NSString *)calculateDifference:(NSDate *)currentTime oldTime:(NSDate *)oldTime
{
    NSDate *date1 = currentTime;
    NSDate *date2 = oldTime;
    
    NSTimeInterval secondsBetween = [date2 timeIntervalSinceDate:date1];
    
    int hh = secondsBetween / (60*60);
    double rem = fmod(secondsBetween, (60*60));
    int mm = rem / 60;
    rem = fmod(rem, 60);
    int ss = rem;
    gapBetweenStartTimeAndEndTime = hh;
    NSDate * dateDifference = [NSDate dateWithTimeIntervalSinceReferenceDate:secondsBetween];
    NSString *str = [NSString stringWithFormat:@"%02d:%02d",hh,mm];
    
    return str;
}
- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    selectedDate = [NSDate date];
    firstSelectedDateForTime = selectedDate;
    secondSelectedDateForTime = selectedDate;
    
    BOOL IsEditEvents = [[NSUserDefaults standardUserDefaults] boolForKey:@"IsEditEvents"];
    
    if(IsEditEvents==true && isViewAppearForFirstTime==true){
        
        NSString *enentId = [[NSUserDefaults standardUserDefaults] objectForKey:kEventId];
        
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        [dataDictionary setObject:userid forKey:kUserId];
        [dataDictionary setObject:enentId forKey:@"eventid"];
        [self showProgressHud];
        
        [[WebService sharedWebService] callGetEditSingleEventsWebService:dataDictionary];
    }
    else if(isViewAppearForFirstTime==true){
        [self showProgressHud];
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        [dataDictionary setObject:userid forKey:@"userid"];
        
        [[WebService sharedWebService] callGetListOfCategoryWebService:dataDictionary];
    }
    
    NSString *dateFromCalandar =[[NSUserDefaults standardUserDefaults] objectForKey:KDateForEventCreate];
    if(dateFromCalandar.length>0)
    {
        lblDate1.text=dateFromCalandar;
        lblDate2.text=dateFromCalandar;
    }
    
    isViewAppearForFirstTime=false;
}

-(void)doneClicked:(UIBarButtonItem*)button
{
    [self.view endEditing:YES];
}

-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
-(void)textField:(IQDropDownTextField*)textField didSelectItem:(NSString*)item
{
    
    if(textField==textFieldTypeOfEvent && [item isEqualToString:@"Other"])
    {
        [textFieldType setAlpha:1];
        [textFieldType setUserInteractionEnabled:true];
        
    }else if(textField==textFieldTypeOfEvent){
        [textFieldType setUserInteractionEnabled:NO];
        
        [UIView beginAnimations:nil context:NULL];
        self.textFieldType.alpha = 0.3;
        //        self.textFieldType.alpha = 1;
        [UIView commitAnimations];
        //        [textFieldType setAlpha:0.3];
    }
    if([item isEqualToString:@"Weekly"]){
        [recurringWeekView setHidden:false];
        [btnRecurringDoneForBordering setFrame:CGRectMake(btnRecurringDoneForBordering.frame.origin.x,btnsunday.frame.origin.y+300, btnRecurringDoneForBordering.frame.size.width,btnRecurringDoneForBordering.frame.size.height)];
    }
    else if(textField==textFieldRecurringType){
        [recurringWeekView setHidden:true];
        [btnRecurringDoneForBordering setFrame:btnRecurringDoneRect];
    }
    
    if([item isEqualToString:@"Other"] && textField==txtRemainderOneDayPrior)
    {
        [txtRemainderDay1 setAlpha:1];
        [txtRemainderHour1 setAlpha:1];
        [txtRemainderMin1 setAlpha:1];
        [txtRemainderOneDayPrior setAlpha:1];
        viewRemainderHideSowForOneDayPrior.hidden=false;
        CGPoint viewReaminderHideSowForOneDayPos = viewRemainderHideSowForOneDayPrior.frame.origin;
        [btnDoneForBorderClipping setFrame:CGRectMake(btnDoneForBorderClipping.frame.origin.x,viewReaminderHideSowForOneDayPos.y+110, btnDoneForBorderClipping.frame.size.width,btnDoneForBorderClipping.frame.size.height)];
        
    }
    else if(textField==txtRemainderOneDayPrior)
    {
        [txtRemainderDay1 setAlpha:0.3];
        [txtRemainderHour1 setAlpha:0.3];
        [txtRemainderMin1 setAlpha:0.3];
        [txtRemainderOneDayPrior setAlpha:0.3];
        
        viewRemainderHideSowForOneDayPrior.hidden=true;
        CGPoint viewReaminderHideSowForOneDayPos = viewRemainderHideSowForOneDayPrior.frame.origin;
        [btnDoneForBorderClipping setFrame:CGRectMake(btnDoneForBorderClipping.frame.origin.x,viewReaminderHideSowForOneDayPos.y, btnDoneForBorderClipping.frame.size.width,btnDoneForBorderClipping.frame.size.height)];
        
    }
    if([item isEqualToString:@"Other"] && textField==textFieldLocation)
    {
        [txtSourceLocationPlaceApi setUserInteractionEnabled:true];
        [txtSourceLocationPlaceApi setAlpha:1];
        [textFieldLocation resignFirstResponder];
        [txtSourceLocationPlaceApi becomeFirstResponder];
    }
    else if (textFieldLocation==textField && [item isEqualToString:@"None"])
    {
        textFieldLocation.text=@"None";
        [txtSourceLocationPlaceApi setUserInteractionEnabled:false];
        [txtSourceLocationPlaceApi setAlpha:0.3];
        txtSourceLocationPlaceApi.text=@"";
        [self.searchTableController toggleHidden:YES];
    }
    else if(textFieldLocation==textField)
    {
        [txtSourceLocationPlaceApi setUserInteractionEnabled:false];
        [txtSourceLocationPlaceApi setAlpha:0.3];
        txtSourceLocationPlaceApi.text=@"";
        textFieldLocation.text = item;
    }
    
    else if(textField==txtRemainderHour1)
    {
        [txtRemainderMin1 setUserInteractionEnabled:true];
        [txtRemainderHour1 setAlpha:1];
        [txtRemainderMin1 setAlpha:1];
    }
    else if([item isEqualToString:@"None"] && textField==textFieldLocation)
    {
        [txtSourceLocationPlaceApi setAlpha:0.3];
        [txtSourceLocationPlaceApi setUserInteractionEnabled:false];
    }
}

- (BOOL) textView: (UITextView*) textView
shouldChangeTextInRange: (NSRange) range
  replacementText: (NSString*) text
{
    if ([text isEqualToString:@"\n"]) {
        [[textView layer] setOpacity:1];
        textView.text = [textView.text stringByReplacingOccurrencesOfString: @"\\n" withString: @"\n"];
        
        return YES;
    }
    return YES;
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (NSString *)calculateDuration:(NSDate *)startDate endDate:(NSDate *)endDate startTime:(NSDate *)startTime endTime:(NSDate *)endTime
{
    NSDate *date1 = startDate;
    NSDate *date2 = endDate;
    NSTimeInterval timeGap;
    int totalHour=0;
    int totalMinute=0;
    
    timeGap = [date2 timeIntervalSinceDate:date1];
    
    int hh;
    int mm;
    double rem ;
    hh = timeGap / (60*60);
    rem = fmod(timeGap, (60*60));
    mm = rem / 60;
    gapBetweenStartTimeAndEndTime = hh;
    totalHour=hh;
    totalMinute=mm;
    NSDate *date3 = startTime;
    NSDate *date4 = endTime;
    
    timeGap = [date4 timeIntervalSinceDate:date3];
    hh = timeGap / (60*60);
    totalHour = totalHour + hh;
    rem = fmod(timeGap, (60*60));
    mm = rem / 60;
    totalMinute = totalMinute+mm;
    NSString *str = [NSString stringWithFormat:@"%02d:%02d",totalHour,totalMinute];
    return str;
}

- (NSString *) getDateStringFromDate:(NSDate *)date desireDateFormat:(NSString*)desireDateFormat{
    NSDateFormatter *dateFormatter =  [DateHandler USDateFormatterWithDateFormat:desireDateFormat];
    return [dateFormatter stringFromDate:date];
}


#pragma mark **********TEXT FIED DELEGATE METHODS**********

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 7;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
    if(textFieldRecurringType==textField){
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=55;
    }
    else if(textField==textFieldNotes){
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
    }
    else if (textFieldRecurringNumberOFTimes==textField){
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=56;
    }
    else if (txtRemainderOneDayPrior==textField)
    {
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=57;
    }
    else if (txtSourceLocationPlaceApi==textField)
    {
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=58;
    }
    else if (txtRemainderDay1==textField)
    {
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=59;
    }
    else if (txtRemainderHour1==textField)
    {
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=60;
    }
    else if (txtRemainderMin1==textField)
    {
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=61;
    }
    else if (txtMinutes==textField)
    {
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=63;
    }
    else if (txtHours==textField)
    {
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=64;
    }
    else if (txtRemainderHour1==textField)
    {
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=62;
    }
    else if(txtRemainderEmailAndNotification==textField){
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
        customKeyboard.currentSelectedTextboxIndex=64;
    }
}
- (void)nextClicked:(NSUInteger)sender {
    
    switch (sender){
        case 1: {
            [textFieldTypeOfEvent resignFirstResponder];
            [textFieldType becomeFirstResponder];
        }
            break;
        case 2: {
            [textFieldType resignFirstResponder];
            [textFieldName becomeFirstResponder];
        }
            break;
        case 3: {
            [textFieldName resignFirstResponder];
            [textFieldNotes becomeFirstResponder];
        }
            break;
        case 4: {
            [textFieldNotes resignFirstResponder];
            [lblTotalDuration becomeFirstResponder];
        }
            break;
        case 5: {
            [lblTotalDuration resignFirstResponder];
            [textFieldLocation becomeFirstResponder];
        }
            break;
            
        case 6: {
            [textFieldLocation resignFirstResponder];
            [textFieldPrivacy becomeFirstResponder];
        }
            break;
            
        case 7: {
            [textFieldPrivacy resignFirstResponder];
            //            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
        case 55:
        {
            [textFieldRecurringType resignFirstResponder];
            [textFieldRecurringNumberOFTimes becomeFirstResponder];
        }
            break;
            
        case 56:{
            [textFieldRecurringNumberOFTimes resignFirstResponder];
        }
            break;
        case 57:{
            [txtRemainderOneDayPrior resignFirstResponder];
        }
            break;
        case 58:{
            [txtSourceLocationPlaceApi resignFirstResponder];
        }
            break;
        case 64:{
            [txtRemainderEmailAndNotification resignFirstResponder];
        }
            break;
            
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    
    switch (sender){
        case 1: {
            [textFieldTypeOfEvent resignFirstResponder];
            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
        case 2: {
            [textFieldTypeOfEvent becomeFirstResponder];
            [textFieldType resignFirstResponder];
            
        }
            break;
        case 3: {
            [textFieldType becomeFirstResponder];
            [textFieldName resignFirstResponder];
            
        }
            break;
        case 4: {
            [textFieldName becomeFirstResponder];
            [textFieldNotes resignFirstResponder];
            
        }
            break;
        case 5: {
            [textFieldNotes becomeFirstResponder];
            [lblTotalDuration resignFirstResponder];
            
        }
            break;
            
        case 6: {
            [lblTotalDuration becomeFirstResponder];
            [textFieldLocation resignFirstResponder];
            
        }
            break;
        case 8: {
            //            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
            [textFieldLocation becomeFirstResponder];
            [textFieldPrivacy resignFirstResponder];
        }
            break;
        case 55:
        {
            [textFieldRecurringType resignFirstResponder];
            [textFieldRecurringNumberOFTimes becomeFirstResponder];
        }
            break;
        case 56:{
            [textFieldRecurringType becomeFirstResponder];
            [textFieldRecurringNumberOFTimes resignFirstResponder];
        }
            break;
        case 57:{
            [txtRemainderOneDayPrior resignFirstResponder];
        }
            break;
        case 58:
        {
            [txtSourceLocationPlaceApi resignFirstResponder];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
    [self.view endEditing:YES];
    
    switch (sender){
        case 1: {
            if ([textFieldTypeOfEvent isFirstResponder]) {
                [textFieldTypeOfEvent resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([textFieldType isFirstResponder]) {
                [textFieldType resignFirstResponder];
            }
        }
            break;
        case 3: {
            if ([textFieldName isFirstResponder]) {
                [textFieldName resignFirstResponder];
            }
        }
            break;
        case 4: {
            if ([textFieldNotes isFirstResponder]) {
                [textFieldNotes resignFirstResponder];
            }
        }
            break;
        case 5: {
            if ([lblTotalDuration isFirstResponder]) {
                [lblTotalDuration resignFirstResponder];
            }
        }
            break;
            
        case 6: {
            if ([textFieldLocation isFirstResponder]) {
                [textFieldLocation resignFirstResponder];
            }
        }
            break;
            
        case 7: {
            if ([textFieldPrivacy isFirstResponder]) {
                //                [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
                [textFieldPrivacy resignFirstResponder];
                
            }
        }
            break;
        case 55: {
            if ([textFieldRecurringType isFirstResponder]) {
                //                [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
                [textFieldRecurringType resignFirstResponder];
            }
        }
            break;
        case 56: {
            if ([textFieldRecurringNumberOFTimes isFirstResponder]) {
                [textFieldRecurringNumberOFTimes resignFirstResponder];
            }
        }
            break;
        case 57: {
            if ([txtRemainderOneDayPrior isFirstResponder]) {
                [txtRemainderOneDayPrior resignFirstResponder];
            }
        }
            break;
        case 58: {
            if ([txtSourceLocationPlaceApi isFirstResponder]) {
                [txtSourceLocationPlaceApi resignFirstResponder];
            }
        }
            break;
        case 59: {
            if ([txtRemainderDay1 isFirstResponder]) {
                [txtRemainderDay1 resignFirstResponder];
            }
        }
            break;
        case 60: {
            if ([txtHours isFirstResponder]) {
                [txtHours resignFirstResponder];
            }
        }
            break;
        case 61: {
            if ([txtMinutes isFirstResponder]) {
                [txtMinutes resignFirstResponder];
            }
        }
            break;
        case 62: {
            if ([txtRemainderHour1 isFirstResponder]) {
                [txtRemainderHour1 resignFirstResponder];
            }
        }
            break;
        case 63: {
            if ([txtRemainderMin1 isFirstResponder]) {
                [txtRemainderMin1 resignFirstResponder];
            }
        }
            break;
            
        case 64: {
            if ([txtRemainderEmailAndNotification isFirstResponder]) {
                [txtRemainderEmailAndNotification resignFirstResponder];
            }
        }
            break;
            
            
        default: {
            [self.view endEditing:YES];
        }
            break;
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnSaveClicked:(id)sender{
    [self callAddAndEditEventWebservice:0];
}

- (BOOL)textFieldShouldReturn:(UITextField* )textField{
    
    if(textFieldType == textField){
        [textFieldType resignFirstResponder];
        [textFieldName becomeFirstResponder];
    }
    else if(textFieldName == textField){
        [textFieldName resignFirstResponder];
        [textFieldNotes becomeFirstResponder];
    }
    else if(textFieldNotes == textField){
        [textFieldNotes resignFirstResponder];
        [lblTotalDuration becomeFirstResponder];
    }
    else if(textFieldPrivacy == textField){
        [textFieldPrivacy resignFirstResponder];
        [lblTotalDuration becomeFirstResponder];
    }
    else if (textFieldRecurringType==textField)
    {
        [textFieldRecurringType resignFirstResponder];
    }
    else if (textFieldRecurringNumberOFTimes==textField)
    {
        [textFieldRecurringNumberOFTimes resignFirstResponder];
        
    }
    else if (txtRemainderOneDayPrior==textField)
    {
        [txtRemainderOneDayPrior resignFirstResponder];
        
    }
    else if (textField==txtSourceLocationPlaceApi)
    {
        [self.searchTableController toggleHidden:YES];
        
    }
    
    else{
        [lblTotalDuration resignFirstResponder];
        
    }
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField* )textField{
    if(textField == lblTotalDuration){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,textFieldNotes.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if (textField==txtSourceLocationPlaceApi)
    {
        NSArray *sourceArray = [NSMutableArray arrayWithArray:[self getSearchHistory]];
        [self.searchTableController reloadDataWithSource:sourceArray];
        
        NSLog(@"search history %@",sourceArray);
        return YES;
    }
    else if(textField == textFieldLocation)
    {
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,lblPrivacy.frame.origin.y+100,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == textFieldPrivacy)
    {
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,lblTotalDuration.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    if(textField == textFieldNotes){
        //        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    return YES;
}


#pragma mark ***********************Timer Picker*****************

-(void)timeWasCancelled:(NSDate *)selectedTime element:(id)element
{
    
}

-(void)timeWasSelected:(NSDate *)selectedTime element:(id)element
{
    [self hideKeyBoardOnDateAndTimeClick];
    
    NSString *strTimeFormat = [[NSUserDefaults standardUserDefaults]
                               objectForKey:KTimeFormat];
    
    strTimeFormat = [NSString stringWithFormat:@"%@", strTimeFormat];
    
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"HH:mm"];
    NSLocale *twentyFour = [[NSLocale alloc] initWithLocaleIdentifier:@"en_GB"];
    formatter.locale = twentyFour;
    NSString *timeString = [formatter stringFromDate:selectedTime];
    
    selectedDate = selectedTime;
    
    if(isTime1Clicked==true){
        isTime1Clicked=false;
        [[lblTime1 layer] setOpacity:1];
        firstSelectedDateForTime=selectedDate;
        if([strTimeFormat isEqualToString:@"12"])
            lblTime1.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else if(timeString.length>0)
            lblTime1.text=timeString;
        
        if(lblTime1.text.length>0 && lblTime2.text.length>0)
        {
            int timeCompare = [DateHandler compareTwoTimeInterval:lblTime1.text endTime:lblTime2.text timeFormat:strTimeFormat];
            
            if(timeCompare==1)
            {
                firstSelectedDateForTime=selectedDate;
                secondSelectedDateForTime=selectedDate;
                lblTime2.text=lblTime1.text;
            }
            else if(timeCompare==0)
            {
                firstSelectedDateForTime=selectedDate;
                secondSelectedDateForTime=selectedDate;
                lblTime2.text=lblTime1.text;
            }
        }
    }
    else if(isTime2Clicked==true)
    {
        secondSelectedDateForTime=selectedDate;
        isTime2Clicked=false;
        [[lblTime2 layer] setOpacity:1];
        if([strTimeFormat isEqualToString:@"12"])
            lblTime2.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else if(timeString.length>0)
            lblTime2.text=timeString;
        
        if([lblTime1.text isEqualToString:@"Select Date"])
        {
            [self hideDatePickerOnAlertAndOnDateSelected];
            totalHours=0;
            firstSelectedDateForTime=selectedDate;
            secondSelectedDateForTime=selectedDate;
            lblTime2.text=lblTime1.text;
            [self.view makeToast:@"Sorry, you can't create an event that ends before it starts."];
            return;
        }
        [self hideDatePickerOnAlertAndOnDateSelected];
        if(lblTime1.text.length>0 && lblTime2.text.length>0){
            int timeCompare = [DateHandler compareTwoTimeInterval:lblTime1.text endTime:lblTime2.text timeFormat:strTimeFormat];
            
            if(timeCompare==1)
            {
                firstSelectedDateForTime=selectedDate;
                secondSelectedDateForTime=selectedDate;
                lblTime2.text=lblTime1.text;
                [self.view makeToast:@"End time should always greater than start time" duration:2.4 position:CSToastPositionBottom];
                return;
            }
            else if(timeCompare==0 )
            {
                firstSelectedDateForTime=selectedDate;
                secondSelectedDateForTime=selectedDate;
                lblTime2.text=lblTime1.text;
                [self.view makeToast:@"Start time and end time is equal"];
                return;
            }
        }
    }
    //    else if()
    //    {
    //        secondSelectedDateForTime=selectedDate;
    //
    //        NSString *duration = [self calculateDuration:firstSelectedDateForTime secondDate:secondSelectedDateForTime];
    //
    //        NSString *hours = nil;
    //        if ([duration length] >= 2)
    //            hours = [duration substringToIndex:2];
    //        else
    //            hours = duration;
    //
    //        int timeCompare = [DateHandler compareTwoTimeInterval:lblTime1.text endTime:lblTime2.text timeFormat:strTimeFormat];
    //        if(timeCompare==1)
    //        {
    //            [self hideTimerPickerOnAlertAndOnDateSelected];
    //            [self.view makeToast:@" Sorry, you can not create an event that ends before it starts."];
    //
    //            lblTime2.text=@"";
    //            return;
    //
    //        }
    //        else if(timeCompare==0)
    //        {
    //            [self hideTimerPickerOnAlertAndOnDateSelected];
    //            [self.view makeToast:@"Start time and end time is equal"];
    //            lblTime2.text=@"";
    //            return;
    //        }
    //
    //        if([hours isEqualToString:@"00"]){
    //            hours=@"01";
    //            duration = [duration stringByReplacingOccurrencesOfString:@"00" withString:hours];
    //
    //            NSTimeInterval interval = [secondSelectedDateForTime timeIntervalSinceDate:firstSelectedDateForTime];
    //            int hours = (int)interval / 3600;             // integer division to get the hours part
    //            int minutes = (interval - (hours*3600)) / 60; // interval minus hours part (in seconds) divided by 60 yields minutes
    //            NSString *timeDiff = [NSString stringWithFormat:@"%d:%02d", hours, minutes];
    //            totalMinutes = minutes;
    //            NSTimeInterval secondsInOneHours = 1 * 60 * 60;
    //
    //            NSDate *dateEightHoursAhead = [secondSelectedDateForTime dateByAddingTimeInterval:secondsInOneHours];
    //            if([strTimeFormat isEqualToString:@"12"])
    //                lblTime2.text = [DateHandler getTimeStringFromDate:dateEightHoursAhead timeFormat:strTimeFormat];
    //            else if(timeString.length>0)
    //                lblTime2.text=timeString;
    //        }
    //    }
}


- (IBAction)timerCancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,800, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    else{
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,1200, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}
- (IBAction)timerDoneButtonClicked:(id)sender{
    [self hideTimerPickerOnAlertAndOnDateSelected];
}

-(void)hideTimerPickerOnAlertAndOnDateSelected
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,800, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    else{
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,1200, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}

-(void)hideDatePickerOnAlertAndOnDateSelected
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}
-(void)hideKeyBoardOnDateAndTimeClick
{
    if ([textFieldTypeOfEvent isFirstResponder]) {
        [textFieldTypeOfEvent resignFirstResponder];
    }
    else if ([textFieldType isFirstResponder]) {
        [textFieldType resignFirstResponder];
    }
    else if ([textFieldName isFirstResponder]) {
        [textFieldName resignFirstResponder];
    }
    else if ([textFieldNotes isFirstResponder]) {
        [textFieldNotes resignFirstResponder];
    }
    else if ([lblTotalDuration isFirstResponder]) {
        [lblTotalDuration resignFirstResponder];
    }
    else if ([textFieldLocation isFirstResponder]) {
        [textFieldLocation resignFirstResponder];
    }
    else if ([textFieldPrivacy isFirstResponder]) {
        [textFieldPrivacy resignFirstResponder];
        
    }
    else if ([textFieldRecurringType isFirstResponder]) {
        [textFieldRecurringType resignFirstResponder];
    }
    else if ([textFieldRecurringNumberOFTimes isFirstResponder]) {
        [textFieldRecurringNumberOFTimes resignFirstResponder];
    }
    else if ([txtRemainderOneDayPrior isFirstResponder]) {
        [txtRemainderOneDayPrior resignFirstResponder];
    }
    else if ([txtSourceLocationPlaceApi isFirstResponder]) {
        [txtSourceLocationPlaceApi resignFirstResponder];
    }
}


-(void)openTimePickerWithSelectedDate:(id)sender selectedDateForPicker:(NSDate*)selectedDateForPicker timeFormat:(NSString*)timeFormat
{
    ActionSheetDatePicker *datePickerBest = [[ActionSheetDatePicker alloc] initWithTitle:@"Select a time" datePickerMode:UIDatePickerModeTime selectedDate:selectedDateForPicker minimumDate:nil maximumDate:nil target:self action:@selector(timeWasSelected:element:) cancelAction:@selector(timeWasCancelled:element:) origin:sender];
    if([timeFormat isEqualToString:@"24"]){
        NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"NL"];
        [datePickerBest setLocale:locale];
    }
    //    datePickerBest.minuteInterval = 5;
    [datePickerBest showActionSheetPicker];
}

-(void)openTimePickerAnimation:(id)sender timeToChange:(NSString*)timeToChange
{
    NSString *strTimeFormat = [[NSUserDefaults standardUserDefaults]
                               objectForKey:KTimeFormat];
    
    strTimeFormat = [NSString stringWithFormat:@"%@", strTimeFormat];
    
    if([timeToChange isEqualToString:@"time1"])
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:firstSelectedDateForTime timeFormat:strTimeFormat];
    else if([timeToChange isEqualToString:@"time2"])
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:secondSelectedDateForTime timeFormat:strTimeFormat];
    
}
- (IBAction)changeTimeButton1Clicked:(id)sender{
    [self hideKeyBoardOnDateAndTimeClick];
    isTime1Clicked=true;
    [self openTimePickerAnimation:sender timeToChange:@"time1"];
    
}
- (IBAction)changeTime2ButtonClicked:(id)sender{
    [self hideKeyBoardOnDateAndTimeClick];
    
    isTime2Clicked=true;
    [self openTimePickerAnimation:sender timeToChange:@"time2"];
}

#pragma mark ***********************Date Picker*****************
- (IBAction)cancelButtonClicked:(id)sender{
    isDate1Clicked=false;
    isDate2Clicked=false;
    isTime1Clicked=false;
    isTime2Clicked=false;
    isDisableRSVP=true;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}

-(void)calculateTotalHours
{
    [[lblTotalDuration layer] setOpacity:1];
    lblTotalDuration.userInteractionEnabled=true;
    NSTimeInterval interval = [secondSelectedDate timeIntervalSinceDate:firstSelectedDate];
    int hours = (int)interval / 3600;             // integer division to get the hours part
    int minutes = (interval - (hours*3600)) / 60; // interval minus hours part (in seconds) divided by 60 yields minutes
    NSString *timeDiff = [NSString stringWithFormat:@"%d:%02d", hours, minutes];
    totalHours= totalHours+hours;
    
    lblTotalDuration.text=[NSString stringWithFormat:@"%ld",(long)totalHours];
}

- (IBAction)doneButtonClicked:(id)sender{
    
    selectedDate = [datePicker date];
    
    [self hideKeyBoardOnDateAndTimeClick];
    totalHours=0;
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
        dateFormatStr = @"dd/MM/yyyy";
    
    if(isDate1Clicked==true){
        isDate1Clicked=false;
        [[lblDate1 layer] setOpacity:1];
        firstSelectedDate = selectedDate;
        datePicker.date = firstSelectedDate;
        lblDate1.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
        
        if(lblDate1.text.length>0 && lblDate2.text.length>0)
        {
            if(([DateHandler isEndDateIsSmallerThanCurrent:firstSelectedDate checkEndDate:secondSelectedDate]==0) || ([DateHandler isEndDateIsSmallerThanCurrent:firstSelectedDate checkEndDate:secondSelectedDate]==1))
            {
                [self hideDatePickerOnAlertAndOnDateSelected];
                firstSelectedDate=selectedDate;
                secondSelectedDate=firstSelectedDate;
                lblDate2.text=lblDate1.text;
                datePicker.date=selectedDate;
                return;
            }
        }
    }
    
    else if(isDate2Clicked==true)
    {
        isDate2Clicked=false;
        [[lblDate2 layer] setOpacity:1];
        secondSelectedDate = selectedDate;
        datePicker.date = selectedDate;
        //            lblTotalDuration.text= [self calculateDuration:firstSelectedDate endDate:secondSelectedDate startTime:firstSelectedDateForTime endTime:secondSelectedDate];
        lblDate2.text = lblDate1.text;
        lblDate2.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
        
        if(lblDate1.text.length>0 && lblDate2.text.length>0){
            if([DateHandler isEndDateIsSmallerThanCurrent:firstSelectedDate checkEndDate:secondSelectedDate]==1)
            {
                [self hideDatePickerOnAlertAndOnDateSelected];
                totalHours=0;
                firstSelectedDate=selectedDate;
                secondSelectedDate=firstSelectedDate;
                lblDate2.text=lblDate1.text;
                datePicker.date=selectedDate;
                [self.view makeToast:@"Sorry, you can't create an event that ends before it starts." duration:2.5 position:CSToastPositionBottom];
                return;
            }
        }
    }
    if(isRecurringDatePickerOpened==true)
    {
        isRecurringDatePickerOpened=false;
        [[lblRecurringDate layer] setOpacity:1];
        if(lblDate2.text.length>0)
        {
            if([DateHandler isEndDateIsSmallerThanCurrent:secondSelectedDateForTime checkEndDate:selectedDate]==1)
            {
                [self hideDatePickerOnAlertAndOnDateSelected];
                firstSelectedDate=selectedDate;
                secondSelectedDate=firstSelectedDate;
                lblDate2.text=lblDate1.text;
                datePicker.date=selectedDate;
                [self.view makeToast:@"Sorry, you can't create an event that ends before it starts." duration:2.5 position:CSToastPositionBottom];
                return;
            }
        }
        lblRecurringDate.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
        [self hideDatePickerOnAlertAndOnDateSelected];
        
        return;
    }
    if(isRSVPDateDibleChecked==false)
    {
        NSString *strRSVPpriorTime = [[NSUserDefaults standardUserDefaults]
                                      objectForKey:kEventRSVPPriorTime];
        [[lblSelectRSVPDate layer] setOpacity:1];
        if([lblDate2.text isEqualToString:@"Select Date"] || [lblDate2.text isEqualToString:@""])
        {
            [self hideDatePickerOnAlertAndOnDateSelected];
            
            [self.view makeToast:@"Please select end date for selecting RSVP date." duration:2.5 position:CSToastPositionBottom];
            return;
        }
        if([DateHandler isEndDateIsSmallerThanCurrent:secondSelectedDate checkEndDate:selectedDate]==0)
        {
            [self hideDatePickerOnAlertAndOnDateSelected];
            
            [self.view makeToast:@"Please select RSVP date less than end date." duration:2.5 position:CSToastPositionBottom];
            return;
        }
        
        NSInteger daysToAdd = [[NSString stringWithFormat:@"%@",strRSVPpriorTime] integerValue];
        NSDate *newDate1 = [selectedDate dateByAddingTimeInterval:-60*60*24*daysToAdd];
        
        lblSelectRSVPDate.text = [DateHandler getDateStringFromDate:newDate1 desireDateFormat:dateFormatStr];
    }
    
    [self hideDatePickerOnAlertAndOnDateSelected];
    
}

- (IBAction)changeDateButton1Clicked:(id)sender{
    isDate1Clicked=true;
    [self oPenDatePicker];
}

- (IBAction)changeDate2ButtonClicked:(id)sender{
    isDate2Clicked=true;
    [self oPenDatePicker];
}

#pragma mark ***************************TOGGLE BUTTONS***************************
- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)toggleRadioButtonEstimateTravelTime:(id)sender
{
    if(isSetEstimateTravelTime==false)
    {
        [txtHours setUserInteractionEnabled:true];
        [txtMinutes setUserInteractionEnabled:true];
        [txtHours setAlpha:1];
        [txtMinutes setAlpha:1];
        isSetEstimateTravelTime=true;
        [btnEstimateTravelTime setImage:nil forState:UIControlStateNormal];
        [btnEstimateTravelTime setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
        
    }else
    {
        [txtHours setUserInteractionEnabled:false];
        [txtMinutes setUserInteractionEnabled:false];
        [txtHours setAlpha:0.3];
        [txtMinutes setAlpha:0.3];
        isSetEstimateTravelTime=false;
        [btnEstimateTravelTime setImage:nil forState:UIControlStateNormal];
        [btnEstimateTravelTime setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
    }
}

- (IBAction)toggleRadioButtonTimedEvent:(id)sender {
    
    [[lblTotalDuration layer] setOpacity:1];
    lblTotalDuration.userInteractionEnabled=true;
    
    staticLableStartTime.hidden=false;
    staticLableEndTime.hidden=false;
    isWholeDayEvent=true;
    [btnTimedEvent setImage:nil forState:UIControlStateNormal];
    [btnWholedayEvent setImage:nil forState:UIControlStateNormal];
    [btnTimedEvent setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
    [btnWholedayEvent setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    
    CGSize textFieldNotesFrame = lblDate1.frame.size;
    
    CGPoint btnSelectStartDatePosXAndY = btnSelectStartDate.frame.origin;
    CGPoint btnSelectEndDatePosXAndY = btnSelectEndDate.frame.origin;
    
    [btnSelectStartDate setFrame:CGRectMake(btnSelectStartDatePosXAndY.x, btnSelectStartDatePosXAndY.y,textFieldNotesFrame.width, textFieldNotesFrame.height)];
    [lblDate1 setFrame:CGRectMake(btnSelectStartDatePosXAndY.x+10, btnSelectStartDatePosXAndY.y,textFieldNotesFrame.width, textFieldNotesFrame.height)];
    
    [lblDate2 setFrame:CGRectMake(btnSelectEndDatePosXAndY.x+10, btnSelectEndDatePosXAndY.y,textFieldNotesFrame.width, textFieldNotesFrame.height)];
    [btnSelectEndDate setFrame:CGRectMake(btnSelectEndDatePosXAndY.x, btnSelectEndDatePosXAndY.y,textFieldNotesFrame.width, textFieldNotesFrame.height)];
    
    [lblTime1 setHidden:false];
    [lblTime2 setHidden:false];
    [btnSelectStartTime setHidden:false];
    [btnSelectEndTime setHidden:false];
}
- (IBAction)changeDateRSVPClicked:(id)sender {
    if(isRSVPDateDibleChecked==false){
        [self oPenDatePicker];
    }
}

- (IBAction)toogleCheckBoxDisableRSVP:(id)sender {
    
    if(isRSVPDateDibleChecked==true)
    {
        [lblSelectRSVPDate setAlpha:1];
        lblSelectRSVPDate.userInteractionEnabled=true;
        isRSVPDateDibleChecked=false;
        [btnDisableRSVPDeadLine setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
    }
    else{
        lblSelectRSVPDate.text=@"";
        [lblSelectRSVPDate setAlpha:0.3];
        lblSelectRSVPDate.userInteractionEnabled=false;
        isRSVPDateDibleChecked=true;
        [btnDisableRSVPDeadLine setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
    }
}

- (IBAction)toggleRadioButtonRecurringYes:(id)sender
{
    isRecurringYes=true;
    [btnRecurringYes setImage:nil forState:UIControlStateNormal];
    [btnRecurringNo setImage:nil forState:UIControlStateNormal];
    [btnRecurringYes setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
    [btnRecurringNo setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    recurringUiViewVisblity.hidden=false;
    recurringUiViewVisblity.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    
    
    [UIView animateWithDuration:0.3/1.5 animations:^{
        recurringUiViewVisblity.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3/2 animations:^{
            recurringUiViewVisblity.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.3/2 animations:^{
                recurringUiViewVisblity.transform = CGAffineTransformIdentity;
            }];
        }];
    }];
}
- (IBAction)toggleRadioButtonRecurringNo:(id)sender {
    
    isRecurringYes=false;
    [btnRecurringNo setImage:nil forState:UIControlStateNormal];
    [btnRecurringYes setImage:nil forState:UIControlStateNormal];
    [btnRecurringNo setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
    [btnRecurringYes setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    recurringUiViewVisblity.hidden=true;
}
- (IBAction)toggleRadioButtonRemainderYes:(id)sender
{
    remainderMainViewhideShow.hidden=false;
    IsRemainderYes=true;
    [btnRemainderNo setImage:nil forState:UIControlStateNormal];
    [btnRemainderYes setImage:nil forState:UIControlStateNormal];
    [btnRemainderYes setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
    [btnRemainderNo setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    remainderMainViewhideShow.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    
    [UIView animateWithDuration:0.3/1.5 animations:^{
        remainderMainViewhideShow.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3/2 animations:^{
            remainderMainViewhideShow.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.3/2 animations:^{
                remainderMainViewhideShow.transform = CGAffineTransformIdentity;
            }];
        }];
    }];
    
}


- (IBAction)toggleRadioButtonRemainderNo:(id)sender {
    remainderMainViewhideShow.hidden=true;
    
    IsRemainderYes=false;
    [btnRemainderNo setImage:nil forState:UIControlStateNormal];
    [btnRemainderYes setImage:nil forState:UIControlStateNormal];
    [btnRemainderNo setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
    [btnRemainderYes setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
}
- (IBAction)toggleWholeDayOrTimedEvet:(id)sender
{
    staticLableStartTime.hidden=true;
    staticLableEndTime.hidden=true;
    
    isWholeDayEvent=false;
    [btnWholedayEvent setImage:nil forState:UIControlStateNormal];
    [btnTimedEvent setImage:nil forState:UIControlStateNormal];
    [btnWholedayEvent setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
    [btnTimedEvent setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    
    CGSize textFieldNotesFrame = textFieldName.frame.size;
    
    CGPoint btnSelectStartDatePosXAndY = btnSelectStartDate.frame.origin;
    CGPoint btnSelectEndDatePosXAndY = btnSelectEndDate.frame.origin;
    
    [btnSelectStartDate setFrame:CGRectMake(btnSelectStartDatePosXAndY.x, btnSelectStartDatePosXAndY.y,textFieldNotesFrame.width, textFieldNotesFrame.height)];
    [lblDate1 setFrame:CGRectMake(btnSelectStartDatePosXAndY.x+10, btnSelectStartDatePosXAndY.y,textFieldNotesFrame.width, textFieldNotesFrame.height)];
    
    [lblDate2 setFrame:CGRectMake(btnSelectEndDatePosXAndY.x+10, btnSelectEndDatePosXAndY.y,textFieldNotesFrame.width, textFieldNotesFrame.height)];
    [btnSelectEndDate setFrame:CGRectMake(btnSelectEndDatePosXAndY.x, btnSelectEndDatePosXAndY.y,textFieldNotesFrame.width, textFieldNotesFrame.height)];
    
    [lblTime1 setHidden:true];
    [lblTime2 setHidden:true];
    [btnSelectStartTime setHidden:true];
    [btnSelectEndTime setHidden:true];
    
}

//hide keyboard
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.searchTableController toggleHidden:YES];
    
}

-(void)oPenDatePicker
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    [UIView commitAnimations];
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (IBAction)btnDonePressForRecurringView:(id)sender {
    recurringUiViewVisblity.hidden=true;
    
}
- (IBAction)recurringDatePickerClicked:(id)sender {
    if(isRecurringDatePickerOpened==false){
        isRecurringDatePickerOpened=true;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
        [UIView commitAnimations];
        return;
    }
}
- (IBAction)toggleRadioButtonEndDate:(id)sender {
    repeatEndsRadioSelectionString = [NSString stringWithFormat:@"%d",3];
    textFieldRecurringNumberOFTimes.text=@"";
    
    [textFieldRecurringNumberOFTimes setUserInteractionEnabled:false];
    [btnRecurringDateForBorder setUserInteractionEnabled:true];
    [btnRecurringEndDate setImage:[UIImage imageNamed:@"radiobutton_on.png"] forState:UIControlStateNormal];
    [btnRecurringNumberOfTimes setImage:[UIImage imageNamed:@"radiobutton_off.png"] forState:UIControlStateNormal];
    [btnRecurringForEver setImage:[UIImage imageNamed:@"radiobutton_off.png"] forState:UIControlStateNormal];
}
- (IBAction)toggleRadioButtonForEver:(id)sender {
    repeatEndsRadioSelectionString = [NSString stringWithFormat:@"%d",1];
    textFieldRecurringNumberOFTimes.text=@"";
    lblRecurringDate.text = @"";
    [textFieldRecurringNumberOFTimes setUserInteractionEnabled:false];
    [btnRecurringDateForBorder setUserInteractionEnabled:false];
    [btnRecurringEndDate setImage:[UIImage imageNamed:@"radiobutton_off.png"] forState:UIControlStateNormal];
    [btnRecurringNumberOfTimes setImage:[UIImage imageNamed:@"radiobutton_off.png"] forState:UIControlStateNormal];
    [btnRecurringForEver setImage:[UIImage imageNamed:@"radiobutton_on.png"] forState:UIControlStateNormal];
}

- (IBAction)toggleRadioButtonNumberOfTimes:(id)sender {
    isRecurringDatePickerOpened=false;
    [self hideDatePickerOnAlertAndOnDateSelected];
    
    repeatEndsRadioSelectionString = [NSString stringWithFormat:@"%d",2];
    lblRecurringDate.text = @"";
    [textFieldRecurringNumberOFTimes setUserInteractionEnabled:true];
    [btnRecurringDateForBorder setUserInteractionEnabled:false];
    [btnRecurringEndDate setImage:[UIImage imageNamed:@"radiobutton_off.png"] forState:UIControlStateNormal];
    [btnRecurringNumberOfTimes setImage:[UIImage imageNamed:@"radiobutton_on.png"] forState:UIControlStateNormal];
    [btnRecurringForEver setImage:[UIImage imageNamed:@"radiobutton_off.png"] forState:UIControlStateNormal];
}
- (IBAction)weeklyCheboxClicked:(id)sender {
    NSInteger tag = [sender tag];
    
    switch (tag){
        case 91: {
            if(isMondayChecked==false)
            {
                isMondayChecked=true;
                [btnMonday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
            }
            else{
                isMondayChecked=false;
                [btnMonday setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
            }
            
        }
            break;
        case 92: {
            if(isTuesdayChecked==false)
            {
                isTuesdayChecked=true;
                [btnTuesday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
            }
            else{
                isTuesdayChecked=false;
                [btnTuesday setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
            }
        }
            break;
        case 93: {
            if(isWednesdayChecked==false)
            {
                isWednesdayChecked=true;
                [btnWednesday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
            }
            else{
                isWednesdayChecked=false;
                [btnWednesday setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
            }
        }
            break;
        case 94: {
            if(isThursdayChecked==false)
            {
                isThursdayChecked=true;
                [btnThursday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
            }
            else{
                isThursdayChecked=false;
                [btnThursday setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
            }
        }
            break;
        case 95: {
            if(isFridayChecked==false)
            {
                isFridayChecked=true;
                [btnFriday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
            }
            else{
                isFridayChecked=false;
                [btnFriday setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
            }
        }
            break;
        case 96: {
            if(issaturdayChecked==false)
            {
                issaturdayChecked=true;
                [btnSaturday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
            }
            else{
                issaturdayChecked=false;
                [btnSaturday setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
            }
        }
            break;
        case 97: {
            if(isSundayChecked==false)
            {
                isSundayChecked=true;
                [btnsunday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
            }
            else{
                isSundayChecked=false;
                [btnsunday setImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
            }
        }
            break;
        default:
            break;
    }
}
- (IBAction)btnRemainderDoneClicked:(id)sender {
    remainderMainViewhideShow.hidden=true;
    schedulingConflictPopUpView.hidden=true;
    [self.searchTableController toggleHidden:YES];
}

- (IBAction)btnRemainderDayPickerClicked:(id)sender {
}

- (IBAction)btnRemainderHourPickerClicked:(id)sender {
}

- (IBAction)btnRemainderMinuteClicked:(id)sender {
}


#pragma mark AutoCompletePlace
-(void)loadAutocompletandSearchTable{
    _autoComplete = [[MNAutoComplete alloc] initWithDelegate:self];
    self.searchTableController = [[SearchViewController alloc] initWithStyle:UITableViewStylePlain];
    //    self.searchTableController.tableView.frame = CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height);
    self.searchTableController.tableView.frame = CGRectMake(txtSourceLocationPlaceApi.frame.origin.x,txtSourceLocationPlaceApi.frame.origin.y+30, txtSourceLocationPlaceApi.frame.size.width,pickerBackGroundView.frame.size.height);
    self.searchTableController.view.layer.zPosition = 100;
    
    self.searchTableController.delegate = self;
    [scrollView addSubview:self.searchTableController.tableView];
    [self.searchTableController toggleHidden:YES];
    
    self.searchTableController.tableView.layer.borderWidth = 2;
    self.searchTableController.tableView.layer.borderColor = [[UIColor blackColor] CGColor];
    
}


-(NSArray *)getSearchHistory{
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"SEARCH_HISTORY"];
}



#pragma mark - Search Delegate
-(void)didSelectSearchedString:(NSString *)selectedString{
    NSLog(@"SELECTED %@",selectedString);
    txtSourceLocationPlaceApi.text=selectedString;
    textFieldLocation.text = @"Other";
    [self.searchTableController toggleHidden:YES];
}

#pragma mark - Autocomplete Delegate
- (void)autocompleteDidReturn:(NSArray *)results {
    NSLog(@"results %@",results);
    [self.searchTableController reloadDataWithSource:results];
}

-(void)autocompleteDidFailWithError:(NSError *)error{
    
}

#pragma mark - Search Text Field

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    [textField resignFirstResponder];
    
    return YES;
}// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if(textField.text.length>=2 && txtSourceLocationPlaceApi==textField)
    {
        [self.searchTableController toggleHidden:NO];
        [_autoComplete startWithKeyword:textField.text];
        
    }
    if (textField.text.length<=1 && txtSourceLocationPlaceApi==textField) {
        [self.searchTableController toggleHidden:YES];
    }
    
    return YES;
}// return NO to not change text

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    return YES;
}// when clear button pressed. return NO to ignore (no notifications)

- (IBAction)btnUserImageClicked:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Photo Library", @"Saved Album", nil];
    actionSheet.tag = 1;
    [actionSheet showInView:self.view];
}

#pragma mark - dataSource method
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return scheduleConflictArray.count;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"UMCell";
    UMTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    NSString *currentText;
    
    id object = [[scheduleConflictArray objectAtIndex:indexPath.row] valueForKey:@"msg"];
    
    if (object == [NSNull null])
        return cell;
    
    currentText = cell.label.text = [[[scheduleConflictArray objectAtIndex:indexPath.row] valueForKey:@"msg"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    cell.label.numberOfLines = 3;
    cell.label.lineBreakMode=YES;
    
    if (cell==Nil) {
        cell = [[UMTableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    cell.delegate = self;
    
    return cell;
    
}

-(void)responseSuccessMessage
{
    EventsListViewController *controllerEvent = [self.storyboard instantiateViewControllerWithIdentifier:@"eventsListViewController"];
    
    for (UIViewController *controller in self.navigationController.viewControllers)
    {
        if ([controller isKindOfClass:[controllerEvent class]])
        {
            [self.navigationController popToViewController:controller animated:YES];
            
            break;
        }
    }
    //      [self.navigationController popToViewController:controller animated:YES];
    //    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - WebService
#pragma mark -
- (void) addEventSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    [self performSelector:@selector(responseSuccessMessage) withObject:self afterDelay:2];
}

- (void) addEventFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSDictionary *responseData = [dictionary objectForKey:@"data"];
    NSArray *schedulingConflictDict = [responseData valueForKey:@"conflict"];
    scheduleConflictArray = [schedulingConflictDict mutableCopy];
    
    lblSchedulingConflict.text = [NSString stringWithFormat:@"Your suggested time of %@ - %@ conflicts with the following existing calendar entries:",lblDate1.text,lblDate2.text];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    [schedulingConflictPopUpView setHidden:false];
    [self.tableView reloadData];
    
    
}
- (void) editEventSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    [self performSelector:@selector(responseSuccessMessage) withObject:self afterDelay:2];
    
}

- (void) editEventFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSDictionary *responseData = [dictionary objectForKey:@"data"];
    NSArray *schedulingConflictDict = [responseData valueForKey:@"conflict"];
    scheduleConflictArray = [schedulingConflictDict mutableCopy];
    lblSchedulingConflict.text = [NSString stringWithFormat:@"Your suggested time of %@ - %@ conflicts with the following existing calendar entries:",lblDate1.text,lblDate2.text];
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    [schedulingConflictPopUpView setHidden:false];
    
    [self.tableView reloadData];
    
}

#pragma mark - WebService
#pragma mark -

- (void) getListOfCategorySuccess:(NSNotification *)notification{
    [self hideProgressHud];
    
    NSString *remainderEmailAndNotificationTxt = txtRemainderEmailAndNotification.text;
    if(remainderEmailAndNotificationTxt.length==0)
        txtRemainderEmailAndNotification.text=@"Email & Notification";
    [txtRemainderEmailAndNotification setSelectedItem:remainderEmailAndNotificationTxt];
    
    NSString *privacyTxt = textFieldPrivacy.text;
    if(privacyTxt.length==0)
        textFieldPrivacy.text=@"Myself And Anyone I Invite";
    [textFieldPrivacy setSelectedItem:privacyTxt];
    
    NSString *remainderOneHourPriorTxt = txtRemainderOneDayPrior.text;
    if(remainderOneHourPriorTxt.length==0)
        txtRemainderOneDayPrior.text=@"1 Hour Prior";
    [txtRemainderOneDayPrior setSelectedItem:remainderOneHourPriorTxt];
    
    NSString *recurringTypeTxt = textFieldRecurringType.text;
    if(recurringTypeTxt.length==0)
        textFieldRecurringType.text=@"Daily";
    [textFieldRecurringType setSelectedItem:recurringTypeTxt];
    
    
    if(categoryNameArray.count>0)
        return;
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSDictionary *locationsDict = [dictionary objectForKey:@"data"];
    NSArray *locationArray = [locationsDict valueForKey:@"categoies"];
    if(locationArray.count==0)
    {
        [textFieldTypeOfEvent setItemList:[NSArray arrayWithObjects:@"None",@"Other",nil]];
        textFieldTypeOfEvent.text=@"None";
        [textFieldTypeOfEvent setSelectedItem:@"None"];
        return;
    }
    
    for (int i=0; i<locationArray.count; i++) {
        NSString *strCategryName = [[[locationArray objectAtIndex:i] valueForKey:@"value"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *strCategoryId = [[locationArray objectAtIndex:i] valueForKey:@"id"];
        strCategoryId = [NSString stringWithFormat:@"%@",strCategoryId];
        if([strCategoryId isEqualToString:@"none"])
            continue;
        
        [categoryIdArray addObject:strCategoryId];
        [categoryNameArray addObject:strCategryName];
    }
    
    NSArray *firstArray = [NSArray arrayWithObjects:@"None",@"Other",nil];
    NSArray  *secondArray = [categoryNameArray copy];
    
    NSString *textFieldLocationIdIs;
    if(allRecordArray.count>0)
        textFieldLocationIdIs = [[allRecordArray objectAtIndex:0] valueForKey:@"cat_id"];
    
    for (int i=0; i<categoryIdArray.count; i++) {
        NSString *strLocationId = [categoryIdArray objectAtIndex:i];
        if([strLocationId isEqualToString:textFieldLocationIdIs]){
            NSString *strCategoryName = [categoryNameArray objectAtIndex:i];
            typeOfEvenetStorageStr = [strCategoryName stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            break;
        }
    }
    if ([textFieldTypeOfEvent.text isEqualToString:@"other"]){
        textFieldTypeOfEvent.text = @"Other";
    }
    else if([textFieldTypeOfEvent.text isEqualToString:@"none"])
    {
        textFieldTypeOfEvent.text = @"None";
        [textFieldTypeOfEvent setSelectedItem:@"None"];
    }
    NSArray  *newArray=[firstArray arrayByAddingObjectsFromArray:secondArray];
    
    [textFieldTypeOfEvent setItemList:newArray];
    textFieldTypeOfEvent.text = typeOfEvenetStorageStr;
    if(typeOfEvenetStorageStr.length==0)
        textFieldTypeOfEvent.text=@"Other";
    [textFieldTypeOfEvent setSelectedItem:textFieldTypeOfEvent.text];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    [dataDictionary setObject:userid forKey:@"userid"];
    [self showProgressHud];
    [[WebService sharedWebService] callgetListOfLocation:dataDictionary];
}

- (void)getListOfCategoryFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) getEditSingleEventSuccess:(NSNotification *)notifications
{
    [self hideProgressHud];
    
    if([existingEnentIdString isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:kEventId]])
        return;
    NSDictionary *dictionary = notifications.object;
    
    NSArray *responseDataArray = [dictionary objectForKey:@"data"];
    
    NSDictionary *responseDatadict;
    NSArray *individualRecordArray;
    
    individualRecordArray = [responseDataArray valueForKey:@"events"];
    for (int i=0; i<individualRecordArray.count; i++) {
        
        responseDatadict = [individualRecordArray objectAtIndex:i];
        NSLog(@"responseDatadict %@",responseDatadict);
        //        if([textFieldTypeOfEvent.text isEqualToString:@"Other"])
        //        {
        textFieldTypeOfEvent.text= [responseDatadict objectForKey:@"cateogry"];
        
        //        textFieldType.text=[responseDatadict objectForKey:@"category_other"];
        
        //        }
        //        else
        //        {
        //            textFieldTypeOfEvent.text= [responseDatadict objectForKey:@"category"];
        //        }
        
        
        textFieldName.text=[[responseDatadict objectForKey:@"title"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        textFieldNotes.text= [[responseDatadict objectForKey:@"desc"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSString *totalHoursString = [responseDatadict objectForKey:@"duration_hours"];
        if(totalHoursString.length>0)
            lblTotalDuration.text = totalHoursString;
        
        
        id objectDate =  [responseDatadict valueForKey:@"last_rsvp_date"];
        if (objectDate == [NSNull null])
        {
            
        }else{
            NSString *dateStringRSVP = [responseDatadict objectForKey:@"last_rsvp_date"];
            if([dateStringRSVP isEqualToString:@"1970-01-01"] || [dateStringRSVP isEqualToString:@"0000-00-00"])
            {
                lblSelectRSVPDate.text=@"";
            }
            else{
                if(![dateStringRSVP isEqualToString:@""]){
                    NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
                    NSDate *dateFromString = [[NSDate alloc] init];
                    dateFromString =  [dateFormatter dateFromString:dateStringRSVP];
                    datePicker.date = dateFromString;
                    
                    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
                    if([dateFormatStr isEqualToString:@""] ){
                        lblSelectRSVPDate.text=@"";
                    }
                    lblSelectRSVPDate.text = [DateHandler getDateFromString:dateStringRSVP desireDateFormat:dateFormatStr dateFormatWeb:@""];
                    
                }
                isRSVPDateDibleChecked=true;
                [btnDisableRSVPDeadLine setImage:nil forState:UIControlStateNormal];
                [btnDisableRSVPDeadLine setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
            }
        }
        
        
        NSString *startDateString = [responseDatadict objectForKey:@"date"];
        
        if(![startDateString isEqualToString:@""] && startDateString.length>0){
            
            NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
            NSDate *dateFromString = [[NSDate alloc] init];
            dateFromString =  [dateFormatter dateFromString:startDateString];
            datePicker.date = dateFromString;
            firstSelectedDate = dateFromString;
            NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
            if([dateFormatStr isEqualToString:@""] ){
                lblDate1.text=@"";
            }
            lblDate1.text = [DateHandler getDateFromString:startDateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
        }
        
        NSString *endDateString = [responseDatadict objectForKey:@"end_date"];
        
        if(![endDateString isEqualToString:@""] && endDateString.length>0){
            
            NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
            NSDate *dateFromString = [[NSDate alloc] init];
            dateFromString =  [dateFormatter dateFromString:endDateString];
            datePicker.date = dateFromString;
            secondSelectedDate = dateFromString;
            NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
            if([dateFormatStr isEqualToString:@""] ){
                lblDate1.text=@"";
            }
            lblDate2.text = [DateHandler getDateFromString:endDateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
        }
        
        
        //        NSTimeInterval interval = [secondSelectedDate timeIntervalSinceDate:firstSelectedDate];
        //        int hours = (int)interval / 3600;             // integer division to get the hours part
        //        int minutes = (interval - (hours*3600)) / 60; // interval minus hours part (in seconds) divided by 60 yields minutes
        //        NSString *timeDiff = [NSString stringWithFormat:@"%d:%02d", hours, minutes];
        //        totalHours= hours+totalHours;
        //        lblTotalDuration.text=[NSString stringWithFormat:@"%ld",(long)totalHours];
        
        NSString *timeFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KTimeFormat];
        timeFormatStr = [NSString stringWithFormat:@"%@",timeFormatStr];
        NSString *startTime = [responseDatadict objectForKey:@"time"];
        id objectStartTime =  startTime;
        if (objectStartTime == [NSNull null])
        {
            
        }else{
            lblTime1.text = [DateHandler convertTimeFormat:startTime timeFormat:timeFormatStr];
        }
        NSDateFormatter *dateFormatterStartTime;
        if([timeFormatStr isEqualToString:@"12"])
            dateFormatterStartTime = [DateHandler USDateFormatterWithDateFormat:@"hh:mm a"];
        else
            dateFormatterStartTime = [DateHandler USDateFormatterWithDateFormat:@"HH:mm"];
        
        firstSelectedDateForTime = [dateFormatterStartTime dateFromString:lblTime1.text];
        NSString *endTime = [responseDatadict objectForKey:@"end_time"];
        id objectEndTime =  endTime;
        if (objectEndTime == [NSNull null])
        {
            
        }else{
            lblTime2.text = [DateHandler convertTimeFormat:endTime timeFormat:timeFormatStr];
        }
        
        NSDateFormatter *dateFormatterEndTime;
        if([timeFormatStr isEqualToString:@"12"])
            dateFormatterEndTime = [DateHandler USDateFormatterWithDateFormat:@"hh:mm a"];
        else
            dateFormatterEndTime = [DateHandler USDateFormatterWithDateFormat:@"HH:mm"];
        
        secondSelectedDateForTime = [dateFormatterEndTime dateFromString:lblTime2.text];
        
        textFieldPrivacy.text=[responseDatadict objectForKey:@"access"];
        if([textFieldPrivacy.text isEqualToString:@"public"])
            textFieldPrivacy.text =@"Public";
        if([textFieldPrivacy.text isEqualToString:@"invite"])
            textFieldPrivacy.text =@"Myself And Anyone I Invite";
        
        //        txtSourceLocationPlaceApi.text=[responseDatadict objectForKey:@"location"];
        
        id object =  [responseDatadict valueForKey:@"location_name"];
        if (object == [NSNull null])
        {
            
        }else{
            textFieldLocation.text= [responseDatadict objectForKey:@"location_name"];
        }
        
        if([responseDatadict objectForKey:@"full_time"])
        {
            [self toggleRadioButtonTimedEvent:nil];
        }
        else{
            [self toggleWholeDayOrTimedEvet:nil];
            
        }
        if([textFieldLocation.text isEqualToString:@"none"]){
            textFieldLocation.text=@"None";
        }
        
        textFieldRecurringNumberOFTimes.text=[responseDatadict objectForKey:@"no_of_times"];
        
        /* Check for the Recurrig Event */
        if([[responseDatadict objectForKey:@"cal_type"] isEqualToString:@"repeating"])
        {
            isRecurringYes=true;
            [btnRecurringYes setImage:nil forState:UIControlStateNormal];
            [btnRecurringNo setImage:nil forState:UIControlStateNormal];
            [btnRecurringYes setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
            [btnRecurringNo setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
        }
        else if([[responseDatadict objectForKey:@"cal_type"] isEqualToString:@"single"])
        {
            isRecurringYes=false;
            [btnRecurringNo setImage:nil forState:UIControlStateNormal];
            [btnRecurringYes setImage:nil forState:UIControlStateNormal];
            [btnRecurringNo setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
            [btnRecurringYes setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
        }
        
        
        NSString *strTotalHoursAndMinutes = [responseDatadict objectForKey:@"estimate_time"];
        
        if(strTotalHoursAndMinutes.length>3){
            
            [self toggleRadioButtonEstimateTravelTime:nil];
            NSString *textTypeHour;
            if(strTotalHoursAndMinutes.length==3)
                textTypeHour = [strTotalHoursAndMinutes substringToIndex:1];
            else
                textTypeHour = [strTotalHoursAndMinutes substringToIndex:2];
            txtHours.text = textTypeHour;
            NSString *textTypeMin;
            if(strTotalHoursAndMinutes.length==3)
                textTypeMin = [strTotalHoursAndMinutes substringFromIndex: [strTotalHoursAndMinutes length] - 1];
            else
                textTypeMin = [strTotalHoursAndMinutes substringFromIndex: [strTotalHoursAndMinutes length] - 2];
            txtMinutes.text = textTypeMin;
        }
        else
        {
            isSetEstimateTravelTime=true;
            [self toggleRadioButtonEstimateTravelTime:nil];
        }
        
        textFieldRecurringType.text=[responseDatadict objectForKey:@"repeat_type"];
        
        id ceRepeatType = [responseDatadict objectForKey:@"ce_repeat_endtype"];
        if (!(ceRepeatType == [NSNull null] || ceRepeatType == NULL))
            
            repeatEndsRadioSelectionString =[responseDatadict objectForKey:@"ce_repeat_endtype"];
        
        if (![repeatEndsRadioSelectionString length] == 0)
        {
            if([repeatEndsRadioSelectionString isEqualToString:@"1"])
            {
                [self toggleRadioButtonForEver:nil];
                
            }
            else if([repeatEndsRadioSelectionString isEqualToString:@"2"])
            {
                [self toggleRadioButtonNumberOfTimes:nil];
                textFieldRecurringNumberOFTimes.text = [responseDatadict objectForKey:@"ce_count"];
                
            }
            else if([repeatEndsRadioSelectionString isEqualToString:@"3"])
            {
                [self toggleRadioButtonEndDate:nil];
                
                NSString *dateString;
                id dateStringIdObject = [responseDatadict objectForKey:@"ce_ends"];
                if(dateStringIdObject == [NSNull null])
                    dateString=@"2012-12-31";
                else
                    dateString = [responseDatadict objectForKey:@"ce_ends"];
                if(![dateString isEqualToString:@""]){
                    NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
                    NSDate *dateFromString = [[NSDate alloc] init];
                    dateFromString =  [dateFormatter dateFromString:dateString];
                    datePicker.date = dateFromString;
                    
                    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
                    if([dateFormatStr isEqualToString:@""] ){
                        lblRecurringDate.text=@"";
                    }else{
                        lblRecurringDate.text = [DateHandler getDateFromString:dateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
                    }
                }
            }
        }
        
        if([[responseDatadict objectForKey:@"ce_type"] isEqualToString:@"Weekly"])
        {
            [textFieldRecurringType setSelectedItem:@"Weekly"];
            NSArray *array = [responseDatadict objectForKey:@"ce_byday"];
            for (int i=0; i<array.count; i++) {
                NSString *strWeekDay = [array objectAtIndex:i];
                
                if (!([strWeekDay rangeOfString:@"mon"].location == NSNotFound)) {
                    isMondayChecked=true;
                    
                    [btnMonday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
                }
                
                else if(!([strWeekDay rangeOfString:@"tues"].location == NSNotFound)){
                    isTuesdayChecked=true;
                    [btnTuesday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
                }
                else if(!([strWeekDay rangeOfString:@"wednes"].location == NSNotFound)){
                    isWednesdayChecked=true;
                    [btnWednesday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
                }
                else if(!([strWeekDay rangeOfString:@"thurs"].location == NSNotFound)){
                    isThursdayChecked=true;
                    [btnThursday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
                }
                else if(!([strWeekDay rangeOfString:@"fri"].location == NSNotFound)){
                    isFridayChecked=true;
                    [btnFriday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
                }
                else if(!([strWeekDay rangeOfString:@"satur"].location == NSNotFound)){
                    issaturdayChecked=true;
                    [btnSaturday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
                }
                else if(!([strWeekDay rangeOfString:@"sun"].location == NSNotFound)){
                    isSundayChecked=true;
                    [btnsunday setImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
                }
            }
        }
        else
        {
            [textFieldRecurringType setSelectedItem:[responseDatadict objectForKey:@"ce_type"]];
        }
        
        /* Set HightLight on Label if Present */
        if([lblDate1.text isEqualToString:@"Select Date"])
            [[lblDate1 layer]setOpacity:0.2];
        else
            [[lblDate1 layer]setOpacity:1];
        
        if([lblDate2.text isEqualToString:@"Select Date"])
            [[lblDate2 layer]setOpacity:0.2];
        else
            [[lblDate2 layer]setOpacity:1];
        if([lblTime1.text isEqualToString:@"Select Time"])
            [[lblTime1 layer]setOpacity:0.2];
        else
            [[lblTime1 layer]setOpacity:1];
        
        if([lblTime2.text isEqualToString:@"Select Time"])
            [[lblTime2 layer]setOpacity:0.2];
        else
            [[lblTime2 layer]setOpacity:1];
        
        if([lblRecurringDate.text isEqualToString:@"Select Date"])
            [[lblRecurringDate layer] setOpacity:0.2];
        else
            [[lblRecurringDate layer]setOpacity:1];
        
        if([txtHours.text isEqualToString:@"Hours"])
            [txtHours setAlpha:0.3];
        
        if([txtMinutes.text isEqualToString:@"Minutes"])
            [txtMinutes setAlpha:0.3];
        
        
        NSString *strRemainderYesOrNo =  [responseDatadict objectForKey:@"reminder"];
        id objectstrRemainderYesOrNo =  strRemainderYesOrNo;
        if (objectstrRemainderYesOrNo == [NSNull null])
        {
            
        }else{
            if([strRemainderYesOrNo isEqualToString:@"yes"])
            {
                IsRemainderYes=true;
                [btnRemainderNo setImage:nil forState:UIControlStateNormal];
                [btnRemainderYes setImage:nil forState:UIControlStateNormal];
                [btnRemainderYes setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
                [btnRemainderNo setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
            }
            
            else if([strRemainderYesOrNo isEqualToString:@"no"])
            {
                IsRemainderYes=false;
                [btnRemainderNo setImage:nil forState:UIControlStateNormal];
                [btnRemainderYes setImage:nil forState:UIControlStateNormal];
                [btnRemainderNo setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
                [btnRemainderYes setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
                
            }
        }
        
        NSArray *multiple_reminderArray = [responseDatadict objectForKey:@"multiple_reminder"];
        if(multiple_reminderArray.count>0)
        {
            IsRemainderYes=true;
            [btnRemainderNo setImage:nil forState:UIControlStateNormal];
            [btnRemainderYes setImage:nil forState:UIControlStateNormal];
            [btnRemainderYes setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
            [btnRemainderNo setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
            
            NSString *notification = [[multiple_reminderArray objectAtIndex:0] valueForKey:@"ce_action"];
            if([notification isEqualToString:@"e"])
                notification=@"Email";
            else if([notification isEqualToString:@"n"])
                notification=@"Notification";
            else if([notification isEqualToString:@"en"])
                notification=@"Email & Notification";
            
            txtRemainderEmailAndNotification.text = notification;
            NSString *remainderEmailAndNotificationTxt = txtRemainderEmailAndNotification.text;
            if(remainderEmailAndNotificationTxt.length==0)
                txtRemainderEmailAndNotification.text=@"Email & Notification";
            [txtRemainderEmailAndNotification setSelectedItem:remainderEmailAndNotificationTxt];
            
            NSString *strTxtRemainderOneDayPrior = [[multiple_reminderArray objectAtIndex:0] objectForKey:@"ce_duration"];
            if([strTxtRemainderOneDayPrior isEqualToString:@"0"])
                strTxtRemainderOneDayPrior=@"On Time";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"15"])
                strTxtRemainderOneDayPrior=@"15 Minutes Prior";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"30"])
                strTxtRemainderOneDayPrior=@"30 Minutes Prior";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"45"])
                strTxtRemainderOneDayPrior=@"45 Minutes Prior";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"1"])
                strTxtRemainderOneDayPrior=@"1 Hour Prior";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"24"])
                strTxtRemainderOneDayPrior=@"24 Hour";
            else
                strTxtRemainderOneDayPrior=@"Other";
            txtRemainderOneDayPrior.text = strTxtRemainderOneDayPrior;
            [txtRemainderOneDayPrior setSelectedItem:txtRemainderOneDayPrior.text];
            [btnRemainderNo setImage:nil forState:UIControlStateNormal];
            [btnRemainderYes setImage:nil forState:UIControlStateNormal];
            txtRemainderDay1.text=[responseDatadict objectForKey:@"ce_days"];
            txtRemainderHour1.text=[responseDatadict objectForKey:@"ce_hours"];
            txtRemainderMin1.text=[responseDatadict objectForKey:@"ce_minutes"];
            [btnRemainderNo setImage:nil forState:UIControlStateNormal];
            [btnRemainderYes setImage:nil forState:UIControlStateNormal];
            
            [btnRemainderYes setImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
            [btnRemainderNo setImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
        }
        
        NSDictionary *rsvpDetailDict = [responseDatadict objectForKey:@"rsvp_details"];
        NSString *rsvpExpiresONot = [rsvpDetailDict objectForKey:@"rsvp_expire"];
        /*
         [dataDictionary setObject:checkTheDaysSelected forKey:@"weekday"];
         }
         
         [dataDictionary setObject:repeatEndsRadioSelectionString forKey:@"repeat_end"];
         }
         else{
         
         [dataDictionary setObject:@"single" forKey:@"event_type"];
         }
         */
        
        /*
         
         TIME BEING COMMENT
         
         */
        
        
        NSString *imgURL=[[responseDatadict objectForKey:@"event_image"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        if(![imgURL isEqualToString:@""] && ![imgURL isEqualToString:nil]){
            [UIImage loadFromURL:[NSURL URLWithString:imgURL] callback:^(UIImage *image){
                userImage.image = image;
            }];
        }
        
        if([textFieldTypeOfEvent.text isEqualToString:@"other"])
            textFieldTypeOfEvent.text=@"Other";
        
        textFieldNotes.text = [[responseDatadict objectForKey:@"desc"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }
    allRecordArray = [individualRecordArray mutableCopy];
    existingEnentIdString = [[NSUserDefaults standardUserDefaults] objectForKey:kEventId];
    
    [self showProgressHud];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    [dataDictionary setObject:userid forKey:@"userid"];
    
    [[WebService sharedWebService] callGetListOfCategoryWebService:dataDictionary];
    
}

- (void) getEditSingleEventFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
}

-(void)callAddAndEditEventWebservice:(NSInteger)isSchedulingComnflict
{
    [self.view endEditing:true];
    BOOL IsEditEvents = [[NSUserDefaults standardUserDefaults] boolForKey:@"IsEditEvents"];
    
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:kUserId];
    
    if(isSchedulingComnflict==1)
        [dataDictionary setObject:[NSString stringWithFormat:@"%ld",(long)isSchedulingComnflict] forKey:@"conflict_confirm"];
    else
        [dataDictionary setObject:[NSString stringWithFormat:@"%d",0] forKey:@"conflict_confirm"];
    
    if(textFieldType.text.length==0 || [textFieldType.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        textFieldType.text=@"";
    }
    else if ([textFieldType.text isEqualToString:@"Other"])
    {
        if(textFieldTypeOfEvent.text.length==0 || [textFieldTypeOfEvent.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
        {
            [self.view makeToast:@"Please enter type of event"];
            return;
        }
    }
    
    if(textFieldName.text.length==0 || [textFieldName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please enter name"];
        return;
    }
    
    [dataDictionary setObject:textFieldName.text forKey:@"title"];
    [dataDictionary setObject:textFieldNotes.text forKey:@"description"];
    
    NSString *txtTextFieldTypeOfEvent = textFieldTypeOfEvent.text;
    typeOfEvenetStorageStr = txtTextFieldTypeOfEvent;
    
    if([txtTextFieldTypeOfEvent isEqualToString:@"Other"]){
        txtTextFieldTypeOfEvent= @"other";
        [dataDictionary setObject:textFieldTypeOfEvent.text forKey:@"category_other"];
        [dataDictionary setObject:@"" forKey:@"category"];
    }
    else
    {
        NSString *strCategoryName = textFieldTypeOfEvent.text;
        NSString *strCategoryIdToSend=@"";
        for (int i=0; i<categoryNameArray.count; i++) {
            NSString *strLocationId = [categoryNameArray objectAtIndex:i];
            if([strLocationId isEqualToString:strCategoryName]){
                strCategoryIdToSend = [categoryIdArray objectAtIndex:i];
                break;
            }
        }
        [dataDictionary setObject:strCategoryIdToSend forKey:@"category"];
    }
    
    
    id objectlblDate1 = lblDate1.text;
    id objectlblDate2 = lblDate2.text;
    id objectlblTime1 = lblTime1.text;
    id objectlblTime2 = lblTime2.text;
    
    if([lblDate1.text isEqualToString:@"nil"] || objectlblDate1 == [NSNull null] || objectlblDate1 == nil){
        [self.view makeToast:@"Please select start date"];
        lblDate1.text=@"";
        return;
    }
    else if([lblDate2.text isEqualToString:@"nil"] || objectlblDate2 == [NSNull null] || objectlblDate2 == nil){
        [self.view makeToast:@"Please select end date"];
        lblDate2.text=@"";
        return;
    }
    if(lblDate1.text.length==0)
    {
        [self.view makeToast:@"Please select start date"];
        return;
        
    }
    if(lblDate2.text.length==0)
    {
        [self.view makeToast:@"Please select end date"];
        return;
    }
    
    /* COMPULSORY DATE TO SEND */
    
    if(lblDate1.text.length==0)
        lblDate1.text=@"";
    if(lblDate2.text.length==0)
        lblDate2.text=@"";
    
    NSString *startDateToSend = lblDate1.text;
    if(startDateToSend.length>0){
        startDateToSend = [DateHandler sendDateFromString:startDateToSend formatToSend:@"" currentDateFormat:dateFormatStr];
        [dataDictionary setObject:startDateToSend forKey:@"start_date"];
    }
    
    NSString *endDateToSend = lblDate2.text;
    if(endDateToSend.length>0)
    {
        endDateToSend = [DateHandler sendDateFromString:endDateToSend formatToSend:@"" currentDateFormat:dateFormatStr];
        [dataDictionary setObject:endDateToSend forKey:@"end_date"];
        [dataDictionary setObject:@"yes" forKey:@"full_time"];
    }
    
    if(isWholeDayEvent==false) /*Four Parameter if not whole day event */
    {
        
    }
    else
    {
        if ([lblTime1.text isEqualToString:@"nil"] || objectlblTime1 == [NSNull null]  || [lblTime1.text isKindOfClass:[NSNull class]] || objectlblTime1 ==nil)
        {
            [self.view makeToast:@"Please select start time"];
            lblTime1.text=@"";
            return;
        }
        else if ([lblTime2.text isEqualToString:@"nil"] || objectlblTime2 == [NSNull null] || [lblTime2.text isKindOfClass:[NSNull class]] || objectlblTime2 ==nil)
        {
            [self.view makeToast:@"Please select end time"];
            lblTime2.text=@"";
            return;
        }
        if(lblTime1.text.length==0)
        {
            [self.view makeToast:@"Please select start time"];
            lblTime1.text=@"";
            return;
        }
        if(lblTime2.text.length==0)
        {
            [self.view makeToast:@"Please select end time"];
            lblTime2.text=@"";
            return;
        }
        if([lblTime1.text isEqualToString:@"Select time"] || [lblTime1.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
            lblTime1.text=@"";
        }
        if([lblTime2.text isEqualToString:@"Select time"] || [lblTime2.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
            lblTime2.text=@"";
        }
        
        [dataDictionary setObject:lblTime1.text forKey:@"start_time"];
        [dataDictionary setObject:lblTime2.text forKey:@"end_time"];
        [dataDictionary setObject:@"no" forKey:@"full_time"];
        [dataDictionary setObject:startDateToSend forKey:@"start_date"];
        [dataDictionary setObject:endDateToSend forKey:@"end_date"];
    }
    
    if(isRSVPDateDibleChecked==false){
        NSString *dateToSend = lblSelectRSVPDate.text;
        if(dateToSend.length>0){
            dateToSend = [DateHandler sendDateFromString:dateToSend formatToSend:@"" currentDateFormat:dateFormatStr];
            [dataDictionary setObject:dateToSend forKey:@"last_rsvp_date"];
        }else{
            [dataDictionary setObject:@"" forKey:@"last_rsvp_date"];
        }
    }
    else{
        [dataDictionary setObject:@"" forKey:@"last_rsvp_date"];
    }
    NSString *strTextFieldPrivacy = textFieldPrivacy.text;
    if([strTextFieldPrivacy isEqualToString:@"Public"])
        strTextFieldPrivacy =@"public";
    if([strTextFieldPrivacy isEqualToString:@"Myself And Anyone I Invite"])
        strTextFieldPrivacy =@"invite";
    
    [dataDictionary setObject:strTextFieldPrivacy forKey:@"access"];
    
    if([textFieldLocation.text isEqualToString:@"Other"]){
        [dataDictionary setObject:@"other" forKey:@"location"];
        [dataDictionary setObject:txtSourceLocationPlaceApi.text forKey:@"location_other"];
    }
    else{
        NSString *strLocationName = textFieldLocation.text;
        NSString *strLocationIdToSend=@"";
        for (int i=0; i<locationName.count; i++) {
            NSString *strLocationId = [locationName objectAtIndex:i];
            if([strLocationId isEqualToString:strLocationName]){
                strLocationIdToSend = [locationIdArray objectAtIndex:i];
                break;
            }
        }
        [dataDictionary setObject:strLocationIdToSend forKey:@"location"];
    }
    
    if(isSetEstimateTravelTime==true)
    {
        [dataDictionary setObject:txtHours.text forKey:@"estimate_time_hours"];
        [dataDictionary setObject:txtMinutes.text forKey:@"estimate_time_minute"];
    }
    
    if(isRecurringYes==true){
        [dataDictionary setObject:@"repeating" forKey:@"event_type"];
        
        if(lblRecurringDate.text.length == 0 || [lblRecurringDate.text isEqualToString:@"Select Date"])
            lblRecurringDate.text=@"";
        
        if([repeatEndsRadioSelectionString isEqualToString:@"2"])
            [dataDictionary setObject:textFieldRecurringNumberOFTimes.text forKey:@"no_of_times"];
        else if ([repeatEndsRadioSelectionString isEqualToString:@"3"]){
            NSString *dateToSend = lblRecurringDate.text;
            if(dateToSend.length>0)
                dateToSend = [DateHandler sendDateFromString:dateToSend formatToSend:@"" currentDateFormat:dateFormatStr];
            [dataDictionary setObject:dateToSend forKey:@"r_end_date"];
        }
        
        [dataDictionary setObject:[NSString stringWithFormat:@"%@",repeatEndsRadioSelectionString]  forKey:@"repeat_end"];
        
        [dataDictionary setObject:textFieldRecurringType.text forKey:@"repeat_type"];
        NSString *checkTheDaysSelected=@"";
        if([textFieldRecurringType.text isEqualToString:@"Weekly"])
        {
            if(isSundayChecked==true)
                checkTheDaysSelected = [checkTheDaysSelected stringByAppendingString:@"sunday,"];
            if(isMondayChecked==true)
                checkTheDaysSelected = [checkTheDaysSelected stringByAppendingString:@"monday,"];
            if(isTuesdayChecked==true)
                checkTheDaysSelected = [checkTheDaysSelected stringByAppendingString:@"tuesday,"];
            if(isWednesdayChecked==true)
                checkTheDaysSelected = [checkTheDaysSelected stringByAppendingString:@"wednesday,"];
            if(isThursdayChecked==true)
                checkTheDaysSelected = [checkTheDaysSelected stringByAppendingString:@"thursday,"];
            if(isFridayChecked==true)
                checkTheDaysSelected = [checkTheDaysSelected stringByAppendingString:@"friday,"];
            if(issaturdayChecked==true)
                checkTheDaysSelected = [checkTheDaysSelected stringByAppendingString:@"saturday,"];
            
            if ([checkTheDaysSelected length] > 0) {
                checkTheDaysSelected = [checkTheDaysSelected substringToIndex:[checkTheDaysSelected length] - 1];
                [dataDictionary setObject:checkTheDaysSelected forKey:@"weekday"];
            }
        }
    }
    else{
        lblRecurringDate.text=@"";
        [dataDictionary setObject:@"single" forKey:@"event_type"];
    }
    
    if(IsRemainderYes==true)
    {
        [dataDictionary setObject:@"yes" forKey:@"reminder"];
        
        NSString *strTxtRemainderOneDayPrior = txtRemainderOneDayPrior.text;
        NSString *strtxtRemainderEmailAndNotification = txtRemainderEmailAndNotification.text;
        if([strtxtRemainderEmailAndNotification isEqualToString:@"Email & Notification"])
            [dataDictionary setObject:@"en" forKey:@"notification"];
        else if([strtxtRemainderEmailAndNotification isEqualToString:@"Notification"])
            [dataDictionary setObject:@"n" forKey:@"notification"];
        else if([strtxtRemainderEmailAndNotification isEqualToString:@"Email"])
            [dataDictionary setObject:@"e" forKey:@"notification"];
        
        if([strTxtRemainderOneDayPrior isEqualToString:@"Other"])
        {
            [dataDictionary setObject:@"other" forKey:@"offset_before"];
            [dataDictionary setObject:txtRemainderDay1.text forKey:@"ce_days"];
            [dataDictionary setObject:txtRemainderHour1.text    forKey:@"ce_hours"];
            [dataDictionary setObject:txtRemainderMin1.text forKey:@"ce_minutes"];
        }
        else
        {
            if([strTxtRemainderOneDayPrior isEqualToString:@"On Time"])
                strTxtRemainderOneDayPrior=@"0";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"15 Minutes Prior"])
                strTxtRemainderOneDayPrior=@"15";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"30 Minutes Prior"])
                strTxtRemainderOneDayPrior=@"30";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"45 Minutes Prior"])
                strTxtRemainderOneDayPrior=@"45";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"1 Hour Prior"])
                strTxtRemainderOneDayPrior=@"1";
            else if([strTxtRemainderOneDayPrior isEqualToString:@"24 Hour"])
                strTxtRemainderOneDayPrior=@"24";
            [dataDictionary setObject:strTxtRemainderOneDayPrior forKey:@"offset_before"];
        }
    }
    else
    {
        [dataDictionary setObject:@"no" forKey:@"reminder"];
    }
    if(isSetEstimateTravelTime==true)
    {
        [dataDictionary setObject:[NSString stringWithFormat:@"%ld",(long)totalHours] forKey:@"duration_hours"];
        
        [dataDictionary setObject:[NSString stringWithFormat:@"%ld",(long)totalMinutes] forKey:@"duration_minute"];
        
        //        NSString *txtHour;
        //        NSDate* date1 = someDate;
        //        NSDate* date2 = someOtherDate;
        //        NSTimeInterval distanceBetweenDates = [date1 timeIntervalSinceDate:date2];
        //        double secondsInAnHour = 3600;
        //        NSInteger hoursBetweenDates = distanceBetweenDates / secondsInAnHour;
        //        = [NSString stringWithFormat:@"%@", txtRemainderHour.text];
        //        txtHour = [NSString stringWithFormat:@"%@", txtHour];
        //
        //        NSString *txtMin = [NSString stringWithFormat:@"%@", txtRemainderMin.text];
        //        txtMin = [NSString stringWithFormat:@"%@", txtMin];
    }
    
    [self showProgressHud];
    
    
    if(!([imageStringAfterCrop isEqualToString:@""]) && imageStringAfterCrop != nil)
    {
        [dataDictionary setObject:imageStringAfterCrop forKey:@"image_path"];
    }
    
    if(IsEditEvents==false){
        [dataDictionary setObject:@"add" forKey:@"action"];
        [[WebService sharedWebService] callAddEventWebService:dataDictionary];
    }
    else
    {
        [dataDictionary setObject:@"edit" forKey:@"action"];
        
        if([existingEnentIdString isEqualToString:@""])
            existingEnentIdString = [[NSUserDefaults standardUserDefaults] valueForKey:kEventId];
        [dataDictionary setObject:[NSString stringWithFormat:@"%@",existingEnentIdString] forKey:@"id"];
        [[WebService sharedWebService] callEditEventWebService:dataDictionary];
    }
}


- (void) getListOfLocationSuccess:(NSNotification *)notification{
    [self hideProgressHud];
    
    if(locationIdArray.count>0)
        return;
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSDictionary *locationsDict = [dictionary objectForKey:@"data"];
    NSArray *locationArray = [locationsDict valueForKey:@"location"];
    if(locationArray.count==0)
    {
        [textFieldLocation setItemList:[NSArray arrayWithObjects:@"None",@"Other",nil]];
        textFieldLocation.text=@"None";
        [textFieldLocation setSelectedItem:@"None"];
        return;
    }
    
    for (int i=0; i<locationArray.count; i++) {
        NSString *strLocationName = [[[locationArray objectAtIndex:i] valueForKey:@"loc_name"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *strLocationId = [[locationArray objectAtIndex:i] valueForKey:@"id"];
        if([strLocationId isEqualToString:@"none"])
            continue;
        
        [locationIdArray addObject:strLocationId];
        [locationName addObject:strLocationName];
    }
    
    NSArray *firstArray = [NSArray arrayWithObjects:@"None",@"Other",nil];
    NSArray  *secondArray = [locationName copy];
    
    
    NSString *textFieldLocationIdIs=textFieldLocation.text;
    
    for (int i=0; i<locationIdArray.count; i++) {
        NSString *strLocationId = [locationIdArray objectAtIndex:i];
        if([strLocationId isEqualToString:textFieldLocationIdIs]){
            textFieldLocation.text = [[locationName objectAtIndex:i] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            break;
        }
    }
    if ([textFieldLocationIdIs isEqualToString:@"none"]){
        textFieldLocation.text = @"None";
        [textFieldLocation setSelectedItem:@"None"];
    }
    if(textFieldLocationIdIs.length==0)
        textFieldLocation.text = @"None";
    
    NSArray  *newArray=[firstArray arrayByAddingObjectsFromArray:secondArray];
    [textFieldLocation setItemList:newArray];
    [textFieldLocation setSelectedItem:textFieldLocation.text];
}

- (void)getListOfLocationFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

#pragma mark UIActionSheet delegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    if ([@"Camera" isEqualToString:title] && [UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([@"Photo Library" isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([@"Saved Album" isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    }
    
}

#pragma mark UIImagePickerControllerDelegate
-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSMutableDictionary *)info {
    UIImage *originalImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    isDataFromWebservice=false;
#ifdef DEV_ENVIRONMENT
    NSLog (@"Image Size, %f, %f", originalImage.size.width, originalImage.size.height
           );
#endif
    
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        [self openCropEditor:[[UIImage memoryOptimizedImageWithImage:originalImage] fixOrientation]];
    }];
}

#pragma mark photo cropper
-(void) openCropEditor:(UIImage *) image {
    PECropViewController *controller = [[PECropViewController alloc] init];
    controller.delegate = self;
    controller.image = image;
    controller.cropAspectRatio = 1;
    
    controller.keepingCropAspectRatio = YES;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:controller];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        navigationController.modalPresentationStyle = UIModalPresentationFormSheet;
    }
    
    [self presentViewController:navigationController animated:YES completion:NULL];
}


- (void)cropViewController:(PECropViewController *)controller didFinishCroppingImage:(UIImage *)croppedImage {
    
    [controller dismissViewControllerAnimated:YES completion:NULL];
    userImage.image = nil;
    userImage.image=croppedImage;
    CGSize imageViewSize = userImage.frame.size;
    
    UIGraphicsBeginImageContext(imageViewSize);
    [croppedImage drawInRect:CGRectMake(0,0,imageViewSize.width,imageViewSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    [Base64 initialize];
    NSData *imageData = UIImageJPEGRepresentation(newImage,1);
    NSString *strEncoded = [Base64 encode:imageData];
    imageStringAfterCrop=@"";
    imageStringAfterCrop = strEncoded;
}

-(void) cropViewControllerDidCancel:(PECropViewController *)controller {
    [controller dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction)btnScheduleConflictCancelClicked:(id)sender {
    [schedulingConflictPopUpView setHidden:true];
}

- (IBAction)btnScheduleConflictOklClicked:(id)sender {
    [schedulingConflictPopUpView setHidden:true];
    [self callAddAndEditEventWebservice:1];
}




@end

