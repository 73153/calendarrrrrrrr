//
//  EventViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "EventViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "EditProfileViewController.h"
#import "MBProgressHUD.h"
#import "InboxMessageViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "EventFeedViewController.h"
#import "EditEventsViewController.h"

#import "RSVPViewController.h"
#import "InviteGuestViewController.h"
#import "ManageGuestViewController.h"
#import "ComposingMessageViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "DateHandler.h"
#import "MapViewController.h"

@interface EventViewController ()
{
    NSString *maleOrFemale;
}

@end

@implementation EventViewController

@synthesize txtEventMainTitle;
@synthesize txtPlaceBelowMainEvent;
@synthesize txtTypeOfEvent;
@synthesize txtNotes;
@synthesize txtStartDate;
@synthesize txtStartTime;
@synthesize txtDuration;
@synthesize txtRepeating;
@synthesize txtBirthDate;
@synthesize scrollView;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnSendMessage;
@synthesize roundedBtnDelete;
@synthesize roundedBtnEdit;
@synthesize roundedBtnInviteGuest;
@synthesize roundedBtnManageGuest;
@synthesize roundedBtnRoundedOption;
@synthesize roundedBtnRsvpStyle;
@synthesize oldDictionary;
@synthesize isDataFromWebservice;
@synthesize deleteAllFollowingLbl;
@synthesize deleteAllInstanceLbl;
@synthesize deleteAllotherLbl;
@synthesize deleteHeaderLbl;
@synthesize deletePopUpView;
@synthesize btnDeleteAllFollowingRoundedCorner;
@synthesize btnDeleteAllInstancesRoundedCorner;
@synthesize btnDeleteOnlyThisInstanceRoundedCorner;
@synthesize deleteCloseBtnRoundedCorner;
@synthesize allRecordArray;
@synthesize deleteHearderLbl;
-(void)viewDidLoad
{
    // Create a tab bar and set it as root view for the application
    [self hideProgressHud];
    maleOrFemale = @"M";
    [self setTitle:@"Event"];
    
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Event"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    oldDictionary = [[NSMutableDictionary alloc] init];
    
    //    roundedBtnSendMessage.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnSendMessage.layer.borderWidth = 2.0f;
    roundedBtnSendMessage.clipsToBounds=YES;
    roundedBtnSendMessage.layer.cornerRadius = 5;
    
    //    roundedBtnDelete.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnDelete.layer.borderWidth = 2.0f;
    roundedBtnDelete.clipsToBounds=YES;
    roundedBtnDelete.layer.cornerRadius = 5;
    
    //    roundedBtnEdit.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnEdit.layer.borderWidth = 2.0f;
    roundedBtnEdit.clipsToBounds=YES;
    roundedBtnEdit.layer.cornerRadius = 5;
    
    
    //    roundedBtnInviteGuest.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnInviteGuest.layer.borderWidth = 2.0f;
    roundedBtnInviteGuest.clipsToBounds=YES;
    roundedBtnInviteGuest.layer.cornerRadius = 5;
    
    //    roundedBtnManageGuest.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnManageGuest.layer.borderWidth = 2.0f;
    roundedBtnManageGuest.clipsToBounds=YES;
    roundedBtnManageGuest.layer.cornerRadius = 5;
    
    roundedBtnRoundedOption.layer.borderColor = [UIColor blackColor].CGColor;
    roundedBtnRoundedOption.layer.borderWidth = 2.0f;
    roundedBtnRoundedOption.clipsToBounds=YES;
    roundedBtnRoundedOption.layer.cornerRadius = 5;
    
    //    roundedBtnRsvpStyle.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnRsvpStyle.layer.borderWidth = 2.0f;
    roundedBtnRsvpStyle.clipsToBounds=YES;
    roundedBtnRsvpStyle.layer.cornerRadius = 5;
    
    txtEventMainTitle.numberOfLines=3;
    deleteAllFollowingLbl.numberOfLines=3;
    deleteAllInstanceLbl.numberOfLines=3;
    deleteAllotherLbl.numberOfLines=3;
    deleteHeaderLbl.numberOfLines=3;
    txtTypeOfEvent.numberOfLines=3;
    txtPlaceBelowMainEvent.titleLabel.numberOfLines=3;
    [txtPlaceBelowMainEvent.titleLabel setTextAlignment:NSTextAlignmentCenter];
    deleteHearderLbl.numberOfLines=3;
    
    deleteHearderLbl.lineBreakMode=YES;
    txtPlaceBelowMainEvent.titleLabel.lineBreakMode=YES;
    txtEventMainTitle.lineBreakMode=YES;
    txtTypeOfEvent.lineBreakMode=YES;
    deleteAllFollowingLbl.lineBreakMode=YES;
    deleteAllInstanceLbl.lineBreakMode=YES;
    deleteAllotherLbl.lineBreakMode=YES;
    deleteHeaderLbl.lineBreakMode=YES;
    
    deletePopUpView.layer.cornerRadius=8;
    deletePopUpView.clipsToBounds=YES;
    deletePopUpView.layer.borderColor = [UIColor blackColor].CGColor;
    deletePopUpView.layer.borderWidth = 5.0f;
    
    deletePopUpView.hidden=true;
    
    //    [deleteCloseBtnRoundedCorner setBackgroundColor:[UIColor lightGrayColor]];
    //    deleteCloseBtnRoundedCorner.layer.borderColor = [UIColor blackColor].CGColor;
    deleteCloseBtnRoundedCorner.layer.borderWidth = 2.0f;
    deleteCloseBtnRoundedCorner.layer.cornerRadius=8;
    deleteCloseBtnRoundedCorner.clipsToBounds=YES;
    
    
    [btnDeleteAllFollowingRoundedCorner setBackgroundColor:[UIColor lightGrayColor]];
    btnDeleteAllFollowingRoundedCorner.layer.borderColor = [UIColor blackColor].CGColor;
    btnDeleteAllFollowingRoundedCorner.layer.borderWidth = 2.0f;
    
    btnDeleteAllFollowingRoundedCorner.layer.cornerRadius=8;
    btnDeleteAllFollowingRoundedCorner.clipsToBounds=YES;
    
    [btnDeleteAllInstancesRoundedCorner setBackgroundColor:[UIColor lightGrayColor]];
    btnDeleteAllInstancesRoundedCorner.layer.borderColor = [UIColor blackColor].CGColor;
    btnDeleteAllInstancesRoundedCorner.layer.borderWidth = 2.0f;
    btnDeleteAllInstancesRoundedCorner.layer.cornerRadius=8;
    btnDeleteAllInstancesRoundedCorner.clipsToBounds=YES;
    
    [btnDeleteOnlyThisInstanceRoundedCorner setBackgroundColor:[UIColor lightGrayColor]];
    btnDeleteOnlyThisInstanceRoundedCorner.layer.borderColor = [UIColor blackColor].CGColor;
    btnDeleteOnlyThisInstanceRoundedCorner.layer.borderWidth = 2.0f;
    btnDeleteOnlyThisInstanceRoundedCorner.layer.cornerRadius=8;
    btnDeleteOnlyThisInstanceRoundedCorner.clipsToBounds=YES;
    
    allRecordArray = [[NSMutableArray alloc] init];
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,800)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1600)];
    }
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"EventFeedBlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getSingleEventsWebServiceSuccess:) name:kGetSingleEventsWebServiceSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getSingleEventsWebServiceFailed:) name:kGetSingleEventsWebServiceFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deleteEventsViewContorllerSuccess:) name:kDeleteEventsFromEventViewControllerSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deleteEventsViewContorllerFailed:) name:kDeleteEventsFromEventViewControllerFailed object:nil];
    
}

-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (BOOL) textView: (UITextView*) textView
shouldChangeTextInRange: (NSRange) range
  replacementText: (NSString*) text
{
    if ([text isEqualToString:@"\n"]) {
        [[textView layer] setOpacity:1];
        textView.text = [textView.text stringByReplacingOccurrencesOfString: @"\\n" withString: @"\n"];
        
        return YES;
    }
    return YES;
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
        
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
     NSString *enentId = [[NSUserDefaults standardUserDefaults] objectForKey:kEventId] ;
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:kUserId];
   [dataDictionary setObject:enentId forKey:@"eventid"];
    [self showProgressHud];
    
    [[WebService sharedWebService] callGetSingleEventsWebService:dataDictionary];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)deleteCloseButtonClicked:(id)sender {
    deletePopUpView.hidden=true;
}


- (IBAction)btnSaveClicked:(id)sender{
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnEditEventClicked:(id)sender {
    
    [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    EditEventsViewController* controller = (EditEventsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editEventsViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)btnEventOptionsClicked:(id)sender {
    EventFeedViewController* controller = (EventFeedViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventFeedViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}


#pragma mark ***************************DELETE EVENT WEBSEVICE*********************

- (void) showDeletePopUpForRepeatingInstance
{
    deletePopUpView.hidden=false;
    deletePopUpView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    
    [UIView animateWithDuration:0.3/1.5 animations:^{
        deletePopUpView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3/2 animations:^{
            deletePopUpView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.3/2 animations:^{
                deletePopUpView.transform = CGAffineTransformIdentity;
            }];
        }];
    }];
}


-(void)deleteEventByInstance:(NSString*)eventInstance
{
    [self showProgressHud];
    
    NSString *str = [[allRecordArray objectAtIndex:0] valueForKey:@"id"];
    
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    [dataDictionary setObject:userid forKey:kUserId];
    [dataDictionary setObject:str forKey:@"id"];
    [dataDictionary setObject:eventInstance forKey:@"type"];
    //    [allRecordArray removeObjectAtIndex:0];
    
    [[WebService sharedWebService] callDeleteEventsFromEventViewControllerWebService:dataDictionary];
}

- (IBAction)btnDeleteOnlyThisIntanceClicked:(id)sender {
    [self deleteEventByInstance:@"this_instance"];
}

- (IBAction)btnDeleteAlFollowingIntanceClicked:(id)sender {
    [self deleteEventByInstance:@"following_events"];
}

- (IBAction)btnDeleteAll_IntanceClicked:(id)sender {
    [self deleteEventByInstance:@"all_events"];
}

- (IBAction)btnDeleteEventClicked:(id)sender {
    NSString *repeatingOrNot;
    if(allRecordArray.count>0)
        repeatingOrNot = [[allRecordArray objectAtIndex:0] valueForKey:@"cal_type"];
    else{
        [self.view makeToast:@"Trying to delete the event that does not exist" duration:3.4 position:CSToastPositionBottom];
        return;
    }
    
    if(![repeatingOrNot isEqualToString:@"single"])
    {
        [self showDeletePopUpForRepeatingInstance];
    }
    else{
        NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:kEventId];
        
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        [dataDictionary setObject:userid forKey:kUserId];
        [dataDictionary setObject:str forKey:@"id"];
        
        [dataDictionary setObject:@"single" forKey:@"type"];
        
        [[WebService sharedWebService] callDeleteEventsFromEventViewControllerWebService:dataDictionary];
    }
}

- (IBAction)btnManageGuestClicked:(id)sender {
    ManageGuestViewController* controller = (ManageGuestViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"manageGuestViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)btnSendMessageClicked:(id)sender {
    ComposingMessageViewController* controller = (ComposingMessageViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"composingMessageViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
        
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnRsvpStyleClicked:(id)sender {
    RSVPViewController* controller = (RSVPViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"rSVPViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)btnInviteGuestClicked:(id)sender {
    InviteGuestViewController* controller = (InviteGuestViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"inviteGuestViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - WebService
#pragma mark -
- (void) getSingleEventsWebServiceSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    
    NSArray *responseDataArray = [dictionary objectForKey:@"data"];
    
    NSDictionary *dict;
    NSArray *individualRecordArray;
    
    individualRecordArray = [responseDataArray valueForKey:@"events"];
    for (int i=0; i<individualRecordArray.count; i++) {
        dict = [individualRecordArray objectAtIndex:i];
        if([txtEventMainTitle.text isEqualToString:@"Other"])
            txtEventMainTitle.text=[dict objectForKey:@"category_other"];
        else
            txtEventMainTitle.text= [dict objectForKey:@"category"];
        
        txtEventMainTitle.text=[[dict objectForKey:@"title"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        txtNotes.text= [[dict objectForKey:@"desc"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSString *startDateString =  [dict objectForKey:@"date"];
        if(![startDateString isEqualToString:@""]){
            //            NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:startDateString];
            //            NSDate *dateFromString = [[NSDate alloc] init];
            //            dateFromString = [dateFormatter dateFromString:startDateString];
            //            startDateString = [startDateString stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
            //
            NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
            if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
                dateFormatStr = @"dd/MM/yyyy";
            
            txtStartDate.text= [DateHandler getDateFromString:startDateString desireDateFormat:dateFormatStr dateFormatWeb:@"yyyy-MM-dd"];
            
        }
        
        NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KTimeFormat];
        dateFormatStr = [NSString stringWithFormat:@"%@",dateFormatStr];
        
        NSString *startTime = [dict objectForKey:@"time"];
        txtStartTime.text = [DateHandler convertTimeFormat:startTime timeFormat:dateFormatStr];
        
        
        txtDuration.text = [dict objectForKey:@"duration_hours"];
        txtRepeating.text = [dict objectForKey:@"cal_type"];
        
        txtTypeOfEvent.text = [dict objectForKey:@"cateogry"];
        
        txtPlaceBelowMainEvent.titleLabel.numberOfLines=3;
        txtPlaceBelowMainEvent.titleLabel.lineBreakMode=true;
        //        txtPlaceBelowMainEvent.titleLabel.text=@"";
        
        id object =  [dict valueForKey:@"location_name"];
        if (object == [NSNull null])
        {
            
        }else{
            NSString *locationName = [dict objectForKey:@"location_name"];
            if(locationName.length>0)
                [txtPlaceBelowMainEvent setTitle:locationName forState: UIControlStateNormal];
        }
        
        //        txtPlaceBelowMainEvent.titleLabel.text=[dict objectForKey:@"location_name"];
        if([txtPlaceBelowMainEvent.titleLabel.text isEqualToString:@"None"])
            txtPlaceBelowMainEvent.titleLabel.text=@"";
        
        if([txtPlaceBelowMainEvent.titleLabel.text isEqualToString:@"other"]){
            txtPlaceBelowMainEvent.titleLabel.text=@"Other";
        }
        
    }
    allRecordArray=[individualRecordArray mutableCopy];
}

- (void) getSingleEventsWebServiceFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *toastMessage =[response objectForKey:@"message"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
}
-(void)responseSuccessMessage
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void) deleteEventsViewContorllerSuccess:(NSNotification *)notification
{
    deletePopUpView.hidden=true;
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    [self performSelector:@selector(responseSuccessMessage) withObject:self afterDelay:2];
    
}

- (void) deleteEventsViewContorllerFailed:(NSNotification *)notification
{
    deletePopUpView.hidden=true;
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

- (IBAction)btnLocationMapViewClicked:(id)sender {
    MapViewController* controller = (MapViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"mapViewController"];
    controller.locationName = txtPlaceBelowMainEvent.titleLabel.text;
    [self.navigationController pushViewController:controller animated:YES];
}
@end
