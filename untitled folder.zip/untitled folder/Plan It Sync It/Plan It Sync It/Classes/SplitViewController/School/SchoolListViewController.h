//
//  SchoolListViewController.h
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"

@interface SchoolListViewController : UIViewController <UITabBarDelegate, SWTableViewCellDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchDisplayDelegate>
{
    NSMutableArray *deletedContactArray;
    
    UIBarButtonItem *barButtonItem;
    
    BOOL isSearchAndDelete;
    BOOL isSelectAllPressed;
    BOOL isPastChecked;
    BOOL isUpcomingChecked;
    BOOL isReverseChecked;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (weak, nonatomic) IBOutlet UILabel *labelNoRecordFound;
@property (assign) BOOL isFiltered;


@property (nonatomic, strong) NSMutableArray *myData;
@property (nonatomic, strong) NSMutableArray *selectedData;
// select row
@property (nonatomic, strong) NSMutableArray *selectedRows;
@property (nonatomic, strong) NSMutableArray *allRecordArray;


@property (nonatomic, weak) UIRefreshControl *refreshControl;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic) BOOL useCustomCells;

@property (nonatomic, strong) NSMutableArray *searchedEmailArray;
@property (nonatomic, strong) NSMutableArray *searchedNameArray;

@property (nonatomic, strong) NSMutableArray *selectedContacts;
@property (nonatomic, strong) NSMutableArray *deletedContactArray;
@property (nonatomic, strong) NSMutableArray *emailIdArray;
@property (nonatomic, strong) NSMutableArray *nameArray;

@property (nonatomic, strong) NSMutableArray *totalIndaxPath;


- (IBAction)btnBackClicked:(id)sender;
-(void)rel;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;


-(void) getListOfSchoolListSuccess:(NSNotification *)notification;
-(void) getListOfSchoolListFailed:(NSNotification *)notification;




@end
