//
//  NotificationViewController.m
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import "NotificationViewController.h"
#import "YearViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
#import "InboxMessageViewController.h"
#import "SentMessageViewController.h"
#import "ComposeMessageViewController.h"
#import "ToDoViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "EventViewController.h"
#import "UIImage+Helpers.h"

@interface NotificationViewController ()


@end

@implementation NotificationViewController
@synthesize tableView;
@synthesize  selectedContacts;
@synthesize totalIndaxPath;
@synthesize  emailIdArray;
@synthesize nameArray;
@synthesize deletedContactArray;
@synthesize searchedEmailArray;
@synthesize viewSelectAllAndDelete;
@synthesize selectedData;
@synthesize selectedRows;
@synthesize mSearchBar;
@synthesize toolBar_EditAndDelete;
@synthesize searchedNameArray;
@synthesize btnSelectAll;
@synthesize labelNoRecordFound;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnClearAll;
@synthesize allRecordArray;
- (void)viewDidLoad
{
    [super viewDidLoad];
    //init data
    self.selectedRows = [NSMutableArray array];
    tableView.dataSource=self;
    tableView.delegate=self;
    mSearchBar.delegate= self;
    [self setTitle:@"Notification"];
//    int height = self.navigationController.navigationBar.frame.size.height;
//    int width = self.navigationController.navigationBar.frame.size.width;
//    
//    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
//    [navLabel setText:@"Notification"];
//    navLabel.textColor = [UIColor whiteColor];
//    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
//    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
//    navLabel.textAlignment = NSTextAlignmentCenter;
//    self.navigationItem.titleView = navLabel;
    
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    self.tableView.rowHeight = 80;
    labelNoRecordFound.hidden=true;
    toolBar_EditAndDelete.hidden = true;
    
    //    roundedBtnClearAll.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnClearAll.layer.borderWidth = 2.0f;
    roundedBtnClearAll.clipsToBounds=YES;
    roundedBtnClearAll.layer.cornerRadius = 5;
    // Initialize Refresh Control
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    
    // Configure Refresh Control
    [refreshControl addTarget:self action:@selector(toggleCells:) forControlEvents:UIControlEventValueChanged];
    refreshControl.tintColor = [UIColor blueColor];
    
    // Configure View Controller
    [self.tableView addSubview:refreshControl];
    self.refreshControl = refreshControl;
    self.useCustomCells = NO;
    totalIndaxPath = [NSMutableArray array];
    
    // Do any additional setup after loading the view, typically from a nib.
    selectedContacts = [NSMutableArray array];
    //    emailIdArray=[[NSMutableArray alloc]initWithObjects:
    //                  @"1 Hour ago",
    //                  @"5 Hour ago",
    //                  nil];
    //    nameArray = [[NSMutableArray alloc]initWithObjects:
    //                 @"Event Name My home seet home",
    //                 @"Event Name Today meeting",
    //                 nil];
    emailIdArray = [[NSMutableArray alloc] init];
    nameArray = [[NSMutableArray alloc] init];
    allRecordArray= [[NSMutableArray alloc] init];
    isSelectAllPressed=false;
    isSearchAndDelete=false;
    searchedEmailArray = emailIdArray;
    searchedNameArray=nameArray;
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfNotificationSuccess:) name:kGetListOfNotificationSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfNotificationFailed:) name:kGetListOfNotificationFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clearAllNotificationSuccess:) name:kClearAllNotificationSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clearAllNotificationFailed:) name:kClearAllNotificationFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clearIndividualNotificationSuccess:) name:kClearIndividualNotificationSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clearIndividualNotificationFailed:) name:kClearIndividualNotificationFailed object:nil];
    
    //    if(emailIdArray.count<=0){
    //        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //        labelNoRecordFound.hidden=false;
    //    }
}

-(void)viewDidAppear:(BOOL)animated
{
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:kUserId];
    [self showProgressHud];
    [[WebService sharedWebService] callGetListOfNotificationWebService:dataDictionary];
}

-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark - dataSource method
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return searchedEmailArray.count;
}
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"UMCell";
    
    UMTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    if(emailIdArray.count>0)
        labelNoRecordFound.hidden=true;
    
    
    NSString *currentText;
    cell.label1.lineBreakMode = NSLineBreakByWordWrapping;
    cell.label.lineBreakMode = NSLineBreakByWordWrapping;
    
    //Search And Without Search data
    if(isSearchAndDelete==true){
        currentText = cell.label.text = searchedEmailArray[indexPath.row];
        cell.label1.text=[searchedNameArray objectAtIndex:indexPath.row];
    }
    else{
        currentText = cell.label.text = emailIdArray[indexPath.row];
        cell.label1.text=[nameArray objectAtIndex:indexPath.row];
    }
    
    cell.label.lineBreakMode=YES;
    cell.label.numberOfLines=3;
    cell.label1.lineBreakMode=YES;
    //    cell.label1.numberOfLines=3;
    
    
    cell.userImage.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    
    NSString *userImage = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"image_path"];
    if(![userImage isEqualToString:@""] && ![userImage isEqualToString:nil]){
        //        cell.userImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString: userImage]]];
        [UIImage loadFromURL:[NSURL URLWithString:userImage] callback:^(UIImage *image){
            cell.userImage.image = image;
       
        }];
    }
    else
    {
        [cell.userImage setImage:[UIImage imageNamed:@"logo.png"]];
    }
    //    [cell.userImage setImage:[UIImage imageNamed:@"logo.png"]];
    cell.userImage.layer.masksToBounds = YES;
    cell.userImage.layer.cornerRadius = 5.0;
    cell.userImage.layer.borderColor = [UIColor whiteColor].CGColor;
    cell.userImage.layer.borderWidth = 1.0f;
    cell.userImage.clipsToBounds = YES;
    
    
    [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:70.0f];
    //    [cell setBackgroundColor:[UIColor clearColor]];
    //
    //    CAGradientLayer *grad = [CAGradientLayer layer];
    //    grad.frame = CGRectMake(0,0,480,80);
    //    //    139-137-137
    //    UIColor *color1 = [UIColor colorWithRed:139.0f/255.0f green:137.0f/255.0f blue:137.0f/255.0f alpha:0.5];
    //    UIColor *color2 = [UIColor colorWithRed:240.0f/255.0f green:240.0f/255.0f blue:240.0f/255.0f alpha:0.5];
    //
    //    //    grad.colors = [NSArray arrayWithObjects:(id)[[UIColor whiteColor] CGColor], (id)[[UIColor greenColor] CGColor], nil];
    //    [grad setColors:[NSArray arrayWithObjects:(id)color1.CGColor, (id)color2.CGColor, nil]];
    //
    //    grad.cornerRadius = 5.0;
    //
    //    [cell setBackgroundView:[[UIView alloc] init]];
    //    [cell.backgroundView.layer insertSublayer:grad atIndex:0];
    
    
    if (cell==Nil) {
        cell = [[UMTableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    //    [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:70.0f];
    cell.delegate = self;
    
    return cell;
    
}

- (void)checkButtonTapped:(id)sender
{
    //    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tableView];
    //    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:buttonPosition];
    //    if (indexPath != nil)
    //    {
    //        if(isSearchAndDelete==true || isSelectAllPressed==true)
    //            return;
    //        NSString *currentText = emailIdArray[indexPath.row];
    //
    //        //new method
    //        if ([selectedContacts containsObject:currentText]) {
    //            [selectedContacts removeObject:currentText];
    //            [self.selectedRows removeObject:indexPath];
    //            mSearchBar.hidden=false;
    //            toolBar_EditAndDelete.hidden=true;
    //        } else {
    //            mSearchBar.hidden=true;
    //            toolBar_EditAndDelete.hidden=false;
    //
    //            [selectedContacts addObject:currentText];
    //            [self.selectedRows addObject:indexPath];
    //        }
    //    }
    //    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    
}

#pragma mark - delegate method
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    EventViewController* controller = (EventViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventViewController"];
    [[NSUserDefaults standardUserDefaults] setObject:[[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"id"] forKey:kEventId];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self.navigationController pushViewController:controller animated:YES];
    
}
- (IBAction)delRow:(id)sender {
    
    //    [tableView reloadRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    //
    //    [UIView beginAnimations:nil context:nil];
    //    [UIView setAnimationDuration:0.4];
    //    /*
    //    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    for (int i=0; i<selectedRows.count; i++) {
    //        NSIndexPath *path = [selectedRows objectAtIndex:i];
    //        dataDictionary = [allRecordArray objectAtIndex:path.row];
    //        [allRecordArray removeObjectAtIndex:path.row];
    //        [nameArray removeObjectAtIndex:path.row];
    //        [emailIdArray removeObjectAtIndex:path.row];
    //
    //    }*/
    //     NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    NSInteger count =  [selectedRows count];
    //    for (NSInteger i = count; i>0; i--) {
    //        NSIndexPath *path = [selectedRows objectAtIndex:i-1];
    //        dataDictionary = [allRecordArray objectAtIndex:path.row];
    //        [nameArray removeObjectAtIndex:path.row];
    //        [emailIdArray removeObjectAtIndex:path.row];
    //        [allRecordArray removeObjectAtIndex:path.row];
    //    }
    //    [self showProgressHud];
    //    [[WebService sharedWebService] callClearIndividualNotificationWebService:dataDictionary];
    
    //
    //    [tableView deleteRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    //    [UIView commitAnimations];
    //    [selectedContacts removeAllObjects];
    //    [self.selectedRows removeAllObjects];
    //    mSearchBar.hidden=false;
    //    toolBar_EditAndDelete.hidden=true;
    //    if(emailIdArray.count<=0){
    //        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //        labelNoRecordFound.hidden=false;
    //    }
    
    
    [tableView reloadRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.4];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableArray *contactIdArr = [NSMutableArray array];
    
    NSInteger count =  [selectedRows count];
    for (NSInteger i = count; i>0; i--) {
        NSIndexPath *path = [selectedRows objectAtIndex:i-1];
        
        NSString *str = [[allRecordArray objectAtIndex:path.row] valueForKey:@"id"];
        [contactIdArr addObject:str];
    }
    dataDictionary[@"id"] = contactIdArr;
    [dataDictionary setObject:userid forKey:@"userid"];
    
    NSInteger index = count;
    for (int i=0; i<count; i++) {
        NSIndexPath *path = [selectedRows objectAtIndex:index-1];
        if([nameArray count] > 0 && [nameArray count] > path.row && index >= 0){
            [nameArray removeObjectAtIndex:path.row];
            [emailIdArray removeObjectAtIndex:path.row];
            [allRecordArray removeObjectAtIndex:path.row];
            index--;
        }
    }
    
    [self showProgressHud];
    [[WebService sharedWebService] callClearIndividualNotificationWebService:dataDictionary];
    
    
    
    [tableView deleteRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    [UIView commitAnimations];
    [selectedContacts removeAllObjects];
    [self.selectedRows removeAllObjects];
    mSearchBar.hidden=false;
    toolBar_EditAndDelete.hidden=true;
    if(emailIdArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    [self.tableView reloadData];
}

- (IBAction)editRows:(id)sender {
    BOOL edit = tableView.editing;
    [tableView setEditing:!edit animated:YES];
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if(isSearchAndDelete==true || isSelectAllPressed==true)
        return;
    if ([self.selectedRows containsObject:indexPath]) {
        [self.selectedRows removeObject:indexPath];
        [selectedContacts removeObject:emailIdArray[indexPath.row]];
    }
    
    [emailIdArray removeObject:emailIdArray[indexPath.row]];
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    NSLog(@"delete");
    
    [tableView setEditing:NO animated:YES];
    if(emailIdArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    
}

- (IBAction)selectAll:(id)sender {
    [self showProgressHud];
    
    if(isSelectAllPressed==false){
        isSelectAllPressed=true;
        btnSelectAll.title = @"Un Select All";
        [selectedContacts removeAllObjects];
        [selectedRows removeAllObjects];
        [allRecordArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            NSString *currentText = emailIdArray[idx];
            [selectedContacts addObject:currentText];
            NSIndexPath *path = [NSIndexPath indexPathForRow:idx inSection:0];
            [selectedRows addObject:path];
            [tableView reloadRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationAutomatic];
            
        }];
    }
    else
    {
        isSelectAllPressed=false;
        btnSelectAll.title = @"Select All";
        toolBar_EditAndDelete.hidden=true;
        mSearchBar.hidden=false;
        isSearchAndDelete=false;
        
        [selectedContacts removeAllObjects];
        [selectedRows removeAllObjects];
        [tableView reloadData];
    }
    [self hideProgressHud];
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UIRefreshControl Selector

- (void)toggleCells:(UIRefreshControl*)refreshControl
{
    [refreshControl beginRefreshing];
    self.useCustomCells = !self.useCustomCells;
    
    if (self.useCustomCells)
    {
        self.refreshControl.tintColor = [UIColor redColor];
    }
    else
    {
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        [dataDictionary setObject:userid forKey:@"userid"];
        [self showProgressHud];
        [[WebService sharedWebService] callGetListOfNotificationWebService:dataDictionary];
        self.refreshControl.tintColor = [UIColor blueColor];
    }
    //    [self.tableView reloadData];
    [refreshControl endRefreshing];
}
//hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}

#pragma mark - WebService
#pragma mark -
- (void) getListOfNotificationSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    [nameArray removeAllObjects];
    [emailIdArray removeAllObjects];
    [allRecordArray removeAllObjects];
    [searchedEmailArray removeAllObjects];
    [searchedNameArray removeAllObjects];
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"status"]];
    
    NSDictionary *maiDict = [dictionary objectForKey:@"data"];
    if([[maiDict objectForKey:@"notification"] isKindOfClass:[NSArray class]])
    {
        
    }
    else if ([[maiDict objectForKey:@"notification"] isKindOfClass:[NSDictionary class]]){
    }
    else
    {
        
    }
    NSDictionary *dict;
    
    NSArray *individualRecordArray;
    individualRecordArray = [maiDict valueForKey:@"notification"];
    for (int i=0; i<individualRecordArray.count; i++) {
        dict = [individualRecordArray objectAtIndex:i];
        if([[dict valueForKey:@"notify_type"] isKindOfClass:[NSArray class]])
        {
            NSLog(@"Nsarray");
            
        }
        else if([[dict valueForKey:@"notify_type"] isKindOfClass:[NSDictionary class]])
        {
            NSLog(@"Dictionary");
        }
        else{
            NSString *name = [dict valueForKey:@"notify_type"];
            NSString *emailId = [dict valueForKey:@"notify_content"];
            [nameArray addObject:name];
            [emailIdArray addObject:emailId];
        }
    }
    allRecordArray = [individualRecordArray mutableCopy];
    if(allRecordArray.count<=0)
    {
        labelNoRecordFound.hidden=false;
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        
    }
    if(emailIdArray.count>0)
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    searchedEmailArray= emailIdArray;
    searchedNameArray = nameArray;
    [tableView reloadData];
    //    NSDictionary *profileDataDict = [maiDict objectForKey:@"user_profile"];
    
    //    txtEmailid.text = [profileDataDict objectForKey:@"email"];
    //    txtName.text = [profileDataDict objectForKey:@"name"];
    //    txtBirthDate.text = [profileDataDict objectForKey:@"birthday"];
    //    txtGender.text = [profileDataDict objectForKey:@"gender"];
    //    txtAddress.text = [profileDataDict objectForKey:@"address"];
    //    //    txtAddress.text = [profileDataDict objectForKey:@"country"];
    //    //    txtAddress.text = [profileDataDict objectForKey:@"email"];
    //    //    txtAddress.text = [profileDataDict objectForKey:@"facebook"];
    //    //    txtAddress.text = [profileDataDict objectForKey:@"gplus"];
    //    txtInstagram.text = [profileDataDict objectForKey:@"instagram"];
    //    txtLinked.text = [profileDataDict objectForKey:@"linkedin"];
    //    txtPhone.text = [profileDataDict objectForKey:@"phone"];
    //    txtMobile.text = [profileDataDict objectForKey:@"mobile"];
    //    txtSkype.text = [profileDataDict objectForKey:@"skype"];
    //    profileImage.image = [profileDataDict objectForKey:@"user_image"];
    //    txtAddress.text = [profileDataDict objectForKey:@"state"];
    //    txtAddress.text = [profileDataDict objectForKey:@"twitter"];
    
}

- (void) getListOfNotificationFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) clearAllNotificationSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    [tableView reloadData];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) clearAllNotificationFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) clearIndividualNotificationSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    [tableView reloadData];
    
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) clearIndividualNotificationFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

//- (void) deleteIndividualNotificationSuccess:(NSNotification *)notification
//{
//    [self hideProgressHud];
//
//    NSDictionary *dictionary = notification.object;
//    NSDictionary *response = [dictionary objectForKey:@"meta"];
//
//    [self.view makeToast:[response objectForKey:@"message"]];
//}
//
//- (void) deleteIndividualNotificationFailed:(NSNotification *)notification
//{
//    [self hideProgressHud];
//
//    NSDictionary *dictionary = notification.object;
//    if(dictionary.count<=0)
//        return;
//    NSDictionary *response = [dictionary objectForKey:@"meta"];
//
//    [self.view makeToast:[response objectForKey:@"message"]];
//}


- (void) getListOfTrashMessagesSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    [tableView reloadData];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) getListOfTrashMessagesFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
#pragma mark -
#pragma mark - tabBarButtonsPressed
#pragma mark -
- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
- (IBAction)btnClearAll:(id)sender {
    
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    [dataDictionary setObject:userid forKey:kUserId];
    
    [self showProgressHud];
    [[WebService sharedWebService] callClearAllNotificationWebService:dataDictionary];
    
    [selectedContacts removeAllObjects];
    [selectedRows removeAllObjects];
    
    [allRecordArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        NSString *currentText = emailIdArray[idx];
        [selectedContacts addObject:currentText];
        NSIndexPath *path = [NSIndexPath indexPathForRow:idx inSection:0];
        [selectedRows addObject:path];
        [tableView reloadRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationAutomatic];
        
    }];
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.4];
    [emailIdArray removeObjectsInArray:selectedContacts];
    if(emailIdArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    
    [tableView deleteRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    [UIView commitAnimations];
    [selectedContacts removeAllObjects];
    [self.selectedRows removeAllObjects];
    mSearchBar.hidden=false;
    toolBar_EditAndDelete.hidden=true;
}

#pragma mark - Search Functionality

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    isSearchAndDelete=true;
    [mSearchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    [mSearchBar setShowsCancelButton:NO animated:YES];
    searchBar.text=@"";
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchText.length>0) {
        searchText = [searchText stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSLog(@"its pincode");
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat: @"SELF CONTAINS[cd] %@", searchText ];
        
        searchedEmailArray = [emailIdArray filteredArrayUsingPredicate:predicate];
        
        
        NSPredicate *predicate1 = [NSPredicate predicateWithFormat: @"SELF CONTAINS[cd] %@", searchText ];
        
        searchedNameArray = [nameArray filteredArrayUsingPredicate:predicate1];
        [tableView reloadData];
    }
    else
    {
        searchedEmailArray=emailIdArray;
        searchedNameArray=nameArray;
        
        [tableView reloadData];
    }
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    isSearchAndDelete=false;
    
    [mSearchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    isSearchAndDelete=false;
    [mSearchBar resignFirstResponder];
    searchedEmailArray=emailIdArray;
    [tableView reloadData];
}


#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


#pragma mark - SWTableViewDelegate

- (void)swipeableTableViewCell:(SWTableViewCell *)cell scrollingToState:(SWCellState)state
{
    switch (state) {
        case 0:
            NSLog(@"utility buttons closed");
            break;
        case 1:
            NSLog(@"left utility buttons open");
            break;
        case 2:
            [cell hideUtilityButtonsAnimated:YES];
            
            NSLog(@"right utility buttons open");
            break;
        default:
            break;
    }
}

- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerLeftUtilityButtonWithIndex:(NSInteger)index
{
    switch (index) {
        case 0:
            NSLog(@"left button 0 was pressed");
            break;
        case 1:
            NSLog(@"left button 1 was pressed");
            break;
        case 2:
            NSLog(@"left button 2 was pressed");
            break;
        case 3:
            NSLog(@"left btton 3 was pressed");
        default:
            break;
    }
}


- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerRightUtilityButtonWithIndex:(NSInteger)index
{
    [cell hideUtilityButtonsAnimated:YES];
    
    switch (index) {
        case 0:
        {
            
            if(isSearchAndDelete==true || isSelectAllPressed==true)
                return;
            // Delete button was pressed
            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            [tableView reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            if(selectedContacts.count>0&&selectedRows.count>0){
                NSString *emailText = emailIdArray[cellIndexPath.row];
                
                [selectedContacts removeObject:emailText];
                [self.selectedRows removeObject:cellIndexPath];
            }
            
            NSLog(@"delete");
            
            NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
            
            NSString *notificationId = [[allRecordArray objectAtIndex:cellIndexPath.row] valueForKey:@"id"];
            
            [dataDictionary setObject:notificationId forKey:@"notification_id"];
            
            [allRecordArray removeObjectAtIndex:cellIndexPath.row];
            [emailIdArray removeObjectAtIndex:cellIndexPath.row];
            [nameArray removeObjectAtIndex:cellIndexPath.row];
            [self showProgressHud];
            [[WebService sharedWebService] callClearIndividualNotificationWebService:dataDictionary];
            
            [tableView setEditing:NO animated:YES];
            
            if(emailIdArray.count<=0){
                [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
                labelNoRecordFound.hidden=false;
            }
            //            [self.tableView reloadData];
            break;
            //            if(isSearchAndDelete==true || isSelectAllPressed==true)
            //                return;
            // Delete button was pressed
            //            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            //            [tableView reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            //            if(selectedContacts.count>0&&selectedRows.count>0){
            //                NSString *emailText = emailIdArray[cellIndexPath.row];
            //                [selectedContacts removeObject:emailText];
            //                [self.selectedRows removeObject:cellIndexPath];
            //            }
            //            [emailIdArray removeObject:emailIdArray[cellIndexPath.row]];
            //            [nameArray removeObject:nameArray[cellIndexPath.row]];
            //            [allRecordArray removeObjectAtIndex:cellIndexPath.row];
            //
            //
            //            NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
            //
            //            NSString *notificationId = [[allRecordArray objectAtIndex:cellIndexPath.row] valueForKey:@"id"];
            //
            //            [dataDictionary setObject:notificationId forKey:@"notification_id"];
            //
            //            [self showProgressHud];
            //            [[WebService sharedWebService] callClearIndividualNotificationWebService:dataDictionary];
            //
            //
            //            [tableView deleteRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            //            NSLog(@"delete");
            //            [tableView setEditing:NO animated:YES];
            //
            //            if(emailIdArray.count<=0){
            //                [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
            //                labelNoRecordFound.hidden=false;
            //            }
            
            //            break;
        }
            
        default:
            break;
    }
}

- (BOOL)swipeableTableViewCellShouldHideUtilityButtonsOnSwipe:(SWTableViewCell *)cell
{
    // allow just one cell's utility button to be open at once
    return YES;
}

- (BOOL)swipeableTableViewCell:(SWTableViewCell *)cell canSwipeToState:(SWCellState)state
{
    switch (state) {
        case 1:
            // set to NO to disable all left utility buttons appearings
            return YES;
            break;
        case 2:
            // set to NO to disable all right utility buttons appearing
            return YES;
            break;
        default:
            break;
    }
    
    return YES;
}

- (NSArray *)rightButtons
{
    NSMutableArray *rightUtilityButtons = [NSMutableArray new];
    
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:1.0f green:0.231f blue:0.188 alpha:1.0f]
                                                title:@"Delete"];
    
    return rightUtilityButtons;
}



@end
