//
//  NotificationViewController.m
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//


#import "RosterWeekListViewController.h"
#import "YearViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
#import "InboxMessageViewController.h"
#import "SentMessageViewController.h"
#import "ComposeMessageViewController.h"
#import "ToDoViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "RosterSetRequestListViewController.h"
#import "NotificationViewController.h"
@interface RosterWeekListViewController ()


@end

@implementation RosterWeekListViewController
@synthesize tableView;
@synthesize nameArray;
@synthesize mSearchBar;
@synthesize labelNoRecordFound;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize allRecordArray;
- (void)viewDidLoad
{
    [super viewDidLoad];
    //init data
    tableView.dataSource=self;
    tableView.delegate=self;
    mSearchBar.delegate= self;
    [self setTitle:@"My Roster"];
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"My Roster"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    self.tableView.rowHeight = 80;
    labelNoRecordFound.hidden=true;
    
    // Initialize Refresh Control
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    
    // Configure Refresh Control
    [refreshControl addTarget:self action:@selector(toggleCells:) forControlEvents:UIControlEventValueChanged];
    refreshControl.tintColor = [UIColor blueColor];
    
    // Configure View Controller
    [self.tableView addSubview:refreshControl];
    self.refreshControl = refreshControl;
    self.useCustomCells = NO;
    
    nameArray = [[NSMutableArray alloc] init];
    allRecordArray= [[NSMutableArray alloc] init];
    isSelectAllPressed=false;
    isSearchAndDelete=false;
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    //    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfNotificationSuccess:) name:kGetListOfNotificationSuccess object:nil];
    //    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfNotificationFailed:) name:kGetListOfNotificationFailed object:nil];
    
    
    
    if(nameArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    NSDictionary *roasterList = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
    allRecordArray = [roasterList objectForKey:@"employee"];
    for (int i=0; i<allRecordArray.count; i++) {
        [nameArray addObject:[[allRecordArray objectAtIndex:i] valueForKey:@"business_name"]];
    }
    [self.tableView reloadData];
}

-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark - dataSource method
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return allRecordArray.count;
}
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"UMCell";
    
    UMTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    if(nameArray.count>0)
        labelNoRecordFound.hidden=true;
    
    
    NSString *currentText;
    cell.label.lineBreakMode = NSLineBreakByWordWrapping;
    
    //Search And Without Search data
    
    cell.label.text = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"business_name"];
    cell.label.lineBreakMode=YES;
    cell.label.numberOfLines=4;
    
    
    
    if (cell==Nil) {
        cell = [[UMTableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    
    return cell;
    
}



#pragma mark - delegate method
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [[NSUserDefaults standardUserDefaults] setObject:[[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"boid"] forKey:kBoidId];
    [[NSUserDefaults standardUserDefaults] synchronize];
    RosterSetRequestListViewController* controller = (RosterSetRequestListViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"rosterSetRequestListViewController"];
    [self.navigationController pushViewController:controller animated:YES];
    
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)aTableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewCellEditingStyleNone;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UIRefreshControl Selector

- (void)toggleCells:(UIRefreshControl*)refreshControl
{
    [refreshControl beginRefreshing];
    self.useCustomCells = !self.useCustomCells;
    
    if (self.useCustomCells)
    {
        self.refreshControl.tintColor = [UIColor redColor];
    }
    else
    {
        //        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        //        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        //        [dataDictionary setObject:userid forKey:@"userid"];
        //        [self showProgressHud];
        //        [[WebService sharedWebService] callGetListOfNotificationWebService:dataDictionary];
        self.refreshControl.tintColor = [UIColor blueColor];
    }
    //    [self.tableView reloadData];
    [refreshControl endRefreshing];
}
//hide keyboard
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}

#pragma mark - WebService
#pragma mark -
- (void) getListOfNotificationSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    [nameArray removeAllObjects];
    [allRecordArray removeAllObjects];
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"status"]];
    
    NSDictionary *maiDict = [dictionary objectForKey:@"data"];
    if([[maiDict objectForKey:@"notification"] isKindOfClass:[NSArray class]])
    {
        
    }
    else if ([[maiDict objectForKey:@"notification"] isKindOfClass:[NSDictionary class]]){
    }
    else
    {
        
    }
    NSDictionary *dict;
    
    NSArray *individualRecordArray;
    individualRecordArray = [maiDict valueForKey:@"notification"];
    for (int i=0; i<individualRecordArray.count; i++) {
        dict = [individualRecordArray objectAtIndex:i];
        if([[dict valueForKey:@"notify_type"] isKindOfClass:[NSArray class]])
        {
            NSLog(@"Nsarray");
            
        }
        else if([[dict valueForKey:@"notify_type"] isKindOfClass:[NSDictionary class]])
        {
            NSLog(@"Dictionary");
        }
        else{
            NSString *name = [dict valueForKey:@"notify_type"];
            NSString *emailId = [dict valueForKey:@"notify_content"];
            [nameArray addObject:name];
        }
    }
    allRecordArray = [individualRecordArray mutableCopy];
    if(nameArray.count>0)
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    if(allRecordArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    [tableView reloadData];
    
    
}

- (void) getListOfNotificationFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) clearAllNotificationSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) clearAllNotificationFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) clearIndividualNotificationSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) clearIndividualNotificationFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(allRecordArray.count==0){
        [self.tableView reloadData];
        labelNoRecordFound.hidden=false;
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    }
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

//- (void) deleteIndividualNotificationSuccess:(NSNotification *)notification
//{
//    [self hideProgressHud];
//
//    NSDictionary *dictionary = notification.object;
//    NSDictionary *response = [dictionary objectForKey:@"meta"];
//
//    [self.view makeToast:[response objectForKey:@"message"]];
//}
//
//- (void) deleteIndividualNotificationFailed:(NSNotification *)notification
//{
//    [self hideProgressHud];
//
//    NSDictionary *dictionary = notification.object;
//    if(dictionary.count<=0)
//        return;
//    NSDictionary *response = [dictionary objectForKey:@"meta"];
//
//    [self.view makeToast:[response objectForKey:@"message"]];
//}


- (void) getListOfTrashMessagesSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) getListOfTrashMessagesFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
#pragma mark -
#pragma mark - tabBarButtonsPressed
#pragma mark -
- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}



#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        RosterWeekListViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"RosterWeekListViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


#pragma mark - SWTableViewDelegate

- (void)swipeableTableViewCell:(SWTableViewCell *)cell scrollingToState:(SWCellState)state
{
    switch (state) {
        case 0:
            NSLog(@"utility buttons closed");
            break;
        case 1:
            NSLog(@"left utility buttons open");
            break;
        case 2:
            [cell hideUtilityButtonsAnimated:YES];
            
            NSLog(@"right utility buttons open");
            break;
        default:
            break;
    }
}

- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerLeftUtilityButtonWithIndex:(NSInteger)index
{
    switch (index) {
        case 0:
            NSLog(@"left button 0 was pressed");
            break;
        case 1:
            NSLog(@"left button 1 was pressed");
            break;
        case 2:
            NSLog(@"left button 2 was pressed");
            break;
        case 3:
            NSLog(@"left btton 3 was pressed");
        default:
            break;
    }
}


- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerRightUtilityButtonWithIndex:(NSInteger)index
{
    switch (index) {
        case 0:
        {
            //            [cell hideUtilityButtonsAnimated:YES];
            //            if(isSearchAndDelete==true || isSelectAllPressed==true)
            //                return;
            //            // Delete button was pressed
            //            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            //            [tableView reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            //
            //            [nameArray removeObject:nameArray[cellIndexPath.row]];
            //            [allRecordArray removeObjectAtIndex:cellIndexPath.row];
            //
            //            NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
            //
            //            NSString *notificationId = [[allRecordArray objectAtIndex:cellIndexPath.row] valueForKey:@"id"];
            //            [dataDictionary setObject:notificationId forKey:@"id"];
            //            [self showProgressHud];
            //            [[WebService sharedWebService] callClearIndividualNotificationWebService:dataDictionary];
            //
            //
            //            [tableView deleteRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            //            NSLog(@"delete");
            //            [tableView setEditing:NO animated:YES];
            //
            //            if(nameArray.count<=0){
            //                [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
            //                labelNoRecordFound.hidden=false;
            //            }
            
            break;
        }
            
        default:
            break;
    }
    [tableView reloadData];
    
}

- (BOOL)swipeableTableViewCellShouldHideUtilityButtonsOnSwipe:(SWTableViewCell *)cell
{
    // allow just one cell's utility button to be open at once
    return YES;
}

- (BOOL)swipeableTableViewCell:(SWTableViewCell *)cell canSwipeToState:(SWCellState)state
{
    switch (state) {
        case 1:
            // set to NO to disable all left utility buttons appearings
            return YES;
            break;
        case 2:
            // set to NO to disable all right utility buttons appearing
            return YES;
            break;
        default:
            break;
    }
    
    return YES;
}

- (NSArray *)rightButtons
{
    NSMutableArray *rightUtilityButtons = [NSMutableArray new];
    
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:1.0f green:0.231f blue:0.188 alpha:1.0f]
                                                title:@"Delete"];
    
    return rightUtilityButtons;
}



@end
