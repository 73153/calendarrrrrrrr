//
//  RosterSetRequestListViewController.h
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
@interface RosterSetRequestListViewController : UIViewController <UITabBarDelegate, SWTableViewCellDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchDisplayDelegate,UITextViewDelegate>
{
    NSMutableArray *deletedContactArray;
    
    UIBarButtonItem *barButtonItem;
    
    BOOL isSearchAndDelete;
    BOOL isSelectAllPressed;
}

@property (weak, nonatomic) IBOutlet UIButton *btnSubmit;
@property (weak, nonatomic) IBOutlet UIButton *btncancel;


- (IBAction)btnSubmitRequestCancelClicked:(id)sender;
- (IBAction)btnCancelRequestClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *txtViewPopUpDetailText;
@property (weak, nonatomic) IBOutlet UILabel *lblPopUp;

@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (weak, nonatomic) IBOutlet UILabel *labelNoRecordFound;

@property (nonatomic, strong) NSMutableArray *allRecordArray;
@property (nonatomic, strong) NSMutableArray *nameArray;

// select row
- (IBAction)btnCancelRequestPressed:(id)sender;

@property (nonatomic, weak) UIRefreshControl *refreshControl;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UISearchBar *mSearchBar;
@property (nonatomic) BOOL useCustomCells;

@property (weak, nonatomic) IBOutlet UIView *popUpviewCancelRequest;


- (IBAction)btnBackClicked:(id)sender;
-(void) rel;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;

-(void) getListOfNotificationSuccess:(NSNotification *)notification;
-(void) getListOfNotificationFailed:(NSNotification *)notification;


-(void) setRequestCancelSuccess:(NSNotification *)notification;
-(void) setRequestCancelFailed:(NSNotification *)notification;
-(void) getListOfRosterSuccess:(NSNotification *)notification;
-(void) getListOfRosterFailed:(NSNotification *)notification;


@end
