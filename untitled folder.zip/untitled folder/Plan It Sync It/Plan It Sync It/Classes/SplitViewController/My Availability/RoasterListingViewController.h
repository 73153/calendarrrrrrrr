//
//  RoasterListingViewController.h
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
@interface RoasterListingViewController : UIViewController <UITabBarDelegate, SWTableViewCellDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchDisplayDelegate>
{
    NSMutableArray *deletedContactArray;
    
    UIBarButtonItem *barButtonItem;
    
    BOOL isSearchAndDelete;
    BOOL isSelectAllPressed;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (weak, nonatomic) IBOutlet UILabel *labelNoRecordFound;

@property (nonatomic, strong) NSMutableArray *allRecordArray;
@property (nonatomic, strong) NSMutableArray *nameArray;

// select row

@property (nonatomic, weak) UIRefreshControl *refreshControl;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UISearchBar *mSearchBar;
@property (nonatomic) BOOL useCustomCells;



- (IBAction)btnBackClicked:(id)sender;
-(void) rel;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;

-(void) getListOfNotificationSuccess:(NSNotification *)notification;
-(void) getListOfNotificationFailed:(NSNotification *)notification;


@end
