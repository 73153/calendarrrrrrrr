//
//  SetMyAvailabilityViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "SetMyAvailabilityViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "UIImage+fixOrientation.h"

#import "MBProgressHUD.h"
#import "ToDoViewController.h"
#import "PECropViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "PlistUtils.h"
#import "TextValidator.h"
#import "DateHandler.h"
#import "ContactsViewController.h"
#import <UIKit/UIKit.h>

#import "ActionSheetDatePicker.h"

#ifdef __IPHONE_8_0
#define GregorianCalendar NSCalendarIdentifierGregorian
#else
#define GregorianCalendar NSGregorianCalendar
#endif
@interface SetMyAvailabilityViewController ()
{
    BOOL isStartDateClicked;
    BOOL isEndDateClicked;
    
    BOOL isMondayStartTimeClicked;
    BOOL isTuesdayStartTimeClicked;
    BOOL isWednesdayStartTimeClicked;
    BOOL isThursdayStartTimeClicked;
    BOOL isFridayStartTimeClicked;
    BOOL isSaturdayStartTimeClicked;
    BOOL isSundayStartTimeClicked;
    
    BOOL isMondayEndTimeClicked;
    BOOL isTuesdayEndTimeClicked;
    BOOL isWednesdayEndTimeClicked;
    BOOL isThursdayEndTimeClicked;
    BOOL isFridayEndTimeClicked;
    BOOL isSaturdayEndTimeClicked;
    BOOL isSundayEndTimeClicked;
    NSDate *startDate;
    NSDate *endDate;
    NSDate *mondayStartTime;
    NSDate *tuesdayStartTime;
    NSDate *wednesdayStartTime;
    NSDate *thursdayStartTime;
    NSDate *fridayStartTime;
    NSDate *saturdayStartTime;
    NSDate *sundayStartTime;
    
    NSDate *mondayEndTime;
    NSDate *tuesdayEndTime;
    NSDate *wednesdayEndTime;
    NSDate *thursdayEndTime;
    NSDate *fridayEndTime;
    NSDate *saturdayEndTime;
    NSDate *sundayEndTime;
    NSString *resultMessage;
    
    NSArray *hoursInTwentyFourHourFormatArray;
    NSArray *minutesArray;
}
@end

@implementation SetMyAvailabilityViewController
@synthesize scrollView;

@synthesize datePicker;
@synthesize pickerBackGroundView;
@synthesize btnBarCancel;
@synthesize btnBarDone;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;

@synthesize lblSatrtDate;
@synthesize lblEndDate;
@synthesize btnEndDate;
@synthesize btnStartDate;

@synthesize btnfridayEndTimeRoundedCorner;
@synthesize btnfridayStartTimeRoundedCorner;
@synthesize btnMondayEndTimeRoundedCorner;
@synthesize btnMondayStartTimeRoundedCorner;
@synthesize btnSaturdayEndTimeRoundedCorner;
@synthesize btnSaturdayStartTimeRoundedCorner;
@synthesize btnSundayEndTimeRoundedCorner;
@synthesize btnSundayStartTimeRoundedCorner;
@synthesize btnThursdayEndTimeRoundedCorner;
@synthesize btnThursdayStartTimeRoundedCorner;
@synthesize btnTuesdayEndTimeRoundedCorner;
@synthesize btnTuesdayStartTimeRoundedCorner;
@synthesize btnWednesdayEndTimeRoundedCorner;
@synthesize btnWednesdayStartTimeRoundedCorner;

@synthesize lblFridayEndTime;
@synthesize lblFridayStartTime;
@synthesize lblMondayEndTime;
@synthesize lblMondayStartTime;
@synthesize lblSaturdayEndTime;
@synthesize lblSaturdayStartTime;
@synthesize lblSundayEndTime;
@synthesize lblSundayStartTime;
@synthesize lblThursdayEndTime;
@synthesize lblThursdayStartTime;
@synthesize lblTuesdayEndTime;
@synthesize lblTuesdayStartTime;
@synthesize lblWednesdayEndTime;
@synthesize lblWednesdayStartTime;

@synthesize timerbtnBarCancel;
@synthesize timerbtnBarDone;
@synthesize timerPicker;
@synthesize timerPickerBackgroundView;

@synthesize oldDictionary;
@synthesize selectedDate;
@synthesize roundedBtnSaveIt;
-(void)viewDidLoad
{
    [self hideProgressHud];
    [self setTitle:@"Set Availablity"];
    
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Set Availablity"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    isStartDateClicked=false;
    isEndDateClicked=false;
    
    minutesArray = @[@"01", @"02", @"03", @"04", @"05", @"06", @"07", @"08", @"09", @"10", @"11", @"12", @"13", @"14", @"15", @"16", @"17", @"18", @"19", @"20", @"21", @"22", @"23", @"24"];
    hoursInTwentyFourHourFormatArray = @[@"00",@"05", @"10", @"15", @"20", @"25", @"30", @"35", @"40", @"45", @"50", @"55", @"60"];
    
    roundedBtnSaveIt.clipsToBounds=YES;
    roundedBtnSaveIt.layer.cornerRadius = 5;
    
    btnMondayStartTimeRoundedCorner.clipsToBounds=YES;
    btnMondayStartTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnMondayStartTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnMondayStartTimeRoundedCorner layer] setOpacity:0.2];
    btnMondayEndTimeRoundedCorner.clipsToBounds=YES;
    btnMondayEndTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnMondayEndTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnMondayEndTimeRoundedCorner layer] setOpacity:0.2];
    btnTuesdayStartTimeRoundedCorner.clipsToBounds=YES;
    btnTuesdayStartTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnTuesdayStartTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnTuesdayStartTimeRoundedCorner layer] setOpacity:0.2];
    btnTuesdayEndTimeRoundedCorner.clipsToBounds=YES;
    btnTuesdayEndTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnTuesdayEndTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnTuesdayEndTimeRoundedCorner layer] setOpacity:0.2];
    btnWednesdayStartTimeRoundedCorner.clipsToBounds=YES;
    btnWednesdayStartTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnWednesdayStartTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnWednesdayStartTimeRoundedCorner layer] setOpacity:0.2];
    btnWednesdayEndTimeRoundedCorner.clipsToBounds=YES;
    btnWednesdayEndTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnWednesdayEndTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnWednesdayEndTimeRoundedCorner layer] setOpacity:0.2];
    btnThursdayStartTimeRoundedCorner.clipsToBounds=YES;
    btnThursdayStartTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnThursdayStartTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnThursdayStartTimeRoundedCorner layer] setOpacity:0.2];
    btnThursdayEndTimeRoundedCorner.clipsToBounds=YES;
    btnThursdayEndTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnThursdayEndTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnThursdayEndTimeRoundedCorner layer] setOpacity:0.2];
    btnfridayStartTimeRoundedCorner.clipsToBounds=YES;
    btnfridayStartTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnfridayStartTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnfridayStartTimeRoundedCorner layer] setOpacity:0.2];
    btnfridayEndTimeRoundedCorner.clipsToBounds=YES;
    btnfridayEndTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnfridayEndTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnfridayEndTimeRoundedCorner layer] setOpacity:0.2];
    btnSaturdayStartTimeRoundedCorner.clipsToBounds=YES;
    btnSaturdayStartTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnSaturdayStartTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnSaturdayStartTimeRoundedCorner layer] setOpacity:0.2];
    btnSaturdayEndTimeRoundedCorner.clipsToBounds=YES;
    btnSaturdayEndTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnSaturdayEndTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnSaturdayEndTimeRoundedCorner layer] setOpacity:0.2];
    btnSundayStartTimeRoundedCorner.clipsToBounds=YES;
    btnSundayStartTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnSundayStartTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnSundayStartTimeRoundedCorner layer] setOpacity:0.2];
    btnSundayEndTimeRoundedCorner.clipsToBounds=YES;
    btnSundayEndTimeRoundedCorner.layer.cornerRadius = 5;
    [[btnSundayEndTimeRoundedCorner layer] setBorderWidth:1.0f];
    [[btnSundayEndTimeRoundedCorner layer] setOpacity:0.2];
    
    [timerPicker setMaximumDate:[NSDate date]];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:GregorianCalendar];
    NSDate *currentDate = [NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setYear:60];
    
    NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    [comps setYear:60];
    //    NSDate *minDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    
    [datePicker setMaximumDate:maxDate];
    [datePicker setMinimumDate:currentDate];
    
    isMondayStartTimeClicked=false;
    isTuesdayStartTimeClicked=false;
    isWednesdayStartTimeClicked=false;
    isThursdayStartTimeClicked=false;
    isFridayStartTimeClicked=false;
    isSaturdayStartTimeClicked=false;
    isSundayStartTimeClicked=false;
    
    isMondayEndTimeClicked=false;
    isTuesdayEndTimeClicked=false;
    isWednesdayEndTimeClicked=false;
    isThursdayEndTimeClicked=false;
    isFridayEndTimeClicked=false;
    isSaturdayEndTimeClicked=false;
    isSundayEndTimeClicked=false;
    
    btnStartDate.clipsToBounds=YES;
    btnStartDate.layer.cornerRadius = 5;
    
    oldDictionary = [[NSDictionary alloc] init];
    
    [[btnStartDate layer] setBorderWidth:1.0f];
    [[btnStartDate layer] setOpacity:0.2];
    
    [[btnEndDate layer] setBorderColor:[UIColor grayColor].CGColor];
    [[btnEndDate layer] setBorderWidth:0.2f];
    
    btnEndDate.layer.cornerRadius = 5; // this value vary as per your desire
    btnEndDate.clipsToBounds = YES;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    scrollView.delegate=self;
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,900)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1600)];
    }
    
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setAvailabilitySuccess:) name:kSetAvailabilitySuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setAvailabilityFailed:) name:kSetAvailabilityFailed object:nil];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAvailabilitySuccess:) name:kGetAvailabilitySuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAvailabilityFailed:) name:kGetAvailabilityFailed object:nil];
}


-(void)viewWillAppear:(BOOL)animated
{
    selectedDate = [NSDate date];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
        dateFormatStr = @"dd/MM/yyyy";
    lblSatrtDate.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
    lblEndDate.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
    
    startDate = [NSDate date];
    endDate = startDate;
    
    NSString *strTimeFormat = [[NSUserDefaults standardUserDefaults]
                               objectForKey:KTimeFormat];
    
    strTimeFormat = [NSString stringWithFormat:@"%@", strTimeFormat];
    if([strTimeFormat isEqualToString:@"12"])
    {
        lblMondayStartTime.text=@"9:00 am";
        lblTuesdayStartTime.text=@"9:00 am";
        lblWednesdayStartTime.text=@"9:00 am";
        lblThursdayStartTime.text=@"9:00 am";
        lblFridayStartTime.text=@"9:00 am";
        lblSaturdayStartTime.text=@"9:00 am";
        lblSundayStartTime.text=@"9:00 am";
        
        lblMondayEndTime.text=@"5:00 pm";
        lblTuesdayEndTime.text=@"5:00 pm";
        lblWednesdayEndTime.text=@"5:00 pm";
        lblThursdayEndTime.text=@"5:00 pm";
        lblFridayEndTime.text=@"5:00 pm";
        lblSaturdayEndTime.text=@"5:00 pm";
        lblSundayEndTime.text=@"5:00 pm";
        
        
        NSString *dateToset;
        
        NSDateFormatter *startDateFormatter = [[NSDateFormatter alloc] init];
        startDateFormatter.dateFormat = @"HH:mm";
        NSLocale *twentyFour = [[NSLocale alloc] initWithLocaleIdentifier:@"en_GB"];
        startDateFormatter.locale = twentyFour;
        dateToset = [NSString stringWithFormat:@"09:00"];
        NSDate *starterDate = [startDateFormatter dateFromString:dateToset];
        startDateFormatter.dateFormat = @"hh:mm a";
        mondayStartTime=starterDate;
        tuesdayStartTime=starterDate;
        wednesdayStartTime=starterDate;
        thursdayStartTime=starterDate;
        fridayStartTime=starterDate;
        saturdayStartTime=starterDate;
        sundayStartTime=starterDate;
        
        NSDateFormatter *endDateFormatter = [[NSDateFormatter alloc] init];
        endDateFormatter.dateFormat = @"HH:mm";
        NSLocale *twelveHourLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
        endDateFormatter.locale = twelveHourLocale;
        
        dateToset = [NSString stringWithFormat:@"17:00"];
        NSDate *endDateSetUp = [endDateFormatter dateFromString:dateToset];
        endDateFormatter.dateFormat = @"hh:mm a";
        //    NSString *pmamDateString = [dateFormatter stringFromDate:date];
        mondayEndTime=endDateSetUp;
        tuesdayEndTime=endDateSetUp;
        wednesdayEndTime=endDateSetUp;
        thursdayEndTime=endDateSetUp;
        fridayEndTime=endDateSetUp;
        saturdayEndTime=endDateSetUp;
        sundayEndTime=endDateSetUp;
    }
    else
    {
        lblMondayStartTime.text=@"9:00";
        lblTuesdayStartTime.text=@"9:00";
        lblWednesdayStartTime.text=@"9:00";
        lblThursdayStartTime.text=@"9:00";
        lblFridayStartTime.text=@"9:00";
        lblSaturdayStartTime.text=@"9:00";
        lblSundayStartTime.text=@"9:00";
        
        lblMondayEndTime.text=@"17:00";
        lblTuesdayEndTime.text=@"17:00";
        lblWednesdayEndTime.text=@"17:00";
        lblThursdayEndTime.text=@"17:00";
        lblFridayEndTime.text=@"17:00";
        lblSaturdayEndTime.text=@"17:00";
        lblSundayEndTime.text=@"17:00";
        
        NSString *dateToset;
        
        NSDateFormatter *startDateFormatter = [[NSDateFormatter alloc] init];
        startDateFormatter.dateFormat = @"HH:mm";
        NSLocale *twentyFour = [[NSLocale alloc] initWithLocaleIdentifier:@"en_GB"];
        startDateFormatter.locale = twentyFour;
        dateToset = [NSString stringWithFormat:@"09:00"];
        NSDate *starterDate = [startDateFormatter dateFromString:dateToset];
        startDateFormatter.dateFormat = @"hh:mm a";
        //    NSString *pmamDateString = [dateFormatter stringFromDate:date];
        mondayStartTime=starterDate;
        tuesdayStartTime=starterDate;
        wednesdayStartTime=starterDate;
        thursdayStartTime=starterDate;
        fridayStartTime=starterDate;
        saturdayStartTime=starterDate;
        sundayStartTime=starterDate;
        
        NSDateFormatter *endDateFormatter = [[NSDateFormatter alloc] init];
        endDateFormatter.dateFormat = @"HH:mm";
        dateToset = [NSString stringWithFormat:@"17:00"];
        NSDate *endDateSetUp = [endDateFormatter dateFromString:dateToset];
        endDateFormatter.dateFormat = @"hh:mm a";
        //    NSString *pmamDateString = [dateFormatter stringFromDate:date];
        mondayEndTime=endDateSetUp;
        tuesdayEndTime=endDateSetUp;
        wednesdayEndTime=endDateSetUp;
        thursdayEndTime=endDateSetUp;
        fridayEndTime=endDateSetUp;
        saturdayEndTime=endDateSetUp;
        sundayEndTime=endDateSetUp;
    }
    
    //    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    //    NSString *boidid = [[NSUserDefaults standardUserDefaults] objectForKey:kBoidId];
    //
    //    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    //    [dataDictionary setObject:[NSString stringWithFormat:@"%d",1372]forKey:kUserId];
    //    //    [dataDictionary setObject:[NSString stringWithFormat:@"%d",2617] forKey:kBoidId];
    //    [dataDictionary setObject:userid forKey:kUserId];
    //    [dataDictionary setObject:boidid forKey:kBoidId];
    //
    //    [self showProgressHud];
    //    [[WebService sharedWebService] callGetMyAvalabilityWebService:dataDictionary];
}
-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (IBAction)selectStartTimeEndTime:(UIControl *)sender {
    
}
-(void)btnClearAndResetAllTheTimeInPicker:(NSInteger)dayToClear
{
    NSString *strTimeFormat = [[NSUserDefaults standardUserDefaults]
                               objectForKey:KTimeFormat];
    
    strTimeFormat = [NSString stringWithFormat:@"%@", strTimeFormat];
    if([strTimeFormat isEqualToString:@"12"])
    {
        
        NSString *dateToset;
        
        NSDateFormatter *startDateFormatter = [[NSDateFormatter alloc] init];
        startDateFormatter.dateFormat = @"HH:mm";
        NSLocale *twentyFour = [[NSLocale alloc] initWithLocaleIdentifier:@"en_GB"];
        startDateFormatter.locale = twentyFour;
        dateToset = [NSString stringWithFormat:@"09:00"];
        NSDate *starterDate = [startDateFormatter dateFromString:dateToset];
        startDateFormatter.dateFormat = @"hh:mm a";
        if(dayToClear==1)
            mondayStartTime=starterDate;
        else if(dayToClear==2)
            tuesdayStartTime=starterDate;
        else if(dayToClear==3)
            wednesdayStartTime=starterDate;
        else if(dayToClear==4)
            thursdayStartTime=starterDate;
        else if(dayToClear==5)
            fridayStartTime=starterDate;
        else if(dayToClear==6)
            saturdayStartTime=starterDate;
        else if(dayToClear==7)
            sundayStartTime=starterDate;
        
        NSDateFormatter *endDateFormatter = [[NSDateFormatter alloc] init];
        endDateFormatter.dateFormat = @"HH:mm";
        NSLocale *twelveHourLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
        endDateFormatter.locale = twelveHourLocale;
        
        dateToset = [NSString stringWithFormat:@"17:00"];
        NSDate *endDateSetUp = [endDateFormatter dateFromString:dateToset];
        endDateFormatter.dateFormat = @"hh:mm a";
        //    NSString *pmamDateString = [dateFormatter stringFromDate:date];
        
        if(dayToClear==1)
            mondayEndTime=endDateSetUp;
        else if(dayToClear==2)
            tuesdayEndTime=endDateSetUp;
        else if(dayToClear==3)
            wednesdayEndTime=endDateSetUp;
        else if(dayToClear==4)
            thursdayEndTime=endDateSetUp;
        else if(dayToClear==5)
            fridayEndTime=endDateSetUp;
        else if(dayToClear==6)
            saturdayEndTime=endDateSetUp;
        else if(dayToClear==7)
            sundayEndTime=endDateSetUp;
    }
    else
    {
        NSString *dateToset;
        
        NSDateFormatter *startDateFormatter = [[NSDateFormatter alloc] init];
        startDateFormatter.dateFormat = @"HH:mm";
        NSLocale *twentyFour = [[NSLocale alloc] initWithLocaleIdentifier:@"en_GB"];
        startDateFormatter.locale = twentyFour;
        dateToset = [NSString stringWithFormat:@"09:00"];
        NSDate *starterDate = [startDateFormatter dateFromString:dateToset];
        startDateFormatter.dateFormat = @"hh:mm a";
        //    NSString *pmamDateString = [dateFormatter stringFromDate:date];
        if(dayToClear==1)
            mondayStartTime=starterDate;
        else if(dayToClear==2)
            tuesdayStartTime=starterDate;
        else if(dayToClear==3)
            wednesdayStartTime=starterDate;
        else if(dayToClear==4)
            thursdayStartTime=starterDate;
        else if(dayToClear==5)
            fridayStartTime=starterDate;
        else if(dayToClear==6)
            saturdayStartTime=starterDate;
        else if(dayToClear==7)
            sundayStartTime=starterDate;
        
        NSDateFormatter *endDateFormatter = [[NSDateFormatter alloc] init];
        endDateFormatter.dateFormat = @"HH:mm";
        dateToset = [NSString stringWithFormat:@"17:00"];
        NSDate *endDateSetUp = [endDateFormatter dateFromString:dateToset];
        endDateFormatter.dateFormat = @"hh:mm a";
        //    NSString *pmamDateString = [dateFormatter stringFromDate:date];
        if(dayToClear==1)
            mondayEndTime=endDateSetUp;
        else if(dayToClear==2)
            tuesdayEndTime=endDateSetUp;
        else if(dayToClear==3)
            wednesdayEndTime=endDateSetUp;
        else if(dayToClear==4)
            thursdayEndTime=endDateSetUp;
        else if(dayToClear==5)
            fridayEndTime=endDateSetUp;
        else if(dayToClear==6)
            saturdayEndTime=endDateSetUp;
        else if(dayToClear==7)
            sundayEndTime=endDateSetUp;
    }
}
- (IBAction)btnClearMondayTimeClicked:(id)sender {
    lblMondayStartTime.text=@"";
    lblMondayEndTime.text=@"";
    [self btnClearAndResetAllTheTimeInPicker:1];
    
}
- (IBAction)btnClearTuesdayTimeClicked:(id)sender {
    lblTuesdayStartTime.text=@"";
    lblTuesdayEndTime.text=@"";
    [self btnClearAndResetAllTheTimeInPicker:2];
    
}
- (IBAction)btnClearWednesdayTimeClicked:(id)sender {
    lblWednesdayStartTime.text=@"";
    lblWednesdayEndTime.text=@"";
    [self btnClearAndResetAllTheTimeInPicker:3];
    
}
- (IBAction)btnClearThursdayTimeClicked:(id)sender {
    lblThursdayStartTime.text=@"";
    lblThursdayEndTime.text=@"";
    [self btnClearAndResetAllTheTimeInPicker:4];
    
}
- (IBAction)btnClearFridayTimeClicked:(id)sender {
    lblFridayStartTime.text=@"";
    lblFridayEndTime.text=@"";
    [self btnClearAndResetAllTheTimeInPicker:5];
    
}
- (IBAction)btnClearSaturdayTimeClicked:(id)sender {
    lblSaturdayStartTime.text=@"";
    lblSaturdayEndTime.text=@"";
    [self btnClearAndResetAllTheTimeInPicker:6];
}

- (IBAction)btnClearSundayTimeClicked:(id)sender {
    lblSundayStartTime.text=@"";
    lblSundayEndTime.text=@"";
    [self btnClearAndResetAllTheTimeInPicker:7];
    
}
- (IBAction)btnMondayStartTimePickerClicked:(id)sender
{
    isMondayStartTimeClicked=true;
    [self openTimePickerAnimation:sender];
}
- (IBAction)btnTuesdayStartTimePickerClicked:(id)sender {
    isTuesdayStartTimeClicked=true;
    [self openTimePickerAnimation:sender];
}

- (IBAction)btnWednesdayStartTimePickerClicked:(id)sender {
    isWednesdayStartTimeClicked=true;
    [self openTimePickerAnimation:sender];
}

- (IBAction)btnThursdayStartTimePickerClicked:(id)sender {
    isThursdayStartTimeClicked=true;
    [self openTimePickerAnimation:sender];
}

- (IBAction)btnFridayStartTimePickerClicked:(id)sender {
    isFridayStartTimeClicked=true;
    [self openTimePickerAnimation:sender];
}

- (IBAction)btnSaturdayStartTimePickerClicked:(id)sender {
    isSaturdayStartTimeClicked=true;
    [self openTimePickerAnimation:sender];
}

- (IBAction)btnSundayStartTimePickerClicked:(id)sender {
    isSundayStartTimeClicked=true;
    [self openTimePickerAnimation:sender];
}


- (IBAction)btnMondayEndTimePickerClicked:(id)sender {
    isMondayEndTimeClicked=true;
    [self openTimePickerAnimation:sender];
}
- (IBAction)btnTuesdayEndTimePickerClicked:(id)sender {
    isTuesdayEndTimeClicked=true;
    [self openTimePickerAnimation:sender];
}
- (IBAction)btnWednesdayEndTimePickerClicked:(id)sender {
    isWednesdayEndTimeClicked=true;
    [self openTimePickerAnimation:sender];
}
- (IBAction)btnThursdayEndTimePickerClicked:(id)sender {
    isThursdayEndTimeClicked=true;
    [self openTimePickerAnimation:sender];
}
- (IBAction)btnFridayEndTimePickerClicked:(id)sender {
    isFridayEndTimeClicked=true;
    [self openTimePickerAnimation:sender];
}
- (IBAction)btnSaturdayEndTimePickerClicked:(id)sender {
    isSaturdayEndTimeClicked=true;
    [self openTimePickerAnimation:sender];
}
- (IBAction)btnSundayEndTimePickerClicked:(id)sender {
    isSundayEndTimeClicked=true;
    [self openTimePickerAnimation:sender];
}

#pragma mark *********************************  TIME PICKER  ******************************

- (IBAction)timerCancelButtonClicked:(id)sender{
    isMondayStartTimeClicked=false;
    isTuesdayStartTimeClicked=false;
    isWednesdayStartTimeClicked=false;
    isThursdayStartTimeClicked=false;
    isFridayStartTimeClicked=false;
    isSaturdayStartTimeClicked=false;
    isSundayStartTimeClicked=false;
    
    isMondayEndTimeClicked=false;
    isTuesdayEndTimeClicked=false;
    isWednesdayEndTimeClicked=false;
    isThursdayEndTimeClicked=false;
    isFridayEndTimeClicked=false;
    isSaturdayEndTimeClicked=false;
    isSundayEndTimeClicked=false;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,800, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    else{
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,1200, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}
-(void)setStartAndEndTime:(NSDate*)dateSelected
{
}
- (IBAction)timerDoneButtonClicked:(id)sender{
    
    selectedDate = [timerPicker date];
    
    [self setStartAndEndTime:selectedDate];
}


#pragma mark *********************************  DATE PICKER  ******************************

- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}
- (IBAction)doneButtonClicked:(id)sender{
    selectedDate = [datePicker date];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
        dateFormatStr = @"dd/MM/yyyy";
    if(isStartDateClicked==true)
    {
        startDate=selectedDate;
        isStartDateClicked=false;
        [[lblSatrtDate layer]setOpacity:1];
        lblSatrtDate.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
        
        if(lblSatrtDate.text.length>0 && lblEndDate.text.length>0)
        {
            if([DateHandler isEndDateIsSmallerThanCurrent:startDate checkEndDate:endDate]==0 || [DateHandler isEndDateIsSmallerThanCurrent:startDate checkEndDate:endDate]==1)
            {
                endDate=selectedDate;
                lblEndDate.text=lblSatrtDate.text;
                datePicker.date=selectedDate;
            }
        }
    }
    else if(isEndDateClicked==true)
    {
        endDate=selectedDate;
        isEndDateClicked=false;
        [[lblSatrtDate layer]setOpacity:1];
        lblEndDate.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
        
        if(lblSatrtDate.text.length>0 && lblEndDate.text.length>0){
            if([DateHandler isEndDateIsSmallerThanCurrent:startDate checkEndDate:endDate]==1 || [DateHandler isEndDateIsSmallerThanCurrent:startDate checkEndDate:endDate]==0)
            {
                endDate=selectedDate;
                startDate=endDate;
                lblEndDate.text=lblSatrtDate.text;
                datePicker.date=selectedDate;
                [self.view makeToast:@"Sorry, you can't create an event that ends before it starts." duration:2.5 position:CSToastPositionBottom];
                return;
            }
        }
    }
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
        
        //        navigationController.viewControllers = @[secondViewController];
        
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 14;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}


- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (IBAction)btnEndDateClicked:(id)sender {
    isEndDateClicked=true;
    [datePicker setDate:endDate];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    [UIView commitAnimations];
}

- (IBAction)btnStartDateClicked:(id)sender {
    [datePicker setDate:startDate];
    
    isStartDateClicked=true;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    [UIView commitAnimations];
}

- (IBAction)btnSaveItPressed:(id)sender {
    
    if([lblSatrtDate.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 || [lblSatrtDate.text isEqualToString:@""]){
        [self.view makeToast:@"Please select start date"];
        return;
    }
    if([lblEndDate.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 || [lblEndDate.text isEqualToString:@""]){
        [self.view makeToast:@"Please select end date"];
        return;
    }
    if([lblMondayStartTime.text length]>0 && [lblMondayEndTime.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please select monday end time"];
        return;
    }
    if([lblTuesdayStartTime.text length]>0 && [lblTuesdayEndTime.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please select tuesday end time"];
        return;
    }
    if([lblWednesdayStartTime.text length]>0 && [lblWednesdayEndTime.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please select wednesday end time"];
        return;
    }
    if([lblThursdayStartTime.text length]>0 && [lblThursdayEndTime.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please select thursday end time"];
        return;
    }
    if([lblFridayStartTime.text length]>0 && [lblFridayEndTime.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please select friday end time"];
        return;
    }
    if([lblSaturdayStartTime.text length]>0 && [lblSaturdayEndTime.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please select saturday end time"];
        return;
    }
    if([lblSundayStartTime.text length]>0 && [lblSundayEndTime.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please select sunday end time"];
        return;
    }
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSString *boidid = [[NSUserDefaults standardUserDefaults] objectForKey:kBoidId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:kUserId];
    [dataDictionary setObject:boidid forKey:kBoidId];
    
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    NSString *startDateToSend = lblSatrtDate.text;
    startDateToSend = [DateHandler sendDateFromString:startDateToSend formatToSend:@"" currentDateFormat:dateFormatStr];
    
    [dataDictionary setObject:startDateToSend forKey:@"from_date"];
    
    NSString *endDateToSend = lblEndDate.text;
    endDateToSend = [DateHandler sendDateFromString:endDateToSend formatToSend:@"" currentDateFormat:dateFormatStr];
    
    [dataDictionary setObject:endDateToSend forKey:@"to_date"];
    
    [dataDictionary setObject:lblMondayStartTime.text forKey:@"mon_start"];
    [dataDictionary setObject:lblMondayEndTime.text forKey:@"mon_end"];
    
    [dataDictionary setObject:lblTuesdayStartTime.text forKey:@"tue_start"];
    [dataDictionary setObject:lblTuesdayEndTime.text forKey:@"tue_end"];
    
    [dataDictionary setObject:lblWednesdayStartTime.text forKey:@"wed_start"];
    [dataDictionary setObject:lblWednesdayEndTime.text forKey:@"wed_end"];
    
    [dataDictionary setObject:lblThursdayStartTime.text forKey:@"thu_start"];
    [dataDictionary setObject:lblThursdayEndTime.text forKey:@"thu_end"];
    
    [dataDictionary setObject:lblFridayStartTime.text forKey:@"fri_start"];
    [dataDictionary setObject:lblFridayEndTime.text forKey:@"fri_end"];
    
    
    [dataDictionary setObject:lblSaturdayStartTime.text forKey:@"sat_start"];
    [dataDictionary setObject:lblSaturdayEndTime.text forKey:@"sat_end"];
    
    [dataDictionary setObject:lblSundayStartTime.text forKey:@"sun_start"];
    [dataDictionary setObject:lblSundayEndTime.text forKey:@"sun_end"];
    
    [self showProgressHud];
    [[WebService sharedWebService] callSetMyAvalabilityWebService:dataDictionary];
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnClearStartDateFieldPressed:(id)sender {
    lblSatrtDate.text=@"";
}

- (IBAction)btnClearEndDateFieldPressed:(id)sender {
    lblEndDate.text=@"";
}

-(void)responseSuccessMessage
{
    [self.navigationController popViewControllerAnimated:YES];
    
}
//}#pragma mark -
#pragma mark - WebService
#pragma mark -
- (void)setAvailabilitySuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    [self.view makeToast:[response objectForKey:@"message"]];
    [self performSelector:@selector(responseSuccessMessage) withObject:self afterDelay:2.0 ];
}

- (void) setAvailabilityFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) getAvailabilitySuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"message"]];
    
    NSArray *contactDataArray = [dictionary objectForKey:@"data"];
    
    NSDictionary *employeeRoasterDict = [contactDataArray objectAtIndex:0];
    NSString *dateString = [employeeRoasterDict objectForKey:@"date"];
    
    NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString =  [dateFormatter dateFromString:dateString];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] ){
        lblSatrtDate.text=@"";
    }
    lblSatrtDate.text = [DateHandler getDateFromString:dateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
    
    if([dateString isEqualToString:@""])
        lblSatrtDate.text=@"";
}

- (void) getAvailabilityFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
        return;
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
        return;
    }
}

-(void)openTimePickerWithSelectedDate:(id)sender selectedDateForPicker:(NSDate*)selectedDateForPicker timeFormat:(NSString*)timeFormat
{
    ActionSheetDatePicker *datePickerBest = [[ActionSheetDatePicker alloc] initWithTitle:@"Select a time" datePickerMode:UIDatePickerModeTime selectedDate:selectedDateForPicker minimumDate:nil maximumDate:nil target:self action:@selector(timeWasSelected:element:) cancelAction:@selector(timeWasCancelled:element:) origin:sender];
    if([timeFormat isEqualToString:@"24"]){
        NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"NL"];
        [datePickerBest setLocale:locale];
    }
    datePickerBest.minuteInterval = 5;
    [datePickerBest showActionSheetPicker];
}

#pragma mar ***************** Time Picker Animation ************************
-(void)openTimePickerAnimation:(id)sender
{
    NSString *strTimeFormat = [[NSUserDefaults standardUserDefaults]
                               objectForKey:KTimeFormat];
    
    strTimeFormat = [NSString stringWithFormat:@"%@", strTimeFormat];
    
    if(isMondayStartTimeClicked==true){
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:mondayStartTime timeFormat:strTimeFormat];
    }
    else if (isMondayEndTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:mondayEndTime timeFormat:strTimeFormat];
    
    else if (isTuesdayStartTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:tuesdayStartTime timeFormat:strTimeFormat];
    else if (isTuesdayEndTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:tuesdayEndTime timeFormat:strTimeFormat];
    
    else if (isWednesdayStartTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:wednesdayStartTime timeFormat:strTimeFormat];
    else if (isWednesdayEndTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:wednesdayEndTime timeFormat:strTimeFormat];
    
    else if (isThursdayStartTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:thursdayStartTime timeFormat:strTimeFormat];
    else if (isThursdayEndTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:thursdayEndTime timeFormat:strTimeFormat];
    
    else if (isFridayStartTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:fridayStartTime timeFormat:strTimeFormat];
    else if (isFridayEndTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:fridayEndTime timeFormat:strTimeFormat];
    
    else if (isSaturdayStartTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:saturdayStartTime timeFormat:strTimeFormat];
    else if (isSaturdayEndTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:saturdayEndTime timeFormat:strTimeFormat];
    
    else if (isSundayStartTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:sundayStartTime timeFormat:strTimeFormat];
    else if (isSundayEndTimeClicked==true)
        [self openTimePickerWithSelectedDate:sender selectedDateForPicker:sundayEndTime timeFormat:strTimeFormat];
    
}

-(void)timeWasCancelled:(NSDate *)selectedTime element:(id)element
{
    isMondayStartTimeClicked=false;
    isTuesdayStartTimeClicked=false;
    isWednesdayStartTimeClicked=false;
    isThursdayStartTimeClicked=false;
    isFridayStartTimeClicked=false;
    isSaturdayStartTimeClicked=false;
    isSundayStartTimeClicked=false;
    
    isMondayEndTimeClicked=false;
    isTuesdayEndTimeClicked=false;
    isWednesdayEndTimeClicked=false;
    isThursdayEndTimeClicked=false;
    isFridayEndTimeClicked=false;
    isSaturdayEndTimeClicked=false;
    isSundayEndTimeClicked=false;
}

-(void)timeWasSelected:(NSDate *)selectedTime element:(id)element
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSString *strTimeFormat = [[NSUserDefaults standardUserDefaults]
                               objectForKey:KTimeFormat];
    strTimeFormat = [NSString stringWithFormat:@"%@",strTimeFormat];
    
    NSString *dateToset;
    NSDate *date2;
    dateToset = [NSString stringWithFormat:@"9:00:00"];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"HH:mm"];
    NSLocale *twentyFour = [[NSLocale alloc] initWithLocaleIdentifier:@"en_GB"];
    formatter.locale = twentyFour;
    NSString *timeString = [formatter stringFromDate:selectedTime];
    NSDate *date1 = [formatter dateFromString:timeString];
    date2 = [formatter dateFromString:dateToset];
    NSComparisonResult result = [date2 compare:date1];
    NSString *truncatedTime = [timeString substringToIndex:2];
    NSString *truncatedTimeMinutes = [timeString substringFromIndex: [timeString length] - 2];
    if(result == NSOrderedDescending)
    {
        [self timeWasCancelled:nil element:nil];
        [self.view makeToast:@"Time should be between 9:00 AM to 5:00 PM" duration:2.4 position:CSToastPositionBottom];
        return;
    }
    else if([truncatedTime integerValue]>=17)
    {
        if([truncatedTimeMinutes integerValue]==00 && [truncatedTime integerValue] == 17){
        }
        else if ([truncatedTime integerValue]>=17 ||[truncatedTimeMinutes integerValue]>1) {
            [self timeWasCancelled:nil element:nil];
            [self.view makeToast:@"Time should be between 9:00 AM to 5:00 PM" duration:2.4 position:CSToastPositionBottom];
            return;
        }
    }
    else if([truncatedTime integerValue]<=9)
    {
        if([truncatedTimeMinutes integerValue]==00 && [truncatedTime integerValue] == 9){
        }
        else if ([truncatedTime integerValue]<9) {
            [self timeWasCancelled:nil element:nil];
            [self.view makeToast:@"Time should be between 9:00 AM to 5:00 PM" duration:2.4 position:CSToastPositionBottom];
            return;
        }
    }
    
    strTimeFormat = [NSString stringWithFormat:@"%@", strTimeFormat];
    if([strTimeFormat isEqualToString:@"12"]){
        NSLocale *twelveHourLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
        dateFormatter.locale = twelveHourLocale;
        [dateFormatter setDateFormat:@"hh:mm a"];
    }
    else{
        NSLocale *twentyFour = [[NSLocale alloc] initWithLocaleIdentifier:@"en_GB"];
        dateFormatter.locale = twentyFour;
        [dateFormatter setDateFormat:@"HH:mm"];
    }
    //    NSString *timeString = [dateFormatter stringFromDate:selectedTime];
    
    
    selectedDate = selectedTime;
    if(isMondayStartTimeClicked==true){
        isMondayStartTimeClicked=false;
        mondayStartTime=selectedDate;
        if([strTimeFormat isEqualToString:@"12"])
            lblMondayStartTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblMondayStartTime.text= timeString;
    }
    else if(isMondayEndTimeClicked==true)
    {
        isMondayEndTimeClicked=false;
        mondayEndTime=selectedDate;
        
        if([strTimeFormat isEqualToString:@"12"])
            lblMondayEndTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblMondayEndTime.text= timeString;
        
        if(lblMondayStartTime.text.length>0 && lblMondayEndTime.text.length>0){
            int timeCompare = [DateHandler compareTwoTimeInterval:lblMondayStartTime.text endTime:lblMondayEndTime.text timeFormat:strTimeFormat];
            
            if(timeCompare==1)
            {
                [self.view makeToast:@"End time should always greater than start time" duration:2.4 position:CSToastPositionBottom];
                
                lblMondayEndTime.text=@"";
                return;
            }
            else if(timeCompare==0 )
            {
                [self.view makeToast:@"Start time and end time is equal"];
                lblMondayEndTime.text=@"";
                return;
            }
        }
        
    }
    else if(isTuesdayStartTimeClicked==true)
    {
        isTuesdayStartTimeClicked=false;
        tuesdayStartTime=selectedDate;
        
        if([strTimeFormat isEqualToString:@"12"])
            lblTuesdayStartTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat ];
        else
            lblTuesdayStartTime.text= timeString;
        
    }
    else if(isTuesdayEndTimeClicked==true)
    {
        isTuesdayEndTimeClicked=false;
        tuesdayEndTime=selectedDate;
        
        if([strTimeFormat isEqualToString:@"12"])
            lblTuesdayEndTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblTuesdayEndTime.text= timeString;
        
        if(lblTuesdayStartTime.text.length>0 && lblTuesdayEndTime.text.length>0){
            int timeCompare = [DateHandler compareTwoTimeInterval:lblTuesdayStartTime.text endTime:lblTuesdayEndTime.text timeFormat:strTimeFormat];
            if(timeCompare==1)
            {
                [self.view makeToast:@"End time should always greater than start time" duration:2.4 position:CSToastPositionBottom];
                lblTuesdayEndTime.text=@"";
                return;
            }
            else if(timeCompare==0 )
            {
                [self.view makeToast:@"Start time and end time is equal"];
                lblTuesdayEndTime.text=@"";
                return;
            }
        }
    }
    else if(isWednesdayStartTimeClicked==true)
    {
        isWednesdayStartTimeClicked=false;
        wednesdayStartTime=selectedDate;
        if([strTimeFormat isEqualToString:@"12"])
            lblWednesdayStartTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblWednesdayStartTime.text= timeString;
    }
    else if(isWednesdayEndTimeClicked==true)
    {
        isWednesdayEndTimeClicked=false;
        wednesdayEndTime=selectedDate;
        
        if([strTimeFormat isEqualToString:@"12"])
            lblWednesdayEndTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblWednesdayEndTime.text= timeString;
        if(lblWednesdayStartTime.text.length>0 && lblWednesdayEndTime.text.length>0){
            
            int timeCompare = [DateHandler compareTwoTimeInterval:lblWednesdayStartTime.text endTime:lblWednesdayEndTime.text timeFormat:strTimeFormat];
            if(timeCompare==1)
            {
                [self.view makeToast:@"End time should always greater than start time" duration:2.4 position:CSToastPositionBottom];
                lblWednesdayEndTime.text=@"";
                return;
            }
            
            else if(timeCompare==0 )
            {
                [self.view makeToast:@"Start time and end time is equal"];
                lblWednesdayEndTime.text=@"";
                return;
            }
        }
        
    }
    else if(isThursdayStartTimeClicked==true)
    {
        isThursdayStartTimeClicked=false;
        thursdayStartTime=selectedDate;
        if([strTimeFormat isEqualToString:@"12"])
            lblThursdayStartTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblThursdayStartTime.text= timeString;
    }
    else if(isThursdayEndTimeClicked==true)
    {
        isThursdayEndTimeClicked=false;
        thursdayEndTime=selectedDate;
        
        if([strTimeFormat isEqualToString:@"12"])
            lblThursdayEndTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblThursdayEndTime.text= timeString;
        if(lblThursdayStartTime.text.length>0 && lblThursdayEndTime.text.length>0){
            
            int timeCompare = [DateHandler compareTwoTimeInterval:lblThursdayStartTime.text endTime:lblThursdayEndTime.text timeFormat:strTimeFormat];
            if(timeCompare==1)
            {
                [self.view makeToast:@"End time should always greater than start time" duration:2.4 position:CSToastPositionBottom];
                lblThursdayEndTime.text=@"";
                return;
            }
            else if(timeCompare==0 )
            {
                [self.view makeToast:@"Start time and end time is equal"];
                lblThursdayEndTime.text=@"";
                return;
                
            }
        }
    }
    else if(isFridayStartTimeClicked==true)
    {
        isFridayStartTimeClicked=false;
        fridayStartTime=selectedDate;
        if([strTimeFormat isEqualToString:@"12"])
            lblFridayStartTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblFridayStartTime.text= timeString;
    }
    else if(isFridayEndTimeClicked==true)
    {
        isFridayEndTimeClicked=false;
        fridayEndTime=selectedDate;
        
        if([strTimeFormat isEqualToString:@"12"])
            lblFridayEndTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblFridayEndTime.text= timeString;
        if(lblFridayStartTime.text.length>0 && lblFridayEndTime.text.length>0){
            
            int timeCompare = [DateHandler compareTwoTimeInterval:lblFridayStartTime.text endTime:lblFridayEndTime.text timeFormat:strTimeFormat];
            if(timeCompare==1)
            {
                [self.view makeToast:@"End time should always greater than start time" duration:2.4 position:CSToastPositionBottom];            lblFridayEndTime.text=@"";
                return;
                
            }
            else if(timeCompare==0 )
            {
                [self.view makeToast:@"Start time and end time is equal"];
                lblFridayEndTime.text=@"";
                return;
            }
        }
        
    }
    else if(isSaturdayStartTimeClicked==true)
    {
        isSaturdayStartTimeClicked=false;
        saturdayStartTime=selectedDate;
        
        if([strTimeFormat isEqualToString:@"12"])
            lblSaturdayStartTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblSaturdayStartTime.text= timeString;
        
    }
    else if(isSaturdayEndTimeClicked==true)
    {
        isSaturdayEndTimeClicked=false;
        saturdayEndTime=selectedDate;
        
        if([strTimeFormat isEqualToString:@"12"])
            lblSaturdayEndTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblSaturdayEndTime.text= timeString;
        if(lblSaturdayStartTime.text.length>0 && lblSaturdayEndTime.text.length>0){
            
            int timeCompare = [DateHandler compareTwoTimeInterval:lblSaturdayStartTime.text endTime:lblSaturdayEndTime.text timeFormat:strTimeFormat];
            if(timeCompare==1)
            {
                [self.view makeToast:@"End time should always greater than start time" duration:2.4 position:CSToastPositionBottom];            lblSaturdayEndTime.text=@"";
                return;
                
            }
            else if(timeCompare==0 )
            {
                [self.view makeToast:@"Start time and end time is equal"];
                lblSaturdayEndTime.text=@"";
                return;
                
            }
        }
        
    }
    else if(isSundayStartTimeClicked==true)
    {
        isSundayStartTimeClicked=false;
        sundayStartTime=selectedDate;
        if([strTimeFormat isEqualToString:@"12"])
            lblSundayStartTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblSundayStartTime.text= timeString;
    }
    else if(isSundayEndTimeClicked==true)
    {
        isSundayEndTimeClicked=false;
        if([strTimeFormat isEqualToString:@"12"])
            lblSundayEndTime.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
        else
            lblSundayEndTime.text= timeString;
        if(lblSundayStartTime.text.length>0 && lblSundayEndTime.text.length>0){
            
            int timeCompare = [DateHandler compareTwoTimeInterval:lblSundayStartTime.text endTime:lblSundayEndTime.text timeFormat:strTimeFormat];
            if(timeCompare==1)
            {
                [self.view makeToast:@"End time should always greater than start time" duration:2.4 position:CSToastPositionBottom];            lblSundayEndTime.text=@"";
                return;
                
            }
            else if(timeCompare==0 )
            {
                [self.view makeToast:@"Start time and end time is equal"];
                lblSundayEndTime.text=@"";
                return;
                
            }
            sundayStartTime=selectedDate;
        }
    }
    
    
    [self closeTimePickerAnimation];
    
}
-(void)closeTimePickerAnimation
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,800, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    else{
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,1200, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}



@end
