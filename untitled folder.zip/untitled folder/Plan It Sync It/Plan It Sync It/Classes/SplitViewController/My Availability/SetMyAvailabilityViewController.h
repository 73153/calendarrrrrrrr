//
//  SetMyAvailabilityViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 18/3/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
#import "AbstractActionSheetPicker.h"
#import <Foundation/Foundation.h>

@interface SetMyAvailabilityViewController : UIViewController<CustomKeyboardDelegate,UITextFieldDelegate,UITextViewDelegate,IQDropDownTextFieldDelegate,UIPickerViewDelegate, UIPickerViewDataSource>
{
    CustomKeyboard *customKeyboard;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (nonatomic, strong) IBOutlet UILabel  *lblSatrtDate;
@property (nonatomic, strong) IBOutlet UILabel  *lblEndDate;
@property (nonatomic, strong) NSDictionary *oldDictionary;

@property (nonatomic, strong) NSString *selectedKey;
@property (nonatomic, strong) NSString *selectedScale;


@property (nonatomic, strong) NSDate *selectedDate;
@property (weak, nonatomic) IBOutlet UILabel *lblMondayStartTime;
@property (weak, nonatomic) IBOutlet UILabel *lblTuesdayStartTime;
@property (weak, nonatomic) IBOutlet UILabel *lblWednesdayStartTime;
@property (weak, nonatomic) IBOutlet UILabel *lblThursdayStartTime;
@property (weak, nonatomic) IBOutlet UILabel *lblFridayStartTime;
@property (weak, nonatomic) IBOutlet UILabel *lblSaturdayStartTime;
@property (weak, nonatomic) IBOutlet UILabel *lblSundayStartTime;

@property (weak, nonatomic) IBOutlet UILabel *lblMondayEndTime;
@property (weak, nonatomic) IBOutlet UILabel *lblTuesdayEndTime;
@property (weak, nonatomic) IBOutlet UILabel *lblWednesdayEndTime;
@property (weak, nonatomic) IBOutlet UILabel *lblThursdayEndTime;
@property (weak, nonatomic) IBOutlet UILabel *lblFridayEndTime;
@property (weak, nonatomic) IBOutlet UILabel *lblSaturdayEndTime;
@property (weak, nonatomic) IBOutlet UILabel *lblSundayEndTime;

@property (nonatomic, strong) AbstractActionSheetPicker *actionSheetPicker;


@property (weak, nonatomic) IBOutlet UIButton *btnStartDate;
@property (weak, nonatomic) IBOutlet UIButton *btnEndDate;

@property (nonatomic, strong) IBOutlet UIView *pickerBackGroundView;
@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarCancel;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarDone;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSaveIt;


@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;

-(void)openTimePickerWithSelectedDate:(id)sender selectedDateForPicker:(NSDate*)selectedDateForPicker timeFormat:(NSString*)timeFormat;

@property (weak, nonatomic) IBOutlet UIButton *btnMondayStartTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnTuesdayStartTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnWednesdayStartTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnThursdayStartTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnfridayStartTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnSaturdayStartTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnSundayStartTimeRoundedCorner;

@property (weak, nonatomic) IBOutlet UIButton *btnMondayEndTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnTuesdayEndTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnWednesdayEndTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnThursdayEndTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnfridayEndTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnSaturdayEndTimeRoundedCorner;
@property (weak, nonatomic) IBOutlet UIButton *btnSundayEndTimeRoundedCorner;

@property (weak, nonatomic) IBOutlet UIView *timerPickerBackgroundView;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *timerbtnBarCancel;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *timerbtnBarDone;
@property (nonatomic, strong) IBOutlet UIDatePicker *timerPicker;


- (IBAction)selectStartTimeEndTime:(UIControl *)sender;

- (IBAction)btnClearMondayTimeClicked:(id)sender;
- (IBAction)btnClearTuesdayTimeClicked:(id)sender;
- (IBAction)btnClearWednesdayTimeClicked:(id)sender;
- (IBAction)btnClearThursdayTimeClicked:(id)sender;
- (IBAction)btnClearFridayTimeClicked:(id)sender;
- (IBAction)btnClearSaturdayTimeClicked:(id)sender;
- (IBAction)btnClearSundayTimeClicked:(id)sender;

- (IBAction)btnMondayStartTimePickerClicked:(id)sender;
- (IBAction)btnTuesdayStartTimePickerClicked:(id)sender;
- (IBAction)btnWednesdayStartTimePickerClicked:(id)sender;
- (IBAction)btnThursdayStartTimePickerClicked:(id)sender;
- (IBAction)btnFridayStartTimePickerClicked:(id)sender;
- (IBAction)btnSaturdayStartTimePickerClicked:(id)sender;
- (IBAction)btnSundayStartTimePickerClicked:(id)sender;

- (IBAction)btnMondayEndTimePickerClicked:(id)sender;
- (IBAction)btnTuesdayEndTimePickerClicked:(id)sender;
- (IBAction)btnWednesdayEndTimePickerClicked:(id)sender;
- (IBAction)btnThursdayEndTimePickerClicked:(id)sender;
- (IBAction)btnFridayEndTimePickerClicked:(id)sender;
- (IBAction)btnSaturdayEndTimePickerClicked:(id)sender;
- (IBAction)btnSundayEndTimePickerClicked:(id)sender;

- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnEndDateClicked:(id)sender;
- (IBAction)btnStartDateClicked:(id)sender;

- (IBAction)btnSaveItPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;

- (IBAction)btnClearStartDateFieldPressed:(id)sender;
- (IBAction)btnClearEndDateFieldPressed:(id)sender;

- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;

- (IBAction)timerCancelButtonClicked:(id)sender;
- (IBAction)timerDoneButtonClicked:(id)sender;

-(void)setStartAndEndTime;
- (void) showProgressHud;
- (void) hideProgressHud;
- (void) setAvailabilitySuccess:(NSNotification *)notification;
- (void) setAvailabilityFailed:(NSNotification *)notification;

- (void) getAvailabilitySuccess:(NSNotification *)notification;
- (void) getAvailabilityFailed:(NSNotification *)notification;
@end

