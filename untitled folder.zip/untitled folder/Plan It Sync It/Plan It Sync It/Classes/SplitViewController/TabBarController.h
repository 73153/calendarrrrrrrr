//
//  DEMOViewController.h
//  Plan It Sync It
//
// Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"

@interface TabBarController : REFrostedViewController

@end
