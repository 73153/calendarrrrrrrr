//
//  DEMOMenuViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 18/3/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "RDVTabBarController.h"
#import "RDVTabBarItem.h"
#import "PECropViewController.h"

@interface DEMOMenuViewController : UITableViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,PECropViewControllerDelegate>
{
    UIImageView *imageView;
    UINavigationController *navigationController;
}

@property (nonatomic, strong) NSMutableDictionary *userDetailDict;
//@property (nonatomic, strong) NSMutableDictionary *animals;
//@property (nonatomic, strong) NSMutableArray *animalSectionTitles;
@property (nonatomic, strong) NSString *checkForTableEntries;

-(void)buttonPressed;
- (void) showProgressHud;
- (void) hideProgressHud;
-(void)userImageChagedSuccess:(NSNotification *)notification;

-(void)getdetailForMasterTableSuccess:(NSNotification *)notification;
-(void)getdetailForMasterTableFailed:(NSNotification *)notification;

@end
