//
//  DEMOViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "DEMOMenuViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "TabBarController.h"
#import "UIViewController+REFrostedViewController.h"
#import "AppConstant.h"
#import "MonthViewController.h"
#import "TimelineViewController.h"
#import "WeekViewExampleController.h"
#import "DayViewController.h"
@interface TabBarController ()

@end


@implementation TabBarController

- (void)awakeFromNib{
    
    self.contentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"contentController"];
    self.menuViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"menuController"];
//    NSString *strTextFieldCalenederView = [[NSUserDefaults standardUserDefaults] objectForKey:KRootController];
//    if([strTextFieldCalenederView  isEqualToString:@"Month"]){
//        MonthViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
//        self.contentViewController = homeViewController;
////        [self.navigationController setViewControllers:[NSArray arrayWithObject:homeViewController] animated:YES];
//    }
//    else if([strTextFieldCalenederView isEqualToString:@"Timeline"]){
//        TimelineViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"timelineViewController"];
//        self.contentViewController = homeViewController;
//
////        [self.navigationController setViewControllers:[NSArray arrayWithObject:homeViewController] animated:YES];
//    }
//    else if([strTextFieldCalenederView isEqualToString:@"Week"]){
//        WeekViewExampleController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"weekViewExampleController"];
//        self.contentViewController = homeViewController;
//
////        [self.navigationController setViewControllers:[NSArray arrayWithObject:homeViewController] animated:YES];
//    }
//    else if([strTextFieldCalenederView isEqualToString:@"Day"]){
//        DayViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"dayViewController"];
//        self.contentViewController = homeViewController;
//
////        [self.navigationController setViewControllers:[NSArray arrayWithObject:homeViewController] animated:YES];
//    }
}


@end
