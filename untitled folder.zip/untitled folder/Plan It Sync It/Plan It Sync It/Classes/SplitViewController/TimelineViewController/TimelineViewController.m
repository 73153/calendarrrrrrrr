//
//  EventsViewController.m
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import "TimelineViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "EditEventsViewController.h"
#import "ToDoViewController.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
#import "CTCheckbox.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "YearViewController.h"
#import "EventViewController.h"
#import "CTCheckbox.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "DateHandler.h"
#import "UIImage+Helpers.h"
#import "ContactsViewController.h"

@interface TimelineViewController ()
{
    NSIndexPath *swipeCellIndexPath;
    
}
@property (nonatomic, strong) CTCheckbox *checkbox1;
@property (nonatomic, strong) CTCheckbox *checkbox2;
@property (nonatomic, strong) CTCheckbox *checkbox3;

@end

@implementation TimelineViewController
@synthesize tableView;
@synthesize  selectedContacts;
@synthesize totalIndaxPath;
@synthesize  emailIdArray;
@synthesize nameArray;
@synthesize deletedContactArray;
@synthesize searchedEmailArray;
@synthesize selectedData;
@synthesize selectedRows;
//@synthesize searchedNameArray;
@synthesize btn1;
@synthesize btn2;
@synthesize btn3;
@synthesize labelNoRecordFound;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize allRecordArray;
@synthesize isFiltered;
@synthesize isPastChecked;
@synthesize isReverseChecked;
@synthesize isUpcomingChecked;
- (void)viewDidLoad
{
    [super viewDidLoad];
    //init data
    self.selectedRows = [NSMutableArray array];
    tableView.dataSource=self;
    tableView.delegate=self;
    [self setTitle:@"Timeline"];
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Timeline"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    labelNoRecordFound.hidden=true;
    
    CGPoint position1 = btn1.frame.origin;
    NSLog(@"position1 x %f and Y %f",position1.x,position1.y);
    CGPoint position2 = btn2.frame.origin;
    NSLog(@"position2 x %f and Y %f",position2.x,position2.y);
    CGPoint position3 = btn3.frame.origin;
    NSLog(@"position2 x %f and Y %f",position3.x,position3.y);
    
    
    
    isPastChecked= false;
    isUpcomingChecked=true;
    isReverseChecked=false;
    
    self.checkbox1 = [[CTCheckbox alloc] initWithFrame:CGRectMake(position1.x, position1.y, 280.0, 30.0)];
    self.checkbox1.textLabel.text = @"Show Past";
    self.checkbox1.tag=111;
    [self.view addSubview:self.checkbox1];
    [self.checkbox1 addTarget:self action:@selector(checkBoxTapped:) forControlEvents:UIControlEventValueChanged];
    
    
    //    self.checkbox2 = [[CTCheckbox alloc] initWithFrame:CGRectMake(position2.x, position2.y, 280.0, 30.0)];
    //    [self.checkbox2 setColor:[UIColor blackColor] forControlState:UIControlStateSelected];
    //    //    [self.checkbox2 setColor:[UIColor grayColor] forControlState:UIControlStateSelected];
    //    self.checkbox2.checked=true;
    //    self.checkbox2.textLabel.text = @"Reverse Order";
    //    [self.view addSubview:self.checkbox2];
    //    self.checkbox2.tag=112;
    //
    //    [self.checkbox2 addTarget:self action:@selector(checkBoxTapped:) forControlEvents:UIControlEventValueChanged];
    self.checkbox3.tag=113;
    
    self.checkbox3 = [[CTCheckbox alloc] initWithFrame:CGRectMake(position3.x, position3.y, 280.0, 30.0)];
    self.checkbox3.textLabel.text = @"Reverse order";
    [self.view addSubview:self.checkbox3];
    
    [self.checkbox3 addTarget:self action:@selector(checkBoxTapped:) forControlEvents:UIControlEventValueChanged];
    
    
    self.tableView.rowHeight = 80;
    
    // Initialize Refresh Control
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    
    // Configure Refresh Control
    [refreshControl addTarget:self action:@selector(toggleCells:) forControlEvents:UIControlEventValueChanged];
    refreshControl.tintColor = [UIColor blueColor];
    
    // Configure View Controller
    [self.tableView addSubview:refreshControl];
    self.refreshControl = refreshControl;
    self.useCustomCells = NO;
    totalIndaxPath = [NSMutableArray array];
    
    allRecordArray = [[NSMutableArray alloc] init];
    // Do any additional setup after loading the view, typically from a nib.
    selectedContacts = [NSMutableArray array];
    
    emailIdArray = [[NSMutableArray alloc] init];
    nameArray = [[NSMutableArray alloc] init];
    
    isSelectAllPressed=false;
    isSearchAndDelete=false;
    //    searchedEmailArray = emailIdArray;
    //    searchedNameArray=nameArray;
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfTimelineSuccess:) name:kGetListOfTimelineSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfTimelineFailed:) name:kGetListOfTimelineFailed object:nil];
    
}

- (void)checkBoxTapped:(CTCheckbox *)checkbox
{
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:@"" forKey:@"eventid"];
    [dataDictionary setObject:@"" forKey:@"instance_date"];
    [dataDictionary setObject:@"" forKey:@"search"];
    
    NSInteger tag = [checkbox tag];
    switch (tag) {
        case 111:{
            if(isPastChecked==false)
                isPastChecked=true;
            else
                isPastChecked=false;
        }
            break;
        case 112:{
            if(isUpcomingChecked==false)
                isUpcomingChecked=true;
            else
                isUpcomingChecked=false;
        }
            break;
        case 113:{
            if(isReverseChecked==false)
                isReverseChecked=true;
            else
                isReverseChecked=false;
        }
            break;
        default:
            break;
    }
    
    [self showProgressHud];
    [dataDictionary setObject:userid forKey:@"user_id"];
    [dataDictionary setObject:[NSString stringWithFormat:@"%d",isPastChecked] forKey:@"past"];
    
    [[WebService sharedWebService] callgetListOfTimeline:dataDictionary];
    
}


-(void)viewWillAppear:(BOOL)animated
{
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:@"user_id"];
    
    [self showProgressHud];
    
    [[WebService sharedWebService] callgetListOfTimeline:dataDictionary];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change
                       context:(void *)context
{
    
}

-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark - dataSource method
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //    return searchedEmailArray.count;
    return allRecordArray.count;
    
}
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"UMCell";
    UMTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    NSString *timeLineColor = [[NSUserDefaults standardUserDefaults] objectForKey:kTimeLineColor];
    
    if([timeLineColor isEqualToString:@"#000000"])
    {
        cell.label.textColor = [UIColor whiteColor];
        cell.label1.textColor = [UIColor whiteColor];
        cell.lblCellDate.textColor = [UIColor whiteColor];
        cell.lblCellTime.textColor = [UIColor whiteColor];
        
        cell.monthColoredEventView.backgroundColor = [UIColor blackColor];
        cell.monthColoredEventView.layer.borderColor = [UIColor whiteColor].CGColor;
        cell.monthColoredEventView.layer.borderWidth = 3.0f;
        cell.monthColoredEventView.layer.cornerRadius=7;
        cell.monthColoredEventView.clipsToBounds=YES;
        //        cell.backgroundView.backgroundColor = [UIColor blackColor];
    }
    else if([timeLineColor isEqualToString:@"#FFFFFF"])
    {
        cell.label.textColor = [UIColor blackColor];
        cell.label1.textColor = [UIColor blackColor];
        cell.lblCellDate.textColor = [UIColor blackColor];
        cell.lblCellTime.textColor = [UIColor blackColor];
        
        cell.monthColoredEventView.backgroundColor = [UIColor whiteColor];
        cell.monthColoredEventView.layer.borderColor = [UIColor blackColor].CGColor;
        cell.monthColoredEventView.layer.borderWidth = 3.0f;
        cell.monthColoredEventView.layer.cornerRadius=7;
        cell.monthColoredEventView.clipsToBounds=YES;
        //        cell.backgroundView.backgroundColor = [UIColor whiteColor];
        
    }
    if(nameArray.count>0)
        labelNoRecordFound.hidden=true;
    NSString *currentText;
    
    id object = [nameArray objectAtIndex:indexPath.row];
    
    if (object == [NSNull null])
        return cell;
    
    id object1 = [[[allRecordArray objectAtIndex:indexPath.row] objectAtIndex:0] valueForKey:@"title"];
    
    if (object1 == [NSNull null])
        return cell;
    
    id object2 =  [[[allRecordArray objectAtIndex:indexPath.row] objectAtIndex:0]valueForKey:@"time"];
    if (object2 == [NSNull null])
        return cell;
    
    cell.label.text = [[[allRecordArray objectAtIndex:indexPath.row] objectAtIndex:0]valueForKey:@"title"];
    currentText =cell.label1.text = [nameArray objectAtIndex:indexPath.row];
    
    NSString *timeString = [[[allRecordArray objectAtIndex:indexPath.row] objectAtIndex:0]valueForKey:@"time"];
    
    NSString *timeFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KTimeFormat];
    timeFormatStr = [NSString stringWithFormat:@"%@",timeFormatStr];
    cell.lblCellTime.text = [DateHandler convertTimeFormat:timeString timeFormat:timeFormatStr];
    
    NSString *dateString = [[[allRecordArray objectAtIndex:indexPath.row] objectAtIndex:0]valueForKey:@"date"];
    
    
    NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString =  [dateFormatter dateFromString:dateString];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] ){
        cell.lblCellDate.text=@"";
    }
    cell.lblCellDate.text = [DateHandler getDateFromString:dateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
    
    cell.lblCellTime.text = [[[allRecordArray objectAtIndex:indexPath.row]  objectAtIndex:0] valueForKey:@"time"];
    
    NSString *repeatingOrNot = [[[allRecordArray objectAtIndex:indexPath.row]  objectAtIndex:0]valueForKey:@"day_title"];
    
    if(![repeatingOrNot isEqualToString:@""])
    {
        [cell.btnCancelRequest setTitle:repeatingOrNot forState:UIControlStateNormal];
    }
    
    cell.label.numberOfLines = 3;
    cell.label1.numberOfLines = 3;
    
    cell.label.lineBreakMode=0;
    cell.label1.lineBreakMode=0;
    
    
    //    NSString *userImage = [[[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"event_image"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    //    if(![userImage isEqualToString:@""] && ![userImage isEqualToString:nil]){
    //
    //        [UIImage loadFromURL:[NSURL URLWithString:userImage] callback:^(UIImage *image){
    //            cell.userImage.image = image;
    //        }];
    //    }
    //    else
    //    {
    //        [cell.userImage setImage:[UIImage imageNamed:@"user_image_default.png"]];
    //    }
    cell.userImage.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    cell.userImage.layer.masksToBounds = YES;
    cell.userImage.layer.cornerRadius = 10.0;
    cell.userImage.layer.borderColor = [UIColor whiteColor].CGColor;
    cell.userImage.layer.borderWidth = 1.0f;
    cell.userImage.clipsToBounds = YES;
    UIImage *image;
    
    if ([selectedContacts containsObject:currentText]) {
        image = [UIImage imageNamed:@"check_on.png"];
    } else  {
        image = [UIImage imageNamed:@"check_off.png"];
    }
    
    [cell.checkBoxButton setImage:image forState:UIControlStateNormal];
    //    [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:70.0f];
    
    if (cell==Nil) {
        cell = [[UMTableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    
    //    [cell setBackgroundColor:[UIColor clearColor]];
    //
    //    CAGradientLayer *grad = [CAGradientLayer layer];
    //    grad.frame = CGRectMake(0,0,480,80);
    //    //    139-137-137
    //    UIColor *color1 = [UIColor colorWithRed:139.0f/255.0f green:137.0f/255.0f blue:137.0f/255.0f alpha:0.5];
    //    UIColor *color2 = [UIColor colorWithRed:240.0f/255.0f green:240.0f/255.0f blue:240.0f/255.0f alpha:0.5];
    //
    //    //    grad.colors = [NSArray arrayWithObjects:(id)[[UIColor whiteColor] CGColor], (id)[[UIColor greenColor] CGColor], nil];
    //    [grad setColors:[NSArray arrayWithObjects:(id)color1.CGColor, (id)color2.CGColor, nil]];
    //
    //    grad.cornerRadius = 5.0;
    //
    //    [cell setBackgroundView:[[UIView alloc] init]];
    //    [cell.backgroundView.layer insertSublayer:grad atIndex:0];
    
    cell.delegate = self;
    
    return cell;
}


#pragma mark - delegate method
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    EventViewController* controller = (EventViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventViewController"];
    [[NSUserDefaults standardUserDefaults] setObject:[[[allRecordArray objectAtIndex:indexPath.row] objectAtIndex:0] valueForKey:@"id"] forKey:kEventId];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self.navigationController pushViewController:controller animated:YES];
    
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)aTableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewCellEditingStyleNone;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if(isSearchAndDelete==true || isSelectAllPressed==true)
        return;
    if ([self.selectedRows containsObject:indexPath]) {
        [self.selectedRows removeObject:indexPath];
        [selectedContacts removeObject:nameArray[indexPath.row]];
    }
    
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UIRefreshControl Selector

- (void)toggleCells:(UIRefreshControl*)refreshControl
{
    [refreshControl beginRefreshing];
    self.useCustomCells = !self.useCustomCells;
    
    if (self.useCustomCells)
    {
        self.refreshControl.tintColor = [UIColor redColor];
    }
    else
    {
        self.refreshControl.tintColor = [UIColor blueColor];
        [self showProgressHud];
        
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        [self showProgressHud];
        [dataDictionary setObject:userid forKey:@"user_id"];
        
        [[WebService sharedWebService] callgetListOfTimeline:dataDictionary];
    }
    [refreshControl endRefreshing];
}
////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}


#pragma mark -
#pragma mark - tabBarButtonsPressed
#pragma mark -
- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
- (IBAction)btnNewEventClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    EditEventsViewController* controller = (EditEventsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editEventsViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}


#pragma mark - WebService
#pragma mark -
- (void) getListOfTimelineSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"message"]];
    
    NSArray *responseDataArray = [dictionary objectForKey:@"data"];
    
    NSDictionary *dict;
    [nameArray removeAllObjects];
    [allRecordArray removeAllObjects];
    NSMutableArray *individualRecordArray = [[NSMutableArray alloc] init];
    NSArray *nameArrayCountChecking;
    for (int i=0; i<responseDataArray.count; i++) {
        dict = [responseDataArray objectAtIndex:i];
        [individualRecordArray addObject:dict];
        NSString *name;
        nameArrayCountChecking = [dict valueForKey:@"title"];
        if(nameArrayCountChecking.count > 0)
        {
            name = [nameArrayCountChecking objectAtIndex:0];
        }
        else
        {
            name = [dict valueForKey:@"title"];
        }
        
        id object =  [dict valueForKey:@"title"];
        if (object == [NSNull null])
            continue;
        if([name isEqualToString:@""])
            continue;
        name = [name stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        [nameArray addObject:name];
    }
    
    allRecordArray = [individualRecordArray mutableCopy];
    
    if(allRecordArray.count>0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    }
    else{
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    
    //    searchedEmailArray = emailIdArray;
    //    searchedNameArray =  nameArray;
    
    [self.tableView reloadData];
}

- (void) getListOfTimelineFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *toastMessage =[response objectForKey:@"message"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    if([toastMessage isEqualToString:@"No data found!"])
    {
        [nameArray removeAllObjects];
        [allRecordArray removeAllObjects];
        [self.tableView reloadData];
        labelNoRecordFound.hidden=false;
    }
    
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}


#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
        
        //        navigationController.viewControllers = @[secondViewController];
        
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


#pragma mark - SWTableViewDelegate

- (void)swipeableTableViewCell:(SWTableViewCell *)cell scrollingToState:(SWCellState)state
{
    switch (state) {
        case 0:
            NSLog(@"utility buttons closed");
            break;
        case 1:
            NSLog(@"left utility buttons open");
            break;
        case 2:
            NSLog(@"right utility buttons open");
            break;
        default:
            break;
    }
}



- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerRightUtilityButtonWithIndex:(NSInteger)index
{
    [cell hideUtilityButtonsAnimated:YES];
    
    switch (index) {
        case 0:
        {
            //            [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"IsEditEvents"];
            //            [[NSUserDefaults standardUserDefaults] synchronize];
            //
            //            EditEventsViewController* controller = (EditEventsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editEventsViewController"];
            //            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            //            [tableView reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            //            [[NSUserDefaults standardUserDefaults] setObject:[[allRecordArray objectAtIndex:cellIndexPath.row] valueForKey:@"id"] forKey:kEventId];
            //            [[NSUserDefaults standardUserDefaults] synchronize];
            //
            //            [self.navigationController pushViewController:controller animated:YES];
            
            break;
            
        }
        case 1:
        {
            //            if(isSearchAndDelete==true || isSelectAllPressed==true)
            //                return;
            //
            //            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            //
            //            NSString *str = [[allRecordArray objectAtIndex:[cellIndexPath row]] valueForKey:@"id"];
            //
            //            // Delete button was pressed
            //            [tableView reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            //
            //            NSString *repeatingOrNot = [[allRecordArray objectAtIndex:[cellIndexPath row]] valueForKey:@"cal_type"];
            //
            //
            //            if(![repeatingOrNot isEqualToString:@"single"])
            //            {
            //                [self showDeletePopUpForRepeatingInstance];
            //                swipeCellIndexPath = cellIndexPath;
            //                return;
            //            }
            //
            //            if(selectedContacts.count>0&&selectedRows.count>0){
            //                NSString *emailText = nameArray[cellIndexPath.row];
            //
            //                [selectedContacts removeObject:emailText];
            //                [self.selectedRows removeObject:cellIndexPath];
            //            }
            //
            //            NSLog(@"delete");
            //
            //            NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
            //
            //            NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
            //            [dataDictionary setObject:userid forKey:kUserId];
            //            [dataDictionary setObject:str forKey:@"id"];
            //
            //            [dataDictionary setObject:@"single" forKey:@"type"];
            //            NSUInteger objIdx = [allRecordArray indexOfObject:cellIndexPath];
            //
            //            [[WebService sharedWebService] callDeleteEventsWebService:dataDictionary];
            //
            //            [tableView setEditing:NO animated:YES];
            //
            //            if(allRecordArray.count<=0){
            //                [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
            //                labelNoRecordFound.hidden=false;
            //            }
            
            break;
        }
            
        default:
            break;
    }
    [self.tableView reloadData];
}

- (BOOL)swipeableTableViewCellShouldHideUtilityButtonsOnSwipe:(SWTableViewCell *)cell
{
    // allow just one cell's utility button to be open at once
    return YES;
}

- (BOOL)swipeableTableViewCell:(SWTableViewCell *)cell canSwipeToState:(SWCellState)state
{
    switch (state) {
        case 1:
            // set to NO to disable all left utility buttons appearings
            return YES;
            break;
        case 2:
            // set to NO to disable all right utility buttons appearing
            return YES;
            break;
        default:
            break;
    }
    
    return YES;
}

- (NSArray *)rightButtons
{
    NSMutableArray *rightUtilityButtons = [NSMutableArray new];
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:0.0f green:1 blue:0.0f alpha:1.0]
                                                title:@"Edit"];
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:1.0f green:0.231f blue:0.188 alpha:1.0f]
                                                title:@"Delete"];
    
    
    return rightUtilityButtons;
}



@end
