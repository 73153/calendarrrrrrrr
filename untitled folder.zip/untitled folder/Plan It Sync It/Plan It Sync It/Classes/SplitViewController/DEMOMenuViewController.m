//
//  DEMOMenuViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 18/3/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "DEMOMenuViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "EventsListViewController.h"
#import "UIViewController+REFrostedViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"

#import "NotificationViewController.h"
#import "ToDoViewController.h"
#import "InboxMessageViewController.h"
#import "YearViewController.h"
#import "ToDoViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "Base64.h"
#import "UIImage+fixOrientation.h"
#import "RoasterListingViewController.h"
#import "SchoolListViewController.h"
#import "UIImage+Helpers.h"
#import "RosterWeekListViewController.h"
@interface DEMOMenuViewController ()
{
    NSDictionary *animals;
    NSArray *animalSectionTitles;
    NSString *imageStringAfterCrop;
    UILabel *labelName;
    
}
@property (nonatomic) UIImagePickerController *imagePickerController;

@end

@implementation DEMOMenuViewController
@synthesize userDetailDict;
@synthesize checkForTableEntries;
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self hideProgressHud];
    
    [self setTitle:@"Calendar"];
    
    int height = self.navigationController.navigationBar.frame.size.height;
    int width = self.navigationController.navigationBar.frame.size.width;
    
    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    [navLabel setText:@"Calendar"];
    navLabel.textColor = [UIColor whiteColor];
    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    navLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = navLabel;
    
    self.tableView.separatorColor = [UIColor colorWithRed:150/255.0f green:161/255.0f blue:177/255.0f alpha:1.0f];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.opaque = NO;
    
    userDetailDict = [[NSMutableDictionary alloc] init];
    
    userDetailDict = [[NSUserDefaults standardUserDefaults] objectForKey:kProfileData];
    
    NSArray *employeeArray = [userDetailDict objectForKey:@"employee"];
    NSArray *schoolArray = [userDetailDict objectForKey:@"school_parent"];
    
    if(employeeArray.count>0 && schoolArray.count>0){
        checkForTableEntries=@"3";
        animals = @{
                    @"" : @[@""],
                    @"Personal" : @[@"Events", @"Contacts"],
                    @"Business" : @[@"My Roster", @"My Availablity"],
                    @"School" : @[@"Interview (PTI)"],
                    @"User Settings" : @[@"Profile", @"Preferences", @"Logout"],
                    };
        animalSectionTitles = @[@"",@"Personal", @"Business", @"School", @"User Settings"];
    }
    
    else if(employeeArray.count>0)
    {
        checkForTableEntries=@"2";
        animals = @{
                    @"" : @[@""],
                    @"Personal" : @[@"Events", @"Contacts"],
                    @"Business" : @[@"My Roster", @"My Availablity"],
                    @"User Settings" : @[@"Profile", @"Preferences", @"Logout"],
                    };
        animalSectionTitles = @[@"",@"Personal", @"Business", @"User Settings"];
    }
    else if(schoolArray.count>0)
    {
        checkForTableEntries=@"1";
        
        animals = @{
                    @"" : @[@""],
                    @"Personal" : @[@"Events", @"Contacts"],
                    @"School" : @[@"Interview (PTI)"],
                    @"User Settings" : @[@"Profile", @"Preferences", @"Logout"],
                    };
        animalSectionTitles = @[@"",@"Personal", @"School", @"User Settings"];
    }
    else{
        animals = @{
                    @"" : @[@""],
                    @"Personal" : @[@"Events", @"Contacts"],
                    @"User Settings" : @[@"Profile", @"Preferences", @"Logout"],
                    };
        animalSectionTitles = @[@"",@"Personal", @"User Settings"];
        checkForTableEntries=@"0";
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSString *userName = [[NSUserDefaults standardUserDefaults] objectForKey:kUserNameInMasterTable];
    
    self.tableView.tableHeaderView = ({
        
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(300, 200, 300, 20.0f)];
        imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 16, 55, 55)];
        imageView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        NSString *imgURL=[userDetailDict objectForKey:@"user_image"];
        if(![imgURL isEqualToString:@""] && ![imgURL isEqualToString:nil]){
            [[NSUserDefaults standardUserDefaults] setValue:imgURL forKey:kUserImage];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [UIImage loadFromURL:[NSURL URLWithString:imgURL] callback:^(UIImage *image){
                imageView.image = image;
            }];
        }
        else
        {
            imageView.image = [UIImage imageNamed:@"profile.png"];
        }
        
        imageView.layer.masksToBounds = YES;
        imageView.layer.cornerRadius = 10.0;
        imageView.layer.borderColor = [UIColor whiteColor].CGColor;
        imageView.layer.borderWidth = 3.0f;
        imageView.layer.rasterizationScale = [UIScreen mainScreen].scale;
        imageView.layer.shouldRasterize = YES;
        imageView.clipsToBounds = YES;

        labelName = [[UILabel alloc] initWithFrame:CGRectMake(67,13, 200, 60)];
        
        labelName.text = userName;
        labelName.backgroundColor = [UIColor clearColor];
        labelName.textColor = [UIColor colorWithRed:(62/255.0f) green:(68/255.0f) blue:(75/255.0f) alpha:1.0f];
//        [labelName sizeToFit];
        labelName.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        labelName.font = [UIFont fontWithName:@"OpenSans-Semibold" size:24];
        
        [view addSubview:imageView];
        [view addSubview:labelName];
        view;
    });
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getdetailForMasterTableSuccess:) name:kGetUserProfileForMasterTableSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getdetailForMasterTableFailed:) name:kGetUserProfileForMasterTableFailed object:nil];
    
    if(userDetailDict.count<=0)
    {
        [self showProgressHud];
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        [dataDictionary setObject:userid forKey:@"userid"];
        [[WebService sharedWebService] callgetdetailForMasterTable:dataDictionary];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userImageChagedSuccess:) name:@"KuserImageChagedSuccess" object:nil];
    
}

-(void)userImageChagedSuccess:(NSNotification *)notification
{
    NSString *userImage = [[NSUserDefaults standardUserDefaults] valueForKey:kUserImage];
    if(![userImage isEqualToString:@""] && ![userImage isEqualToString:nil]){
        
        imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString: userImage]]];
    }
    else{
        imageView.image = [UIImage imageNamed:@"profile.png"];
    }
}

-(void)viewDidAppear:(BOOL)animated
{
    NSString *userName = [[NSUserDefaults standardUserDefaults] objectForKey:kUserNameInMasterTable];
    if(userName.length>10){
        labelName.lineBreakMode=YES;
        labelName.numberOfLines=2;
    }
    labelName.text=userName;
}
-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)customizeTabBarForController:(RDVTabBarController *)tabBarController {
    UIImage *finishedImage = [UIImage imageNamed:@"tabbar_selected_background"];
    UIImage *unfinishedImage = [UIImage imageNamed:@"tabbar_normal_background"];
    NSArray *tabBarItemImages = @[@"first", @"second", @"third"];
    
    NSInteger index = 0;
    for (RDVTabBarItem *item in [[tabBarController tabBar] items]) {
        [item setBackgroundSelectedImage:finishedImage withUnselectedImage:unfinishedImage];
        //        UIImage *selectedimage = [UIImage imageNamed:[NSString stringWithFormat:@"%@_selected",
        //                                                      [tabBarItemImages objectAtIndex:index]]];
        //        UIImage *unselectedimage = [UIImage imageNamed:[NSString stringWithFormat:@"%@_normal",
        //                                                        [tabBarItemImages objectAtIndex:index]]];
        //        [item setFinishedSelectedImage:selectedimage withFinishedUnselectedImage:unselectedimage];
        
        index++;
    }
}
-(void)buttonPressed
{
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.modalPresentationStyle = UIModalPresentationCurrentContext;
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePickerController.delegate = self;
    self.imagePickerController = imagePickerController;
    [self presentViewController:self.imagePickerController animated:YES completion:nil];
}
#pragma mark -
#pragma mark UITableView Delegate



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [animalSectionTitles count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    NSString *sectionTitle = [animalSectionTitles objectAtIndex:section];
    NSArray *sectionAnimals = [animals objectForKey:sectionTitle];
    return [sectionAnimals count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    
    return [animalSectionTitles objectAtIndex:section];
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
    return [animalSectionTitles indexOfObject:title];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.backgroundColor = [UIColor clearColor];
    cell.textLabel.textColor = [UIColor colorWithRed:62/255.0f green:68/255.0f blue:75/255.0f alpha:1.0f];
    cell.textLabel.font = [UIFont fontWithName:@"OpenSans-Semibold.ttf" size:18];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)sectionIndex
{
    if (sectionIndex == 0)
    {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0,0, 0)];
        return view;
    }
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 34)];
    if(sectionIndex==1)
        view.backgroundColor = [UIColor colorWithRed:(34/255.0f) green:(139/255.0f) blue:(34/255.0f) alpha:1];
    else if(sectionIndex==2 && ([checkForTableEntries isEqualToString:@"1"] || [checkForTableEntries isEqualToString:@"2"] || [checkForTableEntries isEqualToString:@"3"]))
        view.backgroundColor = [UIColor colorWithRed:(255/255.0f) green:(127/255.0f) blue:(36/255.0f)  alpha:1];
    else if ([checkForTableEntries isEqualToString:@"0"])
        view.backgroundColor = [UIColor colorWithRed:(34/255.0f) green:(139/255.0f) blue:(34/255.0f)  alpha:1];
    else if(sectionIndex==3 && [checkForTableEntries isEqualToString:@"3"])
        view.backgroundColor = [UIColor colorWithRed:(255/255.0f) green:(127/255.0f) blue:(36/255.0f) alpha:1];
    else if(sectionIndex==3 && [checkForTableEntries isEqualToString:@"1"])
        view.backgroundColor = [UIColor colorWithRed:(34/255.0f) green:(139/255.0f) blue:(34/255.0f)  alpha:1];
    else if([checkForTableEntries isEqualToString:@"2"] || [checkForTableEntries isEqualToString:@"3"])
        view.backgroundColor = [UIColor colorWithRed:(34/255.0f) green:(139/255.0f) blue:(34/255.0f)  alpha:1];
    
    else if(sectionIndex==4)
        view.backgroundColor = [UIColor colorWithRed:(34/255.0f) green:(139/255.0f) blue:(34/255.0f)  alpha:1];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(25, 5, 0, 0)];
    label.text = [animalSectionTitles objectAtIndex:sectionIndex];

    label.textColor = [UIColor whiteColor];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont fontWithName:@"OpenSans-Semibold" size:22];
    [label sizeToFit];
    [view addSubview:label];
    
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)sectionIndex
{
    if (sectionIndex == 0)
        return 0;
    
    return 40;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    UINavigationController *navigationController = (UINavigationController *)self.frostedViewController.contentViewController;
    NSLog(@"indexPath.section == %ld && indexPath.row == %ld",(long)indexPath.section,(long)indexPath.row);
    [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"BlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    switch (indexPath.section) {
        case 1:
            if(indexPath.row==0)
            {
                [self changeToEventsListViewController:navigationController];
            }
            else if (indexPath.row==1)
            {
                [self changeToContactsViewController:navigationController];
                
            }
            else if (indexPath.row==2)
            {
                [self changeToContactsViewController:navigationController];
            }
            break;
        case 2:
            if([checkForTableEntries isEqualToString:@"2"] || [checkForTableEntries isEqualToString:@"3"]){
                if(indexPath.row==0)
                {
                    [self changeToRosterWeekListViewController:navigationController];
                }
                else if (indexPath.row==1)
                {
                    [self changeToRoasterListingViewController:navigationController];
                }
            }
            else if([checkForTableEntries isEqualToString:@"1"])
            {
                /*SCHOOL*/
                [self changeToSchoolListViewController:navigationController];
                
            }
            else
            {
                if(indexPath.row==0)
                {
                    [self changeToProfileViewController:navigationController];
                }
                else if (indexPath.row==1)
                {
                    [self changeToPreferenceViewController:navigationController];
                }
                else if (indexPath.row==2)
                {
                    [self logOutButttonClicked];
                }
            }
            break;
        case 3:
            if([checkForTableEntries isEqualToString:@"3"]){
                if(indexPath.row==0)
                {
                    /*SCHOOL*/
                    [self changeToSchoolListViewController:navigationController];
                }
            }
            else if([checkForTableEntries isEqualToString:@"2"] ||[checkForTableEntries isEqualToString:@"1"])
            {
                if(indexPath.row==0)
                {
                    [self changeToProfileViewController:navigationController];
                }
                else if (indexPath.row==1)
                {
                    [self changeToPreferenceViewController:navigationController];
                    
                }
                else if (indexPath.row==2)
                {
                    [self logOutButttonClicked];
                }
            }
            
            break;
        case 4:
            if(indexPath.row==0)
            {
                [self changeToProfileViewController:navigationController];
            }
            else if (indexPath.row==1)
            {
                [self changeToPreferenceViewController:navigationController];
                
            }
            else if (indexPath.row==2)
            {
                
                [self logOutButttonClicked];
            }
            break;
        default:
            break;
    }
    [self.frostedViewController hideMenuViewController];
}

-(void)changeToRosterWeekListViewController:(UINavigationController *)navigationController{
    RosterWeekListViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"rosterWeekListViewController"];
    [navigationController pushViewController:secondViewController animated:YES];
}


-(void)changeToProfileViewController:(UINavigationController *)navigationController{
    ProfileViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"profileViewController"];
    [navigationController pushViewController:secondViewController animated:YES];
}

-(void)changeToPreferenceViewController:(UINavigationController *)navigationController{
    PreferenceViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"preferenceViewController"];
    [navigationController pushViewController:secondViewController animated:YES];
}

-(void)changeToContactsViewController:(UINavigationController *)navigationController{
    ContactsViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
    [navigationController pushViewController:secondViewController animated:YES];
}

-(void)changeToInboxMessageViewController:(UINavigationController *)navigationController{
    InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
    [navigationController pushViewController:secondViewController animated:YES];
}

-(void)changeToSchoolListViewController:(UINavigationController *)navigationController{
    SchoolListViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"schoolListViewController"];
    [navigationController pushViewController:secondViewController animated:YES];
}

-(void)changeToRoasterListingViewController:(UINavigationController *)navigationController{
    RoasterListingViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"roasterListingViewController"];
    [navigationController pushViewController:secondViewController animated:YES];
}
-(void)changeToEventsListViewController:(UINavigationController *)navigationController{
    EventsListViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"eventsListViewController"];
    [navigationController pushViewController:homeViewController animated:YES];
}
-(void)logOutButttonClicked{
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:kUserMobileNumber];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kUserNameInMasterTable];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kEventRSVPPriorTime];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:KTimeFormat];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kEventId];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kUserId];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kUserImage];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kUserName];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kUserNameInMasterTable];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kBoidId];
    //    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"logged_in"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
#pragma mark -
#pragma mark UITableView Datasource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
//{
//    return 1;
//}
//
//- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
//{
//    return 7;
//}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.separatorInset = UIEdgeInsetsMake(cell.bounds.size.width,0.5, 0.f, 0.f);
    
    NSString *sectionTitle = [animalSectionTitles objectAtIndex:indexPath.section];
    NSArray *sectionAnimals = [animals objectForKey:sectionTitle];
    NSString *animal = [sectionAnimals objectAtIndex:indexPath.row];
    
    NSString* imageName;
    UIImageView *thumbnail;
    if (thumbnail == nil) {
        thumbnail = [[UIImageView alloc]init] ;
    }
    
    switch (indexPath.section) {
        case 1:
            if(indexPath.row==0)
            {
                imageName = @"events_active@2x.png";
                [thumbnail setImage:[UIImage imageNamed:imageName]];
            }
            else if (indexPath.row==1)
            {
                imageName = @"message_active_SideBar@2x.png";
                [thumbnail setImage:[UIImage imageNamed:imageName]];
            }
            else if (indexPath.row==2)
            {
                imageName = @"contact_active@2x.png";
                [thumbnail setImage:[UIImage imageNamed:imageName]];
            }
            break;
        case 2:
            if([checkForTableEntries isEqualToString:@"2"] || [checkForTableEntries isEqualToString:@"3"]){
                if(indexPath.row==0)
                {
                    imageName = @"my_roster@2x.png";
                    [thumbnail setImage:[UIImage imageNamed:imageName]];
                }
                else if (indexPath.row==1)
                {
                    imageName = @"my_availability@2x.png";
                    [thumbnail setImage:[UIImage imageNamed:imageName]];
                }
            }
            else if([checkForTableEntries isEqualToString:@"1"])
            {
                imageName = @"appointments_active@2x.png";
                [thumbnail setImage:[UIImage imageNamed:imageName]];
            }
            else if([checkForTableEntries isEqualToString:@"0"])
            {
                if(indexPath.row==0)
                {
                    imageName = @"profile_active@2x.png";
                    [thumbnail setImage:[UIImage imageNamed:imageName]];
                }
                else if (indexPath.row==1)
                {
                    imageName = @"preference_active@2x.png";
                    [thumbnail setImage:[UIImage imageNamed:imageName]];
                }
                else if (indexPath.row==2)
                {
                    imageName = @"logout_active@2x.png";
                    [thumbnail setImage:[UIImage imageNamed:imageName]];
                }
            }
            break;
        case 3:
            if([checkForTableEntries isEqualToString:@"3"]){
                
                if(indexPath.row==0)
                {
                    imageName = @"appointments_active@2x.png";
                    [thumbnail setImage:[UIImage imageNamed:imageName]];
                }
            }
            else if([checkForTableEntries isEqualToString:@"2"] ||[checkForTableEntries isEqualToString:@"1"])
            {
                if(indexPath.row==0)
                {
                    imageName = @"profile_active@2x.png";
                    [thumbnail setImage:[UIImage imageNamed:imageName]];
                }
                else if (indexPath.row==1)
                {
                    imageName = @"preference_active@2x.png";
                    [thumbnail setImage:[UIImage imageNamed:imageName]];
                }
                else if (indexPath.row==2)
                {
                    imageName = @"logout_active@2x.png";
                    [thumbnail setImage:[UIImage imageNamed:imageName]];
                }
            }
            
            break;
        case 4:
            if(indexPath.row==0)
            {
                imageName = @"profile_active@2x.png";
                [thumbnail setImage:[UIImage imageNamed:imageName]];
            }
            else if (indexPath.row==1)
            {
                imageName = @"preference_active@2x.png";
                [thumbnail setImage:[UIImage imageNamed:imageName]];
            }
            else if (indexPath.row==2)
            {
                imageName = @"logout_active@2x.png";
                [thumbnail setImage:[UIImage imageNamed:imageName]];
            }
            break;
        default:
            break;
    }
    if(indexPath.section==0){
        thumbnail=nil;
    }
    CGSize itemSize = CGSizeMake(25, 25);
    
    [thumbnail setFrame:CGRectMake(0.0, 0.0, itemSize.width, itemSize.height)];
    //    UIGraphicsBeginImageContext(itemSize);
    //    CGRect imageRect = CGRectMake(0.0, 0.0, itemSize.width, itemSize.height);
    //    [thumbnail drawInRect:imageRect];
    cell.imageView.image = thumbnail.image;
    //    cell.imageView.image.frame = CGRectMake(0.0, 0.0, itemSize.width, itemSize.height);
    
    //    UIGraphicsEndImageContext();
    cell.textLabel.text = animal;
    
    return cell;
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
    
    
#ifdef DEV_ENVIRONMENT
    NSLog (@"Image Size, %f, %f", originalImage.size.width, originalImage.size.height
           );
#endif
    
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        [self openCropEditor:[[UIImage memoryOptimizedImageWithImage:image] fixOrientation]];
    }];
}

#pragma mark photo cropper
-(void) openCropEditor:(UIImage *) image {
    PECropViewController *controller = [[PECropViewController alloc] init];
    controller.delegate = self;
    controller.image = image;
    controller.cropAspectRatio = 1;
    
    controller.keepingCropAspectRatio = YES;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:controller];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        navigationController.modalPresentationStyle = UIModalPresentationFormSheet;
    }
    
    [self presentViewController:navigationController animated:YES completion:NULL];
}

- (void)cropViewController:(PECropViewController *)controller didFinishCroppingImage:(UIImage *)croppedImage {
    
    [controller dismissViewControllerAnimated:YES completion:NULL];
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    [imageView setImage:croppedImage];
    CGSize imageViewSize = imageView.frame.size;
    
    UIGraphicsBeginImageContext(imageViewSize);
    [croppedImage drawInRect:CGRectMake(0,0,imageViewSize.width,imageViewSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:@"userid"];
    NSData *imageData = UIImageJPEGRepresentation(newImage, 1);
    [dataDictionary setObject:[Base64 encode:imageData] forKey:@"image"];
    [self showProgressHud];
    [[WebService sharedWebService] callUpdateUserImageWebService:dataDictionary];
}
//lowering the image quality
- (void)encodePhotoInBackground:(UIImage*)image {
    //    NSData *imageData = UIImageJPEGRepresentation(image, 0.5);
    //    [self performSelectorOnMainThread:@selector(saveImageData:) withObject:imageData waitUntilDone:NO];
}

//saving image data
- (void)saveImageData:(NSData*)imageData2 {
    // Do something with the image
    //image byte array
    
    [Base64 initialize];
    NSString *strEncoded = [Base64 encode:imageData2];
    NSString * loginString = [NSString stringWithFormat:@"%@%@",imageStringAfterCrop,strEncoded];
    imageStringAfterCrop=@"";
    imageStringAfterCrop=loginString;
}

- (void) getdetailForMasterTableSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSDictionary *maiDict = [dictionary objectForKey:@"data"];
    
    NSDictionary *profileDataDict = [maiDict objectForKey:@"user_profile"];
    
    [[NSUserDefaults standardUserDefaults] setObject:profileDataDict forKey:kProfileData];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    labelName.text = [profileDataDict objectForKey:@"name"];
    
    NSString *imgURL=[profileDataDict objectForKey:@"user_image"];
    if(![imgURL isEqualToString:@""] && ![imgURL isEqualToString:nil]){
        [[NSUserDefaults standardUserDefaults] setValue:imgURL forKey:kUserImage];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [UIImage loadFromURL:[NSURL URLWithString:imgURL] callback:^(UIImage *image){
            imageView.image = image;
        }];
    }
    
    [[NSUserDefaults standardUserDefaults] setValue:[profileDataDict objectForKey:@"mobile"] forKey:kUserMobileNumber];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}

-(void)getdetailForMasterTableFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"message"]];
}
////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}


@end
