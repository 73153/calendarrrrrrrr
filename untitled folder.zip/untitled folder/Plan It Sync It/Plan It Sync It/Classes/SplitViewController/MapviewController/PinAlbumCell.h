//
//  PinAlbumCell.h
//  PlanWithMap
//
//  Created by Christine on 2014/2/22.
//  Copyright (c) 2014年 Christine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PinAlbumCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@end
