//
//  LocationImageData.m
//  PlanWithMap
//
//  Created by Christine on 2014/3/15.
//  Copyright (c) 2014年 Christine. All rights reserved.
//

#import "LocationImageData.h"
#import "AnnotationData.h"


@implementation LocationImageData

@dynamic imageURL;
@dynamic belongto;

@end
