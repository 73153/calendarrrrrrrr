//
//  MapViewController.h
//
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

//#import "AppDelegate.h"
#import "myAnnotation.h"
#import "myPinAnnotationView.h"
#import "AnnotationData.h"

@interface MapViewController : UIViewController <MKMapViewDelegate, CLLocationManagerDelegate, UITableViewDataSource, UITableViewDelegate, UINavigationControllerDelegate, UISearchBarDelegate>
{
//    NSManagedObjectContext *managedObjectContext;
    NSMutableDictionary *tableSectionDict;
    NSMutableArray *tableSectionOrder;
    myAnnotation *tempAnnotation;
    AnnotationData *dragedAnnotation;
    NSLocale *dateLocale;
    BOOL searchButton;
}

@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
- (IBAction)tabBarButtonsPressed:(id)sender;

@property (strong, nonatomic) IBOutlet MKLocalSearch *localSearch;
@property (strong, nonatomic) IBOutlet UISearchBar *localSearchBar;
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UITableView *pinTableView;
@property (weak, nonatomic) IBOutlet UIButton *deleteButton;
@property (weak, nonatomic) IBOutlet UIButton *addButton;
@property (weak, nonatomic) NSString *locationName;
- (IBAction)btnBackClicked:(id)sender;

//@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, strong) myAnnotation *EdittedAnnotation;
@property (nonatomic, strong) NSArray *foundPlaces;
@property (nonatomic, strong) NSMutableArray *searchResult;

- (IBAction)AddPinLongPressGesture:(UILongPressGestureRecognizer *)sender;
- (IBAction)DeleteAnnotation:(id)sender;
- (IBAction)AddAnnotation:(id)sender;
- (IBAction)getUserLocatioin:(id)sender;
- (IBAction)hideSearchBar:(id)sender;
- (IBAction)showSearchBar:(id)sender;


//-(void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control;
//-(void)DeleteAllAnnotationData:(NSArray *)fetchResults;
@end
