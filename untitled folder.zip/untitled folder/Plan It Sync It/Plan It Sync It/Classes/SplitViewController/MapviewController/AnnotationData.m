//
//  AnnotationData.m
//  PlanWithMap
//
//  Created by Christine on 2014/3/15.
//  Copyright (c) 2014年 Christine. All rights reserved.
//

#import "AnnotationData.h"
#import "LocationImageData.h"


@implementation AnnotationData

@dynamic annotationType;
@dynamic date;
@dynamic locationImageURL;
@dynamic information;
@dynamic latitude;
@dynamic locationAddr;
@dynamic locationName;
@dynamic longitude;
@dynamic own;

@end
