//
//  EditContactsViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 18/3/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
#import "HPGrowingTextView.h"
@interface EditContactsViewController : UIViewController<CustomKeyboardDelegate,UITextFieldDelegate,UITextViewDelegate,HPGrowingTextViewDelegate>
{
    CustomKeyboard *customKeyboard;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (nonatomic, strong) NSDictionary *userDetailDict;

@property (nonatomic, strong) NSString *currentItemString;
@property (nonatomic) int currentItem;
@property (nonatomic, strong) NSIndexPath* checkedIndexPath;
@property (nonatomic, strong) NSMutableArray *filteredCountries;
@property (assign) BOOL isFiltered;
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) NSDate *selectedDate;

@property (nonatomic) BOOL useCustomCells;
@property (nonatomic, weak) UIRefreshControl *refreshControl;
@property (nonatomic, strong) IBOutlet UITextField *txtName;
@property (nonatomic, strong) IBOutlet UITextField *txtEmailId;
@property (nonatomic, strong) IBOutlet UILabel  *lblDate;

@property (nonatomic, strong) IBOutlet UITextView *txtNote;
@property (nonatomic, strong) IBOutlet UIView *pickerBackGroundView;
@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarCancel;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarDone;
@property (weak, nonatomic) IBOutlet UIButton *btnDOB;

@property (nonatomic, strong) IBOutlet UITextField *txtContact;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) IBOutlet UIButton *roundedBtnbtnSave;
@property (weak, nonatomic) IBOutlet UIImageView *profileImage;
- (IBAction)tabBarButtonsPressed:(id)sender;

- (IBAction)btnSaveItPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnDobPressed:(id)sender;
- (IBAction)btnEditProfleClicked:(id)sender;
- (IBAction)btnClearDateFieldPressed:(id)sender;


- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;

- (void) showProgressHud;
- (void) hideProgressHud;
- (void) updateContactSuccess:(NSNotification *)notification;
- (void) updateContactFailed:(NSNotification *)notification;

- (void) insertNewContactSuccess:(NSNotification *)notification;
- (void) insertNewContactFailed:(NSNotification *)notification;
@end

