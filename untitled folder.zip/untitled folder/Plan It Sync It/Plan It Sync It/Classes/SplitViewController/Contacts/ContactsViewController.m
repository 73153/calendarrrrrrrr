//
//  ContactsViewController.m
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import "ContactsViewController.h"
#import "YearViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "ContactsViewController.h"
#import "UINavigationItem+BarButtonGrouping.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
#import "TrashMessageViewController.h"
#import "EditContactsViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "PlistUtils.h"
#import "UIImage+Helpers.h"
@interface ContactsViewController ()


@end

@implementation ContactsViewController
@synthesize tableView;
@synthesize  selectedContacts;
@synthesize totalIndaxPath;
@synthesize  emailIdArray;
@synthesize nameArray;
@synthesize deletedContactArray;
@synthesize searchedEmailArray;
@synthesize viewSelectAllAndDelete;
@synthesize selectedData;
@synthesize selectedRows;
@synthesize mSearchBar;
@synthesize toolBar_EditAndDelete;
//@synthesize searchedNameArray;
@synthesize btnSelectAll;
@synthesize labelNoRecordFound;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnAddContact;
@synthesize allRecordArray;
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //init data
    self.selectedRows = [NSMutableArray array];
    tableView.dataSource=self;
    tableView.delegate=self;
    mSearchBar.delegate= self;
    [self setTitle:@"Contacts"];
    
//    int height = self.navigationController.navigationBar.frame.size.height;
//    int width = self.navigationController.navigationBar.frame.size.width;
//    
//    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
//    [navLabel setText:@"Contacts"];
//    navLabel.textColor = [UIColor whiteColor];
//    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
//    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
//    navLabel.textAlignment = NSTextAlignmentCenter;
//    self.navigationItem.titleView = navLabel;

    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationItem.titleView = titleView;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    self.tableView.rowHeight = 80;
    
    //    roundedBtnAddContact.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnAddContact.layer.borderWidth = 2.0f;
    
    roundedBtnAddContact.clipsToBounds=YES;
    roundedBtnAddContact.layer.cornerRadius = 5;
    
    labelNoRecordFound.hidden=true;
    toolBar_EditAndDelete.hidden = true;
    // Initialize Refresh Control
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    
    // Configure Refresh Control
    [refreshControl addTarget:self action:@selector(toggleCells:) forControlEvents:UIControlEventValueChanged];
    refreshControl.tintColor = [UIColor blueColor];
    
    // Configure View Controller
    [self.tableView addSubview:refreshControl];
    self.refreshControl = refreshControl;
    self.useCustomCells = NO;
    totalIndaxPath = [NSMutableArray array];
    
    
    
    isSelectAllPressed=false;
    isSearchAndDelete=false;
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllContactsListSuccess:) name:kGetAllContactsListSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllContactsListFailed:) name:kGetAllContactsListFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deleteContactSuccess:) name:kDeleteContactSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deleteContactFailed:) name:kDeleteContactFailed object:nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    // Do any additional setup after loading the view, typically from a nib.
    selectedContacts = [NSMutableArray array];
    emailIdArray= [[NSMutableArray alloc] init];
    nameArray = [[NSMutableArray alloc] init];
    allRecordArray =[[NSMutableArray alloc] init];
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:@"userid"];
    [dataDictionary setObject:@"" forKey:@"search"];
    [dataDictionary setObject:@"0" forKey:@"limit_start"];
    [dataDictionary setObject:@"30" forKey:@"limit_end"];
    
    [self showProgressHud];
    [[WebService sharedWebService] callGetAllContactsListWebService:dataDictionary];
}


-(void)viewDidUnload
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark - dataSource method
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return allRecordArray.count;
    
    
}
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"UMCell";
    UMTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    if(nameArray.count==0 || emailIdArray.count==0)
        return cell;
    if(emailIdArray.count>0)
        labelNoRecordFound.hidden=true;
    NSString *currentText;
    //Search And Without Search data
    
    //    CGFloat width = CGRectGetWidth(self.tableView.bounds);
    //    CGFloat height = CGRectGetHeight(self.tableView.bounds);
    //    UIView *container = [[UIView alloc] initWithFrame:CGRectMake(0,0,width,height)];
    //    container.layer.borderColor = [UIColor grayColor].CGColor;
    //    container.layer.borderWidth = 1.0f;
    //    CAGradientLayer *gradient = [self greyGradient];
    //    gradient.frame = container.bounds;
    //    [container.layer addSublayer:gradient];
    //    [cell addSubview:container];
    //    [container addSubview:headerLabel];
    //Gradient color for cell
    //    CAGradientLayer *gradient = [CAGradientLayer layer];
    //    gradient.frame = cell.bounds;
    //    UIColor *color1 = [UIColor colorWithRed:255.0f/255.0f green:255.0f/255.0f blue:255.0f/255.0f alpha:0.5];
    //    UIColor *color2 = [UIColor colorWithRed:240.0f/255.0f green:240.0f/255.0f blue:240.0f/255.0f alpha:0.5];
    //
    //    [gradient setColors:[NSArray arrayWithObjects:(id)color1.CGColor, (id)color2.CGColor, nil]];
    //    [cell.layer addSublayer:gradient];
    
    
    NSString *strName = [nameArray objectAtIndex:indexPath.row];
    NSString *stEmailid = [emailIdArray objectAtIndex:indexPath.row];
    
    if([strName isEqualToString:@""] || [strName isEqualToString:nil] ||[stEmailid isEqualToString:@""] )
    {
    }
    else{
        cell.label.text = stEmailid;
        cell.label1.text = strName;
    }
    
    cell.label1.lineBreakMode = NSLineBreakByWordWrapping;
    cell.label.lineBreakMode = NSLineBreakByWordWrapping;
    
    currentText = cell.label.text = emailIdArray[indexPath.row];
    cell.label1.text=[nameArray objectAtIndex:indexPath.row];
    //    cell.label1.textColor = [UIColor whiteColor];
    cell.label.lineBreakMode=YES;
    cell.label1.lineBreakMode=YES;
    //    cell.label.textColor = [UIColor whiteColor];
    
    NSString *userImage = [[allRecordArray objectAtIndex:indexPath.row] valueForKey:@"image_path"];
    if(![userImage isEqualToString:@""] && ![userImage isEqualToString:nil]){
        //        cell.userImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString: userImage]]];
        [UIImage loadFromURL:[NSURL URLWithString:userImage] callback:^(UIImage *image){
            cell.userImage.image = image;
        }];
    }
    else
    {
        [cell.userImage setImage:[UIImage imageNamed:@"user_image_default.png"]];
    }
    
    cell.userImage.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    cell.userImage.layer.masksToBounds = YES;
    cell.userImage.layer.cornerRadius = 10.0;
    cell.userImage.layer.borderColor = [UIColor whiteColor].CGColor;
    cell.userImage.layer.borderWidth = 1.0f;
    cell.userImage.clipsToBounds = YES;
    // Set the checked state for the contact selection checkbox
    UIImage *image;
    
    if ([selectedContacts containsObject:currentText]) {
        image = [UIImage imageNamed:@"check_on.png"];
    } else  {
        image = [UIImage imageNamed:@"check_off.png"];
    }
    
    [cell.checkBoxButton setImage:image forState:UIControlStateNormal];
    [cell.checkBoxButton addTarget:self action:@selector(checkButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:70.0f];
    
    //    [cell setBackgroundColor:[UIColor clearColor]];
    //
    //    CAGradientLayer *grad = [CAGradientLayer layer];
    //    grad.frame = CGRectMake(0,0,480,80);
    //    grad.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:(0/255) green:(153/255) blue:(76/255) alpha:1] CGColor], (id)[[UIColor whiteColor] CGColor], nil];
    //    grad.cornerRadius = 5.0;
    //
    //    [cell setBackgroundView:[[UIView alloc] init]];
    //    [cell.backgroundView.layer insertSublayer:grad atIndex:0];
    if (cell==Nil) {
        cell = [[UMTableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    //    [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:70.0f];
    cell.delegate = self;
    
    return cell;
    
}
- (CAGradientLayer *) greyGradient {
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.startPoint = CGPointMake(0.5, 0.0);
    gradient.endPoint = CGPointMake(0.5, 1.0);
    
    UIColor *color1 = [UIColor colorWithRed:255.0f/255.0f green:255.0f/255.0f blue:255.0f/255.0f alpha:0.5];
    UIColor *color2 = [UIColor colorWithRed:240.0f/255.0f green:240.0f/255.0f blue:240.0f/255.0f alpha:0.5];
    
    [gradient setColors:[NSArray arrayWithObjects:(id)color1.CGColor, (id)color2.CGColor, nil]];
    return gradient;
}
- (void)checkButtonTapped:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:buttonPosition];
    if (indexPath != nil)
    {
        if(isSearchAndDelete==true || isSelectAllPressed==true)
            return;
        NSString *currentText = emailIdArray[indexPath.row];
        
        //new method
        if ([selectedContacts containsObject:currentText]) {
            [selectedContacts removeObject:currentText];
            [self.selectedRows removeObject:indexPath];
            mSearchBar.hidden=false;
            toolBar_EditAndDelete.hidden=true;
        } else {
            mSearchBar.hidden=true;
            toolBar_EditAndDelete.hidden=false;
            
            [selectedContacts addObject:currentText];
            [self.selectedRows addObject:indexPath];
        }
    }
    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    
}

#pragma mark - delegate method
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"IsEditContacts"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSIndexPath *cellIndexPath = indexPath;
    
    //    NSString *emailText = emailIdArray[cellIndexPath.row];
    //    NSString *nameText = nameArray[cellIndexPath.row];
    NSDictionary *userInfoDict = nil;
    
    userInfoDict = [allRecordArray objectAtIndex:cellIndexPath.row];
    
    EditContactsViewController* controller = (EditContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editContactsViewController"];
    controller.userDetailDict =  [userInfoDict mutableCopy];
    
    [self.navigationController pushViewController:controller animated:YES];
    
}

- (IBAction)delRow:(id)sender {
    
    [self showProgressHud];
    
    [tableView reloadRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.4];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    NSMutableArray *contactIdArr = [NSMutableArray array];
    
    NSInteger count =  [selectedRows count];
    for (NSInteger i = count; i>0; i--) {
        NSIndexPath *path = [selectedRows objectAtIndex:i-1];
        
        NSString *str = [[allRecordArray objectAtIndex:path.row] valueForKey:@"contactid"];
        [contactIdArr addObject:str];
    }
    dataDictionary[@"contactid"] = contactIdArr;
    NSInteger index = count;
    for (int i=0; i<count; i++) {
        NSIndexPath *path = [selectedRows objectAtIndex:index-1];
        if([nameArray count] > 0 && [nameArray count] > path.row && index >= 0){
            [nameArray removeObjectAtIndex:path.row];
            [emailIdArray removeObjectAtIndex:path.row];
            [allRecordArray removeObjectAtIndex:path.row];
            index--;
        }
    }
    
    [[WebService sharedWebService] callDeleteContactWebService:dataDictionary];
    
    
    [tableView deleteRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    [UIView commitAnimations];
    [selectedContacts removeAllObjects];
    [self.selectedRows removeAllObjects];
    mSearchBar.hidden=false;
    toolBar_EditAndDelete.hidden=true;
    if(emailIdArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    [self.tableView reloadData];
}

- (IBAction)editRows:(id)sender {
    BOOL edit = tableView.editing;
    [tableView setEditing:!edit animated:YES];
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if(isSearchAndDelete==true || isSelectAllPressed==true)
        return;
    if ([self.selectedRows containsObject:indexPath]) {
        [self.selectedRows removeObject:indexPath];
        [selectedContacts removeObject:emailIdArray[indexPath.row]];
    }
    
    [emailIdArray removeObject:emailIdArray[indexPath.row]];
    [nameArray removeObject:nameArray[indexPath.row]];
    
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    NSLog(@"delete");
    if(emailIdArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }
    
    [tableView setEditing:NO animated:YES];
}



- (IBAction)selectAll:(id)sender {
    [self showProgressHud];
    if(isSelectAllPressed==false){
        isSelectAllPressed=true;
        btnSelectAll.title = @"Un Select All";
        [selectedContacts removeAllObjects];
        [selectedRows removeAllObjects];
        [allRecordArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            NSString *currentText = emailIdArray[idx];
            [selectedContacts addObject:currentText];
            NSIndexPath *path = [NSIndexPath indexPathForRow:idx inSection:0];
            [selectedRows addObject:path];
            [tableView reloadRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationAutomatic];
            
        }];
    }
    else
    {
        isSearchAndDelete=false;
        isSelectAllPressed=false;
        btnSelectAll.title = @"Select All";
        toolBar_EditAndDelete.hidden=true;
        mSearchBar.hidden=false;
        [selectedContacts removeAllObjects];
        [selectedRows removeAllObjects];
        [tableView reloadData];
    }
    [self hideProgressHud];
    
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UIRefreshControl Selector

- (void)toggleCells:(UIRefreshControl*)refreshControl
{
    [refreshControl beginRefreshing];
    self.useCustomCells = !self.useCustomCells;
    
    if (self.useCustomCells)
    {
        self.refreshControl.tintColor = [UIColor redColor];
    }
    else
    {
        self.refreshControl.tintColor = [UIColor blueColor];
        
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        [dataDictionary setObject:userid forKey:@"userid"];
        [dataDictionary setObject:@"" forKey:@"search"];
        [dataDictionary setObject:@"0" forKey:@"limit_start"];
        [dataDictionary setObject:@"30" forKey:@"limit_end"];
        
        [self showProgressHud];
        [[WebService sharedWebService] callGetAllContactsListWebService:dataDictionary];
        
    }
    [self.tableView reloadData];
    [refreshControl endRefreshing];
}

////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}

#pragma mark -
#pragma mark - tabBarButtonsPressed
#pragma mark -
- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
- (IBAction)btnEditContactClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditContacts"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    EditContactsViewController* controller = (EditContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editContactsViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - Search Functionality

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    isSearchAndDelete=true;
    [mSearchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    [mSearchBar setShowsCancelButton:NO animated:YES];
    //    [self showProgressHud];
    //    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    //    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    [dataDictionary setObject:userid forKey:@"userid"];
    //    [dataDictionary setObject:@"" forKey:@"search"];
    //    [dataDictionary setObject:@"0" forKey:@"limit_start"];
    //    [dataDictionary setObject:@"30" forKey:@"limit_end"];
    //    [[WebService sharedWebService] callGetAllContactsListWebService:dataDictionary];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchText.length>0) {
        searchText = [searchText stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSLog(@"its pincode");
        
        //        NSPredicate *predicate = [NSPredicate predicateWithFormat: @"SELF CONTAINS[cd] %@", searchText ];
        //        searchedNameArray = [NSMutableArray arrayWithArray:[nameArray filteredArrayUsingPredicate:predicate]];
        //
        //        for (int i=0; i< allRecordArray.count; i++) {
        //            NSString *strAllRecordSearchName = [[allRecordArray objectAtIndex:i] valueForKey:@"name"];
        //            for (int j=0; j<searchedNameArray.count; j++) {
        //                NSString *strName = [searchedNameArray objectAtIndex:j];
        //                if([strAllRecordSearchName isEqualToString:strName]){
        //                    NSString *str = [[allRecordArray objectAtIndex:i] valueForKey:@"email"];
        //                    [searchedEmailArray addObject:str];
        //                    break;
        //                }
        //            }
        //        }
        //        if(searchedNameArray.count==0)
        //            [searchedEmailArray removeAllObjects];
        //
        //        //        NSPredicate *predicate1 = [NSPredicate predicateWithFormat: @"SELF CONTAINS[cd] %@", searchText ];
        //        //        searchedNameArray = [NSMutableArray arrayWithArray:[nameArray filteredArrayUsingPredicate:predicate1]];
        //        //        searchedEmailArray = emailIdArray;
        //
        //        [tableView reloadData];
    }
    else
    {
        [self showProgressHud];
        NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        [dataDictionary setObject:userid forKey:@"userid"];
        [dataDictionary setObject:@"" forKey:@"search"];
        [dataDictionary setObject:@"0" forKey:@"limit_start"];
        [dataDictionary setObject:@"30" forKey:@"limit_end"];
        [[WebService sharedWebService] callGetAllContactsListWebService:dataDictionary];
        
    }
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    isSearchAndDelete=false;
    [mSearchBar resignFirstResponder];
    
    [nameArray removeAllObjects];
    [allRecordArray removeAllObjects];
    [selectedContacts removeAllObjects];
    [emailIdArray removeAllObjects];
    
    [self  showProgressHud];
    NSString *serachedText = mSearchBar.text;
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:@"userid"];
    [dataDictionary setObject:serachedText forKey:@"search"];
    [dataDictionary setObject:@"0" forKey:@"limit_start"];
    [dataDictionary setObject:@"30" forKey:@"limit_end"];
    [[WebService sharedWebService] callGetAllContactsListWebService:dataDictionary];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    isSearchAndDelete=false;
    [mSearchBar resignFirstResponder];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:@"userid"];
    [dataDictionary setObject:@"" forKey:@"search"];
    [dataDictionary setObject:@"0" forKey:@"limit_start"];
    [dataDictionary setObject:@"30" forKey:@"limit_end"];
    [[WebService sharedWebService] callGetAllContactsListWebService:dataDictionary];
    //    searchedEmailArray=emailIdArray;
    [tableView reloadData];
}


#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

#pragma mark -
#pragma mark - WebService
#pragma mark -
- (void) getAllContactsListSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"message"]];
    
    NSArray *responseDataArray = [dictionary objectForKey:@"data"];
    
    NSDictionary *dict;
    NSArray *individualRecordArray;
    [nameArray removeAllObjects];
    [emailIdArray removeAllObjects];
    [allRecordArray removeAllObjects];
    
    individualRecordArray = [responseDataArray valueForKey:@"contacts"];
    allRecordArray = [individualRecordArray mutableCopy];
    
    for (int i=0; i<individualRecordArray.count; i++) {
        dict = [individualRecordArray objectAtIndex:i];
        
        NSString *name = [dict valueForKey:@"name"];
        NSString *emailId = [dict valueForKey:@"email"];
        [nameArray addObject:name];
        [emailIdArray addObject:emailId];
    }
    
    [self.tableView reloadData];
    if(emailIdArray.count>0){
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        labelNoRecordFound.hidden=true;
    }
    else{
        [self.tableView reloadData];
        labelNoRecordFound.hidden=false;
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    }
    
    
}

- (void) getAllContactsListFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    
    NSString *toastMessage =[response objectForKey:@"message"];
    if([toastMessage isEqualToString:@"Contact(s) not found"]){
        [self.view makeToast:toastMessage];
        [selectedContacts removeAllObjects];
        [nameArray removeAllObjects];
        [emailIdArray removeAllObjects];
        [allRecordArray removeAllObjects];
        [self.tableView reloadData];
        labelNoRecordFound.hidden=false;
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        
    }
    //    [self.tableView reloadData];
}

- (void) deleteContactSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    if(allRecordArray.count==0){
        labelNoRecordFound.hidden=false;
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    }
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) deleteContactFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

#pragma mark - SWTableViewDelegate

- (void)swipeableTableViewCell:(SWTableViewCell *)cell scrollingToState:(SWCellState)state
{
    switch (state) {
        case 0:
            NSLog(@"utility buttons closed");
            break;
        case 1:
            NSLog(@"left utility buttons open");
            break;
        case 2:
            NSLog(@"right utility buttons open");
            break;
        default:
            break;
    }
}

- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerLeftUtilityButtonWithIndex:(NSInteger)index
{
    switch (index) {
        case 0:
            NSLog(@"left button 0 was pressed");
            break;
        case 1:
            NSLog(@"left button 1 was pressed");
            break;
        case 2:
            NSLog(@"left button 2 was pressed");
            break;
        case 3:
            NSLog(@"left btton 3 was pressed");
        default:
            break;
    }
}


- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerRightUtilityButtonWithIndex:(NSInteger)index
{
    switch (index) {
        case 0:
        {
            [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"IsEditContacts"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [cell hideUtilityButtonsAnimated:YES];
            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            
            NSDictionary *userInfoDict = [allRecordArray objectAtIndex:cellIndexPath.row];
            
            EditContactsViewController* controller = (EditContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editContactsViewController"];
            controller.userDetailDict = userInfoDict;
            
            [self.navigationController pushViewController:controller animated:YES];
            
            break;
        }
        case 1:
        {
            if(isSearchAndDelete==true || isSelectAllPressed==true)
                return;
            // Delete button was pressed
            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            [tableView reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            if(selectedContacts.count>0&&selectedRows.count>0){
                NSString *emailText = emailIdArray[cellIndexPath.row];
                
                [selectedContacts removeObject:emailText];
                [self.selectedRows removeObject:cellIndexPath];
            }
            
            NSLog(@"delete");
            
            NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
            NSString *str = [[allRecordArray objectAtIndex:cellIndexPath.row] valueForKey:@"contactid"];
            
            [dataDictionary setObject:str forKey:@"contactid"];
            
            [allRecordArray removeObjectAtIndex:cellIndexPath.row];
            [emailIdArray removeObjectAtIndex:cellIndexPath.row];
            [nameArray removeObjectAtIndex:cellIndexPath.row];
            [self showProgressHud];
            [[WebService sharedWebService] callDeleteContactWebService:dataDictionary];
            
            [tableView setEditing:NO animated:YES];
            
            if(emailIdArray.count<=0){
                [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
                labelNoRecordFound.hidden=false;
            }
            [self.tableView reloadData];
            break;
        }
        default:
            break;
    }
    [tableView reloadData];
    
}

- (BOOL)swipeableTableViewCellShouldHideUtilityButtonsOnSwipe:(SWTableViewCell *)cell
{
    // allow just one cell's utility button to be open at once
    return YES;
}

- (BOOL)swipeableTableViewCell:(SWTableViewCell *)cell canSwipeToState:(SWCellState)state
{
    switch (state) {
        case 1:
            // set to NO to disable all left utility buttons appearings
            return YES;
            break;
        case 2:
            // set to NO to disable all right utility buttons appearing
            return YES;
            break;
        default:
            break;
    }
    
    return YES;
}

- (NSArray *)rightButtons
{
    NSMutableArray *rightUtilityButtons = [NSMutableArray new];
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:0.0f green:1 blue:0.0f alpha:1.0]
                                                title:@"Edit"];
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:1.0f green:0.231f blue:0.188 alpha:1.0f]
                                                title:@"Delete"];
    
    return rightUtilityButtons;
}



@end
