//
//  EditContactsViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "EditContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "UIImage+fixOrientation.h"

#import "MBProgressHUD.h"
#import "ToDoViewController.h"
#import "PECropViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "PlistUtils.h"
#import "TextValidator.h"
#import "DateHandler.h"
#import "Base64.h"
#import "UIImage+Helpers.h"
#import "ContactsViewController.h"

#ifdef __IPHONE_8_0
#define GregorianCalendar NSCalendarIdentifierGregorian
#else
#define GregorianCalendar NSGregorianCalendar
#endif
@interface EditContactsViewController ()
{
    NSArray *_sections;
    NSMutableArray *_testArray;
    NSString *imageStringAfterCrop;
}
@end

@implementation EditContactsViewController
@synthesize scrollView;
@synthesize txtName;
@synthesize txtEmailId;
@synthesize lblDate;
@synthesize txtContact;
@synthesize txtNote;
@synthesize userDetailDict;
@synthesize datePicker;
@synthesize pickerBackGroundView;
@synthesize btnBarCancel;
@synthesize btnBarDone;
@synthesize selectedDate;
@synthesize btnDOB;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize profileImage;
@synthesize btnTabBarMessage;
@synthesize roundedBtnbtnSave;
-(void)viewDidLoad
{
    [self hideProgressHud];
    
    profileImage.layer.masksToBounds = YES;
    profileImage.layer.cornerRadius = 10.0;
    profileImage.layer.borderColor = [UIColor whiteColor].CGColor;
    profileImage.layer.borderWidth = 3.0f;
    profileImage.layer.shouldRasterize = YES;
    profileImage.clipsToBounds = YES;
    
    txtName.tag = 1;
    txtEmailId.tag = 2;
    txtNote.tag=3;
    txtContact.tag = 4;
    
    txtName.delegate = self;
    txtEmailId.delegate = self;
    txtContact.delegate = self;
    txtNote.delegate=self;
    
    //    roundedBtnbtnSave.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnbtnSave.layer.borderWidth = 2.0f;
    roundedBtnbtnSave.clipsToBounds=YES;
    roundedBtnbtnSave.layer.cornerRadius = 5;
    
    [[btnDOB layer] setBorderWidth:1.0f];
    [[btnDOB layer] setOpacity:0.2];
    
    
    [[btnDOB layer] setBorderColor:[UIColor grayColor].CGColor];
    btnDOB.layer.cornerRadius = 5; // this value vary as per your desire
    btnDOB.clipsToBounds = YES;
    
    txtNote.editable = YES;
    
    [txtName setReturnKeyType:UIReturnKeyNext];
    [txtEmailId setReturnKeyType:UIReturnKeyDone];
    [txtNote setReturnKeyType:UIReturnKeyDefault];
    [txtContact setReturnKeyType:UIReturnKeyDone];
    
    [[self.txtNote layer] setBorderColor:[[UIColor grayColor] CGColor]];
    [[self.txtNote layer] setBorderWidth:1.0f];
    [[self.txtNote layer] setCornerRadius:5];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:GregorianCalendar];
    NSDate *currentDate = [NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setYear:-60];
    NSDate *minDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    [comps setYear:-60];
    
    [datePicker setMaximumDate:currentDate];
    [datePicker setMinimumDate:minDate];
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    if([lblDate.text isEqualToString:@"Birth Date"])
    {
        [[lblDate layer] setOpacity:0.2];
    }
    else
    {
        [[lblDate layer] setOpacity:1];
    }
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,730)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1600)];
    }
    BOOL IsEditContact = [[NSUserDefaults standardUserDefaults] boolForKey:@"IsEditContacts"];
    
    
    //    UILabel *navLabel;
    //
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //    navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    [profileImage setImage:[UIImage imageNamed:@"user_image_default.png"]];
    if(IsEditContact==0){
        [self setTitle:@"Add Contact"];
    }
    else{
        [self setTitle:@"Edit Contact"];
    }
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationItem.titleView = titleView;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    if(IsEditContact==0){
        txtName.text=@"";
        txtEmailId.text=@"";
        txtNote.text=@"Note";
        txtContact.text=@"";
        
    }
    else
    {
        //        NSString *strName = [userInfoDict valueForKey:@"name"];
        //        NSString *stEmailid = [userInfoDict valueForKey:@"email"];
        //        NSString *stMobile = [userInfoDict valueForKey:@"mobile"];
        //        NSString *stNote = [userInfoDict valueForKey:@"note"];
        
        txtName.text = [userDetailDict objectForKey:@"name"];
        txtEmailId.text = [userDetailDict objectForKey:@"email"];
        
        NSString* strWithoutFormatting = [self stringByStrippingHTML:[userDetailDict objectForKey:@"note"]];
        txtNote.text =strWithoutFormatting ;
        txtContact.text = [userDetailDict objectForKey:@"mobile"];
        
        NSString *dateString = [userDetailDict objectForKey:@"birthdate"];
        
        if(![dateString isEqualToString:@""]){
            
            NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
            NSDate *dateFromString = [[NSDate alloc] init];
            dateFromString =  [dateFormatter dateFromString:dateString];
            datePicker.date = dateFromString;

            NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
            if([dateString isEqualToString:@""] ){
                lblDate.text=@"";
            }
            lblDate.text = [DateHandler getDateFromString:dateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
        }
        else{
            lblDate.text=@"Birth Date";
            [[lblDate layer] setOpacity:0.2];
        }
        
        
        NSString *userImage = [userDetailDict valueForKey:@"image_path"];
        if(![userImage isEqualToString:@""] && ![userImage isEqualToString:nil]){
            //        cell.userImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString: userImage]]];
            [UIImage loadFromURL:[NSURL URLWithString:userImage] callback:^(UIImage *image){
                profileImage.image = image;
            }];
        }
        else
        {
            [profileImage setImage:[UIImage imageNamed:@"user_image_default.png"]];
            
        }
    }
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    if([txtNote.text isEqualToString:@""] || [txtNote.text isEqualToString:@"Note"])
    {    [[txtNote layer] setOpacity:0.2];
    }
    else
    {
        [[txtNote layer] setOpacity:1];
    }
    
    if([lblDate.text isEqualToString:@""] || [lblDate.text isEqualToString:@"Birth Date"]){
        lblDate.text=@"Birth Date";
        [[lblDate layer] setOpacity:0.2];
    }
    else {
        [[lblDate layer] setOpacity:1];
    }
    
    txtName.autocapitalizationType = UITextAutocapitalizationTypeWords;
    txtNote.autocapitalizationType = UITextAutocapitalizationTypeWords;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateContactSuccess:) name:kUpdateContactSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateContactFailed:) name:kUpdateContactFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(insertNewContactSuccess:) name:kInsertNewContactSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(insertNewContactFailed:) name:kInsertNewContactFailed object:nil];
}

-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)textViewDidBeginEditing:(UITextView *)textView;
{
    [[txtNote layer]setOpacity:1];
    if([txtNote.text isEqualToString:@"Note"])
        txtNote.text=@"";
}

- (BOOL)textField:(UITextField *) textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if(textField ==txtContact)
    {
        NSUInteger oldLength = [textField.text length];
        NSUInteger replacementLength = [string length];
        NSUInteger rangeLength = range.length;
        
        NSUInteger newLength = oldLength - rangeLength + replacementLength;
        
        BOOL returnKey = [string rangeOfString: @"\n"].location != NSNotFound;
        
        return newLength <= 10 || returnKey;
    }
    return true;
}
- (BOOL) textView: (UITextView*) textView
shouldChangeTextInRange: (NSRange) range
  replacementText: (NSString*) text
{
    if ([text isEqualToString:@"\n"]) {
        [[textView layer] setOpacity:1];
        textView.text = [textView.text stringByReplacingOccurrencesOfString: @"\\n" withString: @"\n"];
        txtNote.text = textView.text;
        return YES;
    }
    return YES;
}

- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}
- (IBAction)doneButtonClicked:(id)sender{
    
    selectedDate = [datePicker date];
    [[lblDate layer]setOpacity:1];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
        dateFormatStr = @"dd/MM/yyyy";
    lblDate.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 4;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    if(textField==txtEmailId)
    {
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
    }
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}
- (void)nextClicked:(NSUInteger)sender {
    switch (sender){
            
        case 1: {
            [txtName resignFirstResponder];
            [txtEmailId becomeFirstResponder];
        }
            break;
            
        case 2: {
            [txtEmailId resignFirstResponder];
        }
            break;
            
        case 3: {
            [txtContact becomeFirstResponder];
        }
            break;
            
        case 4: {
            [txtContact resignFirstResponder];
            //            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    
    switch (sender){
        case 1: {
            [txtName resignFirstResponder];
            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
        case 2: {
            [txtName becomeFirstResponder];
            
        }
            break;
            
        case 3: {
            [txtNote resignFirstResponder];
        }
            break;
            
        case 4: {
            [txtNote becomeFirstResponder];
            [txtContact resignFirstResponder];
            
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
     [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([txtName isFirstResponder]) {
                [txtName resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([txtEmailId isFirstResponder]) {
                [txtEmailId resignFirstResponder];
            }
        }
            break;
            
        case 3: {
            if ([txtNote isFirstResponder]) {
                [txtNote resignFirstResponder];
            }
        }
            break;
            
        case 4: {
            if ([txtContact isFirstResponder]) {
                [txtContact resignFirstResponder];
                //                [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
            }
        }
            break;
            
        default: {
        }
            break;
    }
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField == txtContact){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtContact.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(txtName == textField){
        [txtName resignFirstResponder];
        [txtEmailId becomeFirstResponder];
    }
    
    else if(txtEmailId == textField){
        [txtEmailId resignFirstResponder];
    }
    
    else if(txtContact == textField){
        [txtContact resignFirstResponder];
        //        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    return YES;
}



- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (IBAction)btnSaveItPressed:(id)sender {
    
    if ([txtName isFirstResponder])
        [txtName resignFirstResponder];
    
    else if ([txtEmailId isFirstResponder])
        [txtEmailId resignFirstResponder];
    
    else if ([txtContact isFirstResponder])
        [txtContact resignFirstResponder];
    
    else if ([txtNote isFirstResponder])
        [txtNote resignFirstResponder];
    
    
    id object = lblDate.text;
    if([lblDate.text isEqualToString:@"Birth Date"]){
        lblDate.text=@"";
        [[lblDate layer]setOpacity:0.2];
    }
    else
    {
        [[lblDate layer]setOpacity:1];
    }
    if (object == [NSNull null] || object==nil)
    {
        [self.view makeToast:@"Please select birthdate"];
        return;
        
    }
    if([txtName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please enter name"];
        return;
    }
    else if([TextValidator isValidEmail:txtEmailId.text]==false){
        [self.view makeToast:@"Please enter correct email address"];
        return;
    }
    
    NSString *firstCapChar = [[txtName.text substringToIndex:1] capitalizedString];
    txtName.text = [txtName.text stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:firstCapChar];
    
    BOOL IsEditContact = [[NSUserDefaults standardUserDefaults] boolForKey:@"IsEditContacts"];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    [dataDictionary setObject:userid forKey:@"userid"];
    [dataDictionary setObject:txtName.text forKey:@"name"];
    [dataDictionary setObject:txtEmailId.text forKey:@"email"];
    [dataDictionary setObject:txtNote.text forKey:@"note"];
    [dataDictionary setObject:txtContact.text forKey:@"mobile"];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    NSString *startDateToSend = lblDate.text;
    if(startDateToSend.length>1)
    startDateToSend = [DateHandler sendDateFromString:startDateToSend formatToSend:@"" currentDateFormat:dateFormatStr];
    [dataDictionary setObject:startDateToSend forKey:@"birthdate"];
    
    if(!([imageStringAfterCrop isEqualToString:@""]) && imageStringAfterCrop != nil){
        [dataDictionary setObject:imageStringAfterCrop forKey:@"photo"];
    }
    
    [self showProgressHud];
    if(IsEditContact==0)
    {
        [[WebService sharedWebService] callInsertNewContactWebService:dataDictionary];
    }
    else
    {
        NSLog(@"contact %@",[userDetailDict objectForKey:@"contactid"]);
        [dataDictionary setObject:[userDetailDict objectForKey:@"contactid"] forKey:@"contactid"];
        
        [[WebService sharedWebService] callUpdateContactWebService:dataDictionary];
    }
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnDobPressed:(id)sender {
    
    if ([txtName isFirstResponder])
        [txtName resignFirstResponder];
    
    else if ([txtEmailId isFirstResponder])
        [txtEmailId resignFirstResponder];
    
    else if ([txtContact isFirstResponder])
        [txtContact resignFirstResponder];
    
    else if ([txtNote isFirstResponder])
        [txtNote resignFirstResponder];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    [UIView commitAnimations];
}

- (IBAction)btnEditProfleClicked:(id)sender {
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Photo Library", @"Saved Album", nil];
    actionSheet.tag = 1;
    [actionSheet showInView:self.view];
    //    [self presentViewController:self.imagePickerController animated:NO completion:nil];
}

- (IBAction)btnClearDateFieldPressed:(id)sender {
    lblDate.text=@"";
}
#pragma mark UIActionSheet delegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    if ([@"Camera" isEqualToString:title] && [UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([@"Photo Library" isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([@"Saved Album" isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    }
    
}

#pragma mark UIImagePickerControllerDelegate
-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSMutableDictionary *)info {
    UIImage *originalImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
#ifdef DEV_ENVIRONMENT
    NSLog (@"Image Size, %f, %f", originalImage.size.width, originalImage.size.height
           );
#endif
    
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        [self openCropEditor:[[UIImage memoryOptimizedImageWithImage:originalImage] fixOrientation]];
    }];
}

#pragma mark photo cropper
-(void) openCropEditor:(UIImage *) image {
    PECropViewController *controller = [[PECropViewController alloc] init];
    controller.delegate = self;
    controller.image = image;
    controller.cropAspectRatio = 1;
    
    controller.keepingCropAspectRatio = YES;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:controller];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        navigationController.modalPresentationStyle = UIModalPresentationFormSheet;
    }
    
    [self presentViewController:navigationController animated:YES completion:NULL];
}

- (void)cropViewController:(PECropViewController *)controller didFinishCroppingImage:(UIImage *)croppedImage {
    
    [controller dismissViewControllerAnimated:YES completion:NULL];
    profileImage.image = croppedImage;
    
    CGSize imageViewSize = profileImage.frame.size;
    
    UIGraphicsBeginImageContext(imageViewSize);
    [croppedImage drawInRect:CGRectMake(0,0,imageViewSize.width,imageViewSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    [Base64 initialize];
    NSData *imageData = UIImageJPEGRepresentation(newImage,1);
    NSString *strEncoded = [Base64 encode:imageData];
    imageStringAfterCrop=@"";
    imageStringAfterCrop = strEncoded;
}

-(void) cropViewControllerDidCancel:(PECropViewController *)controller {
    [controller dismissViewControllerAnimated:YES completion:NULL];
}



////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}#pragma mark -
#pragma mark - WebService
#pragma mark -
- (void) updateContactSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    NSString *strMessageResponse = [response objectForKey:@"message"];
    //
    //    if(strMessageResponse.length >=15)
    //    {
    //        [self.view makeToast:strMessageResponse duration:2.4 position:CSToastPositionBottom];
    //    }
    //    else{
    //        [self.view makeToast:[response objectForKey:@"message"]];
    //    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) updateContactFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}
- (void) insertNewContactSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    NSString *strMessageResponse = [response objectForKey:@"message"];
    //
    //    if(strMessageResponse.length >=15)
    //    {
    //        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    //    }
    //    else{
    //        [self.view makeToast:[response objectForKey:@"message"]];
    //    }
    
    //    NSArray *contactDataArray = [dictionary objectForKey:@"data"];
    
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) insertNewContactFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
}


-(NSString *)stringByStrippingHTML:(NSString*)str
{
    NSRange r;
    while ((r = [str rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location     != NSNotFound)
    {
        str = [str stringByReplacingCharactersInRange:r withString:@""];
    }
    return str;
}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

@end
