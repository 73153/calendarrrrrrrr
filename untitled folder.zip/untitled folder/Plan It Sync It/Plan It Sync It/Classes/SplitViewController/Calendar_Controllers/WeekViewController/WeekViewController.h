
#import <UIKit/UIKit.h>
#import "MAWeekView.h" // MAWeekViewDataSource,MAWeekViewDelegate

@class MAEventKitDataSource;

@interface WeekViewController : UIViewController<MAWeekViewDataSource,MAWeekViewDelegate,UITabBarDelegate> {
    MAEventKitDataSource *_eventKitDataSource;
     IBOutlet UITabBar *tabBar;
    
    NSDate *WeekStartDate,*WeekEndDate;
    
    NSDictionary *eventData;
    
    MAWeekView *objWeekView;
    BOOL isServiceCall;
    
}

@property (weak, nonatomic) IBOutlet UIButton *roundedBtnToday;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;

@property(nonatomic,strong) IBOutlet UIView* weekView;
@property(nonatomic,strong) NSMutableArray *eventDic;
@property(weak,nonatomic)id objNotificationData;

@end