/*
 * Copyright (c) 2010-2012 Matias Muhonen <mmu@iki.fi>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#import "DayViewExampleController.h"
#import "MAEvent.h"
#import "MAEventKitDataSource.h"
#import "MAWeekView.h"
#import "MAEvent.h"
#import "MAEventKitDataSource.h"
#import "ProfileViewController.h"
#import "EditEventsViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "MNAutoComplete.h"
#import "PECropViewController.h"
#import "UIImage+fixOrientation.h"
#import "DayViewController.h"
#import "MonthViewController.h"
#import "YearViewController.h"
// Uncomment the following line to use the built in calendar as a source for events:
//#define USE_EVENTKIT_DATA_SOURCE 1

#define DATE_COMPONENTS (NSYearCalendarUnit| NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekCalendarUnit |  NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSWeekdayCalendarUnit | NSWeekdayOrdinalCalendarUnit)
#define CURRENT_CALENDAR [NSCalendar currentCalendar]

@interface DayViewExampleController(PrivateMethods)
@property (readonly) MAEvent *event;
@property (readonly) MAEventKitDataSource *eventKitDataSource;
@end

@implementation DayViewExampleController
@synthesize maDayView;
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	return YES;
}

- (void)viewDidLoad {
//	MADayView *dayView = (MADayView *) self.view;
	/* The default is not to autoscroll, so let's override the default here */
    
    [self setTitle:@"Calendar"];
    UITapGestureRecognizer* myTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
    [self.maDayView addGestureRecognizer:myTap];
	maDayView.autoScrollToFirstEvent = YES;
}

-(void)handleSingleTap:(UITapGestureRecognizer *)sender{
    CGPoint gesturePoint = [sender locationInView:self.view];
    NSLog(@"handleSingleTap!gesturePoint:%f,y:%f",gesturePoint.x,gesturePoint.y);
    CGFloat xx = gesturePoint.x - 5;
    CGFloat yy = gesturePoint.y - 5;
    int xInt= (xx/56);
    int yInt= (yy/45);
    
    if ([maDayView.delegate respondsToSelector:@selector(dayView:eventTapped:)]) {
        [maDayView.delegate dayView:maDayView eventTapped:self.event];
    }
  
//    [self.view addSubview:self.addButton];
}
/* Implementation for the MADayViewDataSource protocol */

static NSDate *date = nil;

#ifdef USE_EVENTKIT_DATA_SOURCE

- (NSArray *)dayView:(MADayView *)dayView eventsForDate:(NSDate *)startDate {
    return [self.eventKitDataSource dayView:maDayView eventsForDate:startDate];
}

#else
- (NSArray *)dayView:(MADayView *)dayView eventsForDate:(NSDate *)startDate {
	date = startDate;

	NSArray *arr = [NSArray arrayWithObjects: self.event, self.event, self.event,
					self.event, self.event, self.event, self.event,  self.event, self.event, nil];
	static size_t generateAllDayEvents;
	
	generateAllDayEvents++;
	
	if (generateAllDayEvents % 4 == 0) {
		((MAEvent *) [arr objectAtIndex:0]).title = @"All-day events test";
		((MAEvent *) [arr objectAtIndex:0]).allDay = YES;
		
		((MAEvent *) [arr objectAtIndex:1]).title = @"All-day events test";
		((MAEvent *) [arr objectAtIndex:1]).allDay = YES;
	}
	return arr;
}
#endif

- (MAEvent *)event {
	static int counter;
	static BOOL flag;
	
	NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
	
	[dict setObject:[NSString stringWithFormat:@"number %i", counter++] forKey:@"test"];
	
	unsigned int r = arc4random() % 24;
	int rr = arc4random() % 3;
	
	MAEvent *event = [[MAEvent alloc] init];
	event.backgroundColor = ((flag = !flag) ? [UIColor purpleColor] : [UIColor brownColor]);
	event.textColor = [UIColor whiteColor];
	event.allDay = NO;
	event.userInfo = dict;
	
	if (rr == 0) {
		event.title = @"Event lorem ipsum es dolor test. This a long text, which should clip the event view bounds.";
	} else if (rr == 1) {
		event.title = @"Foobar.";
	} else {
		event.title = @"Dolor test.";
	}
	
	NSDateComponents *components = [CURRENT_CALENDAR components:DATE_COMPONENTS fromDate:date];
	[components setHour:r];
	[components setMinute:0];
	[components setSecond:0];
	
	event.start = [CURRENT_CALENDAR dateFromComponents:components];
	
	[components setHour:r+rr];
	[components setMinute:0];
	
	event.end = [CURRENT_CALENDAR dateFromComponents:components];
	
	return event;
}

- (MAEventKitDataSource *)eventKitDataSource {
    if (!_eventKitDataSource) {
        _eventKitDataSource = [[MAEventKitDataSource alloc] init];
    }
    return _eventKitDataSource;
}

/* Implementation for the MADayViewDelegate protocol */

- (void)dayView:(MADayView *)dayView eventTapped:(MAEvent *)event {
    
    NSLog(@"%@",event);
    NSLog(@"%@",dayView);
	NSDateComponents *components = [CURRENT_CALENDAR components:DATE_COMPONENTS fromDate:event.start];
	NSString *eventInfo = [NSString stringWithFormat:@"Hour %i. Userinfo: %@", [components hour], [event.userInfo objectForKey:@"test"]];
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Event"
                                                                             message:@""
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Event Title";
    
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Event Description";
      
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Event Date";
  
    }];
    //
    //    [alertController addAction:[UIAlertAction actionWithTitle:@"cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
    //    }]];
    static BOOL flag;

    
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
        
        [dict setObject:[NSString stringWithFormat:@"%@",((UITextField *)alertController.textFields[0]).text] forKey:@"test"];
        MAEvent *event = [[MAEvent alloc] init];
        event.backgroundColor = ((flag = !flag) ? [UIColor blackColor] : [UIColor blackColor]);
        event.textColor = [UIColor whiteColor];
        event.allDay = NO;
        event.userInfo = dict;
        event.title = ((UITextField *)alertController.textFields[0]).text;
        unsigned int r = arc4random() % 24;
        int rr = arc4random() % 3;
        NSDateComponents *components = [CURRENT_CALENDAR components:DATE_COMPONENTS fromDate:event.start];
        [components setHour:r];
        [components setMinute:0];
        [components setSecond:0];
        
        event.start = [CURRENT_CALENDAR dateFromComponents:components];
        
        [components setHour:rr];
        [components setMinute:0];
        
        event.end = [CURRENT_CALENDAR dateFromComponents:components];
        

        NSLog(@"you inputed: %@", ((UITextField *)alertController.textFields[0]).text);
        NSLog(@"you inputed: %@", ((UITextField *)alertController.textFields[1]).text);
        NSLog(@"you inputed: %@", ((UITextField *)alertController.textFields[2]).text);
        
    }]];
    
    [self presentViewController:alertController animated:YES completion:nil];
	
//	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:event.title
//													 message:eventInfo delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//	[alert show];
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        InboxMessageViewController* controller = (InboxMessageViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}




@end
