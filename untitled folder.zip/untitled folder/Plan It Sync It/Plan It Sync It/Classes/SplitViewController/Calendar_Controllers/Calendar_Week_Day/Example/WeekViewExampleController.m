/*
 * Copyright (c) 2010-2012 Matias Muhonen <mmu@iki.fi>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#import "WeekViewExampleController.h"
#import "MAWeekView.h"
#import "MAEvent.h"
#import "MAEventKitDataSource.h"
#import "ProfileViewController.h"
#import "EditEventsViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "MNAutoComplete.h"
#import "PECropViewController.h"
#import "UIImage+fixOrientation.h"
#import "DayViewController.h"
#import "MonthViewController.h"
#import "YearViewController.h"
#import "KxMenu.h"
#import "TimelineViewController.h"
#import "NSDate+FSExtension.h"
#import "AppConstant.h"
#import "AFHTTPRequestOperation.h"
#import "AFHTTPRequestOperationManager.h"
#import "DateHandler.h"
#import "UIView+Toast.h"
// Uncomment the following line to use the built in calendar as a source for events:
//#define USE_EVENTKIT_DATA_SOURCE 1

//#define DATE_COMPONENTS (NSYearCalendarUnit| NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekCalendarUnit |  NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSWeekdayCalendarUnit | NSWeekdayOrdinalCalendarUnit)
#define CURRENT_CALENDAR [NSCalendar currentCalendar]

@interface WeekViewExampleController(PrivateMethods)
@property (readonly) MAEvent *event;
@property (readonly) MAEventKitDataSource *eventKitDataSource;
@end

@implementation WeekViewExampleController
@synthesize allEventRecordArray;
@synthesize allDatesArray;
@synthesize eventOnWeekDateDict;
@synthesize filteredEventDataArray;
@synthesize eventsOnDateArray;
@synthesize allEventDict;

-(void)viewDidLoad
{
    eventOnWeekDateDict=[[NSMutableDictionary alloc] init];

    [self setTitle:@"Week"];
    btnInbox = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnInbox.frame = CGRectMake(0, 0, 56,22);
    btnInbox.titleLabel.textColor = [UIColor whiteColor];
    //    btnInbox.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnInbox.layer.borderWidth = 2.0f;
    btnInbox.clipsToBounds=YES;
    btnInbox.layer.cornerRadius = 5;
    //    _btn3.imageEdgeInsets = UIEdgeInsetsMake(10, 100, 10, 100);
    
    NSInteger checkForMonthOrOther =  [[NSUserDefaults standardUserDefaults] integerForKey:@"MonthWeekDayTimeline"];
    if(checkForMonthOrOther==3) {
        [btnInbox setTitle:@"Month" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeMonth animated:NO];
    }
    else if (checkForMonthOrOther==2){
        [btnInbox setTitle:@"Week" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeWeek animated:NO];
    }
    else if(checkForMonthOrOther==1){
        [btnInbox setTitle:@"Day" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    else
    {
        [btnInbox setTitle:@"Timeline" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    [btnInbox setTitle:@"Week" forState:UIControlStateNormal];
    [btnInbox addTarget:self action:@selector(showMenuItem:) forControlEvents:UIControlEventTouchUpInside];
    [btnInbox setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btnInbox.backgroundColor=[UIColor colorWithRed:(99/255.0f) green:(184/255.0f) blue:(255/255.0f) alpha:1];
    btnInbox.titleLabel.textColor = [UIColor whiteColor];
    
    barButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btnInbox];
    btnInbox.titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:18];
    
    self.navigationItem.rightBarButtonItem = barButtonItem;
    //paresh
    
    allEventRecordArray =[[NSMutableArray alloc] init];
    allDatesArray =[[NSMutableArray alloc] init];
    filteredEventDataArray = [[NSMutableArray alloc]init];
    eventsOnDateArray = [[NSMutableArray alloc] init];
    [self getDataOfTheCalendar:@"2015"];
}
-(void)viewWillAppear:(BOOL)animated
{
    NSString *timeFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KTimeFormat];
    timeFormatStr = [NSString stringWithFormat:@"%@",timeFormatStr];
    
    //    if([timeFormatStr isEqualToString:@"24"]){
    //        [self.weekView setTimeIs24HourFormat:true];
    //    }
    //    else{
    //        [self.weekView setTimeIs24HourFormat:false];
    //    }
    
}
-(void)getDataOfTheCalendar:(NSString*)year
{
    [self showProgressHud];
    
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    //    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://api.weibo.com/oauth2/access_token"]];
    
    //
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    allEventDict = [[NSMutableDictionary alloc] init];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:userid,@"user_id",year,@"year", nil];
    
    [mgr POST:@"http://dev.planitsyncit.com/app/webservices/webservices_calendar.php?action=getcal_by_date" parameters:dictionary success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dictionary = responseObject;
        
        NSDictionary *maiDict = [dictionary objectForKey:@"data"];
        
        allEventDict = [NSMutableDictionary dictionaryWithDictionary:[maiDict objectForKey:@"calendar"]];
        [allEventRecordArray removeAllObjects];
        [allDatesArray removeAllObjects];
        if(allEventDict.count>0){
            allDatesArray = [NSMutableArray arrayWithArray:[allEventDict allKeys]];
            allEventRecordArray = [NSMutableArray arrayWithArray:[allEventDict allValues]];
            [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.5];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        
        [self hideProgressHud];
        NSString* ErrorResponse = [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
        
        [self.view makeToast:ErrorResponse];
        
    }];
}

- (NSDate *)addDays:(NSInteger)days toDate:(NSDate *)originalDate {
    NSDateComponents *components= [[NSDateComponents alloc] init];
    [components setDay:days];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    return [calendar dateByAddingComponents:components toDate:originalDate options:0];
}

-(void)loadEvents{
    
    [filteredEventDataArray removeAllObjects];
    [eventOnWeekDateDict removeAllObjects];
    NSMutableDictionary *eventsByDate = [NSMutableDictionary new];
    [eventsByDate removeAllObjects];
    //    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    //    [formatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    
    int calendarWeek = [DateHandler day:[self.weekView week]];
    
    NSString *objectKeyForCal;
    if(calendarWeek<=9)
        objectKeyForCal = [NSString stringWithFormat:@"0%d", calendarWeek];
    else
        objectKeyForCal = [NSString stringWithFormat:@"%d", calendarWeek];
    
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    [eventsOnDateArray removeAllObjects];
    WeekEndDate =[self addDays:6 toDate:WeekStartDate];
    
    NSDate *startDate = WeekStartDate;
    NSDate *endDate = WeekEndDate;
    for(int i=0; i<allDatesArray.count; i++){
        
        NSString *dateInStirng = [allDatesArray objectAtIndex:i];
        NSDateFormatter *formatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
        NSDate *firstDate = startDate;
        NSDate *secondDate = endDate;
        NSDate *thirdDateForCompare = [formatter dateFromString:dateInStirng];
        
        NSComparisonResult compareStart = [firstDate compare: thirdDateForCompare];
        NSComparisonResult compareEnd = [secondDate compare: thirdDateForCompare];
        
        if ((compareStart == NSOrderedAscending || compareStart == NSOrderedSame)
            && (compareEnd == NSOrderedDescending || compareEnd == NSOrderedSame))
        {
            [filteredEventDataArray addObject:[allEventRecordArray objectAtIndex:i]];
            NSString *dateFoMatch = [[DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"] stringFromDate:thirdDateForCompare];
            //             dateFoMatch = [dateFoMatch stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
            NSArray *evetAMainArr=[allEventDict valueForKey:dateFoMatch];
            for (int i=0; i< evetAMainArr.count; i++) {
                [eventsOnDateArray addObject:[evetAMainArr objectAtIndex:i]];
            }
        }
    }
    eventOnWeekDateDict = [eventsOnDateArray mutableCopy];
    [self hideProgressHud];
    [self.weekView reloadData];
}

- (MAWeekView *)weekView {
    if (!weekViewObj) {
        weekViewObj = [[MAWeekView alloc] init];
    }
    return weekViewObj;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}

/* Implementation for the MAWeekViewDataSource protocol */

#ifdef USE_EVENTKIT_DATA_SOURCE

- (NSArray *)weekView:(MAWeekView *)weekView eventsForDate:(NSDate *)startDate {
    return [self.eventKitDataSource weekView:weekView eventsForDate:startDate];
}
#else

static int counter = 7 * 5;

//- (NSArray *)weekView:(MAWeekView *)weekView eventsForDate:(NSDate *)startDate {
//    counter--;
//
//    unsigned int hoursFrom24 = arc4random() % 24;
//    unsigned int heightOfViewForTimeEvent = arc4random() % 10;
//
//    NSArray *arr;
//
//    if (counter < 0) {
//        arr = [NSArray arrayWithObjects: self.event, nil];
//    } else {
//        if (hoursFrom24 > 5) {
//            ((MAEvent *) [arr objectAtIndex:2]).title = @"Event full day";
//            ((MAEvent *) [arr objectAtIndex:2]).backgroundColor = [UIColor blackColor];
//            ((MAEvent *) [arr objectAtIndex:2]).allDay = YES;
//        }
//        else
//        {
//            arr = (hoursFrom24 <= 5 ? [NSArray arrayWithObjects: self.event, self.event, nil] : [NSArray arrayWithObjects: self.event, self.event, self.event, nil]);
//
//            ((MAEvent *) [arr objectAtIndex:1]).title = @"All-day events test";
//            ((MAEvent *) [arr objectAtIndex:1]).allDay = YES;
//        }
//    }
//
//    ((MAEvent *) [arr objectAtIndex:0]).title = @"Event Week for calendar";
//
//    NSDateComponents *components = [CURRENT_CALENDAR components:DATE_COMPONENTS fromDate:startDate];
//    [components setHour:hoursFrom24];
//    [components setMinute:0];
//    [components setSecond:0];
//
//    ((MAEvent *) [arr objectAtIndex:0]).start = [CURRENT_CALENDAR dateFromComponents:components];
//
//    [components setHour:hoursFrom24+arc4random()%20];
//    [components setMinute:0];
//
//    ((MAEvent *) [arr objectAtIndex:0]).end = [CURRENT_CALENDAR dateFromComponents:components];
//
////    if (heightOfViewForTimeEvent > 5) {
////        ((MAEvent *) [arr objectAtIndex:0]).backgroundColor = [UIColor blackColor];
////    }
//
//    return arr;
//}

#endif

//- (MAEvent *)event {
//    static int counter;
//
//    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
//    NSLog(@"counter %d",counter);
//    [dict setObject:[NSString stringWithFormat:@"number %i", counter++] forKey:@"test"];
//
//    MAEvent *event = [[MAEvent alloc] init];
//    event.backgroundColor = [UIColor blackColor];
//    event.textColor = [UIColor whiteColor];
//    event.allDay = YES;
//    event.userInfo = eventOnWeekDateDict;
//
//    return event;
//}


- (MAEventKitDataSource *)eventKitDataSource {
    if (!_eventKitDataSource) {
        _eventKitDataSource = [[MAEventKitDataSource alloc] init];
    }
    return _eventKitDataSource;
}

/* Implementation for the MAWeekViewDelegate protocol */

- (NSArray *)weekView:(MAWeekView *)WeekView eventsForDate:(NSDate *)startDate {
    counter--;
    if(WeekStartDate==nil)
    {
        WeekStartDate=startDate;
    }
    else{
        startDate=WeekStartDate;
    }
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:dateFormatStr];
    NSMutableArray *arr=[[NSMutableArray alloc] init];
    for (int i=0; i< eventOnWeekDateDict.count; i++) {
        NSString *dateForEvent=[[[[eventsOnDateArray objectAtIndex:i] valueForKey:@"time"]componentsSeparatedByString:@" "] objectAtIndex:0];
        
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *components = [[NSDateComponents alloc] init];
        components.day =1;
        NSDate *newDate = [calendar dateByAddingComponents:components toDate:startDate options:0];
        NSString *calenderDateCompare=[NSString stringWithFormat:@"%@",newDate];
        calenderDateCompare=[[calenderDateCompare componentsSeparatedByString:@" "] objectAtIndex:0];
        if([calenderDateCompare isEqualToString:dateForEvent]){
            [arr addObject:[self event :i : [[eventsOnDateArray objectAtIndex:i] valueForKey:@"time"] ]];
        }
    }
    return arr;
}

-(void)weekView:(MAWeekView *)WeekView weekDidChange:(NSDate *)week
{
    WeekStartDate = week;
    WeekEndDate = [self addDays:7 toDate:WeekStartDate];
    [self showProgressHud];
    [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.5];
}

- (MAEvent *)event : (int)index : (NSDate *)date {
    static int counter;
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    [dateFormatter setDateFormat:dateFormatStr];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:[NSString stringWithFormat:@"number %i", counter++] forKey:@"test"];
    
    MAEvent *event = [[MAEvent alloc] init];
    event.title=[[eventsOnDateArray objectAtIndex:index] valueForKey:@"title"];
    event.userInfo = dict;
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    id dateObject = [[eventsOnDateArray objectAtIndex:index] valueForKey:@"time"];
    if(dateObject == [NSNull null])
        return 0;
    
    NSString *startDateStr = [[eventsOnDateArray objectAtIndex:index] valueForKey:@"time"];
    NSDate *startTimeComp;
    NSDate *endTimeComp;
    NSDateComponents *components;
    NSInteger hour;
    NSInteger minute;
    NSInteger second;
    if(startDateStr.length>0){
        startTimeComp= [formatter dateFromString:startDateStr];
        //        dateFormatter.dateFormat = @"yyyy-MM-dd hh:mm a";
        //        dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm";
        //
        //        NSString *pmamDateString = [dateFormatter stringFromDate:startTimeComp];
        //        startTimeComp =  [formatter dateFromString:pmamDateString];
        
        //        components = [CURRENT_CALENDAR components:DATE_COMPONENTS fromDate:startTimeComp];
        ////        hour = [DateHandler hour:startTimeComp];
        //        hour = [DateHandler hour:startTimeComp];
        
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *components = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:startTimeComp];
        NSInteger hour = [components hour];
        minute = [components minute];
//        NSLog(@"start date hour %ld",(long)hour);
        
        [components setHour:hour];
        [components setMinute:minute];
        if(hour>12)
            event.allDay = YES;
        else
            event.allDay = NO;
        
        event.start = [CURRENT_CALENDAR dateFromComponents:components];
    }
    
    NSString *endDateStr = [[eventsOnDateArray objectAtIndex:index] valueForKey:@"end_time"];
    if(endDateStr.length>0)
    {
        endTimeComp= [formatter dateFromString:endDateStr];
        //        dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm";
        //        NSString *pmamDateString = [dateFormatter stringFromDate:endTimeComp];
        //        endTimeComp =  [formatter dateFromString:pmamDateString];
        
        //        components = [CURRENT_CALENDAR components:DATE_COMPONENTS fromDate:endTimeComp];
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *components = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:endTimeComp];
        NSInteger hour = [components hour];
        minute = [components minute];
        NSLog(@"end date hour %ld",(long)hour);
        [components setHour:hour];
        [components setMinute:minute];
        event.end = [CURRENT_CALENDAR dateFromComponents:components];
        //        event.backgroundColor = [UIColor colorWithRed:(210/255.0) green:(244/255.0) blue:(253/255.0) alpha:1];
        event.backgroundColor = [UIColor blackColor];
        //  event.textColor=[UIColor colorWithRed:(0/255.0) green:(114/255.0) blue:(158/255.0) alpha:1];
        if(hour>12)
            event.allDay = YES;
        else
            event.allDay = NO;
        event.textColor=[UIColor whiteColor];
    }
    return event;
}

- (void)weekView:(MAWeekView *)weekView eventTapped:(MAEvent *)event {
    NSDateComponents *components = [CURRENT_CALENDAR components:DATE_COMPONENTS fromDate:event.start];
    NSString *eventInfo = [NSString stringWithFormat:@"Event tapped: %02li:%02li. Userinfo: %@", (long)[components hour], (long)[components minute], [event.userInfo objectForKey:@"test"]];
    
    //	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:event.title
    //													 message:eventInfo delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    //	[alert show];
}

- (void)weekView:(MAWeekView *)weekView eventDragged:(MAEvent *)event {
    NSDateComponents *components = [CURRENT_CALENDAR components:DATE_COMPONENTS fromDate:event.start];
    NSString *eventInfo = [NSString stringWithFormat:@"Event dragged to %02li:%02li. Userinfo: %@", (long)[components hour], (long)[components minute], [event.userInfo objectForKey:@"test"]];
    
    //	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:event.title
    //                                                    message:eventInfo delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    //	[alert show];
}

- (void)showMenuItem:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      [KxMenuItem menuItem:@"Today"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Day"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Month"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Year"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Timeline"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      ];
    
    [KxMenu showMenuInView:self.view
                  fromRect:CGRectMake(sender.frame.origin.x, sender.frame.origin.y-33, sender.frame.size.width,sender.frame.size.height)
                 menuItems:menuItems];
    
}

- (void) pushMenuItem:(id)sender
{
    NSLog(@"%@", sender);
    
    if([[sender title] isEqual:@"Month"]){
        self.title=@"Month";
        NSDate *date = [NSDate fs_dateWithYear:2015 month:1 day:10];
        MonthViewController* controller = (MonthViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
        controller.calendarWithDate = date;
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if([[sender title]isEqual:@"Today"])
    {
        //        self.dayView.date=[NSDate date];
        
        WeekViewExampleController* controller = (WeekViewExampleController*)[self.storyboard instantiateViewControllerWithIdentifier:@"weekViewExampleController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        NSDate *date = [NSDate fs_dateWithYear:2015 month:1 day:10];
        //        MonthViewController* controller = (MonthViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
        //        controller.isCalendarWeekView = true;
        //        controller.calendarWithDate = date;
        //        [self.navigationController pushViewController:controller animated:YES];
        
        //                [self.weekView setWeek:[NSDate date]];
        //                  [self weekView:self.weekView eventsForDate:[NSDate date]];
        //                [self.weekView reloadData];
    }
    
    else if([[sender title]isEqual:@"Day"])
    {
        self.title=@"Day";
        
        DayViewController* controller = (DayViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"dayViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if([[sender title]isEqual:@"Year"])
    {
        YearViewController* controller = (YearViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if ([[sender title] isEqualToString:@"Timeline"])
    {
        TimelineViewController* controller = (TimelineViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"timelineViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

#pragma mark *********************** TAB BAR *************************
- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        InboxMessageViewController* controller = (InboxMessageViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


@end
