//
//  Utils.m
//  Plan it Sync it
//
//  Created by Vivek on 21/04/15.
//  Copyright (c) 2015 Apple. All rights reserved.
//
#import "Utils.h"
#import <AFNetworking.h>
#import "AppDelegate.h"
#import <ABContactsHelper.h>
#import <ABStandin.h>

@implementation Utils

static NSString *apiEndpoint = @"http://api.reon.social/index2.php";

//--- Get the current member id
+(NSString *)currentMember{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [userDefaults valueForKey:@"memberId"];
}

+(NSString *)currentMemberName{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [userDefaults valueForKey:@"memberName"];
}

+(void) registerNewUserWithDictionaryParams: (NSMutableDictionary *)params profileImageData: (NSData *)imageData setCallback: (void(^)(void))callback{
    
    /*
     * Params:
     * - first_name
     * - last_name
     * - email_address
     * - password
     */
    
    params[@"type"] = @"1";
    
    [Utils apiPOSTWithDictionary:params andImage:imageData andImageName:@"profile_image" withCallback:^(BOOL success, NSDictionary *object) {
        
        if(success){
            
            NSString *memberId = [object valueForKey:@"memberid"];
            NSString *memberName = [object valueForKey:@"name"];
            
            if(memberId){
                
                NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
                [standardDefaults setValue:memberId forKey:@"memberId"];
                [standardDefaults setValue:memberName forKey:@"memberName"];
                [standardDefaults synchronize];
                
                if(callback){
                    callback();
                }
                
            }
            
        }
        
    }];
    
}

+(void) connectFacebookUserWithDictionaryParams: (NSMutableDictionary *)params profileImageData: (NSData *)imageData setCallback: (void(^)(void))callback{
    
    /*
     * Params:
     * - first_name
     * - last_name
     * - email_address
     * - facebook_id
     * - facebook_token
     */
    
    params[@"type"] = @"facebook_connect";
    
    [Utils apiPOSTWithDictionary:params andImage:imageData andImageName:@"profile_image" withCallback:^(BOOL success, NSDictionary *object) {
        
        if(success){
            
            NSString *memberId = [object valueForKey:@"memberid"];
            NSString *memberName = [object valueForKey:@"name"];
            
            NSLog(@"Facebook name: %@", memberName);
            
            if(memberId){
                
                NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
                [standardDefaults setValue:memberId forKey:@"memberId"];
                [standardDefaults setValue:memberName forKey:@"memberName"];
                [standardDefaults synchronize];
                
                if(callback){
                    callback();
                }
                
            }
            
        }
        
    }];
    
}

+(void) loginWithEmailAddress: (NSString *)email andPassword: (NSString *)password withCallback: (void(^)(void))callback{
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    params[@"email_address"] = email;
    params[@"password"] = password;
    params[@"type"] = @"login";
    
    [Utils showSpinner];
    
    [Utils apiPOSTWithDictionary:params withCallback:^(BOOL success, NSDictionary *object) {
        
        [Utils hideSpinner];
        
        if(success){
            
            if([[object valueForKey:@"error"] boolValue]){
                
                UIAlertView *errorAlert = [[UIAlertView alloc] initWithTitle:@"Login Problem" message:@"Your email address and password do not match anyone in our database. Please try again." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                
                [errorAlert show];
                
            }else{
                
                NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
                [standardDefaults setValue:[object valueForKey:@"memberid"] forKey:@"memberId"];
                [standardDefaults setValue:[object valueForKey:@"name"] forKey:@"memberName"];
                [standardDefaults synchronize];
                
                if(callback){
                    callback();
                }
                
            }
            
        }
        
    }];
    
}



//--- 3: Return Sorrounding Members
+(void) queryMemberInfo: (NSArray *)memberIDArray withCallback: (void(^)(NSDictionary *queryObject))callback{
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    params[@"type"] = @"queryMemberInfo";
    params[@"memberids"] = memberIDArray;
    params[@"memberid"] = [Utils currentMember];
    
    [self apiPOSTWithDictionary:params withCallback:^(BOOL success, NSDictionary *object) {
        
        if(success){
            callback(object);
        }
        
    }];
    
}


//--- 5: Check for pending shares
+(void) checkPendingShares: (void(^)(NSMutableDictionary *object, int totalPendingShares, NSArray *pendingSharesObject))callback{
    
    if([Utils currentMember]){
    
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        
        params[@"type"] = @"pending_shares";
        params[@"member_id"] = [Utils currentMember];
        
        [Utils apiPOSTWithDictionary:params withCallback:^(BOOL success, NSDictionary *object) {
            
            NSArray *pendingRequests = [object objectForKey:@"pending_requests"];
            NSMutableDictionary *currentPendingRequest = Nil;
            
            if([pendingRequests count] > 0){
                
                for(NSDictionary *object in pendingRequests){
                    if([[object valueForKey:@"status"] isEqualToString:@"1"]){
                        currentPendingRequest = [object mutableCopy];
                        break;
                    }
                }
                
            }
            
            callback(currentPendingRequest, [[object valueForKey:@"total_pending_requests"] intValue], (NSArray *)[object objectForKey:@"pending_requests"]);
            
        }];
        
    }
    
}

//--- *** Standard POST Object *** ---//
//--- *** Most Like this won't be called directly, but it's available if needed *** --- //

+(void) apiPOSTWithDictionary: (NSDictionary *)postObject withCallback: (void(^)(BOOL success, NSDictionary *object))callback{
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager POST:apiEndpoint parameters:postObject success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        callback(YES, responseObject);
    
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        callback(NO, Nil);
        
        NSLog(@"\n\nFailure Response Body for type: %@: %@", [postObject valueForKey:@"type"], operation.responseString);
        
        //--- Show alert
        NSLog(@"HTTP ERROR: %@", error.localizedDescription);
    
    }];
    
}

+(void) apiPOSTWithDictionary: (NSDictionary *)postObject andImage: (NSData *)imageData andImageName: (NSString *)imageName withCallback: (void(^)(BOOL success, NSDictionary *object))callback
{
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [manager POST:apiEndpoint parameters:postObject constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        if(imageData){
        
            [formData appendPartWithFileData:imageData name:[NSString stringWithFormat:@"%@", imageName] fileName:[NSString stringWithFormat:@"%@.png", imageName] mimeType:@"image/png"];
            
        }
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        callback(YES, responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        callback(NO, Nil);
        
        NSLog(@"\n\nFailure Response Body for type: %@: %@", [postObject valueForKey:@"type"], operation.responseString);
        
    }];
    
}

#pragma mark Spinner Singleton



+(void)showSpinner{
    
    UIView *view = [[[[UIApplication sharedApplication] keyWindow] rootViewController] view];
    
}

+(void)hideSpinner{

    
}


-(CLLocationCoordinate2D) getLocation{
    
    CLLocationManager *locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    [locationManager startUpdatingLocation];
    CLLocation *location = [locationManager location];
    CLLocationCoordinate2D coordinate = [location coordinate];
    
    return coordinate;
    
}

+ (UIImage*) maskImage:(UIImage *)image withMask:(UIImage *)maskImage {
    
    CGImageRef maskRef = maskImage.CGImage;
    
    CGImageRef mask = CGImageMaskCreate(CGImageGetWidth(maskRef),
                                        CGImageGetHeight(maskRef),
                                        CGImageGetBitsPerComponent(maskRef),
                                        CGImageGetBitsPerPixel(maskRef),
                                        CGImageGetBytesPerRow(maskRef),
                                        CGImageGetDataProvider(maskRef), NULL, false);
    
    CGImageRef maskedImageRef = CGImageCreateWithMask([image CGImage], mask);
    UIImage *maskedImage = [UIImage imageWithCGImage:maskedImageRef];
    
    CGImageRelease(mask);
    CGImageRelease(maskedImageRef);
    
    // returns new image with mask applied
    return maskedImage;
}

+(UIImage *) screenshotFromUIImageView: (UIImageView *)imgView{
    
    UIGraphicsBeginImageContext(imgView.frame.size);
    [[imgView layer] renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *screenshot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return screenshot;
    
}

+ (BOOL)date:(NSDate*)date isBetweenDate:(NSDate*)beginDate andDate:(NSDate*)endDate{
    
    if ([date compare:beginDate] == NSOrderedAscending)
    	return NO;
    
    if ([date compare:endDate] == NSOrderedDescending)
    	return NO;
    
    return YES;
}

+ (NSDate *)dateWithYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day isEndOfDay: (BOOL)eod{
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    NSDateComponents *components = [[NSDateComponents alloc] init];
    [components setYear:year];
    [components setMonth:month];
    [components setDay:day];
    
    if(eod == YES){
        
        [components setHour:23];
        [components setMinute:59];
        [components setSecond:59];
        
    }else{
        
        [components setHour:01];
        [components setMinute:0];
        [components setSecond:0];
    
    }
    
    return [calendar dateFromComponents:components];

}

+ (NSDate *) lastDayOfMonth: (int)month inYear: (int)year{
    
    NSDate *curDate = [Utils dateWithYear:year month:month day:1 isEndOfDay:NO];
    NSCalendar *currentCalendar = [NSCalendar currentCalendar];
    NSRange daysRange = [currentCalendar rangeOfUnit:NSDayCalendarUnit inUnit:NSMonthCalendarUnit forDate:curDate];
    
    return [Utils dateWithYear:year month:month day:daysRange.length isEndOfDay:YES];
    
}

+ (NSUInteger) daysInMonth: (int)month withYear: (int)year{
    
    NSDate *curDate = [Utils dateWithYear:year month:month day:1 isEndOfDay:NO];
    NSCalendar *currentCalendar = [NSCalendar currentCalendar];
    NSRange daysRange = [currentCalendar rangeOfUnit:NSDayCalendarUnit inUnit:NSMonthCalendarUnit forDate:curDate];
    
    return daysRange.length;
    
}

+ (NSDate *) firstDayOfMonth: (int)month inYear: (int)year{
    return [Utils dateWithYear:year month:month day:1 isEndOfDay:NO];
}

+(NSArray *) contactsByYear: (int)y month:(int)m day:(int)d{
    
    //--- Date Range
    
    NSString *startDateString = [NSString stringWithFormat:@"%i-%i-%i 00:00:00 +0000", y,m,d];
    NSString *endDateString = [NSString stringWithFormat:@"%i-%i-%i 23:59:59 +0000", y,m,d];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss Z"];
    
    NSDate *startDate = [formatter dateFromString:startDateString];
    NSDate *endDate = [formatter dateFromString:endDateString];
    
    NSPredicate *contactsByDate = [NSPredicate predicateWithFormat:@"creationDate BETWEEN %@", @[startDate, endDate]];
    NSArray *contactsArray = [ABContactsHelper contactsMatchingPredicate:contactsByDate];
    
    return contactsArray.count > 0 ? contactsArray : Nil;
    
}

+(NSArray *) contactsByYear: (int)y month:(int)m{
    
    //--- Date Range
    int daysInMonth = (int)[Utils daysInMonth:m withYear:y];
    NSString *startDateString = [NSString stringWithFormat:@"%i-%i-01 00:00:00 +0000", y,m];
    NSString *endDateString = [NSString stringWithFormat:@"%i-%i-%i 23:59:59 +0000", y,m,daysInMonth];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss Z"];
    
    NSDate *startDate = [formatter dateFromString:startDateString];
    NSDate *endDate = [formatter dateFromString:endDateString];
    
    NSPredicate *contactsByDate = [NSPredicate predicateWithFormat:@"creationDate BETWEEN %@", @[startDate, endDate]];
    NSArray *contactsArray = [ABContactsHelper contactsMatchingPredicate:contactsByDate];
    
    return contactsArray.count > 0 ? contactsArray : Nil;
    
}

+(NSArray *) contactsByYear: (int)y;{
    
    //--- Date Range
    NSString *startDateString = [NSString stringWithFormat:@"%i-01-01 00:00:00 +0000", y];
    NSString *endDateString = [NSString stringWithFormat:@"%i-12-31 23:59:59 +0000", y];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss Z"];
    
    NSDate *startDate = [formatter dateFromString:startDateString];
    NSDate *endDate = [formatter dateFromString:endDateString];
    
    NSPredicate *contactsByDate = [NSPredicate predicateWithFormat:@"creationDate BETWEEN %@", @[startDate, endDate]];
    NSArray *contactsArray = [ABContactsHelper contactsMatchingPredicate:contactsByDate];
    
    return contactsArray.count > 0 ? contactsArray : Nil;
    
}

@end
