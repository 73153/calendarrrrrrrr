//
//  Utils.h
//  Plan it Sync it
//
//  Created by Vivek on 21/04/15.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

typedef enum : NSUInteger {
    meetActionAccepted,
    meetActionRejected,
    meetActionIgnored
} meetAction;

@interface Utils : NSObject<CLLocationManagerDelegate>

+(NSString *)currentMember;
+(NSString *)currentMemberName;
+(void) registerNewUserWithDictionaryParams: (NSMutableDictionary *)params profileImageData: (NSData *)imageData setCallback: (void(^)(void))callback;
+(void) connectFacebookUserWithDictionaryParams: (NSMutableDictionary *)params profileImageData: (NSData *)imageData setCallback: (void(^)(void))callback;
+(void) loginWithEmailAddress: (NSString *)email andPassword: (NSString *)password withCallback: (void(^)(void))callback;
+(void) queryMemberInfo: (NSArray *)memberIDArray withCallback: (void(^)(NSDictionary *queryObject))callback;
+(void) checkPendingShares: (void(^)(NSMutableDictionary *object, int totalPendingShares, NSArray *pendingSharesObject))callback;

+(void) apiPOSTWithDictionary: (NSDictionary *)postObject withCallback: (void(^)(BOOL success, NSDictionary *object))callback;
+(void) apiPOSTWithDictionary: (NSDictionary *)postObject andImage: (NSData *)imageData andImageName: (NSString *)imageName withCallback: (void(^)(BOOL success, NSDictionary *object))callback;

-(CLLocationCoordinate2D) getLocation;

+ (UIImage*) maskImage:(UIImage *)image withMask:(UIImage *)maskImage;
+(UIImage *) screenshotFromUIImageView: (UIImageView *)imgView;

+(void)showSpinner;
+(void)hideSpinner;

+ (BOOL)date:(NSDate*)date isBetweenDate:(NSDate*)beginDate andDate:(NSDate*)endDate;
+ (NSDate *)dateWithYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day isEndOfDay: (BOOL)eod;
+ (NSDate *) lastDayOfMonth: (int)month inYear: (int)year;
+ (NSDate *) firstDayOfMonth: (int)month inYear: (int)year;
+ (NSUInteger) daysInMonth: (int)month withYear: (int)year;

+(NSArray *) contactsByYear: (int)y month:(int)m day:(int)d;
+(NSArray *) contactsByYear: (int)y month:(int)m;
+(NSArray *) contactsByYear: (int)y;

@end
