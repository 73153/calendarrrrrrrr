//
//  JTCircleView.h
//  JTCalendar
//
//  Created by Jonathan Tribouharet
//

#import <UIKit/UIKit.h>

@interface JTCircleView : UIView

@property (nonatomic) UIColor *color;

@end
