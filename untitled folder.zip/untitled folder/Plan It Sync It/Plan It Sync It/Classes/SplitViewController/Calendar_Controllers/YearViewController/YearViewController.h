
//
//  YearViewController.h
//  Plan it Sync it
//
//  Created by Vivek on 21/04/15.
//  Copyright (c) 2015 Apple. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface YearViewController : UIViewController<UICollectionViewDataSource, UICollectionViewDelegate>{
    NSString *currentMonthString;
    NSString *currentDayString;
    NSString *currentYearString;
    int currentYear;
    int currentDay;
    int currentMonth;
    int cellYear;
    NSDate *dateToPassForMonth;
    
    UIBarButtonItem *barButtonItem;
    UIButton * btnInbox;
}
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnToday;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (nonatomic, strong) NSMutableArray *allRecordArray;
@property (nonatomic, strong) NSMutableArray *allDatesArray;


@property (nonatomic, strong) NSDate *selectedDate;

- (void)getUserProfileForMasterTableSuccess:(NSNotification *)notification;
- (void)getUserProfileForMasterTableFailed:(NSNotification *)notification;

- (void)getCalendarAllEventsListingSuccess:(NSNotification *)notification;
- (void)getCalendarAllEventsListingFailed:(NSNotification *)notification;

-(void)getDataOfTheCalendar:(NSString*)year;
-(void)loadEvents;
-(void)loadYearData;
- (IBAction)tabBarButtonsPressed:(id)sender;

@property (weak, nonatomic) IBOutlet UILabel *yearLabel;
@property (weak, nonatomic) IBOutlet UICollectionView *yearlyCollectionView;
@property (strong, nonatomic) NSMutableDictionary *eventDictionary;
- (IBAction)btnPreviousMonthClicked:(id)sender;
- (IBAction)btnNextMonthClicked:(id)sender;
- (IBAction)btnTodayClicked:(id)sender;

@end
