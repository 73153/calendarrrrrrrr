//
//  YearViewController.m
//  Plan it Sync it
//
//  Created by Vivek on 21/04/15.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import "YearViewController.h"
#import "Utils.h"
#import "SmallMonthCell.h"
#import <ABContactsHelper.h>
#import "MonthViewController.h"
#import "NSDate+FSExtension.h"
#import "KxMenu.h"
#import "InboxMessageViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "EventViewController.h"
#import "DayViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "MBProgressHUD.h"
#import "ContactsViewController.h"
#import "TimelineViewController.h"
#import "NSDate+FSExtension.h"
#import "YearViewController.h"
#import "DateHandler.h"
#import "WeekViewExampleController.h"
#import "AFHTTPRequestOperation.h"
#import "AFHTTPRequestOperationManager.h"
static NSUInteger const kCellsCount = 20;
static NSUInteger const kHalfCellsCount = kCellsCount >> 1;
@interface YearViewController ()

@end

@implementation YearViewController
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnToday;
@synthesize yearLabel;
@synthesize eventDictionary;
@synthesize allRecordArray;
@synthesize allDatesArray;

- (void)viewDidLoad{
    
    [super viewDidLoad];
    [self hideProgressHud];
    
    allRecordArray =[[NSMutableArray alloc] init];
    allDatesArray =[[NSMutableArray alloc] init];
    eventDictionary = [[NSMutableDictionary alloc] init];
    
    self.title = @"Calendar";
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    
    yearLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    yearLabel.textColor = [UIColor whiteColor];
    
    roundedBtnToday.titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:15];
    roundedBtnToday.titleLabel.textColor = [UIColor whiteColor];
    
    //Bar color from here changing for.
    NSArray *ver = [[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."];
    if ([[ver objectAtIndex:0] intValue] >= 7) {
        // iOS 7.0 or later
        self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:(34/255.0f) green:(139/255.0f) blue:(34/255.0f) alpha:1];
        self.navigationController.navigationBar.translucent = NO;
    }else {
        // iOS 6.1 or earlier
        self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:(34/255.0f) green:(139/255.0f) blue:(34/255.0f) alpha:1];
    }
    
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    [[NSUserDefaults standardUserDefaults] setObject:@"RegiteredAndVerifiedEmailId" forKey:@"IsRegiteredAndVerifiedEmailId"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    roundedBtnToday.clipsToBounds=YES;
    roundedBtnToday.layer.cornerRadius = 5;
    
    //--- Get Current date
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    //-- Current Month
    [formatter setDateFormat:@"MM"]; // 08
    currentMonthString = [formatter stringFromDate:[NSDate date]];
    currentMonth = [[formatter stringFromDate:[NSDate date]] intValue];
    
    //--- Current Day
    [formatter setDateFormat:@"dd"]; // 22
    currentDayString = [formatter stringFromDate:[NSDate date]];
    currentDay = [[formatter stringFromDate:[NSDate date]] intValue];
    
    //--- Current Year
    [formatter setDateFormat:@"yyyy"]; // 2014
    currentYearString = [formatter stringFromDate:[NSDate date]];
    yearLabel.text = currentYearString;
    currentYear = [currentYearString intValue];
    cellYear = currentYear;
    NSString *yearStr = [NSString stringWithFormat:@"%d",cellYear];
    [self getDataOfTheCalendar:yearStr];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getUserProfileForMasterTableSuccess:) name:kGetUserProfileForMasterTableSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getUserProfileForMasterTableFailed:) name:kGetUserProfileForMasterTableFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCalendarAllEventsListingSuccess:) name:kGetCalendarAllEventsListingSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCalendarAllEventsListingFailed:) name:kGetCalendarAllEventsListingFailed object:nil];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:kUserId];
    
    [self showProgressHud];
    [[WebService sharedWebService] callUserProfileForMasterTable:dataDictionary];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:YES];
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Calendar"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    btnInbox = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnInbox.frame = CGRectMake(0, 0, 56,22);
    btnInbox.titleLabel.textColor = [UIColor whiteColor];
    //    btnInbox.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnInbox.layer.borderWidth = 2.0f;
    btnInbox.clipsToBounds=YES;
    btnInbox.layer.cornerRadius = 5;
    //    _btn3.imageEdgeInsets = UIEdgeInsetsMake(10, 100, 10, 100);
    
    NSInteger checkForMonthOrOther =  [[NSUserDefaults standardUserDefaults] integerForKey:@"MonthWeekDayTimeline"];
    if(checkForMonthOrOther==3) {
        [btnInbox setTitle:@"Month" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeMonth animated:NO];
    }
    else if (checkForMonthOrOther==2){
        [btnInbox setTitle:@"Week" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeWeek animated:NO];
    }
    else if(checkForMonthOrOther==1){
        [btnInbox setTitle:@"Day" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    else
    {
        [btnInbox setTitle:@"Timeline" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    [btnInbox setTitle:@"Year" forState:UIControlStateNormal];
    [btnInbox addTarget:self action:@selector(showMenuItem:) forControlEvents:UIControlEventTouchUpInside];
    [btnInbox setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btnInbox.backgroundColor=[UIColor colorWithRed:(99/255.0f) green:(184/255.0f) blue:(255/255.0f) alpha:1];
    btnInbox.titleLabel.textColor = [UIColor whiteColor];
    
    barButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btnInbox];
    btnInbox.titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:18];
    
    self.navigationItem.rightBarButtonItem = barButtonItem;
    
    
    NSString *dateDetail = [[NSUserDefaults standardUserDefaults] valueForKey:@"MonthTappedDetail"];
    
    if([dateDetail isEqualToString:@""])
    {
    }
    else
    {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        // this is imporant - we set our input date format to match our input string
        // if format doesn't match you'll get nil from your string, so be careful
        [dateFormatter setDateFormat:@"dd-MM-yyyy"];
        NSDate *dateFromString = [[NSDate alloc] init];
        // voila!
        dateFromString = [dateFormatter dateFromString:dateDetail];
    }
    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"EventFeedBlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)showMenuItem:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      [KxMenuItem menuItem:@"Today"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Day"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Week"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Month"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      
      [KxMenuItem menuItem:@"Timeline"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      ];
    
    [KxMenu showMenuInView:self.view
                  fromRect:CGRectMake(sender.frame.origin.x, sender.frame.origin.y-33, sender.frame.size.width,sender.frame.size.height)
                 menuItems:menuItems];
    
}
- (void) pushMenuItem:(id)sender
{
    [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"BlueTabNumber"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    if([[sender title] isEqual:@"Month"]){
        
        NSDate *date = [NSDate fs_dateWithYear:cellYear month:currentMonth day:currentDay];
        MonthViewController* controller = (MonthViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
        controller.calendarWithDate = date;
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if([[sender title]isEqual:@"Week"])
    {
        WeekViewExampleController* controller = (WeekViewExampleController*)[self.storyboard instantiateViewControllerWithIdentifier:@"weekViewExampleController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        NSDate *date = [NSDate fs_dateWithYear:cellYear month:currentMonth day:currentDay];
        //        MonthViewController* controller = (MonthViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
        //        controller.isCalendarWeekView = true;
        //        controller.calendarWithDate = date;
        //        [self.navigationController pushViewController:controller animated:YES];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeWeek animated:NO];
    }
    else if([[sender title]isEqual:@"Day"])
    {
        DayViewController* controller = (DayViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"dayViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if([[sender title]isEqual:@"Today"])
    {
        //--- Get Current date
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        
        //-- Current Month
        [formatter setDateFormat:@"MM"];
        currentMonthString = [formatter stringFromDate:[NSDate date]];
        currentMonth = [[formatter stringFromDate:[NSDate date]] intValue];
        
        //--- Current Day
        [formatter setDateFormat:@"dd"];
        currentDayString = [formatter stringFromDate:[NSDate date]];
        currentDay = [[formatter stringFromDate:[NSDate date]] intValue];
        
        //--- Current Year
        [formatter setDateFormat:@"yyyy"];
        currentYearString = [formatter stringFromDate:[NSDate date]];
        currentYear = [currentYearString intValue];
        cellYear = currentYear;
        NSString *yearStr = [NSString stringWithFormat:@"%d",cellYear];
        [self getDataOfTheCalendar:yearStr];
    }
    else if ([[sender title] isEqualToString:@"Timeline"])
    {
        TimelineViewController* controller = (TimelineViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"timelineViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


#pragma mark -
#pragma mark - WebService
#pragma mark -

- (void) getCalendarAllEventsListingSuccess:(NSNotification *)notification
{
    
    NSDictionary *dictionary = notification.object;
    
    NSDictionary *maiDict = [dictionary objectForKey:@"data"];
    
    NSDictionary *calendarData = [maiDict objectForKey:@"calendar"];
    [allRecordArray removeAllObjects];
    [allDatesArray removeAllObjects];
    if(calendarData.count>0){
        allDatesArray = [[calendarData allKeys]mutableCopy];
        allRecordArray = [[calendarData allValues]mutableCopy];
        [self loadEvents];
        
        //        [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.2];
    }
}

- (void) getCalendarAllEventsListingFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"message"]];
}

- (void) getUserProfileForMasterTableSuccess:(NSNotification *)notification
{
    NSDictionary *dictionary = notification.object;
    
    NSDictionary *maiDict = [dictionary objectForKey:@"data"];
    
    NSDictionary *profileDataDict = [maiDict objectForKey:@"user_profile"];
    
    [[NSUserDefaults standardUserDefaults] setObject:profileDataDict forKey:kProfileData];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}

- (void) getUserProfileForMasterTableFailed:(NSNotification *)notification
{
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"message"]];
}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

- (IBAction)swipeGesture:(UISwipeGestureRecognizer *)sender {
    
    if(sender.direction == UISwipeGestureRecognizerDirectionLeft){
        
        cellYear++;
        NSString *yearStr = [NSString stringWithFormat:@"%d",cellYear];
        [self getDataOfTheCalendar:yearStr];
    }
    
    else if(sender.direction == UISwipeGestureRecognizerDirectionRight){
        
        cellYear--;
        NSString *yearStr = [NSString stringWithFormat:@"%d",cellYear];
        [self getDataOfTheCalendar:yearStr];
    }
}

#pragma mark CollectionView

-(void)loadEvents{
    [eventDictionary removeAllObjects];
    
    //    NSArray *contactsArray = [Utils contactsByYear:cellYear];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
        dateFormatStr = @"dd/MM/yyyy";
    
    NSDateFormatter *formatter = [DateHandler USDateFormatterWithDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    int localCellYear = cellYear;
    for(int i=0; i<allDatesArray.count; i++){
        
        NSArray *dateArray = [allRecordArray objectAtIndex:i];
        for (int j=0; j<dateArray.count; j++) {
            NSString *dateInStirng = [[dateArray objectAtIndex:j] valueForKey:@"time"];
            //        dateInStirng = [dateInStirng stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
            NSDate *date = [formatter dateFromString:dateInStirng];
            
            NSDateComponents* components=  [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:date];
            
            int dayFromDate = (int)[components day];
            int monthFromDate = (int)[components month];
            int yearFromDate= (int)[components year];
            
            //        NSString *monthKey;
            //        if(monthFromDate<=9)
            //            monthKey = [NSString stringWithFormat:@"0%d", monthFromDate];
            //        else
            //            monthKey = [NSString stringWithFormat:@"%d", monthFromDate];
            
            NSString *objectKey;
            //        if(monthFromDate<=9 || dayFromDate<=9){
            //            if(monthFromDate<=9)
            //                objectKey = [NSString stringWithFormat:@"%d0%d%d", dayFromDate,monthFromDate, yearFromDate];
            //            if (dayFromDate<=9)
            //                objectKey = [NSString stringWithFormat:@"0%d%d%d", dayFromDate,monthFromDate, yearFromDate];
            //            if(dayFromDate<=9 && monthFromDate<=9)
            //                objectKey = [NSString stringWithFormat:@"0%d0%d%d", dayFromDate,monthFromDate, yearFromDate];
            //        }
            //        else
            objectKey = [NSString stringWithFormat:@"%d-%d-%d", dayFromDate,monthFromDate, yearFromDate];
            //            NSLog(@"date %@",objectKey);
            if(yearFromDate==localCellYear){
                [eventDictionary setObject:@"1"forKey:objectKey];
            }
            [self performSelector:@selector(loadYearData) withObject:self afterDelay:0.2];
            //            objectKey = [NSString stringWithFormat:@"%d-%d-%d", dayFromDate,monthFromDate, yearFromDate];
            //
            //            NSLog(@"date %@",objectKey);
        }
    }
    [self hideProgressHud];
    
}

-(void)loadYearData{
    yearLabel.text = [NSString stringWithFormat:@"%i", cellYear];
    [_yearlyCollectionView reloadData];
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 12;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    SmallMonthCell *cell = (SmallMonthCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"smallMonth" forIndexPath:indexPath];
    
    int cellMonth = (int)(indexPath.row + 1);
    int daysInMonth = (int)[self daysInMonth:cellMonth];
    
    cell.monthLabel.text = [self intToMonthName:cellMonth isAbbrev:YES];
    cell.monthLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:15];
    cell.eventDictionary = eventDictionary;
    cell.daysInMonth = daysInMonth;
    cell.cellMonth = cellMonth;
    cell.cellYear = cellYear;
    cell.currentMonth = currentMonth;
    cell.currentYear = currentYear;
    cell.currentDay = currentDay;
    [cell.dayCollectionView reloadData];
    
    //    [NSThread detachNewThreadSelector:@selector(loadcellData:) toTarget:self withObject:cell];
    
    return cell;
}
-(void)loadcellData:(SmallMonthCell*)cell
{
    [cell.dayCollectionView reloadData];
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    currentMonth = (int)(indexPath.row + 1);
    
    NSDate *date = [NSDate fs_dateWithYear:cellYear month:currentMonth day:currentDay];
    MonthViewController* controller = (MonthViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
    controller.calendarWithDate = date;
    [self.navigationController pushViewController:controller animated:YES];
    
    //
    //    NSString *stringToPass;
    //
    //    if(currentMonth<=9)
    //        stringToPass = [NSString stringWithFormat:@"%d00%d",cellYear,currentMonth];
    //    else
    //        stringToPass = [NSString stringWithFormat:@"%d0%d",cellYear,currentMonth];
    //
    //      NSInteger tagSelected = [stringToPass integerValue];
    //
    //    MonthViewController* controller = (MonthViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
    //    if ([controller respondsToSelector:@selector(setDateTag:)]) {
    //        [controller setValue:[NSNumber numberWithInteger:tagSelected] forKey:@"dateTag"];
    //    }
    //    self.title = [NSString stringWithFormat:@"%ld", (long)tagSelected / 1000];
    //
    //    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark Date Utilities

-(void)getDataOfTheCalendar:(NSString*)year
{
    [self showProgressHud];
    
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    //    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://api.weibo.com/oauth2/access_token"]];
    
    //拼接参数
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:userid,@"user_id",year,@"year", nil];
    
    [mgr POST:@"http://dev.planitsyncit.com/app/webservices/webservices_calendar.php?action=getcal_by_date" parameters:dictionary success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dictionary = responseObject;
        
        NSDictionary *maiDict = [dictionary objectForKey:@"data"];
        
        NSDictionary *calendarData = [maiDict objectForKey:@"calendar"];
        [allRecordArray removeAllObjects];
        [allDatesArray removeAllObjects];
        if(calendarData.count>0){
            allDatesArray = [[calendarData allKeys]mutableCopy];
            allRecordArray = [[calendarData allValues]mutableCopy];
            [self loadEvents];
            //            [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.5];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        [self hideProgressHud];
        
        NSHTTPURLResponse *response = (NSHTTPURLResponse *)operation.response;
        NSString* ErrorResponse = [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
        
        [self.view makeToast:ErrorResponse];
        
    }];
    
    
    //    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    //
    //    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    [dataDictionary setObject:userid forKey:@"user_id"];
    //    [dataDictionary setObject:year forKey:@"year"];
    //    [[WebService sharedWebService] callGetCalendarAllEventsListingWebService:dataDictionary];
}

-(NSString *) intToMonthName: (int)monthInteger isAbbrev: (BOOL)isAbbrev{
    
    NSString *returnString;
    
    switch(monthInteger){
        case 1: returnString = isAbbrev ? @"January" : @"January"; break;
        case 2: returnString = isAbbrev ? @"February" : @"February"; break;
        case 3: returnString = isAbbrev ? @"March" : @"March"; break;
        case 4: returnString = isAbbrev ? @"April" : @"April"; break;
        case 5: returnString = isAbbrev ? @"May" : @"May"; break;
        case 6: returnString = isAbbrev ? @"June" : @"June"; break;
        case 7: returnString = isAbbrev ? @"July" : @"July"; break;
        case 8: returnString = isAbbrev ? @"August" : @"August"; break;
        case 9: returnString = isAbbrev ? @"September" : @"September"; break;
        case 10: returnString = isAbbrev ? @"October" : @"October"; break;
        case 11: returnString = isAbbrev ? @"November" : @"November"; break;
        case 12: returnString = isAbbrev ? @"December" : @"December"; break;
    }
    
    return returnString;
    
}

-(NSUInteger) daysInMonth: (int)monthInt{
    
    NSCalendar* cal = [NSCalendar currentCalendar];
    NSDateComponents* comps = [[NSDateComponents alloc] init];
    [comps setMonth:monthInt];
    
    NSRange range = [cal rangeOfUnit:NSDayCalendarUnit inUnit:NSMonthCalendarUnit forDate:[cal dateFromComponents:comps]];
    
    return range.length;
}

- (IBAction)btnPreviousMonthClicked:(id)sender {
    cellYear--;
    NSString *yearStr = [NSString stringWithFormat:@"%d",cellYear];
    [self getDataOfTheCalendar:yearStr];
}

- (IBAction)btnNextMonthClicked:(id)sender {
    cellYear++;
    NSString *yearStr = [NSString stringWithFormat:@"%d",cellYear];
    [self getDataOfTheCalendar:yearStr];
}
- (IBAction)btnTodayClicked:(id)sender {
    
    DayViewController* controller = (DayViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"dayViewController"];
    [self.navigationController pushViewController:controller animated:YES];
    
}
@end
