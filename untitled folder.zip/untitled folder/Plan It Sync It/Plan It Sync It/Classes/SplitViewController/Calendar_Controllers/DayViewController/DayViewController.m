//
//  DayViewController.m
//  Calender
//
//  Created by ECWIT on 15/04/15.
//  Copyright (c) 2015 ECWIT. All rights reserved.
//

#import "DayViewController.h"
#import "NSDate+TKCategory.h"
#import "YearViewController.h"
#import "ContactsViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "KxMenu.h"
#import "TimelineViewController.h"
#import "MonthViewController.h"
#import "NSDate+FSExtension.h"
#import "WeekViewExampleController.h"
#import "AFHTTPRequestOperation.h"
#import "AFHTTPRequestOperationManager.h"
#import "AppConstant.h"
#import "DateHandler.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
#import "MBProgressHUD.h"
#import "UIColor+TKCategory.h"
#import "UIView+Toast.h"
#import "EventViewController.h"
#import "EditEventsViewController.h"
@interface DayViewController ()

@end

@implementation DayViewController
@synthesize tabBarBlackLineView;
@synthesize tabBarView;
@synthesize allEventRecordArray;
@synthesize allDatesArray;
@synthesize eventOnMonthDateDict;
@synthesize filteredEventDataArray;
@synthesize eventsOnDateArray;
@synthesize allEventDict;
@synthesize popUpAddEvent;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title = @"Day View";
    mutArrEvents = [NSMutableArray arrayWithObjects:
                    @[@"Calendar day,Test Event 1", @"Vivek Sharma Meeting", @2, @0, @2, @15],
                    @[@"Today complete day calendar, It needs to be done by the EOD", @"Ahmed sir", @7, @0, @7, @45],
                    @[@"Break for 1 hour", @"Vivek Sharma", @15, @0, @16, @00],
                    @[@"Break for 1 hour", @"Vivek Sharma", @15, @0, @16, @30],
                    @[@"Reports the day calendar", @"Vivek Sharma", @5, @30, @6, @0],
                    @[@"Task needed to be done", @"Vivek Sharma", @19, @30, @24, @0], nil];
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    CGRect frame1 = self.view.bounds;
    frame1.origin.y = 0;
    frame1.size.height -= 20;
    
    [self.view insertSubview:self.dayView atIndex:0];
    
    self.dayView.frame = frame1;
    [tabBarView sendSubviewToBack:self.dayView];
    [tabBarBlackLineView sendSubviewToBack:tabBarBlackLineView];
    
    btnInbox = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnInbox.frame = CGRectMake(0, 0, 56,22);
    btnInbox.titleLabel.textColor = [UIColor whiteColor];
    //    btnInbox.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnInbox.layer.borderWidth = 2.0f;
    btnInbox.clipsToBounds=YES;
    btnInbox.layer.cornerRadius = 5;
    //    _btn3.imageEdgeInsets = UIEdgeInsetsMake(10, 100, 10, 100);
    
    NSInteger checkForMonthOrOther =  [[NSUserDefaults standardUserDefaults] integerForKey:@"MonthWeekDayTimeline"];
    if(checkForMonthOrOther==3) {
        [btnInbox setTitle:@"Month" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeMonth animated:NO];
    }
    else if (checkForMonthOrOther==2){
        [btnInbox setTitle:@"Week" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeWeek animated:NO];
    }
    else if(checkForMonthOrOther==1){
        [btnInbox setTitle:@"Day" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    else
    {
        [btnInbox setTitle:@"Timeline" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    [btnInbox setTitle:@"Day" forState:UIControlStateNormal];
    [btnInbox addTarget:self action:@selector(showMenuItem:) forControlEvents:UIControlEventTouchUpInside];
    [btnInbox setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btnInbox.backgroundColor=[UIColor colorWithRed:(99/255.0f) green:(184/255.0f) blue:(255/255.0f) alpha:1];
    btnInbox.titleLabel.textColor = [UIColor whiteColor];
    
    barButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btnInbox];
    btnInbox.titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:18];
    
    self.navigationItem.rightBarButtonItem = barButtonItem;
    //paresh
    NSDateComponents *compNow = [NSDate componentsOfCurrentDate];
    [self performSelector:@selector(updateToCurrentTime) withObject:self afterDelay:60.0f-compNow.second];
    
    allEventRecordArray =[[NSMutableArray alloc] init];
    allDatesArray =[[NSMutableArray alloc] init];
    filteredEventDataArray = [[NSMutableArray alloc]init];
    eventsOnDateArray = [[NSMutableArray alloc] init];
    
    [self getDataOfTheCalendar:@"2015"];
    
    popUpAddEvent.hidden=true;
    
    popUpAddEvent.layer.borderColor = [UIColor blackColor].CGColor;
    popUpAddEvent.layer.borderWidth = 3.0f;
    popUpAddEvent.layer.cornerRadius=10;
    popUpAddEvent.clipsToBounds=YES;
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(addLongpressGesture:)];
    [longPress setDelegate:self];
    [self.dayView addGestureRecognizer:longPress];
}
-(void)viewWillAppear:(BOOL)animated
{
    popUpAddEvent.hidden=true;

    NSString *timeFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KTimeFormat];
    timeFormatStr = [NSString stringWithFormat:@"%@",timeFormatStr];
    
    if([timeFormatStr isEqualToString:@"24"]){
        self.dayView.is24hClock=true;
    }
    else{
        self.dayView.is24hClock=false;
    }
}
- (void)addLongpressGesture:(UILongPressGestureRecognizer *)sender {
    
    UIView *view = sender.view;
    
    CGPoint point = [sender locationInView:view.superview];
    
    if (sender.state == UIGestureRecognizerStateBegan){
        
        // GESTURE STATE BEGAN
        popUpAddEvent.hidden=false;
        popUpAddEvent.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
        
        [UIView animateWithDuration:0.3/1.5 animations:^{
            popUpAddEvent.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.3/2 animations:^{
                popUpAddEvent.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.3/2 animations:^{
                    popUpAddEvent.transform = CGAffineTransformIdentity;
                }];
            }];
        }];
        
        NSDate *date = self.dayView.date;
        NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
        
        NSString *dateFoMatch = [dateFormatter stringFromDate:date];
        
        //   Date format according to preference
        NSDate *dateFromString = [[NSDate alloc] init];
        dateFromString =  [dateFormatter dateFromString:dateFoMatch];
        
        NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
        NSString *addEventDateStr = [DateHandler getDateFromString:dateFoMatch desireDateFormat:dateFormatStr dateFormatWeb:@""];
        
        [[NSUserDefaults standardUserDefaults] setObject:addEventDateStr forKey:KDateForEventCreate];
        [[NSUserDefaults standardUserDefaults]synchronize];

        
    }
    else if (sender.state == UIGestureRecognizerStateChanged){
        
        //GESTURE STATE CHANGED/ MOVED
        
        CGPoint center = view.center;
//        center.x += point.x - _priorPoint.x;
//        center.y += point.y - _priorPoint.y;
//        view.center = center;
        
        // This is how i drag my views
    }
    
    else if (sender.state == UIGestureRecognizerStateEnded){
        
        //GESTURE ENDED
    }
}

-(void)loadEvents{
    [filteredEventDataArray removeAllObjects];
    eventOnMonthDateDict = [[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *eventsByDate = [NSMutableDictionary new];
    [eventsByDate removeAllObjects];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    
    currentYear = [DateHandler year:self.dayView.date];
    
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    [eventsOnDateArray removeAllObjects];
    
    for(int i=0; i<allDatesArray.count; i++){
        
        if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
            dateFormatStr = @"dd/MM/yyyy";
        NSString *dateInStirng = [allDatesArray objectAtIndex:i];
        
        if(dateInStirng.length>0)
        {
            NSDateFormatter *formatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
            
            NSDate *date = [formatter dateFromString:dateInStirng];
            
            NSDate *firstDate = self.dayView.date;
            NSDate *secondDate = date;
            
            NSComparisonResult compareDate = [firstDate compare: secondDate];
            
            if (compareDate == NSOrderedSame)
            {
                [filteredEventDataArray addObject:[allEventRecordArray objectAtIndex:i]];
                NSString *dateFoMatch = [[DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"] stringFromDate:secondDate];
                //             dateFoMatch = [dateFoMatch stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
                NSArray *evetAMainArr=[allEventDict valueForKey:dateFoMatch];
                for (int i=0; i< evetAMainArr.count; i++) {
                    [eventsOnDateArray addObject:[evetAMainArr objectAtIndex:i]];
                }
                self.dayView.date = firstDate;
            }
            //        2015-06-25 10:55:51 +0000
            //        25-06-2015
            //            int dayFromDate = [DateHandler day:date];
            //            //        dayFromDate= dayFromDate-1;
            //            int monthFromDate = [DateHandler month:date];
            //            int yearFromDate= [DateHandler year:date];
            //
            //            NSString *monthKey;
            //            if(monthFromDate<=9)
            //                monthKey = [NSString stringWithFormat:@"0%d", monthFromDate];
            //            else
            //                monthKey = [NSString stringWithFormat:@"%d", monthFromDate];
            //
            //            NSString *objectKey;
            //            if(monthFromDate<=9 || dayFromDate<=9){
            //                if(monthFromDate<=9)
            //                    objectKey = [NSString stringWithFormat:@"%d-0%d-%d", dayFromDate,monthFromDate, yearFromDate];
            //                if (dayFromDate<=9)
            //                    objectKey = [NSString stringWithFormat:@"0%d-%d-%d", dayFromDate,monthFromDate, yearFromDate];
            //                if(dayFromDate<=9 && monthFromDate<=9)
            //                    objectKey = [NSString stringWithFormat:@"0%d-0%d-%d", dayFromDate,monthFromDate, yearFromDate];
            //            }
            //            else
            //                objectKey = [NSString stringWithFormat:@"%d-%d-%d", monthFromDate,dayFromDate, yearFromDate];
            //
            //            NSString *strDate = [NSString stringWithFormat:@"%@",date];
            //            if([objectKeyForCal isEqualToString:monthKey])
            //            {
            //                if(!eventsByDate[objectKey]){
            //                    eventsByDate[objectKey] = [NSMutableArray new];
            //                }
            //
            //                [filteredEventDataArray addObject:[allEventRecordArray objectAtIndex:i]];
            //                NSString *dateFoMatch = [[DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"] stringFromDate:date];
            //
            //                NSArray *evetAMainArr=[allEventDict valueForKey:dateFoMatch];
            //                for (int i=0; i< evetAMainArr.count; i++) {
            //                    [eventsOnDateArray addObject:[evetAMainArr objectAtIndex:i]];
            //                }
            //
            //                [eventsByDate[objectKey] addObject:strDate];
            //            }
            //        }
            //        NSArray * array = @[strDate];
            //        if([objectKeyForCal isEqualToString:monthKey])
            //            [eventOnMonthDateDict setObject:array forKey:objectKey];
        }
    }
    eventOnMonthDateDict = eventsByDate;
    
    //    NSMutableDictionary *arrDateRandom = [NSMutableDictionary new];
    //
    //      for(int i = 0; i < 30; ++i){
    //          // Generate 30 random dates between now and 60 days later
    //          NSDate *randomDate = [NSDate dateWithTimeInterval:(rand() % (3600 * 24 * 60)) sinceDate:[NSDate date]];
    //
    //          // Use the date as key for eventsByDate
    //          NSString *key = [[self dateFormatter] stringFromDate:randomDate];
    //
    //          if(!arrDateRandom[key]){
    //              arrDateRandom[key] = [NSMutableArray new];
    //          }
    //
    //          [arrDateRandom[key] addObject:randomDate];
    //      }
    
    [self hideProgressHud];
}

-(void)getDataOfTheCalendar:(NSString*)year
{
    [self showProgressHud];
    
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    //    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://api.weibo.com/oauth2/access_token"]];
    
    //拼接参数
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    allEventDict = [[NSMutableDictionary alloc] init];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:userid,@"user_id",year,@"year", nil];
    
    [mgr POST:@"http://dev.planitsyncit.com/app/webservices/webservices_calendar.php?action=getcal_by_date" parameters:dictionary success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dictionary = responseObject;
        
        NSDictionary *maiDict = [dictionary objectForKey:@"data"];
        
        allEventDict = [NSMutableDictionary dictionaryWithDictionary:[maiDict objectForKey:@"calendar"]];
        [allEventRecordArray removeAllObjects];
        [allDatesArray removeAllObjects];
        if(allEventDict.count>0){
            allDatesArray = [NSMutableArray arrayWithArray:[allEventDict allKeys]];
            allEventRecordArray = [NSMutableArray arrayWithArray:[allEventDict allValues]];
            [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.5];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        [self hideProgressHud];
        NSString* ErrorResponse = [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
        
        [self.view makeToast:ErrorResponse];
        
    }];
    
    //    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    //
    //    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    [dataDictionary setObject:userid forKey:@"user_id"];
    //    [dataDictionary setObject:year forKey:@"year"];
    //    [[WebService sharedWebService] callGetCalendarAllEventsListingWebService:dataDictionary];
}


-(void)updateToCurrentTime
{
    if (self.dayView) {
        [self.dayView.nowLineView updateTime];
    }
    [self performSelector:@selector(updateToCurrentTime) withObject:self afterDelay:60.0f];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark TKCalendarDayViewDelegate

- (void) calendarDayTimelineView:(TKCalendarDayView*)calendarDay didMoveToDate:(NSDate*)date
{
    self.dayView.date=date;
    [self loadEvents];
}
- (NSArray *) calendarDayTimelineView:(TKCalendarDayView*)calendarDayTimeline eventsForDate:(NSDate *)eventDate{
    
    NSLog(@"eventDate : %@",eventDate);
    
//    if([eventDate compare:[NSDate dateWithTimeIntervalSinceNow:-24*60*60]] == NSOrderedAscending)
//        return @[];
//    
//    if([eventDate compare:[NSDate dateWithTimeIntervalSinceNow:24*60*60]] == NSOrderedDescending)
//        return @[];
    
    NSDateComponents *info = [[NSDate date] dateComponentsWithTimeZone:calendarDayTimeline.calendar.timeZone];
    info.second = 0;
    NSMutableArray *ret = [NSMutableArray array];
    
    for(int i=0; i<eventsOnDateArray.count; i++){
        
        TKCalendarDayEventView *event = [calendarDayTimeline dequeueReusableEventView];
        if(event == nil) event = [TKCalendarDayEventView eventView];
        
        NSString *eventBackgroundColor = [[eventsOnDateArray objectAtIndex:i]valueForKey:@"fcolor"];
        if([eventBackgroundColor isEqualToString:@"#ffffff"])
        {
            event.titleLabel.textColor = [UIColor blackColor];
            event.locationLabel.textColor = [UIColor blackColor];
        }
        else if([eventBackgroundColor isEqualToString:@"#000000"]){
            event.titleLabel.textColor = [UIColor whiteColor];
            event.locationLabel.textColor = [UIColor whiteColor];
        }
        else{
            event.titleLabel.textColor = [UIColor whiteColor];
            event.locationLabel.textColor = [UIColor whiteColor];
        }
     
        event.backgroundColor = [self colorWithHexString:eventBackgroundColor];
        event.edgeView.backgroundColor = [UIColor whiteColor];
//        NSInteger col = arc4random_uniform(3);
//        [event setColorType:col];
        
        event.identifier = nil;
        event.titleLabel.text = [[eventsOnDateArray objectAtIndex:i]valueForKey:@"title"];
        event.locationLabel.text = [[eventsOnDateArray objectAtIndex:i]valueForKey:@"type"];
        
        id startDateObj = [[eventsOnDateArray objectAtIndex:i]valueForKey:@"time"];
        if(startDateObj == [NSNull null])
            return 0;
        
        NSString *startDateTime = [[eventsOnDateArray objectAtIndex:i]valueForKey:@"time"];
        if(startDateTime.length>0){
            
            NSDateFormatter *dateFormatter;
            NSString *timeFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KTimeFormat];
            timeFormatStr = [NSString stringWithFormat:@"%@",timeFormatStr];
            
            dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            
            NSDate *dateFromString = [[NSDate alloc] init];
            dateFromString =  [dateFormatter dateFromString:startDateTime];
            
              if([timeFormatStr isEqualToString:@"24"]){
                dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            }
            else{
                dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                dateFormatter.dateFormat = @"yyyy-MM-dd hh:mm a";
                NSString *pmamDateString = [dateFormatter stringFromDate:dateFromString];
                dateFromString =  [dateFormatter dateFromString:pmamDateString];
            }
            
            NSCalendar *calendar = [NSCalendar currentCalendar];
            NSDateComponents *components;
            NSInteger hour;
            NSInteger minute;
          
            hour = [components hour];
            minute = [components minute];
            components = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:dateFromString];
         
            
            info.hour = hour;
            info.minute = minute;
            event.startDate = dateFromString;
            
            NSString *endDateTime = [[eventsOnDateArray objectAtIndex:i]valueForKey:@"end_time"];
            dateFromString =  [dateFormatter dateFromString:endDateTime];
            
            //        event.startDate = [NSDate dateWithDateComponents:info];
            components = [calendar components:(NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:dateFromString];
            hour = [components hour];
            minute = [components minute];
            
            info.hour = hour;
            info.minute = minute;
            
            event.endDate = dateFromString;
            
            [ret addObject:event];
        }
        
    }
    
    /*for(NSArray *ar in mutArrEvents){
     
     TKCalendarDayEventView *event = [calendarDayTimeline dequeueReusableEventView];
     if(event == nil) event = [TKCalendarDayEventView eventView];
     
     NSInteger col = arc4random_uniform(3);
     [event setColorType:col];
     
     
     event.identifier = nil;
     event.titleLabel.text = ar[0];
     event.locationLabel.text = ar[1];
     
     info.hour = [ar[2] intValue];
     info.minute = [ar[3] intValue];
     event.startDate = [NSDate dateWithDateComponents:info];
     
     info.hour = [ar[4] intValue];
     info.minute = [ar[5] intValue];
     event.endDate = [NSDate dateWithDateComponents:info];
     
     [ret addObject:event];
     
     }*/
    return ret;
}

-(UIColor *)colorWithHexString:(NSString *)str {
    const char *cStr = [str cStringUsingEncoding:NSASCIIStringEncoding];
    long x = strtol(cStr+1, NULL, 16);
    return [self colorWithHex:x];
}
- (UIColor *)colorWithHex:(UInt32)col {
    unsigned char r, g, b;
    b = col & 0xFF;
    g = (col >> 8) & 0xFF;
    r = (col >> 16) & 0xFF;
    return [UIColor colorWithRed:(float)r/255.0f green:(float)g/255.0f blue:(float)b/255.0f alpha:1];
}

- (void) calendarDayTimelineView:(TKCalendarDayView*)calendarDayTimeline eventViewWasSelected:(TKCalendarDayEventView *)eventView{
    NSLog(@"%@",eventView.titleLabel.text);
    
    NSDate *date = eventView.startDate;
    NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
    
    NSString *dateFoMatch = [dateFormatter stringFromDate:date];
    
    //   Date format according to preference
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString =  [dateFormatter dateFromString:dateFoMatch];
    
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    NSString *addEventDateStr = [DateHandler getDateFromString:dateFoMatch desireDateFormat:dateFormatStr dateFormatWeb:@""];
    
    [[NSUserDefaults standardUserDefaults] setObject:addEventDateStr forKey:KDateForEventCreate];
    [[NSUserDefaults standardUserDefaults]synchronize];
    for(int i=0; i<eventsOnDateArray.count; i++){
        NSString *labelForMatch = [[eventsOnDateArray objectAtIndex:i]valueForKey:@"title"];
        if([labelForMatch isEqualToString:eventView.titleLabel.text])
        {
            NSString *idStr = [[eventsOnDateArray objectAtIndex:i]valueForKey:@"id"];
            if(idStr.length>0){
                [[NSUserDefaults standardUserDefaults] setObject:[[eventsOnDateArray objectAtIndex:i]valueForKey:@"id"] forKey:kEventId];
            }
            else{
                 [[NSUserDefaults standardUserDefaults] setObject:@"00000" forKey:kEventId];
            }
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            EventViewController* controller = (EventViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventViewController"];
            
            [self.navigationController pushViewController:controller animated:YES];
        }
    }
    
    
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnRightArrowClicked:(id)sender {
    //    [self showProgressHud];
    
    NSDate *now = self.dayView.date;
    int daysToAdd = 1;
    NSDate *newDate1 = [now dateByAddingTimeInterval:60*60*24*daysToAdd];
    self.dayView.date=newDate1;
    [self loadEvents];
    
    //    [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.5];
    
}

- (IBAction)btnLeftArrowClicked:(id)sender {
    //    [self showProgressHud];
    NSDate *now = self.dayView.date;
    int daysToAdd = -1;
    NSDate *newDate1 = [now dateByAddingTimeInterval:60*60*24*daysToAdd];
    self.dayView.date=newDate1;
    [self loadEvents];
    //    [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.5];
    
}

#pragma mark -
#pragma mark - tabBarButtonsPressed
#pragma mark -
- (void)showMenuItem:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      [KxMenuItem menuItem:@"Today"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Week"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Month"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Year"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Timeline"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      ];
    
    [KxMenu showMenuInView:self.view
                  fromRect:CGRectMake(sender.frame.origin.x, sender.frame.origin.y-33, sender.frame.size.width,sender.frame.size.height)
                 menuItems:menuItems];
    
}
- (void) pushMenuItem:(id)sender
{
    NSLog(@"%@", sender);
    
    if([[sender title] isEqual:@"Month"]){
        self.title=@"Month";
        NSDate *date = [NSDate fs_dateWithYear:2015 month:1 day:10];
        MonthViewController* controller = (MonthViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
        controller.calendarWithDate = date;
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if([[sender title]isEqual:@"Week"])
    {
        WeekViewExampleController* controller = (WeekViewExampleController*)[self.storyboard instantiateViewControllerWithIdentifier:@"weekViewExampleController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        NSDate *date = [NSDate fs_dateWithYear:2015 month:1 day:10];
        //        MonthViewController* controller = (MonthViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"monthViewController"];
        //        controller.isCalendarWeekView = true;
        //        controller.calendarWithDate = date;
        //        [self.navigationController pushViewController:controller animated:YES];
        
        
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeWeek animated:NO];
    }
    else if([[sender title]isEqual:@"Today"])
    {
        self.dayView.date=[NSDate date];
        [self loadEvents];
    }
    else if([[sender title]isEqual:@"Year"])
    {
        YearViewController* controller = (YearViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if ([[sender title] isEqualToString:@"Timeline"])
    {
        TimelineViewController* controller = (TimelineViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"timelineViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
}


- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

- (IBAction)btnAddEventClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    EditEventsViewController* controller = (EditEventsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editEventsViewController"];
    
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)btnCloseAddEventPopUp:(id)sender {
    popUpAddEvent.hidden=true;
}
@end
