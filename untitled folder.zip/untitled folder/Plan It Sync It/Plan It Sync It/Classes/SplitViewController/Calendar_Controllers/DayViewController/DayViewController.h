//
//  DayViewController.h
//  Calender
//
//  Created by ECWIT on 15/04/15.
//  Copyright (c) 2015 ECWIT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TKCalendarDayViewController.h"

@interface DayViewController : TKCalendarDayViewController <UIGestureRecognizerDelegate>
{
    NSMutableArray *mutArrEvents;
    UIBarButtonItem *barButtonItem;
    UIButton * btnInbox;
    int currentYear;
}

@property (nonatomic, strong) NSMutableArray *filteredEventDataArray;
@property (nonatomic, strong) NSMutableArray *allEventRecordArray;
@property (nonatomic, strong) NSMutableArray *allDatesArray;
@property (nonatomic, strong) NSMutableDictionary *eventOnMonthDateDict;
@property (nonatomic, strong) NSMutableDictionary *allEventDict;
@property (nonatomic, strong) NSMutableArray *eventsOnDateArray;
-(void)loadEvents;
- (void) showProgressHud;
- (void) hideProgressHud;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnToday;
@property (weak, nonatomic) IBOutlet UIView *tabBarBlackLineView;
@property (weak, nonatomic) IBOutlet UIView *popUpAddEvent;
- (IBAction)btnAddEventClicked:(id)sender;
- (IBAction)btnCloseAddEventPopUp:(id)sender;

@property (weak, nonatomic) IBOutlet UIView *tabBarView;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnRightArrowClicked:(id)sender;
- (IBAction)btnLeftArrowClicked:(id)sender;
-(void)getDataOfTheCalendar:(NSString*)year;
@end

