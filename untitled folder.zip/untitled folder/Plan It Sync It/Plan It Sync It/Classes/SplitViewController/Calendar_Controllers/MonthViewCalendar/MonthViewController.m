//
//  MonthViewController.m
//  Example
//
//  Created by Jonathan Tribouharet.
//

#import "MonthViewController.h"
#import "MBProgressHUD.h"
#import "ContactsViewController.h"
#import "NotificationViewController.h"
#import "ToDoViewController.h"
#import "KxMenu.h"
#import "TimelineViewController.h"
#import "YearViewController.h"
#import "DayViewController.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
#import "WeekViewExampleController.h"
#import "AFHTTPRequestOperation.h"
#import "AFHTTPRequestOperationManager.h"
#import "AppConstant.h"
#import "DateHandler.h"
#import "EventViewController.h"
#import "UIView+Toast.h"
#import "EditEventsViewController.h"
@interface MonthViewController (){
    int currentYear;
}

@end

@implementation MonthViewController
@synthesize calendarWithDate;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize isCalendarWeekView;
@synthesize tableView;
@synthesize allEventRecordArray;
@synthesize allDatesArray;
@synthesize eventOnMonthDateDict;
@synthesize filteredEventDataArray;
@synthesize eventsOnDateArray;
@synthesize allEventDict;
@synthesize addEventPopUp;
@synthesize centerGreenDateLabel;
@synthesize roundedBtnAddEvent;
@synthesize btnCreateHideShow;
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"Month";
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Month"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    self.calendar = [JTCalendar new];
    
    // All modifications on calendarAppearance have to be done before setMenuMonthsView and setContentView
    // Or you will have to call reloadAppearance
    {
        self.calendar.calendarAppearance.calendar.firstWeekday = 2; // Sunday == 1, Saturday == 7
        self.calendar.calendarAppearance.dayCircleRatio = 9. / 10.;
        self.calendar.calendarAppearance.ratioContentMenu = 2.;
        self.calendar.calendarAppearance.focusSelectedDayChangeMode = YES;
        
        // Customize the text for each month
        self.calendar.calendarAppearance.monthBlock = ^NSString *(NSDate *date, JTCalendar *jt_calendar){
            NSCalendar *calendar = jt_calendar.calendarAppearance.calendar;
            NSDateComponents *comps = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth fromDate:date];
            NSInteger currentMonthIndex = comps.month;
            
            static NSDateFormatter *dateFormatter;
            if(!dateFormatter){
                dateFormatter = [NSDateFormatter new];
                dateFormatter.timeZone = jt_calendar.calendarAppearance.calendar.timeZone;
            }
            
            while(currentMonthIndex <= 0){
                currentMonthIndex += 12;
            }
            
            NSString *monthText = [[dateFormatter standaloneMonthSymbols][currentMonthIndex - 1] capitalizedString];
            
            return [NSString stringWithFormat:@"%ld\n%@", comps.year, monthText];
        };
    }
    NSDate *dateWithMonth=calendarWithDate;
    [self.calendar setMenuMonthsView:self.calendarMenuView];
    [self.calendar setContentView:self.calendarContentView];
    [self.calendar setDataSource:self];
    [self.calendar setCurrentDate:dateWithMonth];
    
    [self.calendar reloadData];
    
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        case 5:
        default:
            break;
    }
    if(isCalendarWeekView==true){
        self.title=@"Week";
        
        self.calendar.calendarAppearance.isWeekMode = !self.calendar.calendarAppearance.isWeekMode;
        [self transitionExample];
    }
    
    btnInbox = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnInbox.frame = CGRectMake(0, 0, 62,22);
    
    //    btnInbox.layer.borderColor = [UIColor blackColor].CGColor;
    //    btnInbox.layer.borderWidth = 2.0f;
    btnInbox.clipsToBounds=YES;
    btnInbox.layer.cornerRadius = 5;
    
    //    _btn3.imageEdgeInsets = UIEdgeInsetsMake(10, 100, 10, 100);
    
    NSInteger checkForMonthOrOther =  [[NSUserDefaults standardUserDefaults] integerForKey:@"MonthWeekDayTimeline"];
    if(checkForMonthOrOther==3) {
        [btnInbox setTitle:@"Month" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeMonth animated:NO];
    }
    else if (checkForMonthOrOther==2){
        [btnInbox setTitle:@"Week" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeWeek animated:NO];
    }
    else if(checkForMonthOrOther==1){
        [btnInbox setTitle:@"Day" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    else
    {
        [btnInbox setTitle:@"Timeline" forState:UIControlStateNormal];
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeDay animated:NO];
    }
    [btnInbox setTitle:@"Month" forState:UIControlStateNormal];
    [btnInbox addTarget:self action:@selector(showMenuItem:) forControlEvents:UIControlEventTouchUpInside];
    [btnInbox setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btnInbox.backgroundColor=[UIColor colorWithRed:(99/255.0f) green:(184/255.0f) blue:(255/255.0f) alpha:1];
    
    barButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btnInbox];
    btnInbox.titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:18];
    
    self.navigationItem.rightBarButtonItem = barButtonItem;
    
    [self getDataOfTheCalendar:[NSString stringWithFormat:@"%d",[DateHandler year:[self.calendar currentDate]]]];
    
    addEventPopUp.hidden=true;
    
    addEventPopUp.layer.borderColor = [UIColor blackColor].CGColor;
    addEventPopUp.layer.borderWidth = 3.0f;
    addEventPopUp.layer.cornerRadius=10;
    addEventPopUp.clipsToBounds=YES;
    
    roundedBtnAddEvent.layer.cornerRadius=5;
    roundedBtnAddEvent.clipsToBounds=YES;
    
    allEventRecordArray =[[NSMutableArray alloc] init];
    allDatesArray =[[NSMutableArray alloc] init];
    filteredEventDataArray = [[NSMutableArray alloc]init];
    eventsOnDateArray = [[NSMutableArray alloc] init];
    btnCreateHideShow.hidden=true;
}

-(void)loadEvents{
    [filteredEventDataArray removeAllObjects];
    eventOnMonthDateDict = [[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *eventsByDate = [NSMutableDictionary new];
    [eventsByDate removeAllObjects];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    
    int calendarMonth = [DateHandler month:[self.calendar currentDate]];
    currentYear = [DateHandler year:[self.calendar currentDate]];
    
    NSString *objectKeyForCal;
    if(calendarMonth<=9)
        objectKeyForCal = [NSString stringWithFormat:@"0%d", calendarMonth];
    else
        objectKeyForCal = [NSString stringWithFormat:@"%d", calendarMonth];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    [eventsOnDateArray removeAllObjects];
    
    for(int i=0; i<allDatesArray.count; i++){
        
        if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
            dateFormatStr = @"dd/MM/yyyy";
        NSString *dateInStirng = [allDatesArray objectAtIndex:i];
        
        if(dateInStirng.length>0)
        {
            NSDateFormatter *formatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
            
            NSDate *date = [formatter dateFromString:dateInStirng];
            //        2015-06-25 10:55:51 +0000
            //        25-06-2015
            int dayFromDate = [DateHandler day:date];
            //        dayFromDate= dayFromDate-1;
            int monthFromDate = [DateHandler month:date];
            int yearFromDate= [DateHandler year:date];
            
            NSString *monthKey;
            if(monthFromDate<=9)
                monthKey = [NSString stringWithFormat:@"0%d", monthFromDate];
            else
                monthKey = [NSString stringWithFormat:@"%d", monthFromDate];
            
            NSString *objectKey;
            if(monthFromDate<=9 || dayFromDate<=9){
                if(monthFromDate<=9)
                    objectKey = [NSString stringWithFormat:@"%d-0%d-%d", dayFromDate,monthFromDate, yearFromDate];
                if (dayFromDate<=9)
                    objectKey = [NSString stringWithFormat:@"0%d-%d-%d", dayFromDate,monthFromDate, yearFromDate];
                if(dayFromDate<=9 && monthFromDate<=9)
                    objectKey = [NSString stringWithFormat:@"0%d-0%d-%d", dayFromDate,monthFromDate, yearFromDate];
            }
            else
                objectKey = [NSString stringWithFormat:@"%d-%d-%d", monthFromDate,dayFromDate, yearFromDate];
            
            NSString *strDate = [NSString stringWithFormat:@"%@",date];
            if([objectKeyForCal isEqualToString:monthKey])
            {
                if(!eventsByDate[objectKey]){
                    eventsByDate[objectKey] = [NSMutableArray new];
                }
                
                [filteredEventDataArray addObject:[allEventRecordArray objectAtIndex:i]];
                NSString *dateFoMatch = [[DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"] stringFromDate:date];
                
                NSArray *evetAMainArr=[allEventDict valueForKey:dateFoMatch];
                for (int i=0; i< evetAMainArr.count; i++) {
                    [eventsOnDateArray addObject:[evetAMainArr objectAtIndex:i]];
                }
                
                [eventsByDate[objectKey] addObject:strDate];
            }
        }
        //        NSArray * array = @[strDate];
        //        if([objectKeyForCal isEqualToString:monthKey])
        //            [eventOnMonthDateDict setObject:array forKey:objectKey];
    }
    eventOnMonthDateDict = eventsByDate;
    [self.calendar reloadData];
    [self performSelector:@selector(reLoadTable) withObject:self afterDelay:1];
    
    //    NSMutableDictionary *arrDateRandom = [NSMutableDictionary new];
    //
    //      for(int i = 0; i < 30; ++i){
    //          // Generate 30 random dates between now and 60 days later
    //          NSDate *randomDate = [NSDate dateWithTimeInterval:(rand() % (3600 * 24 * 60)) sinceDate:[NSDate date]];
    //
    //          // Use the date as key for eventsByDate
    //          NSString *key = [[self dateFormatter] stringFromDate:randomDate];
    //
    //          if(!arrDateRandom[key]){
    //              arrDateRandom[key] = [NSMutableArray new];
    //          }
    //
    //          [arrDateRandom[key] addObject:randomDate];
    //      }
    
    [self hideProgressHud];
}
-(void)viewWillAppear:(BOOL)animated
{
    addEventPopUp.hidden=true;
}

-(void)getDataOfTheCalendar:(NSString*)year
{
    [self showProgressHud];
    
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    //    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
    
    //    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://api.weibo.com/oauth2/access_token"]];
    
    //拼接参数
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    allEventDict = [[NSMutableDictionary alloc] init];
    
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:userid,@"user_id",year,@"year", nil];
    
    [mgr POST:@"http://dev.planitsyncit.com/app/webservices/webservices_calendar.php?action=getcal_by_date" parameters:dictionary success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dictionary = responseObject;
        
        NSDictionary *maiDict = [dictionary objectForKey:@"data"];
        
        allEventDict = [NSMutableDictionary dictionaryWithDictionary:[maiDict objectForKey:@"calendar"]];
        [allEventRecordArray removeAllObjects];
        [allDatesArray removeAllObjects];
        if(allEventDict.count>0){
            allDatesArray = [NSMutableArray arrayWithArray:[allEventDict allKeys]];
            allEventRecordArray = [NSMutableArray arrayWithArray:[allEventDict allValues]];
            [self performSelector:@selector(loadEvents) withObject:self afterDelay:2];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        
        [self hideProgressHud];
        NSString* ErrorResponse = [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
        
        [self.view makeToast:ErrorResponse];
        
    }];
    
    //    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    //
    //    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    [dataDictionary setObject:userid forKey:@"user_id"];
    //    [dataDictionary setObject:year forKey:@"year"];
    //    [[WebService sharedWebService] callGetCalendarAllEventsListingWebService:dataDictionary];
}

-(void)reLoadTable
{
    [self.tableView reloadData];
}

- (void)showMenuItem:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      [KxMenuItem menuItem:@"Today"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Day"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Week"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      
      [KxMenuItem menuItem:@"Year"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      [KxMenuItem menuItem:@"Timeline"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      ];
    
    [KxMenu showMenuInView:self.view
                  fromRect:CGRectMake(sender.frame.origin.x, sender.frame.origin.y-33, sender.frame.size.width,sender.frame.size.height)
                 menuItems:menuItems];
}

- (void) pushMenuItem:(id)sender
{
    NSLog(@"%@", sender);
    
    if([[sender title] isEqual:@"Month"]){
        self.calendar.calendarAppearance.isWeekMode=true;
        self.calendar.calendarAppearance.isWeekMode = !self.calendar.calendarAppearance.isWeekMode;
        [self transitionExample];
    }
    else if ([[sender title] isEqual:@"Today"])
    {
        [self.calendar setCurrentDate:[NSDate date]];
        [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.5];
    }
    else if([[sender title]isEqual:@"Week"])
    {
        WeekViewExampleController* controller = (WeekViewExampleController*)[self.storyboard instantiateViewControllerWithIdentifier:@"weekViewExampleController"];
        [self.navigationController pushViewController:controller animated:YES];
        //        self.title=@"Week";
        //        self.calendar.calendarAppearance.isWeekMode=false;
        //        self.calendar.calendarAppearance.isWeekMode = !self.calendar.calendarAppearance.isWeekMode;
        //
        //        [self transitionExample];
        
        //        [[self calendarView] setDisplayMode:CKCalendarViewModeWeek animated:NO];
    }
    else if([[sender title]isEqual:@"Day"])
    {
        self.title=@"Day";
        
        DayViewController* controller = (DayViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"dayViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if([[sender title]isEqual:@"Year"])
    {
        YearViewController* controller = (YearViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if ([[sender title] isEqualToString:@"Timeline"])
    {
        TimelineViewController* controller = (TimelineViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"timelineViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
}

- (void)viewDidLayoutSubviews
{
    [self.calendar repositionViews];
}

#pragma mark - Buttons callback

- (IBAction)didGoTodayTouch
{
    [self.calendar setCurrentDate:[NSDate date]];
}

- (IBAction)didChangeModeTouch
{
    self.calendar.calendarAppearance.isWeekMode = !self.calendar.calendarAppearance.isWeekMode;
    
    [self transitionExample];
}

#pragma mark - JTCalendarDataSource

- (BOOL)calendarHaveEvent:(JTCalendar *)calendar date:(NSDate *)date
{
    NSString *key = [[self dateFormatter] stringFromDate:date];
    
    if(eventOnMonthDateDict[key] && [eventOnMonthDateDict[key] count] > 0){
        return YES;
    }
    
    return NO;
}

- (void)calendarDidDateSelected:(JTCalendar *)calendar date:(NSDate *)date
{
    self.calendar.calendarAppearance.dayTextColorToday = [UIColor blackColor];
    self.calendar.calendarAppearance.dayDotColorToday = [UIColor blueColor];
    self.calendar.calendarAppearance.dayCircleColorToday = [UIColor clearColor];
    
    NSString *key = [[self dateFormatter] stringFromDate:date];
    NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
    
    NSString *dateFoMatch = [dateFormatter stringFromDate:date];
    
    //   Date format according to preference
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString =  [dateFormatter dateFromString:dateFoMatch];
    
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    NSString *addEventDateStr = [DateHandler getDateFromString:dateFoMatch desireDateFormat:dateFormatStr dateFormatWeb:@""];
    
    centerGreenDateLabel.text=@"";
    centerGreenDateLabel.text = addEventDateStr;
    
    btnCreateHideShow.hidden=false;
    
    [[NSUserDefaults standardUserDefaults] setObject:addEventDateStr forKey:KDateForEventCreate];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    NSArray *events = eventOnMonthDateDict[key];
    [eventsOnDateArray removeAllObjects];
    
    if(allEventDict.count>0 && events.count>0){
        
        if([[allEventDict valueForKey:dateFoMatch] isKindOfClass:[NSDictionary class]])
        {            NSLog(@"[NSDictionary class]");
            
        }else if([[allEventDict valueForKey:dateFoMatch] isKindOfClass:[NSArray class]]){
            NSLog(@"[NSArray class]");
            NSArray *evetAMainArr=[allEventDict valueForKey:dateFoMatch];
            for (int i=0; i< evetAMainArr.count; i++) {
                [eventsOnDateArray addObject:[evetAMainArr objectAtIndex:i]];
            }
        }
        else{
            NSLog(@"%@",[allEventDict valueForKey:dateFoMatch]);
        }
    }
    //        [eventsOnDateArray addObject:[allEventDict valueForKey:key]];
    NSLog(@"Date: %@ - %ld events", date, [events count]);
    [self reLoadTable];
}

- (void)calendarDidLoadPreviousPage
{
    [self showProgressHud];
    [self loadPreviousMonth];
    NSLog(@"Previous page loaded");
}

- (void)calendarDidLoadNextPage
{
    [self showProgressHud];
    [self loadNextMonth];
    NSLog(@"Next page loaded");
}
-(void)loadPreviousMonth
{
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:KDateForEventCreate];
    [[NSUserDefaults standardUserDefaults]synchronize];
    centerGreenDateLabel.text=@"";
    btnCreateHideShow.hidden=true;
    addEventPopUp.hidden=true;
    int year = [DateHandler year:[self.calendar currentDate]];
    if(currentYear==year)
    {
        [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.5];
    }else
    {
        [self showProgressHud];
        [self getDataOfTheCalendar:[NSString stringWithFormat:@"%d",(currentYear-1)]];
    }
}

- (IBAction)btnPreviousClicked:(id)sender {
    centerGreenDateLabel.text=@"";
    btnCreateHideShow.hidden=true;
    addEventPopUp.hidden=true;
    [self.calendar loadPreviousPage];
    [self showProgressHud];
    [self performSelector:@selector(loadPreviousMonth) withObject:self afterDelay:0.5];
}

-(void)loadNextMonth
{
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:KDateForEventCreate];
    [[NSUserDefaults standardUserDefaults]synchronize];
    centerGreenDateLabel.text=@"";
    btnCreateHideShow.hidden=true;
    addEventPopUp.hidden=true;
    int year = [DateHandler year:[self.calendar currentDate]];
    if(currentYear==year)
    {
        [self performSelector:@selector(loadEvents) withObject:self afterDelay:0.5];
    }else
    {
        [self showProgressHud];
        [self getDataOfTheCalendar:[NSString stringWithFormat:@"%d",(currentYear+1)]];
    }
}
- (IBAction)btnNextClicked:(id)sender {
    centerGreenDateLabel.text=@"";
    btnCreateHideShow.hidden=true;
    addEventPopUp.hidden=true;
    [self.calendar loadNextPage];
    [self showProgressHud];
    [self performSelector:@selector(loadNextMonth) withObject:self afterDelay:1];
}
- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnCloseEventPopUpClick:(id)sender {
    addEventPopUp.hidden=true;
}

#pragma mark - dataSource method
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //    return searchedEmailArray.count;
    return eventsOnDateArray.count;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"UMCell";
    UMTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    NSString *eventName = [[eventsOnDateArray objectAtIndex:indexPath.row] valueForKey:@"title"];
    if(eventName.length>0)
        cell.label1.text = eventName;
    id dateStringIdObject = [[eventsOnDateArray objectAtIndex:indexPath.row] valueForKey:@"time"];
    if(dateStringIdObject == [NSNull null]){
    }
    else
    {
        NSString *timeString = [[eventsOnDateArray objectAtIndex:indexPath.row] valueForKey:@"time"];
        NSRange whiteSpaceRange = [timeString rangeOfCharacterFromSet:[NSCharacterSet whitespaceCharacterSet]];
        if (whiteSpaceRange.location != NSNotFound) {
            NSString *timeStrInFomat;
            if(timeString.length>8){
                NSString *timeFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KTimeFormat];
                timeFormatStr = [NSString stringWithFormat:@"%@",timeFormatStr];
                timeStrInFomat = [timeString substringFromIndex: [timeString length] - 8];
                cell.lblCellTime.text = [DateHandler convertTimeFormat:timeStrInFomat timeFormat:timeFormatStr];
            }
            
            NSString *dateString;
            id dateStringIdObject = timeString;
            if(dateStringIdObject == [NSNull null])
                dateString=@"2012-12-31";
            else
                dateString = [timeString substringToIndex:10];
            if(![dateString isEqualToString:@""]){
                
                NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
                NSDate *dateFromString = [[NSDate alloc] init];
                dateFromString =  [dateFormatter dateFromString:dateString];
                
                NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
                if([dateFormatStr isEqualToString:@""] ){
                    cell.lblCellDate.text=@"";
                }else{
                    cell.lblCellDate.text = [DateHandler getDateFromString:dateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
                }
            }
            
        }
    }
    
    
    //    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    //    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
    //        dateFormatStr = @"dd/MM/yyyy";
    //    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //    // this is imporant - we set our input date format to match our input string
    //    // if format doesn't match you'll get nil from your string, so be careful
    //    [dateFormatter setDateFormat:dateFormatStr];
    //    NSDate *dateFromString = [[NSDate alloc] init];
    //    // voila!
    //
    //    cell.lblCellDate.text = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:dateFromString]];
    //
    
    //
    NSString *typeOfEvent = [[eventsOnDateArray objectAtIndex:indexPath.row] valueForKey:@"type"];
    cell.label.text = typeOfEvent;
    
    cell.label.numberOfLines = 3;
    cell.label1.numberOfLines = 3;
    cell.label.lineBreakMode=0;
    cell.label1.lineBreakMode=0;
    
    NSString *eventColor = [[eventsOnDateArray objectAtIndex:indexPath.row] valueForKey:@"bgcolor"];
    [cell.monthColoredEventView setBackgroundColor:[self colorWithHexString:eventColor]];
    //    if(![userImage isEqualToString:@""] && ![userImage isEqualToString:nil]){
    //
    //        [UIImage loadFromURL:[NSURL URLWithString:userImage] callback:^(UIImage *image){
    //            cell.userImage.image = image;
    //        }];
    //    }
    //    else
    //    {
    //        [cell.userImage setImage:[UIImage imageNamed:@"user_image_default.png"]];
    //    }
    //    cell.userImage.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    //    cell.userImage.layer.masksToBounds = YES;
    //    cell.userImage.layer.cornerRadius = 10.0;
    //    cell.userImage.layer.borderColor = [UIColor whiteColor].CGColor;
    //    cell.userImage.layer.borderWidth = 1.0f;
    //    cell.userImage.clipsToBounds = YES;
    //    UIImage *image;
    //
    //    if ([selectedContacts containsObject:currentText]) {
    //        image = [UIImage imageNamed:@"check_on.png"];
    //    } else  {
    //        image = [UIImage imageNamed:@"check_off.png"];
    //    }
    
    //    [cell.checkBoxButton setImage:image forState:UIControlStateNormal];
    //    [cell.checkBoxButton addTarget:self action:@selector(checkButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:70.0f];
    
    if (cell==Nil) {
        cell = [[UMTableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    
    //    [cell setBackgroundColor:[UIColor clearColor]];
    //
    //    CAGradientLayer *grad = [CAGradientLayer layer];
    //    grad.frame = CGRectMake(0,0,480,80);
    //    //    139-137-137
    //    UIColor *color1 = [UIColor colorWithRed:139.0f/255.0f green:137.0f/255.0f blue:137.0f/255.0f alpha:0.5];
    //    UIColor *color2 = [UIColor colorWithRed:240.0f/255.0f green:240.0f/255.0f blue:240.0f/255.0f alpha:0.5];
    //
    //    //    grad.colors = [NSArray arrayWithObjects:(id)[[UIColor whiteColor] CGColor], (id)[[UIColor greenColor] CGColor], nil];
    //    [grad setColors:[NSArray arrayWithObjects:(id)color1.CGColor, (id)color2.CGColor, nil]];
    //
    //    grad.cornerRadius = 5.0;
    //
    //    [cell setBackgroundView:[[UIView alloc] init]];
    //    [cell.backgroundView.layer insertSublayer:grad atIndex:0];
    
    cell.delegate = self;
    
    return cell;
}

-(UIColor *)colorWithHexString:(NSString *)str {
    const char *cStr = [str cStringUsingEncoding:NSASCIIStringEncoding];
    long x = strtol(cStr+1, NULL, 16);
    return [self colorWithHex:x];
}
- (UIColor *)colorWithHex:(UInt32)col {
    unsigned char r, g, b;
    b = col & 0xFF;
    g = (col >> 8) & 0xFF;
    r = (col >> 16) & 0xFF;
    return [UIColor colorWithRed:(float)r/255.0f green:(float)g/255.0f blue:(float)b/255.0f alpha:1];
}
#pragma mark - Transition examples

- (void)transitionExample
{
    //    CGFloat newHeight = 300;
    //    if(self.calendar.calendarAppearance.isWeekMode){
    //        newHeight = 10.;
    //    }
    //
    //    [UIView animateWithDuration:.5
    //                     animations:^{
    //                         self.calendarContentViewHeight.constant = newHeight;
    //                         [self.view layoutIfNeeded];
    //                     }];
    
    [UIView animateWithDuration:.25
                     animations:^{
                         self.calendarContentView.layer.opacity = 0;
                     }
                     completion:^(BOOL finished) {
                         [self.calendar reloadAppearance];
                         
                         [UIView animateWithDuration:.25
                                          animations:^{
                                              if(self.calendar.calendarAppearance.isWeekMode==true)
                                              {
                                                  CGRect newFrame = self.calendarContentView.frame;
                                                  newFrame.size.height = 35;
                                                  [self.calendarContentView setFrame:newFrame];
                                              }
                                              else{
                                                  CGRect newFrame = self.calendarContentView.frame;
                                                  newFrame.size.height = 260;
                                                  [self.calendarContentView setFrame:newFrame];
                                              }
                                              self.calendarContentView.layer.opacity = 1;
                                          }];
                     }];
    
}


#pragma mark - delegate method
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [[NSUserDefaults standardUserDefaults] setObject:[[eventsOnDateArray objectAtIndex:indexPath.row] valueForKey:@"id"] forKey:kEventId];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    EventViewController* controller = (EventViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eventViewController"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
#pragma mark - Fake data

- (NSDateFormatter *)dateFormatter
{
    static NSDateFormatter *dateFormatter;
    if(!dateFormatter){
        dateFormatter = [NSDateFormatter new];
        dateFormatter.dateFormat = @"dd-MM-yyyy";
    }
    
    return dateFormatter;
}

- (void)createRandomEvents
{
    //
    //    for(int i = 0; i < 30; ++i){
    //        // Generate 30 random dates between now and 60 days later
    //        NSDate *randomDate = [NSDate dateWithTimeInterval:(rand() % (3600 * 24 * 60)) sinceDate:[NSDate date]];
    //
    //        // Use the date as key for eventsByDate
    //        NSString *key = [[self dateFormatter] stringFromDate:randomDate];
    //
    //        if(!eventsByDate[key]){
    //            eventsByDate[key] = [NSMutableArray new];
    //        }
    //
    //        [eventsByDate[key] addObject:randomDate];
    //    }
    
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}


#pragma mark - SWTableViewDelegate

- (void)swipeableTableViewCell:(SWTableViewCell *)cell scrollingToState:(SWCellState)state
{
    switch (state) {
        case 0:
            NSLog(@"utility buttons closed");
            break;
        case 1:
            NSLog(@"left utility buttons open");
            break;
        case 2:
            NSLog(@"right utility buttons open");
            break;
        default:
            break;
    }
}

- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerLeftUtilityButtonWithIndex:(NSInteger)index
{
    switch (index) {
        case 0:
            NSLog(@"left button 0 was pressed");
            break;
        case 1:
            NSLog(@"left button 1 was pressed");
            break;
        case 2:
            NSLog(@"left button 2 was pressed");
            break;
        case 3:
            NSLog(@"left btton 3 was pressed");
        default:
            break;
    }
}


- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerRightUtilityButtonWithIndex:(NSInteger)index
{
    switch (index) {
        case 0:
        {
            
            break;
        }
        case 1:
        {
            break;
        }
        default:
            break;
    }
    [tableView reloadData];
}

- (BOOL)swipeableTableViewCellShouldHideUtilityButtonsOnSwipe:(SWTableViewCell *)cell
{
    // allow just one cell's utility button to be open at once
    return YES;
}

- (BOOL)swipeableTableViewCell:(SWTableViewCell *)cell canSwipeToState:(SWCellState)state
{
    switch (state) {
        case 1:
            // set to NO to disable all left utility buttons appearings
            return YES;
            break;
        case 2:
            // set to NO to disable all right utility buttons appearing
            return YES;
            break;
        default:
            break;
    }
    
    return YES;
}

- (NSArray *)rightButtons
{
    NSMutableArray *rightUtilityButtons = [NSMutableArray new];
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:0.0f green:1 blue:0.0f alpha:1.0]
                                                title:@"Edit"];
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:1.0f green:0.231f blue:0.188 alpha:1.0f]
                                                title:@"Delete"];
    
    return rightUtilityButtons;
}


- (IBAction)centerGreenCreateClicked:(id)sender {
    addEventPopUp.hidden=false;
    
    addEventPopUp.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    
    [UIView animateWithDuration:0.3/1.5 animations:^{
        addEventPopUp.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3/2 animations:^{
            addEventPopUp.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.3/2 animations:^{
                addEventPopUp.transform = CGAffineTransformIdentity;
            }];
        }];
    }];
}
- (IBAction)btnAddEventClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"IsEditEvents"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    EditEventsViewController* controller = (EditEventsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"editEventsViewController"];
    
    [self.navigationController pushViewController:controller animated:YES];
}
@end
