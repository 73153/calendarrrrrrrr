//
//  MonthViewController.h
//  Example
//
//  Created by Jonathan Tribouharet.
//

#import <UIKit/UIKit.h>

#import "JTCalendar.h"
#import "SWTableViewCell.h"

@interface MonthViewController : UIViewController<JTCalendarDataSource,UITableViewDataSource,UITableViewDelegate,SWTableViewCellDelegate>
{
    UIBarButtonItem *barButtonItem;
    UIButton * btnInbox;
}
@property (weak, nonatomic) IBOutlet UIButton *btnCreateHideShow;
@property (weak, nonatomic) IBOutlet UILabel *centerGreenDateLabel;
- (IBAction)centerGreenCreateClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *addEventPopUp;
- (IBAction)btnAddEventClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnAddEvent;

@property (weak, nonatomic) IBOutlet UIButton *roundedBtnToday;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (nonatomic, strong) NSMutableArray *filteredEventDataArray;
@property (nonatomic, strong) NSMutableArray *allEventRecordArray;
@property (nonatomic, strong) NSMutableArray *allDatesArray;
@property (nonatomic, strong) NSMutableDictionary *eventOnMonthDateDict;
@property (nonatomic, strong) NSMutableDictionary *allEventDict;
@property (nonatomic, strong) NSMutableArray *eventsOnDateArray;

-(void)getDataOfTheCalendar:(NSString*)year;
- (IBAction)tabBarButtonsPressed:(id)sender;

@property (weak, nonatomic) IBOutlet JTCalendarMenuView *calendarMenuView;
@property (weak, nonatomic) IBOutlet JTCalendarContentView *calendarContentView;
- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnCloseEventPopUpClick:(id)sender;

@property (strong, nonatomic) NSDate *calendarWithDate;
@property (nonatomic, readwrite) BOOL isCalendarWeekView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

-(void)loadEvents;
-(void)reLoadTable;
@property (strong, nonatomic) JTCalendar *calendar;
- (IBAction)btnPreviousClicked:(id)sender;
- (IBAction)btnNextClicked:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;
@end
