//
//  ToDoViewController.h
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
@interface ToDoViewController : UIViewController <UITabBarDelegate, SWTableViewCellDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchDisplayDelegate>
{
    NSMutableArray *deletedContactArray;
    
    UIBarButtonItem *barButtonItem;
    
    BOOL isSearchAndDelete;
    BOOL isSelectAllPressed;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnNewToDo;

@property (weak, nonatomic) IBOutlet UILabel *labelNoRecordFound;

@property (assign) BOOL isFiltered;
@property(nonatomic, weak) IBOutlet UIBarButtonItem *delButton;
- (IBAction)delRow:(id)sender;
- (IBAction)editRows:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn1;
@property (weak, nonatomic) IBOutlet UIButton *btn2;
@property (weak, nonatomic) IBOutlet UIButton *btn3;

@property (nonatomic, strong) NSMutableArray *myData;
@property (nonatomic, strong) NSMutableArray *selectedData;
// select row
@property (nonatomic, strong) NSMutableArray *selectedRows;

@property (nonatomic, weak) UIRefreshControl *refreshControl;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UISearchBar *mSearchBar;
@property (nonatomic) BOOL useCustomCells;

@property (nonatomic, strong) NSMutableArray *searchedEmailArray;
@property (nonatomic, strong) NSMutableArray *searchedNameArray;

@property (nonatomic, strong) NSMutableArray *selectedContacts;
@property (nonatomic, strong) NSMutableArray *deletedContactArray;
@property (nonatomic, strong) NSMutableArray *emailIdArray;
@property (nonatomic, strong) NSMutableArray *nameArray;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *btnSelectAll;
@property (weak, nonatomic) IBOutlet UIToolbar *toolBar_EditAndDelete;

@property (nonatomic, strong) NSMutableArray *totalIndaxPath;

@property (weak, nonatomic) IBOutlet UIView *viewSelectAllAndDelete;
- (IBAction)selectAll:(id)sender;

- (IBAction)btnBackClicked:(id)sender;
-(void)rel;
- (IBAction)btnNewToDoClicked:(id)sender;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;
@end
