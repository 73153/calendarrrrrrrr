//
//  AddToDoViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "ProfileViewController.h"
#import "AddToDoViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "NotificationViewController.h"
#import "ToDoViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "DateHandler.h"

#ifdef __IPHONE_8_0
#define GregorianCalendar NSCalendarIdentifierGregorian
#else
#define GregorianCalendar NSGregorianCalendar
#endif
@interface AddToDoViewController ()
{
    NSString *isAdminAccess;
    
}

@end

@implementation AddToDoViewController


@synthesize btnBack;
@synthesize btnSave;
@synthesize scrollView;
@synthesize selectedDate;
@synthesize oldDictionary;
@synthesize startDate1;
@synthesize startTime1;
@synthesize dueDate;
@synthesize datePicker;
@synthesize timerPicker;
@synthesize pickerBackGroundView;
@synthesize btnBarCancel;
@synthesize btnBarDone;
@synthesize btnDiplayToDo;
@synthesize textFieldName;
@synthesize textFieldNotes;
@synthesize timerPickerBackgroundView;
@synthesize textFieldPriority;
@synthesize textFieldEstimatedMinutes;
@synthesize btnSelectDate;
@synthesize btnSelectDueDate;
@synthesize btnSelectTime;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnSaveIt;
-(void)viewDidLoad
{
    [self hideProgressHud];
    [self setTitle:@"Add To-Do"];
    int height = self.navigationController.navigationBar.frame.size.height;
    int width = self.navigationController.navigationBar.frame.size.width;
    
    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    [navLabel setText:@"Add To-Do"];
    navLabel.textColor = [UIColor whiteColor];
    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    navLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = navLabel;
    
    textFieldEstimatedMinutes.delegate = self;
    textFieldPriority.delegate=self;
    textFieldName.delegate = self;
    textFieldNotes.delegate = self;
    
    
//    roundedBtnSaveIt.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnSaveIt.layer.borderWidth = 2.0f;
    roundedBtnSaveIt.clipsToBounds=YES;
    roundedBtnSaveIt.layer.cornerRadius = 5;
    
    textFieldName.tag = 1;
    textFieldNotes.tag = 2;
    textFieldPriority.tag = 3;
    textFieldEstimatedMinutes.tag = 4;
    
    [[btnSelectDate layer] setBorderWidth:1.0f];
    [[btnSelectDate layer] setOpacity:0.2];
    
    [[btnSelectDate layer] setBorderColor:[UIColor grayColor].CGColor];
    btnSelectDate.layer.cornerRadius = 5; // this value vary as per your desire
    btnSelectDate.clipsToBounds = YES;
    
    [[btnSelectDueDate layer] setBorderWidth:1.0f];
    [[btnSelectDueDate layer] setOpacity:0.2];
    
    [[btnSelectDueDate layer] setBorderColor:[UIColor grayColor].CGColor];
    btnSelectDueDate.layer.cornerRadius = 5; // this value vary as per your desire
    btnSelectDueDate.clipsToBounds = YES;
    
    [[btnSelectTime layer] setBorderWidth:1.0f];
    [[btnSelectTime layer] setOpacity:0.2];
    
    [[btnSelectTime layer] setBorderColor:[UIColor grayColor].CGColor];
    btnSelectTime.layer.cornerRadius = 5; // this value vary as per your desire
    btnSelectTime.clipsToBounds = YES;
    
    [[startDate1 layer]setOpacity:0.2];
    [[startTime1 layer]setOpacity:0.2];
    [[dueDate layer]setOpacity:0.2];
    
    
    //        [[self.startDate1 layer] setOpacity:0.5];
    //    [[self.startDate1 layer] setBorderColor:[[UIColor lightGrayColor] CGColor]];
    //    [[self.startDate1 layer] setBorderWidth:1.0f];
    //    [[self.startDate1 layer] setCornerRadius:15];
    //
    //    [[self.startTime1 layer] setOpacity:0.5];
    //    [[self.startTime1 layer] setBorderColor:[[UIColor lightGrayColor] CGColor]];
    //    [[self.startTime1 layer] setBorderWidth:1.0f];
    //    [[self.startTime1 layer] setCornerRadius:15];
    //
    //    [[self.dueDate layer] setOpacity:0.5];
    //    [[self.dueDate layer] setBorderColor:[[UIColor lightGrayColor] CGColor]];
    //    [[self.dueDate layer] setBorderWidth:1.0f];
    //    [[self.dueDate layer] setCornerRadius:15];
    
    
    
    [textFieldName setReturnKeyType:UIReturnKeyNext];
    [textFieldNotes setReturnKeyType:UIReturnKeyNext];
    [textFieldPriority setReturnKeyType:UIReturnKeyDone];
    [textFieldEstimatedMinutes setReturnKeyType:UIReturnKeyDone];
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    isDate1Clicked=true;
    isTime1Clicked=true;
    isDisplayToDo=false;
    
    
    UIToolbar *toolbar = [[UIToolbar alloc] init];
    [toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [toolbar sizeToFit];
    UIBarButtonItem *buttonflexible = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *buttonDone = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneClicked:)];
    isAdminAccess = @"No";
    
    [toolbar setItems:[NSArray arrayWithObjects:buttonflexible,buttonDone, nil]];
    
    
    textFieldPriority.inputAccessoryView = toolbar;
    
    [textFieldPriority setItemList:[NSArray arrayWithObjects:@"Low",@"Medium",@"High",nil]];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:GregorianCalendar];
    NSDate *currentDate = [NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setYear:30];
    NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    [comps setYear:-30];
    NSDate *minDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    
    [datePicker setMaximumDate:maxDate];
    [datePicker setMinimumDate:minDate];
    
    [timerPicker setMaximumDate:[NSDate date]];
    
    
    
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,850)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1300)];
    }
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)doneClicked:(UIBarButtonItem*)button
{
    [self.view endEditing:YES];
}

-(void)viewDidUnload
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];

    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}




- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    selectedDate = [NSDate date];
    if(oldDictionary){
        //        txtfield1.text = [oldDictionary objectForKey:kVP];
        //        txtfield2.text = [oldDictionary objectForKey:kAP];
        //        txtfield3.text = [oldDictionary objectForKey:kBF];
        //        txtfield4.text = [oldDictionary objectForKey:kKTV];
        //        txtfield5.text = [oldDictionary objectForKey:kSystolic];
        //        txtfield6.text = [oldDictionary objectForKey:kdiastolic];
        //        txtfield7.text = [oldDictionary objectForKey:kDryWeight];
        //        txtfield8.text = [oldDictionary objectForKey:kFluidGain];
        //        txtfield9.text = [oldDictionary objectForKey:kHB];
        //        txtfield10.text = [oldDictionary objectForKey:kBun];
        //        txtfield11.text = [oldDictionary objectForKey:kCR];
        //        txtfield12.text = [oldDictionary objectForKey:kAlbiumin];
        //        txtfield13.text = [oldDictionary objectForKey:kPhosph];
        //        txtfield14.text = [oldDictionary objectForKey:kPTH];
        //        txtfield15.text = [oldDictionary objectForKey:kKT];
        //        txtfield16.text = [oldDictionary objectForKey:kINR];
        //        selectedDate = [oldDictionary objectForKey:kDate];
    }
    else{
        
        //        textFieldTimezone.text = @"";
        //        textFieldTime.text = @"";
        //        textFieldDateFormat.text = @"";
        //        textFieldEventRSVPDate.text = @"";
        //        textFieldEventColor.text = @"";
        //        textFieldLocation.text = @"";
        //        textFieldPrivacy.text = @"";
        //        textFieldNotificationDeleteTime.text = @"";
        //        textFieldCalenederView.text = @"";
        //        textFieldAdditionalGuestLimit.text = @"";
        //        textFieldRepeatingInstancesLimit.text = @"";
        //
    }
}


- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 4;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    if(textField==textFieldPriority){
        [textFieldPriority setInputAccessoryView:[customKeyboard getToolbarWithDone]];
    }
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}
- (void)nextClicked:(NSUInteger)sender {
    
    switch (sender){
        case 1: {
            [textFieldName resignFirstResponder];
            [textFieldNotes becomeFirstResponder];
        }
            break;
        case 2: {
            [textFieldNotes resignFirstResponder];
            [textFieldPriority becomeFirstResponder];
        }
            break;
        case 3: {
            [textFieldPriority resignFirstResponder];
        }
            break;
        case 4: {
            [textFieldEstimatedMinutes resignFirstResponder];
            //            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    
    switch (sender){
        case 1: {
            [textFieldName resignFirstResponder];
            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
        case 2: {
            [textFieldName becomeFirstResponder];
            [textFieldNotes resignFirstResponder];
            
        }
            break;
        case 3: {
            [textFieldNotes becomeFirstResponder];
            [textFieldPriority resignFirstResponder];
            
        }
            break;
        case 4: {
            [textFieldEstimatedMinutes resignFirstResponder];
            
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
     [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([textFieldName isFirstResponder]) {
                [textFieldName resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([textFieldNotes isFirstResponder]) {
                [textFieldNotes resignFirstResponder];
            }
        }
            break;
        case 3: {
            if ([textFieldPriority isFirstResponder]) {
                [textFieldPriority resignFirstResponder];
            }
        }
            break;
        case 4: {
            if ([textFieldEstimatedMinutes isFirstResponder]) {
                [textFieldEstimatedMinutes resignFirstResponder];
            }
        }
            break;
        default: {
        }
            break;
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnSaveClicked:(id)sender{
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //    [dataDictionary setObject:txtfield1.text forKey:kVP];
    //    [dataDictionary setObject:txtfield2.text forKey:kAP];
    //    [dataDictionary setObject:txtfield3.text forKey:kBF];
    //    [dataDictionary setObject:txtfield4.text forKey:kKTV];
    //    [dataDictionary setObject:txtfield5.text forKey:kSystolic];
    //    [dataDictionary setObject:txtfield6.text forKey:kdiastolic];
    //    [dataDictionary setObject:txtfield7.text forKey:kDryWeight];
    //    [dataDictionary setObject:txtfield8.text forKey:kFluidGain];
    //    [dataDictionary setObject:txtfield9.text forKey:kHB];
    //    [dataDictionary setObject:txtfield10.text forKey:kBun];
    //    [dataDictionary setObject:txtfield11.text forKey:kCR];
    //    [dataDictionary setObject:txtfield12.text forKey:kAlbiumin];
    //    [dataDictionary setObject:txtfield13.text forKey:kPhosph];
    //    [dataDictionary setObject:txtfield14.text forKey:kPTH];
    //    [dataDictionary setObject:txtfield15.text forKey:kKT];
    //    [dataDictionary setObject:txtfield16.text forKey:kINR];
    //    [dataDictionary setObject:selectedDate forKey:kDate];
    if(oldDictionary){
        //        [[DataManager sharedDataManager] updateDialysisReading:dataDictionary forRowId:[[oldDictionary objectForKey:kRowId] intValue]];
    }
    else{
        //        [[DataManager sharedDataManager] insertDialysisreading:dataDictionary];
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField* )textField{
    
    if(textFieldName == textField){
        [textFieldName resignFirstResponder];
        [textFieldNotes becomeFirstResponder];
    }
    else if(textFieldNotes == textField){
        [textFieldNotes resignFirstResponder];
        [textFieldNotes becomeFirstResponder];
    }
    else if(textFieldNotes == textField){
        [textFieldNotes resignFirstResponder];
        [textFieldPriority becomeFirstResponder];
    }
    else if(textFieldPriority == textField){
        [textFieldPriority resignFirstResponder];
    }
    else{
        [textFieldEstimatedMinutes resignFirstResponder];
        //        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        
    }
    
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField* )textField{
    
    if(textField == textFieldEstimatedMinutes){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,dueDate.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    return YES;
}


#pragma mark ***********************Timer Picker*****************

- (IBAction)timerCancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,800, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    else{
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,1200, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}
- (IBAction)timerDoneButtonClicked:(id)sender{
    
    selectedDate = [timerPicker date];
    [[startTime1 layer]setOpacity:1];
    NSString *strTimeFormat = [[NSUserDefaults standardUserDefaults]
                               objectForKey:KTimeFormat];
    
    strTimeFormat = [NSString stringWithFormat:@"%@", strTimeFormat];
    startTime1.text = [DateHandler getTimeStringFromDate:selectedDate timeFormat:strTimeFormat];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,800, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    else{
        [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,1200, timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    }
    [UIView commitAnimations];
    
}
- (IBAction)changeTimeButtonClicked:(id)sender{
    isTime1Clicked=true;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [timerPickerBackgroundView setFrame:CGRectMake(timerPickerBackgroundView.frame.origin.x,self.view.frame.size.height-(timerPickerBackgroundView.frame.size.height), timerPickerBackgroundView.frame.size.width,timerPickerBackgroundView.frame.size.height)];
    [UIView commitAnimations];
}

#pragma mark ***********************Date Picker*****************
- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}
- (IBAction)doneButtonClicked:(id)sender{
    
    selectedDate = [datePicker date];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
        dateFormatStr = @"dd/MM/yyyy";
    if(isDate1Clicked==true){
        [[startDate1 layer]setOpacity:1];
   
        startDate1.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
    }
    else if(isDate1Clicked==false)
    {
        [[dueDate layer]setOpacity:1];
        dueDate.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
    }
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,700, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
    
}

- (IBAction)clearStartDateClicked:(id)sender {
    startDate1.text=@"";
}

- (IBAction)clearStartTimeClicked:(id)sender {
    startTime1.text=@"";
}

- (IBAction)clearDueDateClicked:(id)sender {
    dueDate.text=@"";
}
- (IBAction)changeDateButton1Clicked:(id)sender{
    isDate1Clicked=true;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    [UIView commitAnimations];
}
- (IBAction)changeDueDateButtonClicked:(id)sender{
    isDate1Clicked=false;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    [UIView commitAnimations];
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
//        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
//        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

#pragma mark ***************************TOGGLE BUTTONS***************************
- (IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)toggleRadioButtonDiplayToDo:(id)sender
{
    if(isDisplayToDo==true)
    {
        isDisplayToDo=false;
        [btnDiplayToDo setBackgroundImage:nil forState:UIControlStateNormal];
        [btnDiplayToDo setBackgroundImage:[UIImage imageNamed:@"check_on.png"] forState:UIControlStateNormal];
        
    }else
    {
        isDisplayToDo=true;
        [btnDiplayToDo setBackgroundImage:nil forState:UIControlStateNormal];
        [btnDiplayToDo setBackgroundImage:[UIImage imageNamed:@"check_off.png"] forState:UIControlStateNormal];
    }
}

////hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
@end
