//
//  AddToDoViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "IQDropDownTextField.h"
#import "CustomKeyboard.h"

@interface AddToDoViewController: UIViewController<UITabBarDelegate,UITextFieldDelegate,CustomKeyboardDelegate,IQDropDownTextFieldDelegate>
{
    CustomKeyboard *customKeyboard;
    BOOL isDate1Clicked;
    BOOL isTime1Clicked;
    BOOL isDisplayToDo;
}

@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSaveIt;


@property (nonatomic, strong) IBOutlet UILabel  *startDate1;
@property (nonatomic, strong) IBOutlet UILabel  *startTime1;
@property (nonatomic, strong) IBOutlet UILabel  *dueDate;

@property (nonatomic, strong) IBOutlet UIButton *btnBack;
@property (nonatomic, strong) IBOutlet UIButton *btnSave;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) NSDate *selectedDate;

@property (nonatomic, strong) NSDictionary *oldDictionary;
@property (weak, nonatomic) IBOutlet UIView *timerPickerBackgroundView;

@property (nonatomic, strong) IBOutlet UIView *pickerBackGroundView;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarCancel;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarDone;

@property (nonatomic, strong) IBOutlet UIBarButtonItem *timerbtnBarCancel;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *timerbtnBarDone;

@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;
@property (nonatomic, strong) IBOutlet UIDatePicker *timerPicker;

@property (weak, nonatomic) IBOutlet UIButton *btnSelectDate;

@property (nonatomic, strong) IBOutlet UIButton *btnDiplayToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectDueDate;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectTime;

- (IBAction)toggleRadioButtonDiplayToDo:(id)sender;

- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnSaveClicked:(id)sender;

- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)clearStartDateClicked:(id)sender;
- (IBAction)clearStartTimeClicked:(id)sender;
- (IBAction)clearDueDateClicked:(id)sender;


- (IBAction)timerCancelButtonClicked:(id)sender;
- (IBAction)timerDoneButtonClicked:(id)sender;


- (IBAction)changeTimeButtonClicked:(id)sender;
//
- (IBAction)changeDateButton1Clicked:(id)sender;
- (IBAction)changeDueDateButtonClicked:(id)sender;
- (IBAction)tabBarButtonsPressed:(id)sender;

- (void) showProgressHud;
- (void) hideProgressHud;

@property (nonatomic, strong) IBOutlet UITextField *textFieldName;
@property (nonatomic, strong) IBOutlet UITextField *textFieldNotes;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldPriority;
@property (nonatomic, strong) IBOutlet UITextField *textFieldEstimatedMinutes;


@end
