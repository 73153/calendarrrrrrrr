//
//  ProfileViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
@interface ProfileViewController : UIViewController<UITabBarDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CustomKeyboardDelegate,UITextFieldDelegate>
{
    CustomKeyboard *customKeyboard;
}


@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMenuButton;
@property(strong,nonatomic)NSMutableDictionary *  mainProfileDictData;

@property (nonatomic) UIImagePickerController *imagePickerController;
@property (nonatomic, strong) IBOutlet UILabel *txtEmailid;
@property (nonatomic, strong) IBOutlet UILabel *txtPhone;
@property (nonatomic, strong) IBOutlet UILabel *txtMobile;
@property (nonatomic, strong) IBOutlet UILabel *txtLinked;
@property (nonatomic, strong) IBOutlet UILabel *txtSkype;
@property (weak, nonatomic) IBOutlet UILabel *txtTwitter;
@property (weak, nonatomic) IBOutlet UILabel *txtGoogle;
@property (weak, nonatomic) IBOutlet UILabel *txtFacebook;

@property (nonatomic, strong) IBOutlet UILabel *txtInstagram;
@property (nonatomic, strong) IBOutlet UILabel *txtName;
@property (nonatomic, strong) IBOutlet UILabel *txtGender;
@property (nonatomic, strong) IBOutlet UILabel *txtAddress;
@property (nonatomic, strong) IBOutlet UILabel *txtBirthDate;
@property (nonatomic, strong) IBOutlet UIImageView *profileImage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnEditProfile;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnChangePassword;

@property (weak, nonatomic) IBOutlet UIButton *profileButtonImage;

@property (nonatomic, strong) IBOutlet UIButton *btnEditProfile;
@property (nonatomic, strong) IBOutlet UIButton *btnChangePasword;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) NSDate *selectedDate;
@property (weak, nonatomic) IBOutlet UIButton *roundedCornerCalceBtn;

@property (weak, nonatomic) IBOutlet UIButton *roundedCornerSaveBtn;

/*       Password PopUop   */
@property (weak, nonatomic) IBOutlet UIScrollView *passwordScrollView;
@property (weak, nonatomic) IBOutlet UITextField *txtOldPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtNewPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtConfirmPassword;
@property (weak, nonatomic) IBOutlet UIView *popUpViewPassword;
- (IBAction)btnPasswordCancelClicked:(id)sender;
- (IBAction)btnPasswordSaveClicked:(id)sender;


- (void) changePasswordSuccess:(NSNotification *)notification;
- (void) changePasswordFailed:(NSNotification *)notification;
- (IBAction)onProfilePicClicked:(id)sender;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;

- (IBAction)btnEditProfileClicked:(id)sender;
- (IBAction)btnChangePaswordClicked:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;

- (NSString *)encodeToBase64String:(UIImage *)image;
- (void)getUserProfileSuccess:(NSNotification *)notification;
- (void)getUserProfileFailed:(NSNotification *)notification;
@end
