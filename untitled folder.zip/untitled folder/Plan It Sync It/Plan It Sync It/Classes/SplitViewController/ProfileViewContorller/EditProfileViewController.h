//
//  EditProfileViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "CustomKeyboard.h"
#import "PECropViewController.h"
#import "SearchViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>

@interface EditProfileViewController : UIViewController<UITabBarDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CustomKeyboardDelegate,UITextInputDelegate, PECropViewControllerDelegate, UIActionSheetDelegate,SearchDelegate>
{
    CustomKeyboard *customKeyboard;
}

@property (nonatomic, strong) SearchViewController *searchTableController;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;

@property (nonatomic) UIImagePickerController *imagePickerController;

@property (nonatomic, strong) IBOutlet UITextField *txtfield1;
@property (nonatomic, strong) IBOutlet UITextField *txtfield2;
@property (nonatomic, strong) IBOutlet UITextField *txtfield3;
@property (nonatomic, strong) IBOutlet UITextField *txtfield4;
@property (nonatomic, strong) IBOutlet UITextField *txtfield5;
@property (nonatomic, strong) IBOutlet UITextField *txtfield7;
@property (nonatomic, strong) IBOutlet UITextField *txtfield8;
@property (nonatomic, strong) IBOutlet UITextField *txtfield9;
@property (nonatomic, strong) IBOutlet UITextField *txtfield10;
@property (nonatomic, strong) IBOutlet UITextField *txtfield11;
@property (nonatomic, strong) IBOutlet UITextField *txtfield12;

@property (weak, nonatomic) IBOutlet UIButton *profileButtonImage;
@property (weak, nonatomic) IBOutlet UIImageView *profileImage;

@property (nonatomic, strong) IBOutlet UIButton *btnBack;
@property (nonatomic, strong) IBOutlet UIButton *roundedBtnbtnSave;
@property (weak, nonatomic) IBOutlet UIButton *btnDOB;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) NSDate *selectedDate;
@property (nonatomic, strong) NSDictionary *oldDictionary;

@property (nonatomic, strong) NSDictionary *imagePathAndNameDict;


@property (nonatomic, strong) IBOutlet UIView *pickerBackGroundView;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarCancel;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarDone;
@property (nonatomic, strong) IBOutlet UILabel  *lblDate;
@property (nonatomic, strong) IBOutlet UIButton *btnChangeDate;
@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;

@property (nonatomic, strong) IBOutlet UIButton *btnMale;
@property (nonatomic, strong) IBOutlet UIButton *btnFemale;
- (IBAction)tabBarButtonsPressed:(id)sender;

- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnSaveClicked:(id)sender;
- (IBAction)changeDatePressed:(id)sender;
- (IBAction)onProfilePicClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)toggleRadioButton:(id)sender;
- (IBAction)buttonPressed:(id)sender;
- (IBAction)btnClearDateFieldPressed:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;
- (void) editProfileSuccess:(NSNotification *)notification;
- (void) editProfileFailed:(NSNotification *)notification;
@end
