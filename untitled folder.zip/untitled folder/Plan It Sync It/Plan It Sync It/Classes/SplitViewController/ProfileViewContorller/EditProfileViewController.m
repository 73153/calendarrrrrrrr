//
//  EditProfileViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "EditProfileViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "ProfileViewController.h"
#import "MBProgressHUD.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "UIImage+fixOrientation.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "MNAutoComplete.h"
#import "UIImage+fixOrientation.h"
#import "PECropViewController.h"
#import "Base64.h"
#import "DateHandler.h"
#import "TextValidator.h"

@interface EditProfileViewController ()
{
    NSString *maleOrFemale;
    MNAutoComplete *_autoComplete;
    NSString *imageStringAfterCrop;
    
    
    NSString *currentDateFormat;
    
    
    NSString *date1FormatToSend;
    NSString *date2FormatToSend;
    NSString *date3FormatToSend;
    NSString *date4FormatToSend;
    NSString *date5FormatToSend;
}

@end

@implementation EditProfileViewController
@synthesize txtfield1;
@synthesize txtfield2;
@synthesize txtfield3;
@synthesize txtfield4;
@synthesize txtfield5;
@synthesize txtfield7;
@synthesize txtfield8;
@synthesize txtfield9;
@synthesize txtfield10;
@synthesize txtfield11;
@synthesize txtfield12;
@synthesize profileButtonImage;
@synthesize btnMale;
@synthesize btnFemale;
@synthesize btnBack;
@synthesize roundedBtnbtnSave;

@synthesize scrollView;
@synthesize selectedDate;

@synthesize oldDictionary;

@synthesize lblDate;
@synthesize btnChangeDate;
@synthesize datePicker;
@synthesize btnDOB;
@synthesize pickerBackGroundView;
@synthesize btnBarCancel;
@synthesize btnBarDone;
@synthesize profileImage;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize imagePathAndNameDict;
-(void)viewDidLoad
{
    [self hideProgressHud];
    
    
    [self loadAutocompletandSearchTable];
    [self setTitle:@"Edit Profile"];
    
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Edit Profile"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    profileImage.layer.masksToBounds = YES;
    profileImage.layer.cornerRadius = 10.0;
    profileImage.layer.borderColor = [UIColor whiteColor].CGColor;
    profileImage.layer.borderWidth = 3.0f;
    profileImage.layer.shouldRasterize = YES;
    profileImage.clipsToBounds = YES;
    
    //    roundedBtnbtnSave.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnbtnSave.layer.borderWidth = 2.0f;
    
    roundedBtnbtnSave.clipsToBounds=YES;
    roundedBtnbtnSave.layer.cornerRadius=5;
    
    [txtfield3 setUserInteractionEnabled:false];
    
    
    // Create a tab bar and set it as root view for the application
    [datePicker setMaximumDate:[NSDate date]];
    [txtfield1 setReturnKeyType:UIReturnKeyNext];
    [txtfield2 setReturnKeyType:UIReturnKeyNext];
    [txtfield4 setReturnKeyType:UIReturnKeyNext];
    [txtfield5 setReturnKeyType:UIReturnKeyDone];
    [txtfield7 setReturnKeyType:UIReturnKeyNext];
    [txtfield8 setReturnKeyType:UIReturnKeyNext];
    [txtfield9 setReturnKeyType:UIReturnKeyNext];
    [txtfield10 setReturnKeyType:UIReturnKeyNext];
    [txtfield11 setReturnKeyType:UIReturnKeyNext];
    [txtfield12 setReturnKeyType:UIReturnKeyDone];
    maleOrFemale = @"M";
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1260)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1600)];
    }
    
    txtfield1.tag = 1;
    txtfield2.tag = 2;
    txtfield4.tag=4;
    txtfield5.tag = 5;
    txtfield7.tag=7;
    txtfield8.tag=8;
    txtfield9.tag=9;
    txtfield10.tag=10;
    txtfield11.tag=11;
    txtfield12.tag=12;
    [[btnDOB layer] setBorderWidth:1.0f];
    [[btnDOB layer] setOpacity:0.2];
    
    [[btnDOB layer] setBorderColor:[UIColor grayColor].CGColor];
    btnDOB.layer.cornerRadius = 5; // this value vary as per your desire
    btnDOB.clipsToBounds = YES;
    
    NSString *userImage = [[NSUserDefaults standardUserDefaults] valueForKey:kUserImage];
    if(![userImage isEqualToString:@""] && ![userImage isEqualToString:nil]){
        
        profileImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString: userImage]]];
    }
    else
    {
        profileImage.image = [UIImage imageNamed:@"profile.png"];
    }
    
    txtfield1.delegate = self;
    txtfield2.delegate = self;
    txtfield4.delegate = self;
    txtfield5.delegate = self;
    txtfield7.delegate = self;
    txtfield8.delegate = self;
    txtfield9.delegate = self;
    txtfield10.delegate = self;
    txtfield11.delegate = self;
    txtfield12.delegate = self;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    profileImage.layer.masksToBounds = YES;
    profileImage.layer.cornerRadius = 10.0;
    profileImage.layer.borderColor = [UIColor whiteColor].CGColor;
    profileImage.layer.borderWidth = 3.0f;
    profileImage.layer.shouldRasterize = YES;
    profileImage.clipsToBounds = YES;
    
    imagePathAndNameDict = [[NSMutableDictionary alloc] init];
    
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    txtfield1.autocapitalizationType = UITextAutocapitalizationTypeWords;
    //    txtNote.autocapitalizationType = UITextAutocapitalizationTypeWords;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(editProfileSuccess:) name:kEditProfileSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(editProfileFailed:) name:kEditProfileFailed object:nil];
    
}
-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (BOOL) textView: (UITextView*) textView
shouldChangeTextInRange: (NSRange) range
  replacementText: (NSString*) text
{
    if ([text isEqualToString:@"\n"]) {
        [[textView layer] setOpacity:1];
        textView.text = [textView.text stringByReplacingOccurrencesOfString: @"\\n" withString: @"\n"];
        
        return YES;
    }
    return YES;
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
        
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    selectedDate = [NSDate date];
    if(oldDictionary){
        txtfield1.text = [oldDictionary objectForKey:@"name"];
        txtfield2.text = [oldDictionary objectForKey:@"phone"];
        
        txtfield3.text = [[NSUserDefaults standardUserDefaults] objectForKey:kUserMobileNumber];
        
        txtfield4.text = [oldDictionary objectForKey:@"address"];
        txtfield5.text = [oldDictionary objectForKey:@"zip"];
        
        NSString *dateString = [oldDictionary objectForKey:@"birthday"];
        
        if(![dateString isEqualToString:@""] ){
            NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
            NSDate *dateFromString = [[NSDate alloc] init];
            dateFromString =  [dateFormatter dateFromString:dateString];
            datePicker.date = dateFromString;
            
            NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
            if([dateFormatStr isEqualToString:@""] ){
                lblDate.text=@"";
            }
            lblDate.text = [DateHandler getDateFromString:dateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
            
        }else{
            lblDate.text=@"Birth date";
            [[lblDate layer] setOpacity:0.2];
        }
        if([dateString isEqualToString:@""])
            lblDate.text=@"";
        maleOrFemale =  [oldDictionary objectForKey:@"gender"];
        
        if ([maleOrFemale isEqualToString:@"M"])
        {
            maleOrFemale = @"M";
            [btnMale setBackgroundImage:nil forState:UIControlStateNormal];
            [btnFemale setBackgroundImage:nil forState:UIControlStateNormal];
            
            [btnMale setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
            [btnFemale setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
        }
        else{
            
            maleOrFemale = @"F";
            [btnFemale setBackgroundImage:nil forState:UIControlStateNormal];
            [btnMale setBackgroundImage:nil forState:UIControlStateNormal];
            
            [btnFemale setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
            [btnMale setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
            
        }
        
        if([maleOrFemale isEqualToString:@"M"]){
            [btnMale setBackgroundImage:nil forState:UIControlStateNormal];
            [btnFemale setBackgroundImage:nil forState:UIControlStateNormal];
            
            [btnMale setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
            [btnFemale setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
        }
        else{
            [btnFemale setBackgroundImage:nil forState:UIControlStateNormal];
            [btnMale setBackgroundImage:nil forState:UIControlStateNormal];
            
            [btnFemale setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
            [btnMale setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
        }
        txtfield5.text = [oldDictionary objectForKey:@"zipcode"];
        txtfield7.text = [oldDictionary objectForKey:@"twitter"];
        txtfield8.text = [oldDictionary objectForKey:@"facebook"];
        txtfield9.text = [oldDictionary objectForKey:@"gplus"];
        txtfield10.text = [oldDictionary objectForKey:@"linkedin"];
        txtfield11.text = [oldDictionary objectForKey:@"skype"];
        txtfield12.text = [oldDictionary objectForKey:@"instagram"];
        
        
        
        //        lblDate.text =   [oldDictionary objectForKey:@"birthday"];
        //        profileImage.image = [UIImage imageWithContentsOfFile:@"http://dev.planitsyncit.com/uploaded/143758ee65fb29d30caa170c0db0ed36/images/ukzKaLZWfp.jpg"];
    }
    else{
        txtfield1.text = @"";
        txtfield2.text = @"";
        txtfield3.text = @"";
        txtfield4.text = @"";
        txtfield5.text = @"";
        txtfield7.text = @"";
        txtfield8.text = @"";
        txtfield9.text = @"";
        txtfield10.text = @"";
        txtfield11.text = @"";
        txtfield12.text = @"";
        
        //Todays date.
        lblDate.text = @"Birth Date";
        [[lblDate layer]setOpacity:0.2];
    }
}

- (IBAction)onProfilePicClicked:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Photo Library", @"Saved Album", nil];
    actionSheet.tag = 1;
    [actionSheet showInView:self.view];
    //    [self presentViewController:self.imagePickerController animated:NO completion:nil];
}
#pragma mark UIActionSheet delegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    if ([@"Camera" isEqualToString:title] && [UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([@"Photo Library" isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else if ([@"Saved Album" isEqualToString:title]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    }
    
}

#pragma mark UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    UIImage *originalImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    imagePathAndNameDict = [info mutableCopy];
    
    NSData *webData = UIImagePNGRepresentation(originalImage);
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *mediaType = [info objectForKey: UIImagePickerControllerMediaType];
    NSURL *assetURL = [info objectForKey:UIImagePickerControllerReferenceURL];
    
    ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *imageAsset)
    {
        ALAssetRepresentation *imageRep = [imageAsset defaultRepresentation];
        NSLog(@"[imageRep filename] : %@", [imageRep filename]);
    };
    
    ALAssetsLibrary* assetslibrary = [[ALAssetsLibrary alloc] init];
    [assetslibrary assetForURL:assetURL resultBlock:resultblock failureBlock:nil];
    
    NSString *localFilePath = [documentsDirectory stringByAppendingPathComponent:@"image.png"];
    [webData writeToFile:localFilePath atomically:YES];
    NSLog(@"localFilePath.%@",localFilePath);
#ifdef DEV_ENVIRONMENT
    NSLog (@"Image Size, %f, %f", originalImage.size.width, originalImage.size.height
           );
#endif
    
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        [self openCropEditor:[[UIImage memoryOptimizedImageWithImage:originalImage] fixOrientation]];
    }];
}

#pragma mark photo cropper
-(void) openCropEditor:(UIImage *) image {
    PECropViewController *controller = [[PECropViewController alloc] init];
    controller.delegate = self;
    controller.image = image;
    controller.cropAspectRatio = 1;
    
    controller.keepingCropAspectRatio = YES;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:controller];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        navigationController.modalPresentationStyle = UIModalPresentationFormSheet;
    }
    
    [self presentViewController:navigationController animated:YES completion:NULL];
}

- (void)cropViewController:(PECropViewController *)controller didFinishCroppingImage:(UIImage *)croppedImage {
    
    [controller dismissViewControllerAnimated:YES completion:NULL];
    profileImage.image=croppedImage;
    [Base64 initialize];
    CGSize imageViewSize = profileImage.frame.size;
    
    UIGraphicsBeginImageContext(imageViewSize);
    [croppedImage drawInRect:CGRectMake(0,0,imageViewSize.width,imageViewSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    
    NSData *imageData = UIImageJPEGRepresentation(newImage, 1);
    NSString *strEncoded = [Base64 encode:imageData];
    
    imageStringAfterCrop = strEncoded;
}
//lowering the image quality
- (void)encodePhotoInBackground:(UIImage*)image {
    
}

//saving image data
- (void)saveImageData:(NSData*)imageData2 {
    // Do something with the image
    //image byte array
    
    [Base64 initialize];
    NSString *strEncoded = [Base64 encode:imageData2];
    NSString * loginString = [NSString stringWithFormat:@"%@%@",imageStringAfterCrop,strEncoded];
    imageStringAfterCrop=@"";
    imageStringAfterCrop=loginString;
}


-(NSString *)imageToNSString:(UIImage *)image
{
    NSData *imageData = UIImageJPEGRepresentation(image, 1);
    
    return [imageData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
}

- (UIImage *)decodeBase64ToImage:(NSString *)strEncodeData {
    NSData *data = [[NSData alloc]initWithBase64EncodedString:strEncodeData options:NSDataBase64DecodingIgnoreUnknownCharacters];
    return [UIImage imageWithData:data];
}
- (NSString *)encodeToBase64String:(UIImage *)image {
    return [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
}

-(void) cropViewControllerDidCancel:(PECropViewController *)controller {
    [controller dismissViewControllerAnimated:YES completion:NULL];
}


#pragma  mark ************** UiTextField Delegate ******************
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 12;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    if(textField==txtfield5){
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
    }
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}
- (void)nextClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [txtfield1 resignFirstResponder];
            [txtfield2 becomeFirstResponder];
        }
            break;
            
        case 2: {
            [txtfield2 resignFirstResponder];
        }
            break;
            
        case 4: {
            [txtfield4 becomeFirstResponder];
        }
            break;
            
        case 5: {
            [txtfield4 resignFirstResponder];
            
            [txtfield5 becomeFirstResponder];
        }
            break;
        case 7: {
            [txtfield5 resignFirstResponder];
            [txtfield7 resignFirstResponder];
            [txtfield8 becomeFirstResponder];
        }
            break;
        case 8: {
            [txtfield4 resignFirstResponder];
            
            [txtfield8 resignFirstResponder];
            [txtfield9 becomeFirstResponder];
        }
            break;
        case 9: {
            [txtfield4 resignFirstResponder];
            
            [txtfield9 resignFirstResponder];
            [txtfield10 becomeFirstResponder];
        }
            break;
        case 10: {
            [txtfield4 resignFirstResponder];
            
            [txtfield10 resignFirstResponder];
            [txtfield11 becomeFirstResponder];
        }
            break;
        case 11: {
            [txtfield4 resignFirstResponder];
            
            [txtfield11 resignFirstResponder];
            [txtfield12 becomeFirstResponder];
        }
            break;
        case 12: {
            [txtfield4 resignFirstResponder];
            [self.searchTableController toggleHidden:YES];
            
            [txtfield12 resignFirstResponder];
            //            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
            
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
            [txtfield1 resignFirstResponder];
        }
            break;
        case 2: {
            [txtfield1 becomeFirstResponder];
            [txtfield2 resignFirstResponder];
            
        }
            break;
            
        case 4: {
            [txtfield2 becomeFirstResponder];
            [txtfield4 resignFirstResponder];
        }
            break;
        case 5: {
            [txtfield4 becomeFirstResponder];
            [txtfield5 resignFirstResponder];
            
        }
            break;
            
        case 7: {
            [txtfield5 becomeFirstResponder];
            [txtfield7 resignFirstResponder];
        }
            break;
        case 8: {
            [txtfield8 resignFirstResponder];
        }
            break;
        case 9: {
            [txtfield8 becomeFirstResponder];
            [txtfield9 resignFirstResponder];
        }
            break;
        case 10: {
            [txtfield9 becomeFirstResponder];
            [txtfield10 resignFirstResponder];
        }
            break;
        case 11: {
            [txtfield10 becomeFirstResponder];
            [txtfield11 resignFirstResponder];
        }
            break;
        case 12: {
            [txtfield11 becomeFirstResponder];
            [txtfield12 resignFirstResponder];
        }
            break;
            
            
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
    [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([txtfield1 isFirstResponder]) {
                [txtfield1 resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([txtfield2 isFirstResponder]) {
                [txtfield2 resignFirstResponder];
            }
        }
            break;
            
            
        case 4: {
            if ([txtfield4 isFirstResponder]) {
                [txtfield4 resignFirstResponder];
            }
        }
            break;
            
        case 5: {
            if ([txtfield5 isFirstResponder]) {
                [txtfield5 resignFirstResponder];
            }
        }
            break;
        case 7: {
            if ([txtfield7 isFirstResponder]) {
                [txtfield7 resignFirstResponder];
            }
        }
            break;
        case 8: {
            if ([txtfield8 isFirstResponder]) {
                [txtfield8 resignFirstResponder];
            }
        }
            break;
        case 9: {
            if ([txtfield9 isFirstResponder]) {
                [txtfield9 resignFirstResponder];
            }
        }
            break;
        case 10: {
            if ([txtfield10 isFirstResponder]) {
                [txtfield10 resignFirstResponder];
            }
        }
            break;
        case 11: {
            if ([txtfield11 isFirstResponder]) {
                [txtfield11 resignFirstResponder];
            }
        }
            break;
        case 12: {
            if ([txtfield12 isFirstResponder]) {
                [txtfield12 resignFirstResponder];
                //                [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
            }
        }
            break;
            
        default: {
        }
            break;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField == txtfield1){
        [txtfield1 resignFirstResponder];
        [txtfield2 becomeFirstResponder];
    }
    else if(textField == txtfield2){
        [txtfield2 resignFirstResponder];
    }
    else if(textField == txtfield5){
        [txtfield5 resignFirstResponder];
    }
    
    else if(textField == txtfield7){
        [txtfield7 resignFirstResponder];
        [txtfield8 becomeFirstResponder];
    }
    else if(textField == txtfield8){
        [txtfield8 resignFirstResponder];
        [txtfield9 becomeFirstResponder];
    }
    else if(textField == txtfield9){
        [txtfield9 resignFirstResponder];
        [txtfield10 becomeFirstResponder];
    }
    else if(textField == txtfield10){
        [txtfield10 resignFirstResponder];
        [txtfield11 becomeFirstResponder];
    }
    else if(textField == txtfield11){
        [txtfield11 resignFirstResponder];
        [txtfield12 becomeFirstResponder];
    }
    else if(textField == txtfield12){
        [txtfield12 resignFirstResponder];
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    return YES;
}
- (BOOL)textField:(UITextField *) textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    if ([textField.text length] >= 2 && txtfield4==textField) {
        [self.searchTableController toggleHidden:NO];
        [_autoComplete startWithKeyword:textField.text];
    }
    if (textField.text.length<=1 && txtfield4==textField) {
        
        [self.searchTableController toggleHidden:YES];
    }
    else if(textField == txtfield2){
        if ([textField.text length] > 11) {
            textField.text = [textField.text substringToIndex:11-1];
            return NO;
        }
    }
    else if(textField == txtfield5){
        if ([textField.text length] > 6) {
            textField.text = [textField.text substringToIndex:6-1];
            return NO;
        }
    }
    
    return YES;
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    if (textField==txtfield4)
    {
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,(txtfield5.frame.origin.y)-150,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        
        NSArray *sourceArray = [NSMutableArray arrayWithArray:[self getSearchHistory]];
        [self.searchTableController reloadDataWithSource:sourceArray];
        
        return YES;
    }
    
    if(textField == txtfield5){
        [self.searchTableController toggleHidden:YES];
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtfield5.frame.origin.y-30,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    else if(textField == txtfield7){
        
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtfield7.frame.origin.y-100,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == txtfield8){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtfield8.frame.origin.y+200,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == txtfield9){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtfield9.frame.origin.y+300,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == txtfield10){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtfield10.frame.origin.y+340,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == txtfield11){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtfield11.frame.origin.y+380,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == txtfield12){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,txtfield12.frame.origin.y+440,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    return YES;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btnSaveClicked:(id)sender{
    
    if ([txtfield1 isFirstResponder]) {
        [txtfield1 resignFirstResponder];
    }
    else if ([txtfield2 isFirstResponder]) {
        [txtfield2 resignFirstResponder];
    }
    else if ([txtfield4 isFirstResponder]) {
        [txtfield4 resignFirstResponder];
    }
    else if ([txtfield5 isFirstResponder]) {
        [txtfield5 resignFirstResponder];
    }
    else if ([txtfield7 isFirstResponder]) {
        [txtfield7 resignFirstResponder];
    }
    else if ([txtfield8 isFirstResponder]) {
        [txtfield8 resignFirstResponder];
    }
    else if ([txtfield9 isFirstResponder]) {
        [txtfield9 resignFirstResponder];
    }
    else if ([txtfield10 isFirstResponder]) {
        [txtfield10 resignFirstResponder];
    }
    else if ([txtfield11 isFirstResponder]) {
        [txtfield11 resignFirstResponder];
    }
    else if ([txtfield12 isFirstResponder]) {
        [txtfield12 resignFirstResponder];
    }
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:@"userid"];
    if([txtfield1.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 || txtfield1.text.length<1){
        [self.view makeToast:@"Please enter full name"];
        return;
    }
    
    
    [dataDictionary setObject:txtfield1.text forKey:@"name"];
    [dataDictionary setObject:txtfield2.text forKey:@"phone"];
    [dataDictionary setObject:txtfield4.text forKey:@"address"];
    [dataDictionary setObject:txtfield5.text forKey:@"zip"];
    if([lblDate.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        lblDate.text=@"";
    }
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    
    NSString *dobToSend = lblDate.text;
    if(dobToSend.length>1)
        dobToSend = [DateHandler sendDateFromString:dobToSend formatToSend:@"" currentDateFormat:dateFormatStr];
    
    [dataDictionary setObject:dobToSend forKey:@"dob"];
    if([maleOrFemale isEqualToString:@"M"])
    {
        maleOrFemale=@"M";
        [dataDictionary setObject:maleOrFemale forKey:@"gender"];
    }
    else if([maleOrFemale isEqualToString:@"F"])
    {
        maleOrFemale=@"F";
        [dataDictionary setObject:maleOrFemale forKey:@"gender"];
        
    }
    //     if([TextValidator isValidEmail:txtfield7.text]==false && ![txtfield7.text isEqualToString:@""]){
    //
    //        [self.view makeToast:@"Please enter correct twitter email address"];
    //        return;
    //    }
    //    else if([TextValidator isValidEmail:txtfield8.text]==false  && ![txtfield8.text isEqualToString:@""]){
    //
    //        [self.view makeToast:@"Please enter correct facebook email address"];
    //        return;
    //    }
    //    else if([TextValidator isValidEmail:txtfield9.text]==false  && ![txtfield9.text isEqualToString:@""]){
    //
    //        [self.view makeToast:@"Please enter correct gplus email address"];
    //        return;
    //    }
    //    else if([TextValidator isValidEmail:txtfield10.text]==false  && ![txtfield10.text isEqualToString:@""]){
    //
    //        [self.view makeToast:@"Please enter correct linkedin email address"];
    //        return;
    //    }
    //    else if([TextValidator isValidEmail:txtfield11.text]==false  && ![txtfield11.text isEqualToString:@""]){
    //
    //        [self.view makeToast:@"Please enter correct skype email address"];
    //        return;
    //    }
    //    else if([TextValidator isValidEmail:txtfield12.text]==false  && ![txtfield12.text isEqualToString:@""]){
    //
    //        [self.view makeToast:@"Please enter correct instagram email address"];
    //        return;
    //    }
    [dataDictionary setObject:txtfield7.text forKey:@"twitter"];
    [dataDictionary setObject:txtfield8.text forKey:@"facebook"];
    [dataDictionary setObject:txtfield9.text forKey:@"gplus"];
    [dataDictionary setObject:txtfield10.text forKey:@"linkedin"];
    [dataDictionary setObject:txtfield11.text forKey:@"skype"];
    [dataDictionary setObject:txtfield12.text forKey:@"instagram"];
    
    
    if(!([imageStringAfterCrop isEqualToString:@""]) && imageStringAfterCrop != nil)
    {
        [dataDictionary setObject:imageStringAfterCrop forKey:@"image"];
    }
    
    [self showProgressHud];
    
    [[WebService sharedWebService] callEditProfileWebService:dataDictionary];
}

- (IBAction)changeDatePressed:(id)sender {
    if ([txtfield1 isFirstResponder]) {
        [txtfield1 resignFirstResponder];
    }
    else if ([txtfield2 isFirstResponder]) {
        [txtfield2 resignFirstResponder];
    }
    else if ([txtfield4 isFirstResponder]) {
        [txtfield4 resignFirstResponder];
    }
    else if ([txtfield5 isFirstResponder]) {
        [txtfield5 resignFirstResponder];
    }
    else if ([txtfield7 isFirstResponder]) {
        [txtfield7 resignFirstResponder];
    }
    else if ([txtfield8 isFirstResponder]) {
        [txtfield8 resignFirstResponder];
    }
    else if ([txtfield9 isFirstResponder]) {
        [txtfield9 resignFirstResponder];
    }
    else if ([txtfield10 isFirstResponder]) {
        [txtfield10 resignFirstResponder];
    }
    else if ([txtfield11 isFirstResponder]) {
        [txtfield11 resignFirstResponder];
    }
    else if ([txtfield12 isFirstResponder]) {
        [txtfield12 resignFirstResponder];
    }
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    [UIView commitAnimations];
}


- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}
- (IBAction)doneButtonClicked:(id)sender{
    selectedDate = [datePicker date];
    [[lblDate layer]setOpacity:1];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
        dateFormatStr = @"dd/MM/yyyy";
    lblDate.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}


- (IBAction)toggleRadioButton:(id)sender{
    if([sender tag] == 101){
        maleOrFemale = @"M";
        [btnMale setBackgroundImage:nil forState:UIControlStateNormal];
        [btnFemale setBackgroundImage:nil forState:UIControlStateNormal];
        
        [btnMale setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
        [btnFemale setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    }
    else{
        maleOrFemale = @"F";
        [btnFemale setBackgroundImage:nil forState:UIControlStateNormal];
        [btnMale setBackgroundImage:nil forState:UIControlStateNormal];
        
        
        [btnFemale setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
        [btnMale setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    }
}

- (IBAction)buttonPressed:(id)sender {
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Photo Library", @"Saved Album", nil];
    actionSheet.tag = 1;
    [actionSheet showInView:self.view];
}

- (IBAction)btnClearDateFieldPressed:(id)sender {
    lblDate.text=@"";
}


#pragma mark AutoCompletePlace

-(void)loadAutocompletandSearchTable{
    _autoComplete = [[MNAutoComplete alloc] initWithDelegate:self];
    self.searchTableController = [[SearchViewController alloc] initWithStyle:UITableViewStylePlain];
    
    self.searchTableController.tableView.frame = CGRectMake(txtfield4.frame.origin.x,txtfield4.frame.origin.y+35, txtfield4.frame.size.width,pickerBackGroundView.frame.size.height);
    self.searchTableController.view.layer.zPosition = 100;
    
    self.searchTableController.delegate = self;
    [scrollView addSubview:self.searchTableController.tableView];
    [self.searchTableController toggleHidden:YES];
    
    self.searchTableController.tableView.layer.borderWidth = 2;
    self.searchTableController.tableView.layer.borderColor = [[UIColor blackColor] CGColor];
    
}


#pragma mark -
#pragma mark - WebService
#pragma mark -
- (void) editProfileSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    //    [self.view makeToast:[response objectForKey:@"message"]];
    NSDictionary *profileDataDict = [dictionary objectForKey:@"data"];
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (void) editProfileFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
}


#pragma mark - Search Delegate
-(void)didSelectSearchedString:(NSString *)selectedString{
    NSLog(@"SELECTED %@",selectedString);
    txtfield4.text=selectedString;
    [self.searchTableController toggleHidden:YES];
}

#pragma mark - Autocomplete Delegate
- (void)autocompleteDidReturn:(NSArray *)results {
    NSLog(@"results %@",results);
    [self.searchTableController reloadDataWithSource:results];
}

-(void)autocompleteDidFailWithError:(NSError *)error{
    
}

//hide keyboard
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.searchTableController toggleHidden:YES];
    
}


#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
-(NSArray *)getSearchHistory{
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"SEARCH_HISTORY"];
}


@end
