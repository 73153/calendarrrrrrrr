//
//  ProfileViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "EditProfileViewController.h"
#import "MBProgressHUD.h"
#import "InboxMessageViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"

#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "DateHandler.h"
#import "UIImage+Helpers.h"
#import "AFHTTPRequestOperation.h"
#import "AFHTTPRequestOperationManager.h"

@interface ProfileViewController ()
{
    NSString *maleOrFemale;
    
}

@end

@implementation ProfileViewController
@synthesize txtEmailid;
@synthesize txtPhone;
@synthesize txtMobile;
@synthesize txtLinked;
@synthesize txtSkype;
@synthesize txtInstagram;
@synthesize txtName;
@synthesize txtGender;
@synthesize txtAddress;
@synthesize txtBirthDate;
@synthesize profileImage;
@synthesize profileButtonImage;
@synthesize  btnChangePasword;
@synthesize scrollView;
@synthesize selectedDate;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnChangePassword;
@synthesize roundedBtnEditProfile;
@synthesize mainProfileDictData;
@synthesize passwordScrollView;
@synthesize txtConfirmPassword;
@synthesize txtNewPassword;
@synthesize txtOldPassword;
@synthesize popUpViewPassword;
@synthesize roundedCornerCalceBtn;
@synthesize roundedCornerSaveBtn;
@synthesize txtFacebook;
@synthesize txtGoogle;
@synthesize txtTwitter;
-(void)viewDidLoad
{
    // Create a tab bar and set it as root view for the application
    [self hideProgressHud];
    maleOrFemale = @"M";
    //    roundedBtnChangePassword.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnChangePassword.layer.borderWidth = 2.0f;
    roundedBtnChangePassword.clipsToBounds=YES;
    roundedBtnChangePassword.layer.cornerRadius = 5;
    
    //    roundedBtnEditProfile.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnEditProfile.layer.borderWidth = 2.0f;
    roundedBtnEditProfile.clipsToBounds=YES;
    roundedBtnEditProfile.layer.cornerRadius = 5;
    popUpViewPassword.hidden=true;
    mainProfileDictData = [[NSMutableDictionary alloc] init];
    
    popUpViewPassword.layer.borderColor = [UIColor blackColor].CGColor;
    popUpViewPassword.layer.borderWidth = 2.0f;
    
    popUpViewPassword.layer.cornerRadius=5;
    popUpViewPassword.clipsToBounds=YES;
    
    roundedCornerCalceBtn.clipsToBounds = YES;
    roundedCornerCalceBtn.layer.cornerRadius = 5.0;
    
    roundedCornerCalceBtn.clipsToBounds = YES;
    roundedCornerCalceBtn.layer.cornerRadius = 5.0;
    
    roundedCornerSaveBtn.clipsToBounds = YES;
    roundedCornerSaveBtn.layer.cornerRadius = 5.0;
    
    txtOldPassword.tag = 1;
    txtOldPassword.delegate = self;
    txtOldPassword.secureTextEntry=true;
    txtNewPassword.tag = 2;
    txtNewPassword.delegate = self;
    txtNewPassword.secureTextEntry=true;
    
    txtConfirmPassword.tag = 3;
    txtConfirmPassword.delegate = self;
    txtConfirmPassword.secureTextEntry=true;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    //    [self setTitle:@"Profile"];
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Profile"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    
    self.title = @"Profile";
    
    // Init views with rects with height and y pos
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationItem.titleView = titleView;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,900)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1600)];
    }
    btnChangePasword.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
    // you probably want to center it
    btnChangePasword.titleLabel.textAlignment = NSTextAlignmentCenter; // if you want to
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    profileImage.layer.masksToBounds = YES;
    profileImage.layer.cornerRadius = 10.0;
    profileImage.layer.borderColor = [UIColor whiteColor].CGColor;
    profileImage.layer.borderWidth = 3.0f;
    profileImage.layer.shouldRasterize = YES;
    profileImage.clipsToBounds = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getUserProfileSuccess:) name:kGetUserProfileSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getUserProfileFailed:) name:kGetUserProfileFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changePasswordSuccess:) name:kChangePasswordSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changePasswordFailed:) name:kChangePasswordFailed object:nil];
}
-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
-(void)viewWillAppear:(BOOL)animated
{
    [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    
    selectedDate = [NSDate date];
    
    /* AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
     //    mgr.responseSerializer = [AFJSONResponseSerializer serializer];
     
     //    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://api.weibo.com/oauth2/access_token"]];
     
     //拼接参数
     NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
     
     NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
     [dataDictionary setObject:userid forKey:@"userid"];
     
     [mgr GET:@"http://dev.planitsyncit.com/app/webservices/webservices.php?action=profile" parameters:dataDictionary success:^(AFHTTPRequestOperation *operation, id responseObject) {
     [self hideProgressHud];
     NSDictionary *dictionary = responseObject;
     
     NSDictionary *maiDict = [dictionary objectForKey:@"data"];
     
     NSDictionary *profileDataDict = [maiDict objectForKey:@"user_profile"];
     
     
     [[NSUserDefaults standardUserDefaults] setObject:profileDataDict forKey:kProfileData];
     [[NSUserDefaults standardUserDefaults] synchronize];
     
     txtAddress.lineBreakMode = NSLineBreakByWordWrapping;
     //    txtAddress.numberOfLines = 0;
     [txtAddress setNumberOfLines:2];
     
     txtEmailid.text = [profileDataDict objectForKey:@"email"];
     txtName.text = [profileDataDict objectForKey:@"name"];
     
     [[NSUserDefaults standardUserDefaults] setObject:txtName.text forKey:kUserNameInMasterTable];
     [[NSUserDefaults standardUserDefaults] synchronize];
     
     NSString *imgURL=[profileDataDict objectForKey:@"user_image"];
     if(![imgURL isEqualToString:@""] && ![imgURL isEqualToString:nil]){
     [[NSUserDefaults standardUserDefaults] setValue:imgURL forKey:kUserImage];
     [[NSUserDefaults standardUserDefaults] synchronize];
     
     [UIImage loadFromURL:[NSURL URLWithString:imgURL] callback:^(UIImage *image){
     profileImage.image = image;
     }];
     
     [[NSNotificationCenter defaultCenter] postNotificationName:@"KuserImageChagedSuccess" object:@"imageChanged"];
     }
     else
     {
     
     }
     NSString *dateString = [profileDataDict objectForKey:@"birthday"];
     
     
     NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
     // this is imporant - we set our input date format to match our input string
     // if format doesn't match you'll get nil from your string, so be careful
     [dateFormatter setDateFormat:@"yyyy-MM-dd"];
     NSDate *dateFromString = [[NSDate alloc] init];
     // voila!
     dateFromString = [dateFormatter dateFromString:dateString];
     NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
     dateString = [dateString stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
     
     txtBirthDate.text = [DateHandler getDateStringFromDate:dateFromString desireDateFormat:dateFormatStr];
     if([dateString isEqualToString:@""])
     txtBirthDate.text=@"";
     
     [[NSUserDefaults standardUserDefaults] setValue:[profileDataDict objectForKey:@"mobile"] forKey:kUserMobileNumber];
     [[NSUserDefaults standardUserDefaults] synchronize];
     
     txtGender.text = [profileDataDict objectForKey:@"gender"];
     if ([txtGender.text isEqualToString:@"M"])
     txtGender.text = @"Male";
     else
     txtGender.text = @"Female";
     
     txtAddress.lineBreakMode=YES;
     txtAddress.numberOfLines=5;
     txtAddress.text = [profileDataDict objectForKey:@"address"];
     txtInstagram.text = [profileDataDict objectForKey:@"instagram"];
     txtLinked.text = [profileDataDict objectForKey:@"linkedin"];
     txtPhone.text = [profileDataDict objectForKey:@"phone"];
     txtTwitter.text = [profileDataDict objectForKey:@"twitter"];
     txtGoogle.text = [profileDataDict objectForKey:@"gplus"];
     txtFacebook.text = [profileDataDict objectForKey:@"facebook"];
     
     txtMobile.text = [[NSUserDefaults standardUserDefaults] valueForKey:kUserMobileNumber];
     txtPhone.text = [profileDataDict objectForKey:@"phone"];
     
     [[NSUserDefaults standardUserDefaults] setObject:[profileDataDict objectForKey:@"mobile"] forKey:kUserMobileNumber];
     [[NSUserDefaults standardUserDefaults] synchronize];
     txtSkype.text = [profileDataDict objectForKey:@"skype"];
     mainProfileDictData=[profileDataDict mutableCopy];
     
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
     NSLog(@"%@",error);
     [self hideProgressHud];
     NSString* ErrorResponse = [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
     [self.view makeToast:ErrorResponse];
     
     //        NSDictionary *dictionary = notification.object;
     //        if(dictionary.count<=0)
     //            return;
     //        NSDictionary *response = [dictionary objectForKey:@"meta"];
     //
     //        NSString *strMessageResponse = [response objectForKey:@"message"];
     //
     //        if(strMessageResponse.length >=15)
     //        {
     //            [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
     //        }
     //        else{
     //            [self.view makeToast:[response objectForKey:@"message"]];
     //        }
     }];
     */
    
    [self showProgressHud];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    [dataDictionary setObject:userid forKey:kUserId];
    
    [[WebService sharedWebService] callGetUserProfileDataWebService:dataDictionary];
    
}
#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
        
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)gotoEditProfilePage
{
    EditProfileViewController* controller = (EditProfileViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"eitProfileViewController"];
    controller.oldDictionary = [mainProfileDictData mutableCopy];
    
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)btnEditProfileClicked:(id)sender
{
    [self showProgressHud];
    [self performSelector:@selector(gotoEditProfilePage) withObject:self afterDelay:0.3];
    
}
- (IBAction)btnChangePaswordClicked:(id)sender
{
    popUpViewPassword.hidden=false;
    
    popUpViewPassword.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    
    [UIView animateWithDuration:0.3/1.5 animations:^{
        popUpViewPassword.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3/2 animations:^{
            popUpViewPassword.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.3/2 animations:^{
                popUpViewPassword.transform = CGAffineTransformIdentity;
            }];
        }];
    }];
    
    
    //    UIAlertController *alertController = [UIAlertController
    //                                          alertControllerWithTitle:@"Change Password"
    //                                          message:nil
    //                                          preferredStyle:UIAlertControllerStyleAlert];
    //
    //    UIAlertAction *cancelAction = [UIAlertAction
    //                                   actionWithTitle:@"Cancel"
    //                                   style:UIAlertActionStyleDefault
    //                                   handler:^(UIAlertAction *action) {
    ////                                       [self dismissViewControllerAnimated:YES completion:nil];
    //                                   }];
    //
    //    UIAlertAction *okAction = [UIAlertAction
    //                               actionWithTitle:@"Ok"
    //                               style:UIAlertActionStyleDefault
    //                               handler:^(UIAlertAction *action) {
    //                                   NSString *oldPassword =
    //                                   ((UITextField *)
    //                                    [alertController.textFields objectAtIndex:0]).text;
    //
    //                                   NSString *newPassword =
    //                                   ((UITextField *)
    //                                    [alertController.textFields objectAtIndex:1]).text;
    //
    //                                   NSString *CofirmPassword =
    //                                   ((UITextField *)
    //                                    [alertController.textFields objectAtIndex:2]).text;
    //
    //                               }];
    //
    //    [alertController
    //     addTextFieldWithConfigurationHandler:^(UITextField *textfield) {
    //         textfield.secureTextEntry = YES;
    //
    //         textfield.placeholder = @"Old Password";
    //     }];
    //
    //    [alertController
    //     addTextFieldWithConfigurationHandler:^(UITextField *textfield) {
    //         textfield.placeholder = @"New Password";
    //         textfield.secureTextEntry = YES;
    //     }];
    //
    //    [alertController
    //     addTextFieldWithConfigurationHandler:^(UITextField *textfield) {
    //         textfield.placeholder = @"Confirm Password";
    //         textfield.secureTextEntry = YES;
    //     }];
    //
    //
    //    [alertController addAction:cancelAction];
    //    [alertController addAction:okAction];
    
    
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}


#pragma mark ******************** Text Delegates ***********************

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 3;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
}
- (void)nextClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [txtOldPassword resignFirstResponder];
            [txtNewPassword becomeFirstResponder];
        }
            break;
            
        case 2: {
            [txtNewPassword resignFirstResponder];
            [txtConfirmPassword becomeFirstResponder];
            
        }
            break;
            
        case 3: {
            [txtConfirmPassword resignFirstResponder];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    switch (sender){
        case 1: {
            [txtOldPassword resignFirstResponder];
        }
            break;
            
        case 2: {
            [txtOldPassword becomeFirstResponder];
            [txtNewPassword resignFirstResponder];
            
        }
            break;
            
        case 3: {
            [txtNewPassword becomeFirstResponder];
            [txtConfirmPassword resignFirstResponder];
        }
            break;
            
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
     [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([txtOldPassword isFirstResponder]) {
                [txtOldPassword resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([txtNewPassword isFirstResponder]) {
                [txtNewPassword resignFirstResponder];
            }
        }
            break;
            
            
        case 3: {
            if ([txtConfirmPassword isFirstResponder]) {
                [txtConfirmPassword resignFirstResponder];
            }
        }
            break;
            
        default: {
        }
            break;
    }
}


- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
//hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}
#pragma mark -
#pragma mark - WebService
#pragma mark -
- (void) getUserProfileSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSDictionary *maiDict = [dictionary objectForKey:@"data"];
    
    NSDictionary *profileDataDict = [maiDict objectForKey:@"user_profile"];
    
    
    [[NSUserDefaults standardUserDefaults] setObject:profileDataDict forKey:kProfileData];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    txtAddress.lineBreakMode = NSLineBreakByWordWrapping;
    //    txtAddress.numberOfLines = 0;
    [txtAddress setNumberOfLines:2];
    
    txtEmailid.text = [profileDataDict objectForKey:@"email"];
    txtName.text = [profileDataDict objectForKey:@"name"];
    
    [[NSUserDefaults standardUserDefaults] setObject:txtName.text forKey:kUserNameInMasterTable];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSString *imgURL=[profileDataDict objectForKey:@"user_image"];
    if(![imgURL isEqualToString:@""] && ![imgURL isEqualToString:nil]){
        [[NSUserDefaults standardUserDefaults] setValue:imgURL forKey:kUserImage];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [UIImage loadFromURL:[NSURL URLWithString:imgURL] callback:^(UIImage *image){
            profileImage.image = image;
        }];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"KuserImageChagedSuccess" object:@"imageChanged"];
    }
    else
    {
        
    }
    NSString *dateString = [profileDataDict objectForKey:@"birthday"];
    
    NSDateFormatter *dateFormatter = [DateHandler USDateFormatterWithDateFormat:@"yyyy-MM-dd"];
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString =  [dateFormatter dateFromString:dateString];
    
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] ){
        txtBirthDate.text=@"";
    }
    txtBirthDate.text = [DateHandler getDateFromString:dateString desireDateFormat:dateFormatStr dateFormatWeb:@""];
    
    if([dateString isEqualToString:@""])
        txtBirthDate.text=@"";
    
    //    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:@"dateFormat"];
    //    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
    //        dateFormatStr = @"dd/MM/yyyy";
    //    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //    [dateFormatter setDateFormat:dateFormatStr];
    //
    //    NSString *dateToBFormated = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate: [dateFormatter dateFromString:dateString]]];
    //    dateToBFormated = [dateToBFormated stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
    
    //    txtBirthDate.text = dateToBFormated;
    
    
    //    dateString = [dateFormatter dateFromString:dateFromString];
    //
    //    txtBirthDate.text = [DateHandler getDateStringFromDate:dateFromString desireDateFormat:dateFormatStr];
    
    
    [[NSUserDefaults standardUserDefaults] setValue:[profileDataDict objectForKey:@"mobile"] forKey:kUserMobileNumber];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    txtGender.text = [profileDataDict objectForKey:@"gender"];
    if ([txtGender.text isEqualToString:@"M"])
        txtGender.text = @"Male";
    else
        txtGender.text = @"Female";
    
    txtAddress.lineBreakMode=YES;
    txtAddress.numberOfLines=5;
    txtAddress.text = [profileDataDict objectForKey:@"address"];
    txtInstagram.text = [profileDataDict objectForKey:@"instagram"];
    txtLinked.text = [profileDataDict objectForKey:@"linkedin"];
    txtPhone.text = [profileDataDict objectForKey:@"phone"];
    txtTwitter.text = [profileDataDict objectForKey:@"twitter"];
    txtGoogle.text = [profileDataDict objectForKey:@"gplus"];
    txtFacebook.text = [profileDataDict objectForKey:@"facebook"];
    
    txtMobile.text = [[NSUserDefaults standardUserDefaults] valueForKey:kUserMobileNumber];
    txtPhone.text = [profileDataDict objectForKey:@"phone"];
    
    [[NSUserDefaults standardUserDefaults] setObject:[profileDataDict objectForKey:@"mobile"] forKey:kUserMobileNumber];
    [[NSUserDefaults standardUserDefaults] synchronize];
    txtSkype.text = [profileDataDict objectForKey:@"skype"];
    mainProfileDictData=[profileDataDict mutableCopy];
}

- (void) getUserProfileFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

+ (CAGradientLayer*) greyGradient {
    
    UIColor *colorOne = [UIColor colorWithWhite:0.9 alpha:1.0];
    UIColor *colorTwo = [UIColor colorWithHue:0.625 saturation:0.0 brightness:0.85 alpha:1.0];
    UIColor *colorThree     = [UIColor colorWithHue:0.625 saturation:0.0 brightness:0.7 alpha:1.0];
    UIColor *colorFour = [UIColor colorWithHue:0.625 saturation:0.0 brightness:0.4 alpha:1.0];
    
    NSArray *colors =  [NSArray arrayWithObjects:(id)colorOne.CGColor, colorTwo.CGColor, colorThree.CGColor, colorFour.CGColor, nil];
    
    NSNumber *stopOne = [NSNumber numberWithFloat:0.0];
    NSNumber *stopTwo = [NSNumber numberWithFloat:0.02];
    NSNumber *stopThree     = [NSNumber numberWithFloat:0.99];
    NSNumber *stopFour = [NSNumber numberWithFloat:1.0];
    
    NSArray *locations = [NSArray arrayWithObjects:stopOne, stopTwo, stopThree, stopFour, nil];
    CAGradientLayer *headerLayer = [CAGradientLayer layer];
    headerLayer.colors = colors;
    headerLayer.locations = locations;
    
    return headerLayer;
    
}

- (IBAction)btnPasswordCancelClicked:(id)sender {
    [popUpViewPassword setHidden:true];
    
}

- (IBAction)btnPasswordSaveClicked:(id)sender {
    if ([txtOldPassword isFirstResponder]) {
        [txtOldPassword resignFirstResponder];
    }
    else if ([txtNewPassword isFirstResponder]) {
        [txtNewPassword resignFirstResponder];
    }
    else if ([txtConfirmPassword isFirstResponder]) {
        [txtConfirmPassword resignFirstResponder];
    }
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    
    if([txtOldPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        
        [self.view makeToast:@"Please enter old password"];
        return ;
        
    }
    else if([txtNewPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0){
        
        [self.view makeToast:@"Please enter new password"];
        return ;
        
    }
    else if ([txtConfirmPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please enter confirm password"];
        return ;
    }
    else if(![txtConfirmPassword.text isEqualToString:txtNewPassword.text]){
        [self.view makeToast:@"Password should match with confirm passwor"];
        return ;
        
    }
    else if(txtConfirmPassword.text.length >= 6)
    {
        NSCharacterSet *upperlowerCaseChars = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLKMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"];
        
        NSCharacterSet *numbers = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        if ([txtConfirmPassword.text rangeOfCharacterFromSet:upperlowerCaseChars].location != NSNotFound &&  [txtConfirmPassword.text rangeOfCharacterFromSet:numbers].location != NSNotFound && txtConfirmPassword.text.length >=6  )
        {
            [self showProgressHud];
            
            NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:userid,@"userid",txtOldPassword.text,@"oldpassword",txtNewPassword.text,@"newpassword", nil];
            [[WebService sharedWebService] callChangePasswordWebService:dictionary];
        }
        else
        {
            [self.view makeToast:@"Password must be 6 character long and it must have a combination of letters and numbers for your security" duration:3 position:CSToastPositionBottom];
            return ;
            
        }
    }
}

- (void) changePasswordSuccess:(NSNotification *)notification{
    [self hideProgressHud];
    txtConfirmPassword.text=@"";
    txtNewPassword.text=@"";
    txtOldPassword.text=@"";
    NSLog(@"Data=%@",notification.object);
    NSDictionary *dictionary = notification.object;
    [popUpViewPassword setHidden:true];
    
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
}

- (void) changePasswordFailed:(NSNotification *)notification{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
    
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:[response objectForKey:@"message"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert show];
}

#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
@end
