//
//  PreferenceViewController.m
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import "YearViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
#import "DateHandler.h"
#import "MNAutoComplete.h"
#import "DayViewController.h"
#import "WeekViewExampleController.h"
#import "MonthViewController.h"
#import "TimelineViewController.h"
@interface PreferenceViewController ()<AutocompleteDelgate>
{
    NSString *isAdminAccess;
    NSString *date1Format;
    NSString *date2Format;
    NSString *date3Format;
    NSString *date4Format;
    NSString *date5Format;
    
    NSString *date1FormatToSend;
    NSString *date2FormatToSend;
    NSString *date3FormatToSend;
    NSString *date4FormatToSend;
    NSString *date5FormatToSend;
    MNAutoComplete *_autoComplete;
}

@end

@implementation PreferenceViewController


@synthesize btnBack;
@synthesize roundedBtnSave;

@synthesize scrollView;
@synthesize selectedDate;

@synthesize oldDictionary;

@synthesize lblDate;
@synthesize btnChangeDate;
@synthesize datePicker;

@synthesize pickerBackGroundView;
@synthesize btnBarCancel;
@synthesize btnBarDone;
@synthesize btnAdminAcessYes;
@synthesize btnAdminAcessNo;

@synthesize textFieldTimezone;
@synthesize textFieldTime;
@synthesize textFieldDateFormat;
@synthesize textFieldEventRSVPDate;
@synthesize textFieldEventColor;
@synthesize textFieldLocation;
@synthesize textFieldPrivacy;
@synthesize textFieldNotificationDeleteTime;
@synthesize textFieldCalenederView;
@synthesize textFieldAdditionalGuestLimit;
@synthesize textFieldRepeatingInstancesLimit;

@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize locationPopUpview;
@synthesize txtOtherLocation;
@synthesize locationIdArray;
@synthesize locationName;
@synthesize textFieldTimelineYearLimit;

-(void)viewDidLoad
{
    [self hideProgressHud];
    [self setTitle:@"Preferences"];
    //    int height = self.navigationController.navigationBar.frame.size.height;
    //    int width = self.navigationController.navigationBar.frame.size.width;
    //
    //    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    //    [navLabel setText:@"Preferences"];
    //    navLabel.textColor = [UIColor whiteColor];
    //    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    //    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    //    navLabel.textAlignment = NSTextAlignmentCenter;
    //    self.navigationItem.titleView = navLabel;
    
    CGFloat titleHeight = self.navigationController.navigationBar.frame.size.height;
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    
    // Set font for sizing width
    titleLabel.font = [UIFont boldSystemFontOfSize:20.f];
    
    CGFloat desiredWidth = [self.title sizeWithFont:titleLabel.font constrainedToSize:CGSizeMake([[UIScreen mainScreen] applicationFrame].size.width, titleLabel.frame.size.height) lineBreakMode:NSLineBreakByCharWrapping].width;
    
    CGRect frame;
    
    frame = titleLabel.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleLabel.frame = frame;
    
    frame = titleView.frame;
    frame.size.height = titleHeight;
    frame.size.width = desiredWidth;
    titleView.frame = frame;
    
    // Ensure text is on one line, centered and truncates if the bounds are restricted
    titleLabel.numberOfLines = 1;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    // Use autoresizing to restrict the bounds to the area that the titleview allows
    titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    titleView.autoresizesSubviews = YES;
    titleLabel.autoresizingMask = titleView.autoresizingMask;
    
    // Set the text
    titleLabel.text = self.title;
    titleLabel.textColor = [UIColor whiteColor];
    // Add as the nav bar's titleview
    [titleView addSubview:titleLabel];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    
    [self loadAutocompletandSearchTable];
    
    //    roundedBtnSave.layer.borderColor = [UIColor blackColor].CGColor;
    //    roundedBtnSave.layer.borderWidth = 2.0f;
    roundedBtnSave.clipsToBounds=YES;
    roundedBtnSave.layer.cornerRadius = 5;
    
    textFieldAdditionalGuestLimit.delegate = self;
    textFieldRepeatingInstancesLimit.delegate = self;
    
    locationPopUpview.hidden=true;
    //    locationPopUpview.layer.borderColor = [UIColor blackColor].CGColor;
    //    locationPopUpview.layer.borderWidth = 2.0f;
    
    
    locationPopUpview.layer.cornerRadius=8;
    locationPopUpview.clipsToBounds=YES;
    
    txtOtherLocation.delegate=self;
    textFieldTimezone.delegate = self;
    textFieldTime.delegate = self;
    textFieldDateFormat.delegate = self;
    textFieldEventRSVPDate.delegate = self;
    textFieldEventColor.delegate = self;
    textFieldLocation.delegate = self;
    textFieldPrivacy.delegate = self;
    textFieldNotificationDeleteTime.delegate = self;
    textFieldCalenederView.delegate = self;
    textFieldAdditionalGuestLimit.delegate = self;
    textFieldRepeatingInstancesLimit.delegate = self;
    textFieldTimelineYearLimit.delegate=self;
    
    textFieldTimezone.tag = 1;
    textFieldTime.tag = 2;
    textFieldDateFormat.tag = 3;
    textFieldEventRSVPDate.tag = 4;
    textFieldEventColor.tag = 5;
    textFieldLocation.tag = 6;
    textFieldPrivacy.tag = 7;
    textFieldNotificationDeleteTime.tag = 8;
    textFieldAdditionalGuestLimit.tag = 9;
    textFieldTimelineYearLimit.tag = 10;
    textFieldCalenederView.tag = 11;
    textFieldRepeatingInstancesLimit.tag = 12;
    txtOtherLocation.tag=13;
    
    //    [textFieldTimezone setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldTime setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldDateFormat setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldEventRSVPDate setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldEventColor setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldLocation setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldPrivacy setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldNotificationDeleteTime setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldCalenederView setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldAdditionalGuestLimit setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    //    [textFieldRepeatingInstancesLimit setValue:[UIColor colorWithRed:120.0/255.0 green:116.0/255.0 blue:115.0/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    
    [textFieldRepeatingInstancesLimit setReturnKeyType:UIReturnKeyDone];
    [txtOtherLocation setReturnKeyType:UIReturnKeyDone];
    
    customKeyboard = [[CustomKeyboard alloc] init];
    customKeyboard.delegate = self;
    
    UIToolbar *toolbar = [[UIToolbar alloc] init];
    [toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [toolbar sizeToFit];
    UIBarButtonItem *buttonflexible = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *buttonDone = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneClicked:)];
    
    locationName = [[NSMutableArray  alloc] init];
    locationIdArray = [[NSMutableArray alloc]init];
    
    isAdminAccess = @"No";
    
    date1FormatToSend= @"d/m/Y";
    date2FormatToSend = @"m/d/Y";
    date3FormatToSend = @"Y/m/d";
    date4FormatToSend = @"j M Y";
    date5FormatToSend = @"M j, Y";
    
    [toolbar setItems:[NSArray arrayWithObjects:buttonflexible,buttonDone, nil]];
    
    textFieldTimezone.inputAccessoryView = toolbar;
    textFieldTime.inputAccessoryView = toolbar;
    textFieldDateFormat.inputAccessoryView = toolbar;
    textFieldEventRSVPDate.inputAccessoryView = toolbar;
    textFieldEventColor.inputAccessoryView = toolbar;
    textFieldLocation.inputAccessoryView = toolbar;
    textFieldPrivacy.inputAccessoryView = toolbar;
    textFieldNotificationDeleteTime.inputAccessoryView = toolbar;
    textFieldCalenederView.inputAccessoryView = toolbar;
    
    oldDictionary = [[NSMutableDictionary alloc]init];
    
    
    //    textFieldTextPicker.isOptionalDropDown = NO;
    [textFieldTimezone setItemList:[NSArray arrayWithObjects:@"Australia/Currie",@"Australia/Perth",@"Australia/Eucla",@"Australia/Adelaide",@"Australia/Lindeman",@"Australia/Lord_Howe",@"Australia/Sydney",@"Australia/Brisbane",@"Australia/Hobart",@"Australia/Broken_Hill",@"Australia/Melbourne", nil]];
    
    [textFieldTimelineYearLimit setItemList:[NSArray arrayWithObjects:@"2015",@"2016",@"2017",@"2018",@"2019",@"2020",@"2021",@"2022",@"2023",@"2024",@"2025",@"2026",@"2027",@"2028",@"2029",@"2030",@"2031",@"2032",@"2033",@"2034",@"2035",@"2036",@"2037",@"2038",@"2039",@"2040",@"2041",@"2042",@"2043",@"2044",@"2045",@"2046",@"2047",@"2048",@"2049",@"2050",@"2051",@"2052",@"2053",@"2054",@"2055",@"2056",@"2057",@"2058",@"2059",@"2060",@"2061",@"2062",@"2063",@"2064",@"2065",@"2066",@"2067",@"2068",@"2069",@"2070",@"2071",@"2072",@"2073",@"2074",@"2075",@"2076",@"2077",@"2078",@"2079",@"2080",@"2081",@"2082",@"2083",@"2084", nil]];
    [textFieldTime setItemList:[NSArray arrayWithObjects:@"12 Hour",@"24 Hour", nil]];
    selectedDate = [NSDate date];
    date1Format = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:@"dd/MM/yyyy"];
    date2Format = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:@"MM/dd/yyyy"];
    date3Format = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:@"yyyy/MM/dd"];
    date4Format = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:@"dd MMMM yyyy"];
    date5Format = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:@"MMMM dd yyyy"];
    
    [textFieldDateFormat setItemList:[NSArray arrayWithObjects:date1Format,date2Format,date3Format,date4Format,date5Format, nil]];
    [textFieldEventRSVPDate setItemList:[NSArray arrayWithObjects:@"1 Day Prior",@"2 Days Prior",@"3 Days Prior",@"4 Days Prior",@"5 Days Prior",@"6 Days Prior",@"7 Days Prior", nil]];
    
    
    [textFieldEventColor setItemList:[NSArray arrayWithObjects:@"Black",@"White", nil]];
    [textFieldPrivacy setItemList:[NSArray arrayWithObjects:@"Myself and Anyone I Invite",@"Public", nil]];
    [textFieldNotificationDeleteTime setItemList:[NSArray arrayWithObjects:@"30 Days",@"20 Days",@"10 Days",@"5 Days",@"1 Day", nil]];
    [textFieldCalenederView setItemList:[NSArray arrayWithObjects:@"Timeline",@"Month",@"Week",@"Day", nil]];
    [textFieldLocation setItemList:[NSArray arrayWithObjects:@"None",@"Other",nil]];
    [datePicker setMaximumDate:[NSDate date]];
    
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1230)];
    }
    else{
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1300)];
    }
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updatePreferencesSuccess:) name:kUpdatePreferencesSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updatePreferencesFailed:) name:kUpdatePreferencesFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getLocationSuccess:) name:kGetLocationSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getLocationFailed:) name:kGetLocationFailed object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPreferencesSuccess:) name:kGetPrefSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getPreferencesFailed:) name:kGetPrefFailed object:nil];
    
    //    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    //
    //
    //
    //    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    //    [dataDictionary setObject:userid forKey:@"userid"];
    //    [self showProgressHud];
    //    [[WebService sharedWebService] callgetLocation:dataDictionary];
}
-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
-(void)textField:(IQDropDownTextField*)textField didSelectItem:(NSString*)item //Called when textField changes it's selected item.
{
    if(textField==textFieldEventColor)
    {
        if([item isEqualToString:@"Black"]){
            [textFieldEventColor setBackgroundColor:[UIColor blackColor]];
            [textFieldEventColor setTextColor:[UIColor whiteColor]];
        }
        else{
            [textFieldEventColor setBackgroundColor:[UIColor whiteColor]];
            [textFieldEventColor setTextColor:[UIColor blackColor]];
        }
    }
    if(textField==textFieldDateFormat)
    {
        if([textField.text isEqualToString:date1Format]){
            date1FormatToSend = @"d/m/Y";
            [[NSUserDefaults standardUserDefaults] setValue:@"dd/MM/yyyy" forKey:KDateFormat];
        }
        else if ([textField.text isEqualToString:date2Format]){
            date2FormatToSend = @"m/d/Y";
            [[NSUserDefaults standardUserDefaults] setValue:@"MM/dd/yyyy" forKey:KDateFormat];
        }
        else if ([textField.text isEqualToString:date3Format]){
            date3FormatToSend = @"Y/m/d";
            [[NSUserDefaults standardUserDefaults] setValue:@"yyyy/MM/dd" forKey:KDateFormat];
        }
        else if ([textField.text isEqualToString:date4Format]){
            date4FormatToSend = @"j M Y";
            [[NSUserDefaults standardUserDefaults] setValue:@"dd MMMM yyyy" forKey:KDateFormat];
        }
        else if ([textField.text isEqualToString:date5Format]){
            date5FormatToSend = @"M j, Y";
            [[NSUserDefaults standardUserDefaults] setValue:@"MMMM dd yyyy" forKey:KDateFormat];
        }
        
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    if([item isEqualToString:@"Other"] && textFieldLocation ==textField)
    {
        [self.searchTableController toggleHidden:YES];
        
        locationPopUpview.hidden=false;
        locationPopUpview.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
        
        [UIView animateWithDuration:0.3/1.5 animations:^{
            locationPopUpview.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.3/2 animations:^{
                locationPopUpview.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.3/2 animations:^{
                    locationPopUpview.transform = CGAffineTransformIdentity;
                }];
            }];
        }];
    }
    else if (![item isEqualToString:@"None"] && ![item isEqualToString:@"Other"] && textFieldLocation ==textField)
    {
        locationPopUpview.hidden=true;
        
        [self.searchTableController toggleHidden:YES];
    }
    if([item isEqualToString:@"None"] && textFieldLocation ==textField)
    {
        [self.searchTableController toggleHidden:YES];
        [txtOtherLocation resignFirstResponder];
        locationPopUpview.hidden=true;
        txtOtherLocation.text=@"";
    }
}


-(void)doneClicked:(UIBarButtonItem*)button
{
    [self.view endEditing:YES];
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    selectedDate = [NSDate date];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    [dataDictionary setObject:userid forKey:@"userid"];
    [self showProgressHud];
    [[WebService sharedWebService] callgetPrefWebService:dataDictionary];
}

#pragma mark AutoCompletePlace

-(void)loadAutocompletandSearchTable{
    _autoComplete = [[MNAutoComplete alloc] initWithDelegate:self];
    self.searchTableController = [[SearchViewController alloc] initWithStyle:UITableViewStylePlain];
    //    self.searchTableController.tableView.frame = CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height);
    self.searchTableController.tableView.frame = CGRectMake(txtOtherLocation.frame.origin.x+20,txtOtherLocation.frame.origin.y+260, txtOtherLocation.frame.size.width,pickerBackGroundView.frame.size.height);
    self.searchTableController.view.layer.zPosition = 100;
    
    self.searchTableController.delegate = self;
    [self.view addSubview:self.searchTableController.tableView];
    [self.searchTableController toggleHidden:YES];
    
    self.searchTableController.tableView.layer.borderWidth = 2;
    self.searchTableController.tableView.layer.borderColor = [[UIColor blackColor] CGColor];
    
}
-(NSArray *)getSearchHistory{
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"SEARCH_HISTORY"];
}

#pragma mark - Search Delegate
-(void)didSelectSearchedString:(NSString *)selectedString{
    NSLog(@"SELECTED %@",selectedString);
    txtOtherLocation.text=selectedString;
    textFieldLocation.text = selectedString;
    [self.searchTableController toggleHidden:YES];
    locationPopUpview.hidden=true;
}

#pragma mark - Autocomplete Delegate
- (void)autocompleteDidReturn:(NSArray *)results {
    NSLog(@"results %@",results);
    [self.searchTableController reloadDataWithSource:results];
}

-(void)autocompleteDidFailWithError:(NSError *)error{
    
}
#pragma mark - Search Text Field

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    [textField resignFirstResponder];
    
    return YES;
}// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if(textField.text.length>=2 && txtOtherLocation==textField)
    {
        [self.searchTableController toggleHidden:NO];
        [_autoComplete startWithKeyword:textField.text];
        
    }
    if (textField.text.length<=1 && txtOtherLocation==textField) {
        [self.searchTableController toggleHidden:YES];
    }
    else if(textField ==textFieldAdditionalGuestLimit)
    {
        NSUInteger oldLength = [textField.text length];
        NSUInteger replacementLength = [string length];
        NSUInteger rangeLength = range.length;
        
        NSUInteger newLength = oldLength - rangeLength + replacementLength;
        
        BOOL returnKey = [string rangeOfString: @"\n"].location != NSNotFound;
        
        return newLength <= 3 || returnKey;
    }
    else if(textField ==textFieldRepeatingInstancesLimit)
    {
        NSUInteger oldLength = [textField.text length];
        NSUInteger replacementLength = [string length];
        NSUInteger rangeLength = range.length;
        
        NSUInteger newLength = oldLength - rangeLength + replacementLength;
        
        BOOL returnKey = [string rangeOfString: @"\n"].location != NSNotFound;
        
        return newLength <= 3 || returnKey;
    }
    return true;
    
    return YES;
}// return NO to not change text

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    BOOL showPrev = textField.tag != 1;
    BOOL showNext = textField.tag != 14;
    
    [textField setInputAccessoryView:[customKeyboard getToolbarWithPrevNextDone:showPrev :showNext]];
    customKeyboard.currentSelectedTextboxIndex = textField.tag;
    if(textField==txtOtherLocation){
        [textField setInputAccessoryView:[customKeyboard getToolbarWithDone]];
    }
}
- (void)nextClicked:(NSUInteger)sender {
    
    switch (sender){
        case 1: {
            [textFieldTimezone resignFirstResponder];
            [textFieldTime becomeFirstResponder];
        }
            break;
        case 2: {
            [textFieldTime resignFirstResponder];
            [textFieldDateFormat becomeFirstResponder];
        }
            break;
        case 3: {
            [textFieldDateFormat resignFirstResponder];
            [textFieldEventRSVPDate becomeFirstResponder];
        }
            break;
        case 4: {
            [textFieldEventRSVPDate resignFirstResponder];
            [textFieldEventColor becomeFirstResponder];
        }
            break;
        case 5: {
            [textFieldEventColor resignFirstResponder];
            [textFieldLocation becomeFirstResponder];
        }
            break;
        case 6: {
            locationPopUpview.hidden=true;
            [textFieldLocation resignFirstResponder];
            [textFieldPrivacy becomeFirstResponder];
        }
            break;
        case 7: {
            [textFieldPrivacy resignFirstResponder];
            [textFieldNotificationDeleteTime becomeFirstResponder];
        }
            break;
        case 8: {
            [textFieldNotificationDeleteTime resignFirstResponder];
            [textFieldAdditionalGuestLimit becomeFirstResponder];
        }
            break;
        case 9: {
            [textFieldAdditionalGuestLimit resignFirstResponder];
            [textFieldTimelineYearLimit becomeFirstResponder];
        }
            break;
        case 10: {
            [textFieldTimelineYearLimit resignFirstResponder];
            [textFieldCalenederView becomeFirstResponder];
        }
            break;
        case 11: {
            [textFieldCalenederView resignFirstResponder];
            [textFieldRepeatingInstancesLimit becomeFirstResponder];
        }
        case 12: {
            [textFieldRepeatingInstancesLimit resignFirstResponder];
        }
            break;
            
            
        default: {
        }
            break;
    }
}

- (void)previousClicked:(NSUInteger)sender {
    
    switch (sender){
        case 1: {
            [textFieldTimezone resignFirstResponder];
            
            [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        }
            break;
        case 2: {
            [textFieldTimezone becomeFirstResponder];
            [textFieldTime resignFirstResponder];
            
        }
            break;
        case 3: {
            [textFieldTime becomeFirstResponder];
            [textFieldDateFormat resignFirstResponder];
            
        }
            break;
            
        case 4: {
            [textFieldDateFormat becomeFirstResponder];
            [textFieldEventRSVPDate resignFirstResponder];
        }
            break;
            
        case 5: {
            [textFieldEventRSVPDate becomeFirstResponder];
            [textFieldEventColor resignFirstResponder];
            
        }
            break;
            
        case 6: {
            [textFieldEventColor becomeFirstResponder];
            [textFieldLocation resignFirstResponder];
            
        }
            break;
            
        case 7: {
            [textFieldLocation becomeFirstResponder];
            [textFieldPrivacy resignFirstResponder];
            
        }
            break;
            
        case 8: {
            [textFieldPrivacy becomeFirstResponder];
            [textFieldNotificationDeleteTime resignFirstResponder];
            
        }
            break;
            
        case 9: {
            [textFieldNotificationDeleteTime becomeFirstResponder];
            [textFieldAdditionalGuestLimit resignFirstResponder];
        }
            break;
            
        case 10: {
            [textFieldAdditionalGuestLimit becomeFirstResponder];
            [textFieldTimelineYearLimit resignFirstResponder];
            
        }
            break;
            
        case 11: {
            [textFieldTimelineYearLimit becomeFirstResponder];
            [textFieldCalenederView resignFirstResponder];
        }
            break;
        case 12: {
            [textFieldCalenederView becomeFirstResponder];
            [textFieldRepeatingInstancesLimit resignFirstResponder];
        }
            break;
        default: {
        }
            break;
    }
}

- (void)resignResponder:(NSUInteger)sender {
    [self.view endEditing:YES];
    switch (sender){
        case 1: {
            if ([textFieldTimezone isFirstResponder]) {
                [textFieldTimezone resignFirstResponder];
            }
        }
            break;
        case 2: {
            if ([textFieldTime isFirstResponder]) {
                [textFieldTime resignFirstResponder];
            }
        }
            break;
        case 3: {
            if ([textFieldDateFormat isFirstResponder]) {
                [textFieldDateFormat resignFirstResponder];
            }
        }
            break;
        case 4: {
            if ([textFieldEventRSVPDate isFirstResponder]) {
                [textFieldEventRSVPDate resignFirstResponder];
            }
        }
            break;
        case 5: {
            locationPopUpview.hidden=true;
            
            if ([textFieldEventColor isFirstResponder]) {
                [textFieldEventColor resignFirstResponder];
            }
        }
            break;
        case 6: {
            if ([textFieldLocation isFirstResponder]) {
                [textFieldLocation resignFirstResponder];
            }
        }
            break;
        case 7: {
            locationPopUpview.hidden=true;
            
            if ([textFieldPrivacy isFirstResponder]) {
                [textFieldPrivacy resignFirstResponder];
            }
        }
            break;
        case 8: {
            
            if ([textFieldNotificationDeleteTime isFirstResponder]) {
                [textFieldNotificationDeleteTime resignFirstResponder];
            }
        }
            break;
        case 9: {
            if ([textFieldAdditionalGuestLimit isFirstResponder]) {
                [textFieldAdditionalGuestLimit resignFirstResponder];
            }
        }
            break;
        case 10: {
            if ([textFieldTimelineYearLimit isFirstResponder]) {
                [textFieldTimelineYearLimit resignFirstResponder];
            }
        }
            break;
        case 11: {
            if ([textFieldCalenederView isFirstResponder]) {
                [textFieldCalenederView resignFirstResponder];
            }
        }
            break;
        case 12: {
            if ([textFieldRepeatingInstancesLimit isFirstResponder]) {
                [textFieldRepeatingInstancesLimit resignFirstResponder];
            }
        }
            break;
        case 13: {
            if ([txtOtherLocation isFirstResponder]) {
                [txtOtherLocation resignFirstResponder];
                
                locationPopUpview.hidden=true;
                [self.searchTableController toggleHidden:YES];
            }
        }
            break;
            
        default: {
        }
            break;
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBackClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btnSaveClicked:(id)sender{
    locationPopUpview.hidden=true;
    if ([textFieldTimezone isFirstResponder]) {
        [textFieldTimezone resignFirstResponder];
    }
    else if ([textFieldTime isFirstResponder]) {
        [textFieldTime resignFirstResponder];
    }
    else if ([textFieldDateFormat isFirstResponder]) {
        [textFieldDateFormat resignFirstResponder];
    }
    else if ([textFieldEventRSVPDate isFirstResponder]) {
        [textFieldEventRSVPDate resignFirstResponder];
    }
    else if ([textFieldEventColor isFirstResponder]) {
        [textFieldEventColor resignFirstResponder];
    }
    else if ([textFieldLocation isFirstResponder]) {
        [textFieldLocation resignFirstResponder];
    }
    else if ([textFieldPrivacy isFirstResponder]) {
        [textFieldPrivacy resignFirstResponder];
    }
    
    else if ([textFieldNotificationDeleteTime isFirstResponder]) {
        [textFieldNotificationDeleteTime resignFirstResponder];
    }
    else if ([textFieldCalenederView isFirstResponder]) {
        [textFieldCalenederView resignFirstResponder];
    }
    else if ([textFieldRepeatingInstancesLimit isFirstResponder]) {
        [textFieldRepeatingInstancesLimit resignFirstResponder];
    }
    else if ([textFieldAdditionalGuestLimit isFirstResponder]) {
        [textFieldRepeatingInstancesLimit resignFirstResponder];
    }
    else if ([textFieldTimelineYearLimit isFirstResponder]) {
        [textFieldTimelineYearLimit resignFirstResponder];
    }
    else if ([txtOtherLocation isFirstResponder]) {
        [txtOtherLocation resignFirstResponder];
        
        locationPopUpview.hidden=true;
        [self.searchTableController toggleHidden:YES];
    }
    
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    
    NSString *strTextFieldEventColor = textFieldEventColor.text;
    if([strTextFieldEventColor isEqualToString:@"White"]){
        strTextFieldEventColor =@"FFFFFF";
        [[NSUserDefaults standardUserDefaults] setValue:@"#FFFFFF" forKey:kTimeLineColor];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    else if([strTextFieldEventColor isEqualToString:@"Black"]){
        strTextFieldEventColor =@"000000";
        [[NSUserDefaults standardUserDefaults] setValue:@"#000000" forKey:kTimeLineColor];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    strTextFieldEventColor = [strTextFieldEventColor stringByReplacingOccurrencesOfString:@"#" withString:@""];
    
    if([strTextFieldEventColor isEqualToString:@""]){
        [self.view makeToast:@"Please select color"];
        return;
    }
    
    [dataDictionary setObject:strTextFieldEventColor forKey:@"default_color_event"];
    
    [dataDictionary setObject:userid forKey:@"userid"];
    
    if([textFieldAdditionalGuestLimit.text isEqualToString:@""]){
        [self.view makeToast:@"Please enter guest limit"];
        return;
    }
    
    [dataDictionary setObject:textFieldAdditionalGuestLimit.text forKey:@"default_guest_limit"];
    
    if([textFieldRepeatingInstancesLimit.text isEqualToString:@""]){
        [self.view makeToast:@"Please enter timeline repeat limit"];
        return;
    }
    [dataDictionary setObject:textFieldRepeatingInstancesLimit.text forKey:@"timeline_repeating_limit"];
    
    NSString *strTextFieldTime = textFieldTime.text;
    
    if([strTextFieldTime isEqualToString:@"12 Hour"])
        strTextFieldTime = @"12";
    else if([strTextFieldTime isEqualToString:@"24 Hour"])
        strTextFieldTime = @"24";
    [dataDictionary setObject:strTextFieldTime forKey:@"default_time_format"];
    
    if([strTextFieldTime isEqualToString:@""]){
        [self.view makeToast:@"Please select time format"];
        return;
    }
    if([textFieldTimezone.text isEqualToString:@""])
    {
        [self.view makeToast:@"Please select time zone"];
        return;
    }
    [dataDictionary setObject:textFieldTimezone.text forKey:@"default_time_zone"];
    NSString *strDateFormat = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    
    
    NSString *strTextFieldDateFormat = textFieldDateFormat.text;
    if([strTextFieldDateFormat isEqualToString:@""] || strTextFieldDateFormat.length<=0 || [strTextFieldDateFormat stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0)
    {
        [self.view makeToast:@"Please select date format"];
        return;
    }
    
    if([strDateFormat isEqualToString:@"dd/MM/yyyy"]){
        strTextFieldDateFormat=date1FormatToSend;
    }
    else if ([strDateFormat isEqualToString:@"MM/dd/yyyy"]){
        strTextFieldDateFormat=date2FormatToSend;
    }
    else if ([strDateFormat isEqualToString:@"yyyy/MM/dd"]){
        strTextFieldDateFormat=date3FormatToSend;
    }
    else if ([strDateFormat isEqualToString:@"dd MMMM yyyy"]){
        strTextFieldDateFormat=date4FormatToSend;
    }
    else if ([strDateFormat isEqualToString:@"MMMM dd yyyy"]){
        strTextFieldDateFormat=date5FormatToSend;
    }
    
    //    if([strTextFieldDateFormat isEqualToString:date1FormatToSend] || [strTextFieldDateFormat isEqualToString:date2FormatToSend]|| [strTextFieldDateFormat isEqualToString:date3FormatToSend]|| [strTextFieldDateFormat isEqualToString:date2FormatToSend]|| [strTextFieldDateFormat isEqualToString:date2FormatToSend]){
    //        [self.view makeToast:@"Please select date format"];
    //        return;
    //    }
    [dataDictionary setObject:strTextFieldDateFormat forKey:@"default_date_format"];
    
    NSString *strTextFieldLocation = textFieldLocation.text;
    
    if(txtOtherLocation.text.length>0 && ![txtOtherLocation.text isEqualToString:@""])
    {
        NSString *otherLocation = txtOtherLocation.text;
        otherLocation = [otherLocation stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        [dataDictionary setObject:otherLocation forKey:@"location_other"];
        [dataDictionary setObject:@"" forKey:@"default_location"];
    }
    
    else
    {
        [dataDictionary setObject:@"" forKey:@"location_other"];
        
        [dataDictionary setObject:strTextFieldLocation forKey:@"default_location"];
    }
    if ([strTextFieldLocation isEqualToString:@"None"])
    {
        strTextFieldLocation=@"none";
    }
    if([strTextFieldLocation isEqualToString:@""]){
        [self.view makeToast:@"Please select location"];
        return;
    }
    if([strTextFieldLocation isEqualToString:@"Other"] && txtOtherLocation.text.length==0){
        [self.view makeToast:@"Please enter other location"];
        return;
    }
    
    
    NSString *strTextFieldPrivacy = textFieldPrivacy.text;
    
    if([strTextFieldPrivacy isEqualToString:@"Public"])
        strTextFieldPrivacy =@"public";
    if([strTextFieldPrivacy isEqualToString:@"Myself and Anyone I Invite"])
        strTextFieldPrivacy =@"invite";
    [dataDictionary setObject:strTextFieldPrivacy forKey:@"default_access"];
    
    if([strTextFieldPrivacy isEqualToString:@""]){
        [self.view makeToast:@"Please select privacy"];
        return;
    }
    NSString *strTextFieldEventRSVPDate = textFieldEventRSVPDate.text;
    
    if([strTextFieldEventRSVPDate isEqualToString:@"1 Day Prior"])
        strTextFieldEventRSVPDate = @"1";
    else if([strTextFieldEventRSVPDate isEqualToString:@"2 Days Prior"])
        strTextFieldEventRSVPDate = @"2";
    else if([strTextFieldEventRSVPDate isEqualToString:@"3 Days Prior"])
        strTextFieldEventRSVPDate = @"3";
    else if([strTextFieldEventRSVPDate isEqualToString:@"4 Days Prior"])
        strTextFieldEventRSVPDate = @"4";
    else if([strTextFieldEventRSVPDate isEqualToString:@"5 Days Prior"])
        strTextFieldEventRSVPDate = @"5";
    else if([strTextFieldEventRSVPDate isEqualToString:@"6 Days Prior"])
        strTextFieldEventRSVPDate = @"6";
    else if([strTextFieldEventRSVPDate isEqualToString:@"7 Days Prior"])
        strTextFieldEventRSVPDate = @"7";
    if([strTextFieldEventRSVPDate isEqualToString:@""]){
        [self.view makeToast:@"Please select RSVP date"];
        return;
    }
    [dataDictionary setObject:strTextFieldEventRSVPDate forKey:@"default_rsvp_date"];
    
    NSString *strTextFieldNotificationDeleteTime = textFieldNotificationDeleteTime.text;
    
    if([strTextFieldNotificationDeleteTime isEqualToString:@"30 Days"])
        strTextFieldNotificationDeleteTime = @"30";
    else if([strTextFieldNotificationDeleteTime isEqualToString:@"20 Days"])
        strTextFieldNotificationDeleteTime = @"20";
    else if([strTextFieldNotificationDeleteTime isEqualToString:@"10 Days"])
        strTextFieldNotificationDeleteTime = @"10";
    else if([strTextFieldNotificationDeleteTime isEqualToString:@"5 Days"])
        strTextFieldNotificationDeleteTime = @"5";
    else if([strTextFieldNotificationDeleteTime isEqualToString:@"1 Days"])
        strTextFieldNotificationDeleteTime = @"1";
    if([strTextFieldNotificationDeleteTime isEqualToString:@""]){
        [self.view makeToast:@"Please select notification delete time"];
        return;
    }
    [dataDictionary setObject:strTextFieldNotificationDeleteTime forKey:@"default_del_notification"];
    
    if([textFieldTimelineYearLimit.text isEqualToString:@""]){
        [self.view makeToast:@"Please select timeine year limit"];
        return;
    }
    
    [dataDictionary setObject:textFieldTimelineYearLimit.text forKey:@"timeline_future_year_limit"];
    
    NSString *strTextFieldCalenederView = textFieldCalenederView.text;
    if([strTextFieldCalenederView isEqualToString:@""]){
        [self.view makeToast:@"Please select calendar view"];
        return;
    }
    else{
        
    }
    if([strTextFieldCalenederView  isEqualToString:@"Month"]){
        strTextFieldCalenederView =@"month";
    }
    else if([strTextFieldCalenederView isEqualToString:@"Timeline"]){
        strTextFieldCalenederView = @"timeline";
    }
    else if([strTextFieldCalenederView isEqualToString:@"Week"]){
        strTextFieldCalenederView = @"week";
    }
    else if([strTextFieldCalenederView isEqualToString:@"Day"]){
        strTextFieldCalenederView = @"day";
    }
    
    
    
    
    [dataDictionary setObject:strTextFieldCalenederView forKey:@"default_calendar"];
    
    NSString *strTextFieldRepeatingInstancesLimit = textFieldRepeatingInstancesLimit.text;
    [dataDictionary setObject:strTextFieldRepeatingInstancesLimit forKey:@"timeline_repeating_limit"];
    if([isAdminAccess isEqualToString:@"Yes"])
        isAdminAccess=@"yes";
    else if ([isAdminAccess isEqualToString:@"No"])
        isAdminAccess=@"no";
    [dataDictionary setObject:isAdminAccess forKey:@"account_access_admin"];
    
    [[NSUserDefaults standardUserDefaults] setObject:strTextFieldEventRSVPDate forKey:kEventRSVPPriorTime];
    [[NSUserDefaults standardUserDefaults] setObject:strTextFieldTime forKey:KTimeFormat];
    [self showProgressHud];
    [[WebService sharedWebService] callUpdatePreferencesWebService:dataDictionary];
}

- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (BOOL)textFieldShouldReturn:(UITextField* )textField{
    
    if(textField == textFieldTimezone){
        [textFieldTimezone resignFirstResponder];
        [textFieldTime becomeFirstResponder];
    }
    else if(textField == textFieldTime){
        [textFieldTime resignFirstResponder];
        [textFieldDateFormat becomeFirstResponder];
    }
    else if(textField == textFieldDateFormat){
        [textFieldDateFormat resignFirstResponder];
        [textFieldEventRSVPDate becomeFirstResponder];
    }
    else if(textField == textFieldEventRSVPDate){
        [textFieldEventRSVPDate resignFirstResponder];
        [textFieldEventColor becomeFirstResponder];
    }
    else if(textField == textFieldEventColor){
        [textFieldEventColor resignFirstResponder];
        [textFieldLocation becomeFirstResponder];
    }
    else if(textField == textFieldLocation){
        [textFieldLocation resignFirstResponder];
        [textFieldPrivacy becomeFirstResponder];
    }
    else if(textField == textFieldPrivacy){
        [textFieldPrivacy resignFirstResponder];
        [textFieldNotificationDeleteTime becomeFirstResponder];
    }
    else if(textField == textFieldNotificationDeleteTime){
        [textFieldNotificationDeleteTime resignFirstResponder];
        [textFieldAdditionalGuestLimit becomeFirstResponder];
    }
    else if(textField == textFieldAdditionalGuestLimit){
        [textFieldAdditionalGuestLimit resignFirstResponder];
        [textFieldCalenederView becomeFirstResponder];
    }
    else if(textField == textFieldCalenederView){
        [textFieldCalenederView resignFirstResponder];
        [textFieldRepeatingInstancesLimit becomeFirstResponder];
    }
    else if (textField==txtOtherLocation)
    {
        [self.searchTableController toggleHidden:YES];
        [txtOtherLocation resignFirstResponder];
        
        locationPopUpview.hidden=true;
        [self.searchTableController toggleHidden:YES];
        
    }
    else if(textField == textFieldRepeatingInstancesLimit){
        [textFieldRepeatingInstancesLimit resignFirstResponder];
        //        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,0,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == textFieldRepeatingInstancesLimit){
        [textFieldRepeatingInstancesLimit resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField* )textField{
    
    if(textField==textFieldEventColor){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,textFieldTime.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    else if (textField==txtOtherLocation)
    {
        NSArray *sourceArray = [NSMutableArray arrayWithArray:[self getSearchHistory]];
        [self.searchTableController reloadDataWithSource:sourceArray];
        
        NSLog(@"search history %@",sourceArray);
        
        return YES;
    }
    else if(textField == textFieldLocation){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,textFieldEventRSVPDate.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == textFieldPrivacy){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,textFieldEventRSVPDate.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == textFieldNotificationDeleteTime){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,textFieldEventColor.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == textFieldCalenederView){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,textFieldLocation.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == textFieldAdditionalGuestLimit){
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,textFieldPrivacy.frame.origin.y,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    else if(textField == textFieldRepeatingInstancesLimit){
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,1200)];
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.origin.x,textFieldRepeatingInstancesLimit.frame.origin.y+30,scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
    }
    
    return YES;
}

- (IBAction)cancelButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}
- (IBAction)doneButtonClicked:(id)sender{
    selectedDate = [datePicker date];
    NSString *dateFormatStr = [[NSUserDefaults standardUserDefaults] valueForKey:KDateFormat];
    if([dateFormatStr isEqualToString:@""] || dateFormatStr==nil)
        dateFormatStr = @"dd/MM/yyyy";
    lblDate.text = [DateHandler getDateStringFromDate:selectedDate desireDateFormat:dateFormatStr];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone){
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,800, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    else{
        [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,1200, pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    }
    [UIView commitAnimations];
}

- (IBAction)changeDateButtonClicked:(id)sender{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [pickerBackGroundView setFrame:CGRectMake(pickerBackGroundView.frame.origin.x,self.view.frame.size.height-(pickerBackGroundView.frame.size.height+49), pickerBackGroundView.frame.size.width,pickerBackGroundView.frame.size.height)];
    [UIView commitAnimations];
}

- (IBAction)toggleRadioButton:(id)sender
{
    if([sender tag] == 101){
        isAdminAccess = @"No";
        
        [btnAdminAcessNo setBackgroundImage:nil forState:UIControlStateNormal];
        [btnAdminAcessYes setBackgroundImage:nil forState:UIControlStateNormal];
        
        [btnAdminAcessNo setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
        [btnAdminAcessYes setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    }
    else{
        isAdminAccess = @"Yes";
        [btnAdminAcessYes setBackgroundImage:nil forState:UIControlStateNormal];
        [btnAdminAcessNo setBackgroundImage:nil forState:UIControlStateNormal];
        
        [btnAdminAcessYes setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
        [btnAdminAcessNo setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    }
}


//hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}
#pragma mark -
#pragma mark - WebService
#pragma mark -
- (void) getPreferencesSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    
    NSDictionary *preferenceDict = [dictionary objectForKey:@"data"];
    oldDictionary = [preferenceDict valueForKey:@"preference"];
    
    NSString *timezone = [oldDictionary valueForKey:@"default_time_zone"];
    
    textFieldTimezone.text =timezone;
    [textFieldTimezone setSelectedItem:textFieldTimezone.text];
    
    
    textFieldTime.text = [NSString stringWithFormat:@"%@",[oldDictionary valueForKey:@"default_time_format"]];
    if([textFieldTime.text isEqualToString:@"12"])
        textFieldTime.text = @"12 Hour";
    else if ([textFieldTime.text isEqualToString:@"24"])
        textFieldTime.text = @"24 Hour";
    
    [textFieldTime setSelectedItem:textFieldTime.text];
    
    textFieldDateFormat.text = [oldDictionary valueForKey:@"default_date_format"] ;
    
    strFromWebDateFormat = [preferenceDict valueForKey:@"default_date_format"] ;
    
    NSString *localdate1FormatToSend= @"d-m-Y";
    NSString *localdate2FormatToSend = @"m-d-Y";
    NSString *localdate3FormatToSend = @"Y-m-d";
    NSString *localdate4FormatToSend = @"j M Y";
    NSString *localdate5FormatToSend = @"M j, Y";
    
    NSString *localdate1FormatToSendReceive= @"d/m/Y";
    NSString *localdate2FormatToSendReceive = @"m/d/Y";
    NSString *localdate3FormatToSendReceive = @"Y/m/d";
    if([textFieldDateFormat.text  isEqualToString:date1FormatToSend] || [textFieldDateFormat.text  isEqualToString:localdate1FormatToSend] || [textFieldDateFormat.text  isEqualToString:localdate1FormatToSendReceive] )
        textFieldDateFormat.text=date1Format;
    else if ([textFieldDateFormat.text  isEqualToString:date2FormatToSend]|| [textFieldDateFormat.text  isEqualToString:localdate2FormatToSend] || [textFieldDateFormat.text  isEqualToString:localdate2FormatToSendReceive])
        textFieldDateFormat.text=date2Format;
    else if ([textFieldDateFormat.text  isEqualToString:date3FormatToSend]|| [textFieldDateFormat.text  isEqualToString:localdate3FormatToSend]|| [textFieldDateFormat.text  isEqualToString:localdate3FormatToSendReceive])
        textFieldDateFormat.text=date3Format;
    else if ([textFieldDateFormat.text  isEqualToString:date4FormatToSend]|| [textFieldDateFormat.text  isEqualToString:localdate4FormatToSend])
        textFieldDateFormat.text=date4Format;
    else if ([textFieldDateFormat.text  isEqualToString:date5FormatToSend]|| [textFieldDateFormat.text  isEqualToString:localdate5FormatToSend])
        textFieldDateFormat.text=date5Format;
    
    [textFieldDateFormat setSelectedItem:textFieldDateFormat.text];
    
    
    textFieldPrivacy.text = [oldDictionary valueForKey:@"default_access"];
    if([textFieldPrivacy.text isEqualToString:@"public"])
        textFieldPrivacy.text =@"Public";
    if([textFieldPrivacy.text isEqualToString:@"invite"])
        textFieldPrivacy.text =@"Myself and Anyone I Invite";
    if([textFieldPrivacy.text isEqualToString:@"private"])
        textFieldPrivacy.text =@"Myself and Anyone I Invite";
    [textFieldPrivacy setSelectedItem:textFieldPrivacy.text];
    
    
    NSString *txtTextFieldEventColor = [oldDictionary valueForKey:@"default_color_event"];
    textFieldEventColor.text = txtTextFieldEventColor;
    if([txtTextFieldEventColor isEqualToString:@"#000000"])
        txtTextFieldEventColor =@"Black";
    else if([txtTextFieldEventColor isEqualToString:@"#FFFFFF"])
        txtTextFieldEventColor =@"White";
    else
        txtTextFieldEventColor =@"White";
    
    if([txtTextFieldEventColor isEqualToString:@"Black"]){
        [textFieldEventColor setBackgroundColor:[UIColor blackColor]];
        [textFieldEventColor setTextColor:[UIColor whiteColor]];
    }
    else{
        [textFieldEventColor setBackgroundColor:[UIColor whiteColor]];
        [textFieldEventColor setTextColor:[UIColor blackColor]];
    }
    textFieldEventColor.text =txtTextFieldEventColor;
    
    [textFieldEventColor setSelectedItem:textFieldEventColor.text];
    
    
    textFieldEventRSVPDate.text = [oldDictionary valueForKey:@"default_rsvp_date"];
    
    if([textFieldEventRSVPDate.text isEqualToString:@"1"])
        textFieldEventRSVPDate.text = @"1 Day Prior";
    else if([textFieldEventRSVPDate.text isEqualToString:@"2"])
        textFieldEventRSVPDate.text = @"2 Days Prior";
    else if([textFieldEventRSVPDate.text isEqualToString:@"3"])
        textFieldEventRSVPDate.text = @"3 Days Prior";
    else if([textFieldEventRSVPDate.text isEqualToString:@"4"])
        textFieldEventRSVPDate.text = @"4 Days Prior";
    else if([textFieldEventRSVPDate.text isEqualToString:@"5"])
        textFieldEventRSVPDate.text = @"5 Days Prior";
    else if([textFieldEventRSVPDate.text isEqualToString:@"6"])
        textFieldEventRSVPDate.text = @"6 Days Prior";
    else if([textFieldEventRSVPDate.text isEqualToString:@"7"])
        textFieldEventRSVPDate.text = @"7 Days Prior";
    else
        textFieldEventRSVPDate.text=@"1 Day Prior";
    
    [textFieldEventRSVPDate setSelectedItem:textFieldEventRSVPDate.text];
    
    NSString *timeLineStr;
    id timeLineLimit = [oldDictionary valueForKey:@"timeline_future_year_limit"];
    if (timeLineLimit == [NSNull null]) {
        timeLineStr = @"2017";
    }
    if(timeLineStr.length==0)
        timeLineStr =@"2017";
    [textFieldTimelineYearLimit setSelectedItem:timeLineStr];
    
    if ([timeLineStr isEqualToString:@"none"]){
        timeLineStr = @"None";
        [textFieldLocation setSelectedItem:@"None"];
    }
    textFieldTimelineYearLimit.text = timeLineStr;
    textFieldNotificationDeleteTime.text = [NSString stringWithFormat:@"%@",[oldDictionary valueForKey:@"default_del_notification"]];
    if([textFieldNotificationDeleteTime.text isEqualToString:@"30"])
        textFieldNotificationDeleteTime.text = @"30 Days";
    else if([textFieldNotificationDeleteTime.text isEqualToString:@"20"])
        textFieldNotificationDeleteTime.text = @"20 Days";
    else if([textFieldNotificationDeleteTime.text isEqualToString:@"10"])
        textFieldNotificationDeleteTime.text = @"10 Days";
    else if([textFieldNotificationDeleteTime.text isEqualToString:@"5"])
        textFieldNotificationDeleteTime.text = @"5 Days";
    else if([textFieldNotificationDeleteTime.text isEqualToString:@"1"])
        textFieldNotificationDeleteTime.text = @"1 Day";
    
    [textFieldNotificationDeleteTime setSelectedItem:textFieldNotificationDeleteTime.text];
    
    textFieldCalenederView.text = [oldDictionary valueForKey:@"default_calendar"];
    
    if([textFieldCalenederView.text  isEqualToString:@"month"])
        textFieldCalenederView.text =@"Month";
    else if([textFieldCalenederView.text isEqualToString:@"timeline"])
        textFieldCalenederView.text = @"Timeline";
    else if([textFieldCalenederView.text isEqualToString:@"week"])
        textFieldCalenederView.text = @"Week";
    else if([textFieldCalenederView.text isEqualToString:@"day"])
        textFieldCalenederView.text = @"Day";
    [textFieldCalenederView setSelectedItem:textFieldCalenederView.text];
    
    
    textFieldAdditionalGuestLimit.text = [NSString stringWithFormat:@"%@",[oldDictionary valueForKey:@"default_guest_limit"]];
    if([textFieldAdditionalGuestLimit.text isEqualToString:@"<null>"])
        textFieldAdditionalGuestLimit.text =@"10";
    
    textFieldRepeatingInstancesLimit.text =[NSString stringWithFormat:@"%@",[oldDictionary valueForKey:@"timeline_repeating_limit"]];
    if([textFieldRepeatingInstancesLimit.text isEqualToString:@"<null>"])
        textFieldRepeatingInstancesLimit.text =@"10";
    id object = [oldDictionary valueForKey:@"account_access_admin"];
    if (object == [NSNull null]){
        isAdminAccess=@"no";
    }
    else{
        isAdminAccess = [oldDictionary valueForKey:@"account_access_admin"];
    }
    if([isAdminAccess isEqualToString:@"yes"])
        isAdminAccess=@"Yes";
    else if ([isAdminAccess isEqualToString:@"no"])
        isAdminAccess=@"No";
    
    if([isAdminAccess isEqualToString:@"No"]){
        
        [btnAdminAcessNo setBackgroundImage:nil forState:UIControlStateNormal];
        [btnAdminAcessYes setBackgroundImage:nil forState:UIControlStateNormal];
        
        [btnAdminAcessNo setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
        [btnAdminAcessYes setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    }
    else{
        [btnAdminAcessYes setBackgroundImage:nil forState:UIControlStateNormal];
        [btnAdminAcessNo setBackgroundImage:nil forState:UIControlStateNormal];
        
        [btnAdminAcessYes setBackgroundImage:[UIImage imageNamed:@"radiobutton_on"] forState:UIControlStateNormal];
        [btnAdminAcessNo setBackgroundImage:[UIImage imageNamed:@"radiobutton_off"] forState:UIControlStateNormal];
    }
    
    textFieldLocation.text = [oldDictionary valueForKey:@"default_location"];
    NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    [dataDictionary setObject:userid forKey:@"userid"];
    [self showProgressHud];
    [[WebService sharedWebService] callgetLocation:dataDictionary];
    
}

- (void) getPreferencesFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) updatePreferencesSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}
- (void)updatePreferencesFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}

- (void) getLocationSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    
    if(locationIdArray.count>0)
        return;
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    NSDictionary *locationsDict = [dictionary objectForKey:@"data"];
    NSArray *locationArray = [locationsDict valueForKey:@"location"];
    if(locationArray.count==0)
    {
        [textFieldLocation setItemList:[NSArray arrayWithObjects:@"None",@"Other",nil]];
        textFieldLocation.text=@"None";
        [textFieldLocation setSelectedItem:@"None"];
        return;
    }
    
    for (int i=0; i<locationArray.count; i++) {
        NSString *strLocationName = [[[locationArray objectAtIndex:i] valueForKey:@"loc_name"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSString *strLocationId = [[locationArray objectAtIndex:i] valueForKey:@"id"];
        if([strLocationId isEqualToString:@"none"])
            continue;
        
        [locationIdArray addObject:strLocationId];
        [locationName addObject:strLocationName];
    }
    
    NSArray *firstArray = [NSArray arrayWithObjects:@"None",@"Other",nil];
    NSArray  *secondArray = [locationName copy];
    
    
    NSString *textFieldLocationIdIs=textFieldLocation.text;
    
    for (int i=0; i<locationIdArray.count; i++) {
        NSString *strLocationId = [locationIdArray objectAtIndex:i];
        if([strLocationId isEqualToString:textFieldLocationIdIs]){
            textFieldLocation.text = [[locationName objectAtIndex:i] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            break;
        }
    }
    if ([textFieldLocation.text isEqualToString:@"none"]){
        textFieldLocation.text = @"None";
        [textFieldLocation setSelectedItem:@"None"];
    }
    
    NSArray  *newArray=[firstArray arrayByAddingObjectsFromArray:secondArray];
    [textFieldLocation setItemList:newArray];
    [textFieldLocation setSelectedItem:textFieldLocation.text];
}

- (void)getLocationFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        [self.view makeToast:[response objectForKey:@"message"]];
    }
}
//hide keyboard
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.searchTableController toggleHidden:YES];
    
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}

- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}
@end
