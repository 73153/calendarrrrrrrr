//
//  PreferenceViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 02/5/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "IQDropDownTextField.h"
#import "CustomKeyboard.h"
#import "SearchViewController.h"

@interface PreferenceViewController : UIViewController<UITabBarDelegate,UITextFieldDelegate,CustomKeyboardDelegate,IQDropDownTextFieldDelegate,SearchDelegate>
{
    CustomKeyboard *customKeyboard;
    NSString  *strFromWebDateFormat;
}
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIView *locationPopUpview;
@property (weak, nonatomic) IBOutlet UITextField *txtOtherLocation;
@property (nonatomic, strong) SearchViewController *searchTableController;


@property (nonatomic, strong) IBOutlet UIButton *btnBack;
@property (nonatomic, strong) IBOutlet UIButton *roundedBtnSave;

@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) NSDate *selectedDate;
@property (nonatomic, strong) NSMutableDictionary *oldDictionary;
@property (nonatomic, strong) NSMutableArray *locationIdArray;
@property (nonatomic, strong) NSMutableArray *locationName;

@property (nonatomic, strong) IBOutlet UIView *pickerBackGroundView;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarCancel;
@property (nonatomic, strong) IBOutlet UIBarButtonItem *btnBarDone;
@property (nonatomic, strong) IBOutlet UILabel  *lblDate;
@property (nonatomic, strong) IBOutlet UIButton *btnChangeDate;
@property (nonatomic, strong) IBOutlet UIDatePicker *datePicker;

@property (nonatomic, strong) IBOutlet UIButton *btnAdminAcessYes;
@property (nonatomic, strong) IBOutlet UIButton *btnAdminAcessNo;

@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldTimezone;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldTimelineYearLimit;

@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldTime;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldDateFormat;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldEventRSVPDate;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldEventColor;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldLocation;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldPrivacy;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldNotificationDeleteTime;
@property (nonatomic, strong) IBOutlet IQDropDownTextField *textFieldCalenederView;
@property (nonatomic, strong) IBOutlet UITextField *textFieldAdditionalGuestLimit;
@property (nonatomic, strong) IBOutlet UITextField *textFieldRepeatingInstancesLimit;

- (IBAction)toggleRadioButton:(id)sender;
-(void)textField:(IQDropDownTextField*)textField didSelectItem:(NSString*)item; //Called when textField changes it's selected item.


- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnSaveClicked:(id)sender;
- (IBAction)tabBarButtonsPressed:(id)sender;

- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)doneButtonClicked:(id)sender;
- (IBAction)changeDateButtonClicked:(id)sender;
- (void) showProgressHud;
- (void) hideProgressHud;

-(void)updatePreferencesFailed:(NSNotification *)notification;
-(void)updatePreferencesSuccess:(NSNotification *)notification;
-(void)insertPreferencesSuccess:(NSNotification *)notification;
-(void)insertPreferencesFailed:(NSNotification *)notification;
-(void)getPreferencesSuccess:(NSNotification *)notification;
-(void)getPreferencesFailed:(NSNotification *)notification;

-(void)getLocationSuccess:(NSNotification *)notification;
-(void)getLocationFailed:(NSNotification *)notification;

@end
