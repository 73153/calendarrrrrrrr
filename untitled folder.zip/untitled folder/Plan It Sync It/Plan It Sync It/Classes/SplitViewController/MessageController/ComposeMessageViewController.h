//
//  ComposeMessageViewController.h
//  Plan It Sync It
//
//  Created by Vivek on 18/3/15.
//  Copyright (c) 2015 Vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "Countries.h"
#import "SWTableViewCell.h"
#import "CustomKeyboard.h"

@interface ComposeMessageViewController : UIViewController<UITabBarDelegate,CustomKeyboardDelegate,UITextFieldDelegate,UITextViewDelegate>
{
    CustomKeyboard *customKeyboard;
}
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;

@property (weak, nonatomic) IBOutlet UIButton *btnTabBarHome;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarNotification;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarToDo;
@property (weak, nonatomic) IBOutlet UIButton *btnTabBarMessage;
@property (weak, nonatomic) IBOutlet UIButton *roundedBtnSendMessage;

@property (weak, nonatomic) IBOutlet UITextField *txtTo;
@property (weak, nonatomic) IBOutlet UITextField *txtSubject;
@property (weak, nonatomic) IBOutlet UITextView *txtMessage;
- (IBAction)btnSendMessagePressed:(id)sender;
- (IBAction)tabBarButtonsPressed:(id)sender;
- (IBAction)btnBackClicked:(id)sender;
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView;

- (void) showProgressHud;
- (void) hideProgressHud;
@end
