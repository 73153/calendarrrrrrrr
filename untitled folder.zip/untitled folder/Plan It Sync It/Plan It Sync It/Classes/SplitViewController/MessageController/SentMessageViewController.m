//
//  SentMessageViewController.m
//  Plan it Sync it
//
//  Created by Vivek on 15-4-30.
//  Copyright (c) 2015 Apple. All rights reserved.
//

#import "SentMessageViewController.h"
#import "YearViewController.h"
#import "ProfileViewController.h"
#import "PreferenceViewController.h"
#import "ContactsViewController.h"
#import "InboxMessageViewController.h"
#import "LoginViewController.h"
#import "MBProgressHUD.h"
#import "SentMessageViewController.h"
#import "UINavigationItem+BarButtonGrouping.h"
#import "SWTableViewCell.h"
#import "UMTableViewCell.h"
#import "SentMessageViewController.h"
#import "TrashMessageViewController.h"
#import "ComposeMessageViewController.h"
#import "ToDoViewController.h"
#import "NotificationViewController.h"
#import "KxMenu.h"
#import "MessageDetalViewController.h"
#import "WebService.h"
#import "AppConstant.h"
#import "UIView+Toast.h"
@interface SentMessageViewController ()


@end

@implementation SentMessageViewController
@synthesize tableView;
@synthesize  selectedContacts;
@synthesize totalIndaxPath;
@synthesize  emailIdArray;
@synthesize nameArray;
@synthesize deletedContactArray;
@synthesize searchedEmailArray;
@synthesize viewSelectAllAndDelete;
@synthesize selectedData;
@synthesize selectedRows;
@synthesize mSearchBar;
@synthesize toolBar_EditAndDelete;
@synthesize searchedNameArray;
@synthesize btnSelectAll;
@synthesize labelNoRecordFound;
@synthesize btnTabBarHome;
@synthesize btnTabBarNotification;
@synthesize btnTabBarToDo;
@synthesize btnTabBarMessage;
@synthesize roundedBtnComposeMessage;
- (void)viewDidLoad
{
    [super viewDidLoad];
    //init data
    self.selectedRows = [NSMutableArray array];
    tableView.dataSource=self;
    tableView.delegate=self;
    mSearchBar.delegate= self;
    [self setTitle:@"Sent"];
    int height = self.navigationController.navigationBar.frame.size.height;
    int width = self.navigationController.navigationBar.frame.size.width;
    
    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    [navLabel setText:@"Sent Messages"];
    navLabel.textColor = [UIColor whiteColor];
    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    navLabel.font = [UIFont fontWithName:@"OpenSans-Semibold" size:20];
    navLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = navLabel;
    labelNoRecordFound.hidden=true;
    self.tableView.rowHeight = 80;
//    roundedBtnComposeMessage.layer.borderColor = [UIColor blackColor].CGColor;
//    roundedBtnComposeMessage.layer.borderWidth = 2.0f;
    roundedBtnComposeMessage.clipsToBounds=YES;
    roundedBtnComposeMessage.layer.cornerRadius = 5;
    UIButton * btnInbox = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnInbox.frame = CGRectMake(0, 0, 100,100);
    //    _btn3.imageEdgeInsets = UIEdgeInsetsMake(10, 100, 10, 100);
    [btnInbox setTitle:@"Sent" forState:UIControlStateNormal];
    [btnInbox addTarget:self action:@selector(showMenuItem:) forControlEvents:UIControlEventTouchUpInside];
    toolBar_EditAndDelete.hidden = true;
    // Initialize Refresh Control
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    
    // Configure Refresh Control
    [refreshControl addTarget:self action:@selector(toggleCells:) forControlEvents:UIControlEventValueChanged];
    refreshControl.tintColor = [UIColor blueColor];
    
    // Configure View Controller
    [self.tableView addSubview:refreshControl];
    self.refreshControl = refreshControl;
    self.useCustomCells = NO;
    totalIndaxPath = [NSMutableArray array];
    
    
    barButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btnInbox];
    self.navigationItem.rightBarButtonItem = barButtonItem;
    // Do any additional setup after loading the view, typically from a nib.
    selectedContacts = [NSMutableArray array];
    emailIdArray=[[NSMutableArray alloc]initWithObjects:
                  @"Ashish@gmail.com",
                  @"Vivek@gmail.com",
                  @"Kunjan@gmail.com",
                  @"Ahmed@gmail.com",
                  @"Bhupat@gmail.com",
                  @"Preyas@gmail.com",
                  @"Tejas@gmail.com",
                  @"Nipul@gmail.com",
                  @"Pravin@gmail.com",
                  @"Minal@gmail.com",
                  @"Salman@gmail.com",
                  nil];
    nameArray = [[NSMutableArray alloc]initWithObjects:
                 @"Ashish Soni",
                 @"Vivek Sharma",
                 @"kunjan Shah",
                 @"Ahmed",
                 @"Bhupat Bheda",
                 @"Preyas Rana",
                 @"Tejas",
                 @"Nipul Bhogayta",
                 @"Pravin",
                 @"Minal Chauhan",
                 @"Salman",
                 nil];
    isSelectAllPressed=false;
    isSearchAndDelete=false;
    searchedEmailArray = emailIdArray;
    searchedNameArray=nameArray;
    NSInteger tabButtonClickInt = [[NSUserDefaults standardUserDefaults] integerForKey:@"BlueTabNumber"];
    switch (tabButtonClickInt) {
        case 1:
            [btnTabBarHome setImage:[UIImage imageNamed:@"home_active.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [btnTabBarNotification setImage:[UIImage imageNamed:@"notification_active.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [btnTabBarToDo setImage:[UIImage imageNamed:@"todo_active.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [btnTabBarMessage setImage:[UIImage imageNamed:@"contact_active_TabBar.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfSentMessagesSuccess:) name:kGetListOfSentMessagesSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getListOfSentMessagesFailed:) name:kGetListOfSentMessagesFailed object:nil];
    
    NSString *userid = [[NSUserDefaults standardUserDefaults] objectForKey:kUserId];
    if (userid!=nil) {
        NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
        [dataDictionary setObject:userid forKey:@"userid"];
        [dataDictionary setObject:@"" forKey:@"search"];
        [dataDictionary setObject:@"0" forKey:@"limit_start"];
        [dataDictionary setObject:@"30" forKey:@"limit_end"];
        
        [self showProgressHud];
        [[WebService sharedWebService] callGetListOfSentMessagesWebService:dataDictionary];
    }
}

-(void)viewDidUnload
{
    [self hideProgressHud];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - dataSource method
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return searchedEmailArray.count;
}
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"UMCell";
    UMTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    if(emailIdArray.count>0)
        labelNoRecordFound.hidden=true;
    NSString *currentText;
    //Search And Without Search data
    if(isSearchAndDelete==true){
        currentText = cell.label.text = searchedEmailArray[indexPath.row];
        cell.label1.text=[searchedNameArray objectAtIndex:indexPath.row];
        
    }
    else{
        currentText = cell.label.text = emailIdArray[indexPath.row];
        cell.label1.text=[nameArray objectAtIndex:indexPath.row];
    }
    cell.label.lineBreakMode=YES;
    cell.label1.lineBreakMode=YES;
    
    cell.userImage.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    [cell.userImage setImage:[UIImage imageNamed:@"profile.png"]];
    cell.userImage.layer.masksToBounds = YES;
    cell.userImage.layer.cornerRadius = 5.0;
    cell.userImage.layer.borderColor = [UIColor whiteColor].CGColor;
    cell.userImage.layer.borderWidth = 1.0f;
    cell.userImage.clipsToBounds = YES;
    // Set the checked state for the contact selection checkbox
    UIImage *image;
    
    if ([selectedContacts containsObject:currentText]) {
        image = [UIImage imageNamed:@"check_on.png"];
    } else  {
        image = [UIImage imageNamed:@"check_off.png"];
    }
    
    [cell.checkBoxButton setImage:image forState:UIControlStateNormal];
    [cell.checkBoxButton addTarget:self action:@selector(checkButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:70.0f];
    [cell setBackgroundColor:[UIColor clearColor]];
    
    CAGradientLayer *grad = [CAGradientLayer layer];
    grad.frame = CGRectMake(0,0,480,80);
    grad.colors = [NSArray arrayWithObjects:(id)[[UIColor whiteColor] CGColor], (id)[[UIColor greenColor] CGColor], nil];
    grad.cornerRadius = 5.0;
    
    [cell setBackgroundView:[[UIView alloc] init]];
    [cell.backgroundView.layer insertSublayer:grad atIndex:0];

    
    if (cell==Nil) {
        cell = [[UMTableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    //    [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:70.0f];
    cell.delegate = self;
    
    return cell;
    
}

- (void)checkButtonTapped:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:buttonPosition];
    if (indexPath != nil)
    {
        if(isSearchAndDelete==true || isSelectAllPressed==true)
            return;
        NSString *currentText = emailIdArray[indexPath.row];
        
        //new method
        if ([selectedContacts containsObject:currentText]) {
            [selectedContacts removeObject:currentText];
            [self.selectedRows removeObject:indexPath];
            mSearchBar.hidden=false;
            toolBar_EditAndDelete.hidden=true;
        } else {
            mSearchBar.hidden=true;
            toolBar_EditAndDelete.hidden=false;
            
            [selectedContacts addObject:currentText];
            [self.selectedRows addObject:indexPath];
        }
    }
    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    
}

#pragma mark - delegate method
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    MessageDetalViewController* controller = (MessageDetalViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"messageDetalViewController"];
    [self.navigationController pushViewController:controller animated:YES];
    
}

- (IBAction)delRow:(id)sender {
    
    [tableView reloadRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.4];
    [emailIdArray removeObjectsInArray:selectedContacts];
    
    [tableView deleteRowsAtIndexPaths:self.selectedRows withRowAnimation:UITableViewRowAnimationAutomatic];
    [UIView commitAnimations];
    [selectedContacts removeAllObjects];
    [self.selectedRows removeAllObjects];
    mSearchBar.hidden=false;
    toolBar_EditAndDelete.hidden=true;
    if(emailIdArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }

}

- (IBAction)editRows:(id)sender {
    BOOL edit = tableView.editing;
    [tableView setEditing:!edit animated:YES];
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if(isSearchAndDelete==true || isSelectAllPressed==true)
        return;
    if ([self.selectedRows containsObject:indexPath]) {
        [self.selectedRows removeObject:indexPath];
        [selectedContacts removeObject:emailIdArray[indexPath.row]];
    }
    
    [emailIdArray removeObject:emailIdArray[indexPath.row]];
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    NSLog(@"delete");
    
    [tableView setEditing:NO animated:YES];
    if(emailIdArray.count<=0){
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        labelNoRecordFound.hidden=false;
    }

}



- (IBAction)selectAll:(id)sender {
    [self showProgressHud];

    if(isSelectAllPressed==false){
        isSelectAllPressed=true;
        btnSelectAll.title = @"Un Select All";
        [selectedContacts removeAllObjects];
        [selectedRows removeAllObjects];
        [emailIdArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            NSString *currentText = emailIdArray[idx];
            [selectedContacts addObject:currentText];
            [selectedRows addObject:[NSIndexPath indexPathForRow:idx inSection:0]];
        }];
        [tableView reloadData];
    }
    else
    {
        isSelectAllPressed=false;
        btnSelectAll.title = @"Select All";
        toolBar_EditAndDelete.hidden=true;
        mSearchBar.hidden=false;
        isSearchAndDelete=false;

        [selectedContacts removeAllObjects];
        [selectedRows removeAllObjects];
        [tableView reloadData];
    }
    [self hideProgressHud];
}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UIRefreshControl Selector

- (void)toggleCells:(UIRefreshControl*)refreshControl
{
    [refreshControl beginRefreshing];
    self.useCustomCells = !self.useCustomCells;
    if (self.useCustomCells)
    {
        self.refreshControl.tintColor = [UIColor redColor];
    }
    else
    {
        self.refreshControl.tintColor = [UIColor blueColor];
    }
    [self.tableView reloadData];
    [refreshControl endRefreshing];
}
//hide keyboard
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}


#pragma mark -
#pragma mark - tabBarButtonsPressed
#pragma mark -
- (IBAction)tabBarButtonsPressed:(id)sender {
    
    NSInteger tag = [sender tag];
    NSLog(@"Tag is your choice：%ld",[sender tag]);
    
    if (tag == 1) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 2)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:3 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
        
        //        navigationController.viewControllers = @[homeViewController];
    }
    else if (tag == 4)
    {
        [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"BlueTabNumber"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        //        [[NSUserDefaults standardUserDefaults] setInteger:5 forKey:@"BlueTabNumber"];
        //        [[NSUserDefaults standardUserDefaults] synchronize];
        [self.frostedViewController presentMenuViewController];
        
        //        InboxMessageViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        //        navigationController.viewControllers = @[secondViewController];
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

- (IBAction)btnComoseMessageClicked:(id)sender {
    ComposeMessageViewController* controller = (ComposeMessageViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"composeMessageViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - Search Functionality

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    isSearchAndDelete=true;
    [mSearchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    [mSearchBar setShowsCancelButton:NO animated:YES];
    searchBar.text=@"";
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchText.length>0) {
        searchText = [searchText stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSLog(@"its pincode");
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat: @"SELF CONTAINS[cd] %@", searchText ];
        
        searchedEmailArray = [emailIdArray filteredArrayUsingPredicate:predicate];
        
        
        NSPredicate *predicate1 = [NSPredicate predicateWithFormat: @"SELF CONTAINS[cd] %@", searchText ];
        
        searchedNameArray = [nameArray filteredArrayUsingPredicate:predicate1];
        [tableView reloadData];
    }
    else
    {
        searchedEmailArray=emailIdArray;
        searchedNameArray=nameArray;
        
        [tableView reloadData];
    }
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    isSearchAndDelete=false;
    
    [mSearchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    isSearchAndDelete=false;
    [mSearchBar resignFirstResponder];
    searchedEmailArray=emailIdArray;
    [tableView reloadData];
}


- (void)showMenuItem:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      [KxMenuItem menuItem:@"Inbox"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      
      [KxMenuItem menuItem:@"Sent"
                     image:nil
                    target:nil
                    action:NULL],
      [KxMenuItem menuItem:@"Trash"
                     image:nil
                    target:self
                    action:@selector(pushMenuItem:)],
      ];
    
    KxMenuItem *first = menuItems[1];
    first.foreColor = [UIColor colorWithRed:47/255.0f green:112/255.0f blue:225/255.0f alpha:1.0];
    first.alignment = NSTextAlignmentCenter;
    
    [KxMenu showMenuInView:self.view
                  fromRect:sender.frame
                 menuItems:menuItems];
}

- (void) pushMenuItem:(id)sender
{
    NSLog(@"%@", sender);
    
    if([[sender title] isEqual:@"Inbox"]){
        InboxMessageViewController* controller = (InboxMessageViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"inboxMessageController"];
        [self.navigationController pushViewController:controller animated:YES];
        
    }
    else if([[sender title]isEqual:@"Trash"])
    {
        TrashMessageViewController* controller = (TrashMessageViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"trashMessageController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
}

#pragma mark - WebService
#pragma mark -
- (void) getListOfSentMessagesSuccess:(NSNotification *)notification
{
    [self hideProgressHud];
    NSDictionary *dictionary = notification.object;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    
    NSString *strMessageResponse = [response objectForKey:@"message"];
    
    if(strMessageResponse.length >=15)
    {
        [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
    }
    else{
        NSString *strMessageResponse = [response objectForKey:@"message"];
        
        if(strMessageResponse.length >=15)
        {
            [self.view makeToast:strMessageResponse duration:3.4 position:CSToastPositionBottom];
        }
        else{
            [self.view makeToast:[response objectForKey:@"message"]];
        }
    }
}

- (void) getListOfSentMessagesFailed:(NSNotification *)notification
{
    [self hideProgressHud];
    NSDictionary *dictionary = notification.object;
    if(dictionary.count<=0)
        return;
    NSDictionary *response = [dictionary objectForKey:@"meta"];
    [self.view makeToast:[response objectForKey:@"message"]];
}
#pragma mark -
#pragma mark - ProgressHud
#pragma mark -
- (void) showProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *progressHUD = [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [progressHUD setLabelText:@"Please wait"];
    });
    
}
- (void) hideProgressHud
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:self.view animated:NO];
    });
}

#pragma mark UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger tag = item.tag;
    NSLog(@"Tag is your choice：%ld",(long)tag);
    
    if (tag == 1) {
        if(self.navigationController.viewControllers.count>0){
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
        else{
            YearViewController *homeViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"yearViewController"];
            [self.navigationController pushViewController:homeViewController animated:YES];
        }
    }
    else if (tag == 2)
    {
        NotificationViewController *secondViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
        [self.navigationController pushViewController:secondViewController animated:YES];
    }
    else if (tag == 3)
    {
        ToDoViewController* controller = (ToDoViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"toDoViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 4)
    {
        ContactsViewController* controller = (ContactsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"contactsViewController"];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (tag == 5)
    {
        [self.frostedViewController presentMenuViewController];
        
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


#pragma mark - SWTableViewDelegate

- (void)swipeableTableViewCell:(SWTableViewCell *)cell scrollingToState:(SWCellState)state
{
    switch (state) {
        case 0:
            NSLog(@"utility buttons closed");
            break;
        case 1:
            NSLog(@"left utility buttons open");
            break;
        case 2:
            NSLog(@"right utility buttons open");
            break;
        default:
            break;
    }
}

- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerLeftUtilityButtonWithIndex:(NSInteger)index
{
    switch (index) {
        case 0:
            NSLog(@"left button 0 was pressed");
            break;
        case 1:
            NSLog(@"left button 1 was pressed");
            break;
        case 2:
            NSLog(@"left button 2 was pressed");
            break;
        case 3:
            NSLog(@"left btton 3 was pressed");
        default:
            break;
    }
}


- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerRightUtilityButtonWithIndex:(NSInteger)index
{
    switch (index) {
        case 0:
        {
            [cell hideUtilityButtonsAnimated:YES];
            if(isSearchAndDelete==true || isSelectAllPressed==true)
                return;
            // Delete button was pressed
            NSIndexPath *cellIndexPath = [tableView indexPathForCell:cell];
            [tableView reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            if(selectedContacts.count>0&&selectedRows.count>0){
                NSString *emailText = emailIdArray[cellIndexPath.row];
                
                [selectedContacts removeObject:emailText];
                [self.selectedRows removeObject:cellIndexPath];
            }
            [emailIdArray removeObject:emailIdArray[cellIndexPath.row]];
            [nameArray removeObject:nameArray[cellIndexPath.row]];
            [tableView deleteRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            NSLog(@"delete");
            
            [tableView setEditing:NO animated:YES];
            if(emailIdArray.count<=0){
                [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
                labelNoRecordFound.hidden=false;
            }
     
        }
            
        default:
            break;
    }
    [tableView reloadData];
    
}

- (BOOL)swipeableTableViewCellShouldHideUtilityButtonsOnSwipe:(SWTableViewCell *)cell
{
    // allow just one cell's utility button to be open at once
    return YES;
}

- (BOOL)swipeableTableViewCell:(SWTableViewCell *)cell canSwipeToState:(SWCellState)state
{
    switch (state) {
        case 1:
            // set to NO to disable all left utility buttons appearings
            return YES;
            break;
        case 2:
            // set to NO to disable all right utility buttons appearing
            return YES;
            break;
        default:
            break;
    }
    
    return YES;
}

- (NSArray *)rightButtons
{
    NSMutableArray *rightUtilityButtons = [NSMutableArray new];
    
    [rightUtilityButtons sw_addUtilityButtonWithColor:
     [UIColor colorWithRed:1.0f green:0.231f blue:0.188 alpha:1.0f]
                                                title:@"Delete"];
    
    return rightUtilityButtons;
}



@end
